<?php


if(!defined('_index_noinit')) {
define('_indexroot', './');
require _indexroot."require/load.php";
}


require _indexroot."require/functions-template.php";



$notpublic_form = false;
$notpublic_form_wholesite = false;
$found = true;

$url = parse_url(_url.'/');
if(false === $url || !isset($url['path'])) $base_path = '/';
else $base_path = $url['path'];


if(!empty($_POST) && !_xsrfCheck()) {


$output = '';
require _indexroot.'require/xsrfscreen.php';
$output = _xsrfAutoProtect($output);
define('_indexOutput_title', $_lang['xsrf.title']);
define('_indexOutput_content', $output);

} elseif(_publicAccess(!_notpublicsite) or (isset($_GET['m']) and in_array($_GET['m'], array("login", "reg", "lostpass")))) {


if(isset($_GET['m'])) {
$mid = strval($_GET['m']);
if(_loginindicator or !in_array($mid, array("settings", "editpost", "messages"))) {


$ok = true;
$nologin = false;
$custom = false;
$file = null;
switch($mid) {


case "login":
define('_indexOutput_title', $_lang['login.title']);
break;


case "ulist":
if(_ulist) define('_indexOutput_title', $_lang['admin.users.list']);
else $ok = false;
break;


case "reg":
if(_registration and !_loginindicator) define('_indexOutput_title', $_lang['mod.reg']);
else {
$ok = false;
$nologin = true;
}
break;


case "lostpass":
if(_lostpass and !_loginindicator) define('_indexOutput_title', $_lang['mod.lostpass']);
else {
$ok = false;
$nologin = true;
}
break;


case "profile":
define('_indexOutput_title', $_lang['mod.profile']);
break;


case "profile-arts":
define('_indexOutput_title', $_lang['mod.profile.arts']);
break;


case "profile-posts":
define('_indexOutput_title', $_lang['mod.profile.posts']);
break;


case "settings":
define('_indexOutput_title', $_lang['mod.settings']);
break;


case "editpost":
define('_indexOutput_title', $_lang['mod.editpost']);
break;


case "locktopic":
define('_indexOutput_title', $_lang['mod.locktopic']);
break;


case "stickytopic":
define('_indexOutput_title', $_lang['mod.stickytopic']);
break;


case "movetopic":
define('_indexOutput_title', $_lang['mod.movetopic']);
break;


case "messages":
if(_messages) define('_indexOutput_title', $_lang['mod.messages']);
else $ok = false;
break;


case "search":
if(_search) define('_indexOutput_title', $_lang['mod.search']);
else $ok = false;
break;


case "topic":

break;


default:

$title = null;
_extend('call', 'mod.custom.'.$mid, array('file' => &$file, 'title' => &$title));
if(isset($file, $title)) {

$custom = true;
define('_indexOutput_title', $title);
} else $ok = false;
break;

}


if($ok) {


$module = '';
define('_indexOutput_ptype', 'module');
define('_indexOutput_pid', $mid);
if($mid !== 'topic') define('_indexOutput_url', "index.php?m=".$mid);


$extend_args = _extendArgs($module, array('mid' => $mid, 'custom' => &$custom, 'file' => &$file));
_extend('call', 'mod.'.$mid.'.pre', $extend_args);


require $custom ? $file : _indexroot.'require/mod/'.$mid.'.php';
_extend('call', 'mod.'.$mid.'.post', $extend_args);


$module = _xsrfAutoProtect($module);


define('_indexOutput_content', $module);

} elseif($nologin) {

define('_indexOutput_title', $_lang['nologin.title']);
define('_indexOutput_content', (_template_autoheadings ? "<h1>"._indexOutput_title."</h1>" : '')._formMessage(1, $_lang['nologin.msg']));

}

} else {
$notpublic_form = true;
}
}

else {










function _tmp_indexFetchPageData($title_seo, $types = null, $extra_cols = null, $extra_joins = null, $extra_conds = null)
{

$title_seo_multi = is_array($title_seo);


$sql = "SELECT page.*,inter.id AS inter_id,inter.title_seo AS inter_title_seo, inter.public AS inter_public,inter.level AS inter_level,inter.var2 AS inter_var2";
if(null !== $extra_cols) $sql .= ','.$extra_cols;
$sql .= " FROM `"._mysql_prefix."-root` AS page LEFT JOIN `"._mysql_prefix."-root` AS inter ON(page.intersection=inter.id)";
if(null !== $extra_joins) $sql .= ' '.$extra_joins;

$conds = array();
if(null !== $title_seo) {
if($title_seo_multi) $conds[] = 'page.`title_seo` IN('.DB::arr($title_seo).')';
else $conds[] = 'page.`title_seo`='.DB::val($title_seo);
}
if(null !== $types) $conds[] = ' page.type IN('.implode(',', $types).')';
if(null !== $extra_conds) $conds[] = '('.$extra_conds.')';
if(!empty($conds)) $sql .= ' WHERE '.implode(' AND ', $conds);


$query = DB::query($sql);
$pages = array();
while($row = DB::row($query)) {
$pages[$row['title_seo']] = $row;
}


if($title_seo_multi) {

for($i = 0; isset($title_seo[$i]); ++$i) {
if(isset($pages[$title_seo[$i]])) {
return $pages[$title_seo[$i]];
}
}
} else {
return current($pages);
}
return false;

}






function _tmp_indexContentIds($idt)
{
$idt = strval($idt);
$idt_arr = array();
$idt_size = 0;

$segment = '';
$slash = true;
for($i = 0, $last = (strlen($idt) - 1); isset($idt[$i]); ++$i) {

$char = $idt[$i];
if('/' === $char) {
if($slash || $last === $i) $segment .= '/';
else {
$idt_arr[] = $segment;
++$idt_size;
$segment = '';
}
$slash = true;
} else {
$segment .= $char;
$slash = false;
}

if($last === $i && '' !== $segment) {
$idt_arr[] = $segment;
++$idt_size;
}

}


if($idt_size > 2) $idt_arr = array(implode('/', array_slice($idt_arr, 0, $idt_size - 1)), $idt_arr[$idt_size - 1]);
if(!isset($idt_arr[1])) $idt_arr[1] = null;
return array($idt_arr, $idt);
}


$continue = false;
$nokit = false;
if(_modrewrite && isset($_GET['_rwp'])) {


$type = null;
list($ids, $ids_full) = _tmp_indexContentIds($_GET['_rwp']);
$rewritten = true;

if(isset($ids[1])) {


$query = _tmp_indexFetchPageData(
array($ids_full, $ids[0]),
null,
'art.id AS art_id',
'LEFT JOIN `'._mysql_prefix.'-articles` AS art ON(page.type=2 AND art.home1=page.id AND art.`title_seo`='.DB::val($ids[1]).')',
'page.type!=4'
);

if(false !== $query) {
if(isset($query['art_id'])) {

$type = 1;
$query = DB::query_row('SELECT * FROM `'._mysql_prefix.'-articles` WHERE id='.$query['art_id']);
$continue = true;
} elseif(2 == $query['type'] && $ids_full !== $query['title_seo']) {

$type = 1;
$continue = true;
$query = false;
} elseif(9 == $query['type']) {

$type = 0;
$continue = true;
} elseif($ids_full === $query['title_seo']) {

$ids = array($ids_full, null);
$type = 0;
$continue = true;
}
}

} else {


$type = 0;
$continue = true;
$query = _tmp_indexFetchPageData($ids[0], null, null, null, 'page.type!=4');

if(false === $query) {

$query = DB::query_row('SELECT art.id,art.title,art.title_seo,cat.title_seo AS cat_title_seo FROM `'._mysql_prefix.'-articles` AS art JOIN `'._mysql_prefix.'-root` AS cat ON(cat.id=art.home1) WHERE art.title_seo='.DB::val($ids[0]));
if(false !== $query) {
define('_redirect_to', _url.'/'._linkArticle($query['id'], $query['title_seo'], $query['cat_title_seo']));
$query = false;
}
}

}

} elseif(isset($_GET['a'])) {


$type = 1;
list($ids, $ids_full) = _tmp_indexContentIds($_GET['a']);
$rewritten = false;

if(isset($ids[1])) {
$query = DB::query_row("SELECT art.* FROM `"._mysql_prefix."-articles` AS art JOIN `"._mysql_prefix."-root` AS cat ON(cat.`title_seo`=".DB::val($ids[0])." AND art.home1=cat.id) WHERE art.`title_seo`='".DB::esc($ids[1])."' LIMIT 1");
$continue = true;
} else {

if(is_numeric($ids[0])) {

$query = false;
$continue = true;
} else {

$query = DB::query_row('SELECT art.id,art.title,art.title_seo,cat.title_seo AS cat_title_seo FROM `'._mysql_prefix.'-articles` AS art JOIN `'._mysql_prefix.'-root` AS cat ON(cat.id=art.home1) WHERE art.title_seo='.DB::val($ids[0]));
if(false !== $query) {
define('_redirect_to', _url.'/'._linkArticle($query['id'], $query['title_seo'], $query['cat_title_seo']));
}
}
}

} elseif(isset($_GET['p'])) {


$type = 0;
list($ids, $ids_full) = _tmp_indexContentIds($_GET['p']);
$rewritten = false;
$continue = true;
$query = _tmp_indexFetchPageData(array($ids_full, $ids[0]), null, null, null, 'page.type!=4');

if(false !== $query && isset($ids[1]) && 9 != $query['type'] && $ids_full !== $query['title_seo']) {


$query = false;

}

} else {


$type = 0;
$ids = null;
$rewritten = null;

$query = _tmp_indexFetchPageData(null, null, null, null, 'page.id='._index_page_id);
if(false !== $query) {
$continue = true;
} else {


if(_index_page_id != 0) {
$query = DB::query_row('SELECT * FROM `'._mysql_prefix.'-root` WHERE `type`!=4 AND `intersection`=-1 AND `visible`=1 ORDER BY `ord` LIMIT 1');
if($query === false) {

$fix_id = 0;
$nokit = true;
} else {

$fix_id = $query['id'];
$continue = true;
}
DB::query('UPDATE `'._mysql_prefix.'-settings` SET `val`='.$fix_id.' WHERE `var`=\'index_page_id\'');
}

}

}


if(_modrewrite && $rewritten && isset($ids)) {
define('_path', $base_path.$ids_full);
}


if($continue) {
if(false !== $query) {

if($type === 0) {




$id = $query['id'];
define('_indexOutput_url', _linkRoot($id, $query['title_seo']));
define('_indexOutput_pid', $id);


if(_modrewrite && isset($ids) && !$rewritten) {
parse_str($_SERVER['QUERY_STRING'], $redir_query);
unset($redir_query['p']);
define('_redirect_to', _url.'/'._addGetToLink(_indexOutput_url, _buildQuery($redir_query), false));
} elseif(isset($ids) && $id == _index_page_id) {

define('_redirect_to', _url.'/');
} else {


if(_publicAccess($query['public'], $query['level']) && (!isset($query['inter_id']) || _publicAccess($query['inter_public'], $query['inter_level']))) {


if(null !== $query['events']) {
$query['events'] = _parseStr($query['events']);
for($i = 0; isset($query['events'][$i]); ++$i) {
$event = explode(':', $query['events'][$i], 2);
_extend('call', 'page.event.'.$event[0], array('arg' => isset($event[1]) ? $event[1] : null, 'query' => &$query));
}
}


$backlink = null;
_extend('call', 'page.backlink', array('backlink' => &$backlink, 'query' => $query));

if(null === $backlink && isset($query['inter_id']) && $query['visible'] == 1 && _template_intersec_backlink && $query['inter_var2'] != 1) {

$backlink = _linkRoot($query['inter_id'], $query['inter_title_seo']);
}

if(null !== $backlink) $backlink = "<a href='".$backlink."' class='backlink'>&lt; ".$_lang['global.return']."</a>";
else $backlink = "";


$plugin = false;
$state = 1;
switch($query['type']) {
case 1:
define('_indexOutput_ptype', 'section');
break;
case 2:
define('_indexOutput_ptype', 'category');
break;
case 3:
define('_indexOutput_ptype', 'book');
break;
case 5:
define('_indexOutput_ptype', 'gallery');
break;
case 6:
define('_indexOutput_ptype', 'link');
break;
case 7:
define('_indexOutput_ptype', 'intersection');
break;
case 8:
define('_indexOutput_ptype', 'forum');
break;

case 9:


$plugin = true;
$state = 2;


if(null === $query['type_idt']) break;


$pluginfile = null;
$plugin_segment_handled = false;
_extend('call', 'ppage.'.$query['type_idt'].'.show', array('file' => &$pluginfile, 'query' => &$query, 'segment' => $ids[1], 'segment_handled' => &$plugin_segment_handled));
if(null === $pluginfile) break;


if(isset($ids[1]) && !$plugin_segment_handled) {

$state = 0;
break;
}


$state = 1;
$pluginerr = false;
define('_indexOutput_ptype', $query['type_idt']);
break;

}

if(1 === $state) {


$title = '';
$content = '';


$file = null;
$extend_args = _extendArgs($content, array('query' => &$query));
_extend('call', 'page.all.pre', $extend_args);
_extend('call', 'page.'._indexOutput_ptype.'.pre', _extendArgs($content, array('query' => &$query, 'file' => &$file)));


if($query['keywords'] !== '') define('_indexOutput_keywords', $query['keywords']);
if($query['description'] !== '') define('_indexOutput_description', $query['description']);


require (isset($file) ? $file : ($plugin ? $pluginfile : _indexroot.'require/page/'._indexOutput_ptype.'.php'));
_extend('call', 'page.'._indexOutput_ptype.'.post', $extend_args);
$content = _xsrfAutoProtect($content);


define('_indexOutput_title', $title);
define('_indexOutput_content', $backlink.$content);

} elseif(2 === $state) {


define('_indexOutput_title', $_lang['index.pagerr.title']);
define('_indexOutput_content', $backlink._formMessage(3, sprintf($_lang['index.pagerr.p'], $query['type_idt'])));

}

} else {
$notpublic_form = true;
}
}


} else {




$access = _articleAccess($query);
$id = $query['id'];
$query['cat_title_seo'] = $ids[0];
define('_indexOutput_url', _linkArticle($id, $query['title_seo'], $query['cat_title_seo']));
define('_indexOutput_ptype', 'article');


if(_modrewrite && !$rewritten) {
parse_str($_SERVER['QUERY_STRING'], $redir_query);
unset($redir_query['a']);
define('_redirect_to', _url.'/'._addGetToLink(_indexOutput_url, _buildQuery($redir_query), false));
} else {


if($access == 1) {


$content = '';


$file = null;
$extend_args = _extendArgs($content, array('query' => &$query));
_extend('call', 'article.pre', _extendArgs($content, array('query' => &$query, 'file' => &$file)));


if($query['keywords'] !== '') define('_indexOutput_keywords', $query['keywords']);
if($query['description'] !== '') define('_indexOutput_description', $query['description']);


require (isset($file) ? $file : _indexroot."require/page/article.php");
_extend('call', 'article.post', $extend_args);


$content = _xsrfAutoProtect($content);


define('_indexOutput_content', $content);
define('_indexOutput_title', $title);

} elseif($access == 2) {
$notpublic_form = true;
}

}


}

} else {



do {


if(_modrewrite) {
$q = DB::query_row('SELECT new FROM `'._mysql_prefix.'-redir` WHERE old=\''.DB::esc($ids_full).'\' AND active=1');
if(false !== $q) {
define('_redirect_to', _url.'/'.$q['new']);
break;
}
}


if(!$rewritten && is_numeric($ids[0])) {
$ids = intval($ids[0]);
if(0 === $type) $query = DB::query('SELECT `id`,`title_seo` FROM `'._mysql_prefix.'-root` WHERE `id`='.$ids);
else $query = DB::query('SELECT art.`id`,art.`title_seo`,cat.`title_seo` AS cat_title_seo FROM `'._mysql_prefix.'-articles` AS art JOIN `'._mysql_prefix.'-root` AS cat ON(cat.id=art.home1) WHERE art.`id`='.$ids);
$query = DB::row($query);
if($query !== false) {

define('_redirect_to', _url.'/'.(($type === 0) ? _linkRoot($query['id'], $query['title_seo']) : _linkArticle($query['id'], $query['title_seo'], $query['cat_title_seo'])));
break;
}
}


if($rewritten || $type === 0) {
$title = $content = null;
_extend('call', 'index.notfound.hook', array('output' => &$content, 'title' => &$title, 'ids' => $ids));
if(isset($title, $content)) {
define('_indexOutput_ptype', 'custom');
define('_indexOutput_title', $title);
$content = _xsrfAutoProtect($content);
define('_indexOutput_content', $content);
break;
}
}

} while(false);

}

} elseif($nokit) {

define('_indexOutput_content', (_template_autoheadings ? "<h1>".$_lang['global.error404.title']."</h1>" : '')._formMessage(2, $_lang['global.nokit']));
define('_indexOutput_title', $_lang['global.error404.title']);
}

}


} else {
$notpublic_form = true;
$notpublic_form_wholesite = true;
}



if(!defined('_indexOutput_pid')) define('_indexOutput_pid', -1);
if(!defined('_indexOutput_ptype')) define('_indexOutput_ptype', '');
if(!defined('_indexOutput_url')) define('_indexOutput_url', _indexroot);
if(!defined('_path')) define('_path', $base_path);



if(!defined('_indexOutput_content')) {
if(!$notpublic_form) {
$content_404 = (_template_autoheadings ? "<h1>".$_lang['global.error404.title']."</h1>" : '')._formMessage(2, $_lang['global.error404']);
_extend('call', 'index.notfound', _extendArgs($content_404));
$content_404 = _xsrfAutoProtect($content_404);
define('_indexOutput_content', $content_404);
define('_indexOutput_title', $_lang['global.error404.title']);
$found = false;
} else {
$form = _uniForm("notpublic", array($notpublic_form_wholesite));
_extend('call', 'index.notpublic', _extendArgs($form[0]));
$form[0] = _xsrfAutoProtect($form[0]);
define('_indexOutput_content', $form[0]);
define('_indexOutput_title', $form[1]);
}
}



if(!defined('_redirect_to')) {
if(!$found) header("HTTP/1.1 404 Not Found");
if(isset($__template_overload) && file_exists($__template_overload)) require $__template_overload;
else require _indexroot."plugins/templates/"._template."/template.php";
} else {
header("HTTP/1.1 301 Moved Permanently");
header("Location: "._redirect_to);
exit;
}
