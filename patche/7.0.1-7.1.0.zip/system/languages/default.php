<?php

/*--- main ---*/
$_lang['main.version']="7.1.0";
$_lang['main.languagespecification']="cs";



/*--- global ---*/
$_lang['global.nokit']="nenalezena žádná položka";
$_lang['global.error']="Chyba";
$_lang['global.error404']="Vámi požádovaná stránka se na tomto serveru nenachází.";
$_lang['global.error404.title']="Stránka nenalezena";
$_lang['global.accessdenied']="Přístup odepřen.";
$_lang['global.send']="Odeslat";
$_lang['global.do']="Proveď";
$_lang['global.continue']="Pokračovat";
$_lang['global.login']="Přihlásit";
$_lang['global.apply']="Nastavit";
$_lang['global.save']="Uložit";
$_lang['global.savechanges']="Uložit provedené změny";
$_lang['global.reset']="Reset";
$_lang['global.open']="Otevřít";
$_lang['global.name']="Název";
$_lang['global.create']="Vytvořit";
$_lang['global.insert']="Vložit";
$_lang['global.newitem']="# Nová položka";
$_lang['global.novalue']="bez hodnoty";
$_lang['global.cancel']="zrušit";
$_lang['global.badinput']="Neplatný vstup.";
$_lang['global.limited']="omezená práce s položkou";
$_lang['global.return']="návrat zpět";
$_lang['global.saved']="Uloženo.";
$_lang['global.created']="Vytvořeno.";
$_lang['global.inserted']="Vloženo.";
$_lang['global.done']="Provedeno.";
$_lang['global.action']="Akce";
$_lang['global.edit']="upravit";
$_lang['global.delete']="odstranit";
$_lang['global.group']="Skupina";
$_lang['global.email']="E-mail";
$_lang['global.avatar']="Avatar";
$_lang['global.note']="Poznámka";
$_lang['global.all']="Všechny";
$_lang['global.all2']="Všech";
$_lang['global.icq']="ICQ";
$_lang['global.user']="Uživatel";
$_lang['global.baduser']="Uživatel neexistuje.";
$_lang['global.disallowed']="K provedení této akce nemáte dostatečné oprávnění.";
$_lang['global.icq']="ICQ";
$_lang['global.paging']="Strana";
$_lang['global.next']="další";
$_lang['global.previous']="předchozí";
$_lang['global.last']="poslední";
$_lang['global.first']="první";
$_lang['global.check']="kontrola";
$_lang['global.item']="Položka";
$_lang['global.preview']="Ukázka";
$_lang['global.articlesnum']="Článků";
$_lang['global.postsnum']="Příspěvků";
$_lang['global.lastpost']="Poslední příspěvek";
$_lang['global.posttime']="Čas";
$_lang['global.postauthor']="Zaslal";
$_lang['global.imgsnum']="Obrázků";
$_lang['global.unconfirmed']="neschválený";
$_lang['global.article']="Článek";
$_lang['global.id']="ID";



/*--- notpublic ---*/
$_lang['notpublic.title']="Pouze pro registrované";
$_lang['notpublic.p']="Tuto stránku mohou zobrazit pouze zaregistrovaní uživatelé.";
$_lang['notpublic.p2']="Obsah těchto stránek mohou zobrazit pouze zaregistrovaní uživatelé.";



/*--- usermenu ---*/
$_lang['usermenu.login']="přihlásit";
$_lang['usermenu.logout']="odhlásit";
$_lang['usermenu.guest']="nepřihlášen";
$_lang['usermenu.ulist']="uživatelé";
$_lang['usermenu.registration']="registrace";
$_lang['usermenu.settings']="nastavení";
$_lang['usermenu.messages']="vzkazy";



/*--- modules ---*/

  //reg
  $_lang['mod.reg']="Registrace";
  $_lang['mod.reg.p']="Uživatelské jméno může obsahovat pouze písmena (A-Z), tečku (.) a pomlčku (-). Maximální délka je 24 znaků. E-mailová adresa je povinná.";
  $_lang['mod.reg.done']="Registrace proběhla úspěšně. Nyní se můžete se svým novým uživatelským jménem <a href='index.php?m=login'>přihlásit</a>.";
  $_lang['mod.reg.passwordneeded']="je nutné zvolit heslo";
  $_lang['mod.reg.nosame']="zadaná hesla nejsou shodná";
  $_lang['mod.reg.submit']="Zaregistrovat";
  
  //search
  $_lang['mod.search']="Vyhledávání";
  $_lang['mod.search.p']="Do pole níže zadejte frázi, kterou chcete vyhledat (můžete použít zástupné znaky <q>_</q> a <q>%</q>).";
  $_lang['mod.search.submit']="Vyhledat";
  $_lang['mod.search.where']="Prohledávat";
  $_lang['mod.search.where.root']="stránky";
    $_lang['mod.search.where.articles']="články";
    $_lang['mod.search.where.posts']="příspěvky";
  $_lang['mod.search.minlength']="Hledaná fráze musí mít alespoň 3 znaky.";
  $_lang['mod.search.noresult']="Nebyly nalezeny žádné stránky.";
  
  //messages
  $_lang['mod.messages']="Vzkazy";
  $_lang['mod.messages.inbox']="Doručené";
  $_lang['mod.messages.outbox']="Odeslané";
  $_lang['mod.messages.outbox.p']="Zde jsou zobrazeny vámi odeslané vzkazy (pouze ty, které příjemce nesmazal). Zvýrazněné vzkazy nebyly dosud příjemcem přečteny.";
  $_lang['mod.messages.new']="Napsat vzkaz";
    $_lang['mod.messages.message']="Vzkaz";
    $_lang['mod.messages.sender']="Odesílatel";
    $_lang['mod.messages.receiver']="Příjemce";
    $_lang['mod.messages.answer']="Odpovědět";
    $_lang['mod.messages.deleteselected']="Smazat označené vzkazy";
    $_lang['mod.messages.nokit']="nenalezeny žádné vzkazy";
    $_lang['mod.messages.nosubject']="Bez předmětu";
    $_lang['mod.messages.error.notext']="nebyl zadán text vzkazu";
    $_lang['mod.messages.error.badreceiver']="příjemce nebyl nalezen";
    $_lang['mod.messages.sent']="Vzkaz byl odeslán.";
  
  //profile
  $_lang['mod.profile']="Profil";
  $_lang['mod.profile.regtime']="Zaregistrován od";
  $_lang['mod.profile.lastact']="Naposledy aktivní";
  
  //settings
  $_lang['mod.settings']="Nastavení";
  $_lang['mod.settings.p']="Položky označené <span class='forced'>*</span> jsou povinné.";
  $_lang['mod.settings.profilelink']="Přejít na profil";
  $_lang['mod.settings.submit']="Uložit změny v nastavení";
  $_lang['mod.settings.badcurrentpass']="chybné současné heslo";
  $_lang['mod.settings.newpassnosame']="nové heslo a jeho kontrola se neshodují";
  $_lang['mod.settings.badnewpass']="nové heslo nesmí být prázdné";
  $_lang['mod.settings.usernamechangedenied']="v uživatelském jménu je dovoleno měnit pouze velikost písmen";
  $_lang['mod.settings.selfremove.failed']="zadané heslo pro potvrzení zrušení účtu není správné";
  $_lang['mod.settings.selfremove.imposible']="tento účet nelze odstranit";
  $_lang['mod.settings.userdata']="Uživatelská data";
    $_lang['mod.settings.userdata.namechangenote']="lze změnit pouze velikost písmen";
    $_lang['mod.settings.userdata.massemail']="zasílat hromadné e-maily";
  $_lang['mod.settings.avatar']="Avatar (uživatelský obrázek)";
    $_lang['mod.settings.avatar.hint']="Maximální velikost obrázku je 96x128 pixelů (větší nebudou zobrazeny celé). Adresa musí být v absolutním tvaru - např. <em>http://mojestranky1.cz/avatar.jpg</em>.<br /><br />Pokud nechcete používat žádný vlastní obrázek, ponechejte toto pole prázdné. V takovém případě bude zobrazen přednastavený systémový avatar.";
  $_lang['mod.settings.password']="Nastavení hesla";
    $_lang['mod.settings.password.hint']="Pole současné heslo a nové heslo vyplňujte pouze chcete-li jej změnit.";
    $_lang['mod.settings.password.current']="Současné heslo";
    $_lang['mod.settings.password.new']="Nové heslo";
  $_lang['mod.settings.admin']="Nastavení administrace";
    $_lang['mod.settings.admin.wysiwyg']="používat wysiwyg editor pro editaci (pokud je dostupný)";
  $_lang['mod.settings.selfremove']="Zrušení účtu";
    $_lang['mod.settings.selfremove.box']="chci zrušit tento účet (nelze vzít zpět!!)";
    $_lang['mod.settings.selfremove.confirm']="Potvrďte svým heslem";

  //ulist
  $_lang['mod.ulist.p']="Kliknutím na uživatelské jméno zobrazíte profil zvoleného uživatele.";
  
  //editpost
  $_lang['mod.editpost']="Úprava příspěvku";
  $_lang['mod.editpost.failed']="Nebyl zadán text!";
  $_lang['mod.editpost.delete']="odstranit tento příspěvek";
  $_lang['mod.editpost.deleted']="Příspěvek byl odstraněn.";



/*--- posts ---*/
$_lang['posts.comments']="Komentáře";
$_lang['posts.addcomment']="přidat komentář";
$_lang['posts.addpost']="přidat příspěvek";
$_lang['posts.reply']="odpovědět";
$_lang['posts.replied']="odpověděl";
$_lang['post.replynote']="Zasílate odpověď ke stávajícímu příspěvku";
$_lang['posts.nocomments']="nebyly přidány žádné komentáře";
$_lang['posts.noposts']="nebyly přidány žádné příspěvky";
$_lang['posts.guestname']="Jméno";
$_lang['posts.subject']="Předmět";
$_lang['posts.text']="Text";
$_lang['posts.loginrequired']="Nemáte oprávnění přidávat příspěvky.";
$_lang['posts.anonym']="Anonym";
$_lang['posts.failed']="Nepodařilo se přidat příspěvek. Zkontrolujte, zda jste zadali text a případně znaky z kontrolního obrázku.";
$_lang['posts.added']="Příspěvek byl přidán.";
$_lang['posts.limit']="Je možné zaslat maximálně jeden příspěvek/vzkaz za *postsendexpire* sekund.";



/*--- article ---*/
$_lang['article.author']="Autor";
$_lang['article.posted']="Vydáno";
$_lang['article.readed']="Přečteno";
$_lang['article.rate']="Hodnocení";
$_lang['article.rate.num']="hodnoceno";
$_lang['article.rate.do']="Hodnotit článek";
$_lang['article.rate.nodata']="neohodnoceno";
$_lang['article.comments']="Komentářů";
$_lang['article.category']="Kategorie";
$_lang['article.id']="ID článku";



/*--- login ---*/
$_lang['login.title']="Přihlášení";
$_lang['login.username']="Uživatelské jméno";
$_lang['login.password']="Heslo";
$_lang['login.success']="Přihlášení proběhlo bez problémů.";
$_lang['login.failure']="Chybné uživatelské jméno nebo heslo.";
$_lang['login.ininfo']="Jste přihlášeni pod uživatelským jménem";
$_lang['login.blocked']="Zablokovaný účet";
$_lang['login.blocked.message']="Váš účet je zablokovaný.";
$_lang['login.securitylogout']="Z bezpečnostních důvodů (změna hesla z jiného počítače, zablokování nebo smazání účtu) proběhlo automatické odhlášení.";
$_lang['login.selfremove']="Váš účet byl zrušen.";
$_lang['login.attemptlimit']="Byl překročen limit počtu nezdařilých pokusů o přihlášení, který je maximálně *1* nezdařilých pokusů za *2* minut.";



/*--- admin ---*/
$_lang['admin.defaulttitle']="Administrace";
$_lang['admin.link']="administrace";
$_lang['admin.homelink']="zpět na hlavní stranu";
$_lang['admin.denied']="Nemáte dostatečná práva pro vstup do administrace.";
$_lang['admin.moduleunavailable']="Modul není dostupný.";

$_lang['admin.topicon.home']="otevřít hlavní stranu";
$_lang['admin.topicon.newwin']="nové okno administrace";
$_lang['admin.topicon.help']="dokumentace";

$_lang['admin.menu.index']="Úvod";
$_lang['admin.menu.content']="Správa obsahu";
$_lang['admin.menu.users']="Uživatelé a skupiny";
$_lang['admin.menu.fman']="Souborový manažer";
$_lang['admin.menu.settings']="Nastavení systému";
$_lang['admin.menu.other']="Ostatní funkce";


    /*-- index --*/
    $_lang['admin.index.p']="Vítejte! Přihlášení do administrace proběhlo úspěšně. Z menu výše si vyberte, s čím chcete pracovat. Dolpňující informace o pokročilých funkcích a technickou podporu naleznete v <a href='http://sunlight-cms.net/feedback/docs.php' target='_blank'>online dokumentaci</a>.";
    $_lang['admin.index.server']="Server";
      $_lang['admin.index.server.url']="Adresa";
      $_lang['admin.index.server.os']="Operační systém";
      $_lang['admin.index.server.php']="Verze PHP";
      $_lang['admin.index.server.mysql']="Verze MySQL";
      $_lang['admin.index.server.software']="Software";
    $_lang['admin.index.system']="Systém";
      $_lang['admin.index.system.version']="Verze";
      $_lang['admin.index.system.uptodate']="Aktuální verze";
      $_lang['admin.index.system.web']="Web";
      
      
    /*-- fman --*/
    $_lang['admin.fman.menu.upload']="Nahrát soubor";
    $_lang['admin.fman.menu.createfile']="Vytvořit soubor";
    $_lang['admin.fman.menu.createfolder']="Vytvořit adresář";
    $_lang['admin.fman.menu.home']="Výchozí adresář";
    
    $_lang['admin.fman.msg.newfolder.done']="Adresář byl vytvořen.";
    $_lang['admin.fman.msg.newfolder.failure']="Nepodařilo se vytvořit adresář.";
    $_lang['admin.fman.msg.newfolder.failure2']="Adresář s tímto názvem již existuje nebo jeho název není platný.";
    $_lang['admin.fman.msg.delete.done']="Soubor/adresář byl odstraněn.";
    $_lang['admin.fman.msg.deleteselected.done']="Bylo odstraněno *done* souborů z *total*.";
    $_lang['admin.fman.msg.delete.failure']="Soubor/adresář se nepodařilo odstranit.";
    $_lang['admin.fman.msg.rename.done']="Soubor/adresář byl přejmenován.";
    $_lang['admin.fman.msg.rename.failure']="Soubor/adresář se nepodařilo přejmenovat.";
    $_lang['admin.fman.msg.edit.done']="Soubor byl uložen.";
    $_lang['admin.fman.msg.edit.failure']="Soubor se nepodařilo uložit.";
    $_lang['admin.fman.msg.move.done']="Bylo přesunuto *done* souborů z *total*.";
    $_lang['admin.fman.msg.upload.done']="Bylo nahráno *done* souborů z *total*.";
    $_lang['admin.fman.msg.defdircreationfailure']="Nepodařilo se vytvořit výchozí adresář.";
    $_lang['admin.fman.msg.rootlimit']="Soubory nelze přesunout - zvolený adresář leží mimo vaše oprávnění.";
    $_lang['admin.fman.msg.exists']="Soubor/adresář s tímto názvem již existuje.";
    $_lang['admin.fman.msg.disallowedextension']="Nemáte oprávnění pracovat s tímto typem souborů.";
    
    $_lang['admin.fman.currentdir']="Aktuální adresář";
    $_lang['admin.fman.filecounter']="Počet souborů";
    $_lang['admin.fman.file']="Soubor";
    $_lang['admin.fman.rename']="přejmenovat";
    $_lang['admin.fman.rename.title']="Přejmenování";
    $_lang['admin.fman.delete.title']="Odstranění";
    $_lang['admin.fman.edit']="upravit";
    $_lang['admin.fman.edit.title']="Úprava / vytváření souboru";
    $_lang['admin.fman.edit.namenote']="změnou jména souboru jej uložíte jako nový (původní zůstane nezměněn)";
    $_lang['admin.fman.edit.namenote2']="vytváříte nový soubor (případný soubor se stejným jménem bude přepsán)";
    $_lang['admin.fman.newname']="Nové jméno";
    $_lang['admin.fman.delask']="Opravdu chcete odstranit soubor/adresář <q><em>*name*</em></q>?";
    $_lang['admin.fman.selected']="Zaškrtnuté";
    $_lang['admin.fman.selectall']="Zaškrtnout vše";
    $_lang['admin.fman.deselectall']="Odškrtnout vše";
    $_lang['admin.fman.selected.move']="Přesunout";
    $_lang['admin.fman.selected.move.prompt']="Zadejte nové umístění (relativně k aktuálnímu adresáři)";
    $_lang['admin.fman.selected.delete']="Odstranit";
    $_lang['admin.fman.selected.delete.confirm']="Opravdu chcete odstranit zaškrtnuté soubory?";
    $_lang['admin.fman.extra']="Speciální funkce";
    $_lang['admin.fman.selected.addtogallery']="Přidat zaškrtnuté obrázky do galerie";
    $_lang['admin.fman.selected.addtogallery.getid']="Zadejte ID galerie";
    $_lang['admin.fman.selected.addtogallery.failure']="Neplatná galerie.";
    $_lang['admin.fman.selected.addtogallery.done']="*done* obrázků bylo vloženo do galerie.";
    $_lang['admin.fman.upload.nomorefiles']="Nelze přidat více souborů.";
    $_lang['admin.fman.upload.addfile']="další soubor";
      
      
    /*-- content --*/
    $_lang['admin.content.p']="Ve správě obsahu můžete vytvářet, upravovat a mazat obsah stránek. Funkce přístupné v tomto modulu závisí na vašich právech.";
    $_lang['admin.content.section']="sekce";
    $_lang['admin.content.category']="kategorie";
    $_lang['admin.content.book']="kniha";
    $_lang['admin.content.separator']="oddělovač";
    $_lang['admin.content.gallery']="galerie";
    $_lang['admin.content.link']="odkaz";
    $_lang['admin.content.intersection']="rozcestník";
    $_lang['admin.content.move']="Posouvání";
    $_lang['admin.content.titles']="Titulky";
    $_lang['admin.content.articles']="Články";
    $_lang['admin.content.confirm']="Schvalování";
    $_lang['admin.content.movearts']="Přesouvání";
    $_lang['admin.content.other']="Ostatní";
    $_lang['admin.content.polls']="Ankety";
    $_lang['admin.content.boxes']="Boxy";
    $_lang['admin.content.manage']="Spravovat";
    $_lang['admin.content.newart']="Napsat článek";
    $_lang['admin.content.saveord']="Aktualizovat pořadová čísla";
    
    $_lang['admin.content.form.title']="Titulek";
    $_lang['admin.content.form.intersection']="Rozcestník";
    $_lang['admin.content.form.intersection.none']="# Žádný";
    $_lang['admin.content.form.category.none']="# Žádná";
    $_lang['admin.content.form.ord']="Pořadí";
    $_lang['admin.content.form.settings']="Nastavení";
    $_lang['admin.content.form.visible']="viditelnost";
    $_lang['admin.content.form.public']="veřejné";
    $_lang['admin.content.form.comments']="komentáře";
    $_lang['admin.content.form.artrate']="hodnocení";
    $_lang['admin.content.form.resetartrate']="vynulovat hodnocení";
    $_lang['admin.content.form.resetartread']="vynulovat počet přečtení";
    $_lang['admin.content.form.confirmed']="schválený";
    $_lang['admin.content.form.delcomments']="smazat komentáře";
    $_lang['admin.content.form.delposts']="smazat příspěvky";
    $_lang['admin.content.form.unregpost']="neregistrovaní mohou psát příspěvky";
    $_lang['admin.content.form.artorder']="řadit články podle";
    $_lang['admin.content.form.artorder.1']="času vydání";
    $_lang['admin.content.form.artorder.2']="pořadí vytvoření";
    $_lang['admin.content.form.artorder.3']="abecedy (A-Z)";
    $_lang['admin.content.form.artorder.4']="abecedy (Z-A)";
    $_lang['admin.content.form.artsperpage']="článků na stranu";
    $_lang['admin.content.form.postsperpage']="příspěvků na stranu";
    $_lang['admin.content.form.content']="Obsah";
    $_lang['admin.content.form.url']="URL";
    $_lang['admin.content.form.newwindow']="do nového okna (funguje pouze v menu)";
    $_lang['admin.content.form.thisid']="ID této položky je";
    $_lang['admin.content.form.intersectionperex']="Popis";
    $_lang['admin.content.form.showinfo']="zobrazovat informace u položek";
    $_lang['admin.content.form.perex']="Perex";
    $_lang['admin.content.form.infobox']="Infobox";
    $_lang['admin.content.form.timehelp']="DD.MM. YYYY HH:MM:SS";
    $_lang['admin.content.form.timeupdate']="nastavit při uložení";
    $_lang['admin.content.form.flink']="rozbalovací menu (některé motivy nepodporují)";
    $_lang['admin.content.form.imgsperrow']="obrázků na řádek";
    $_lang['admin.content.form.imgsperpage']="na stránku";
    $_lang['admin.content.form.prevheight']="výška aut. náhledu";
    $_lang['admin.content.form.manageimgs']="spravovat obrázky v galerii";
    $_lang['admin.content.form.imgs']="Obrázky";
    $_lang['admin.content.form.pagehelp']="Dokumentácia";
    $_lang['admin.content.form.question']="Otázka";
    $_lang['admin.content.form.answers']="Možné odpovědi<br />(oddělené #)";
    
      //move
      $_lang['admin.content.move.title']="Posouvání položek";
      $_lang['admin.content.move.p']="Posouvání pořadových čísel určitých položek o danou hodnotu. Ovlivňuje pouze kořenové položky (ty, které nepatří do žádného rozcestníku).";
      $_lang['admin.content.move.choice1']="Zvětšit";
      $_lang['admin.content.move.choice2']="Zmenšit";
      $_lang['admin.content.move.text1']="pořadové číslo položek, jejichž pořadové číslo je";
      $_lang['admin.content.move.choice3']="větší";
      $_lang['admin.content.move.choice4']="menší";
      $_lang['admin.content.move.text2']="nebo rovno";
      $_lang['admin.content.move.text3']="o hodnotu";
      
      //titles
      $_lang['admin.content.titles.title']="Titulky položek";
      $_lang['admin.content.titles.p']="Změna titulků jednotlivých položek.";
      
      //articles
      $_lang['admin.content.articles.title']="Správa článků";
        $_lang['admin.content.articles.p']="Zde můžete psát, upravovat a mazat články. Kliknutím na název kategorie zobrazíte články dostupné k editaci.";
        $_lang['admin.content.articles.create']="napsat nový článek";
        $_lang['admin.content.articles.openid']="Otevřít článek s ID";
      $_lang['admin.content.articles.list.title']="Seznam článků kategorie";
        $_lang['admin.content.articles.list.p']="Zvolte článek, se kterým chcete pracovat (kliknutím na příslušnou ikonu akce u článku).";
      $_lang['admin.content.articles.edit.title']="Úprava / vytváření článku";
        $_lang['admin.content.articles.edit.p']="Upravujete stávající nebo vytváříte nový článek.";
        $_lang['admin.content.articles.edit.newconfnote']="Váš článek musí být před publikováním schválen.";
        $_lang['admin.content.articles.edit.confnote']="Tento článek stále není schválen.";
        $_lang['admin.content.articles.edit.error1']="nebyl zadán titulek";
        $_lang['admin.content.articles.edit.error2']="zvolená kategorie není platná";
        $_lang['admin.content.articles.edit.error3']="neplatný autor";
      $_lang['admin.content.articles.delete.title']="Smazání článku";
        $_lang['admin.content.articles.delete.p']="Chystáte se odstranit zvolený článek <q>*arttitle*</q>.";
        $_lang['admin.content.articles.delete.confirmbox']="Odstranit článek";
        $_lang['admin.content.articles.delete.done']="Článek byl odstraněn.";
      
      //confirm
      $_lang['admin.content.confirm.title']="Schvalování článků";
      $_lang['admin.content.confirm.p']="V tabulce níže můžete vidět seznam neschválených článků seřazených podle času vydání (od starších po novější). Pokud nemáte právo k upravování cizích článků, nebudete moci článek upravit nebo vzít schválení zpět.";
      $_lang['admin.content.confirm.filter']="Zobrazit pouze kategorii";
      $_lang['admin.content.confirm.confirm']="schválit";
      
      //movearts
      $_lang['admin.content.movearts.title']="Přesouvání článků";
      $_lang['admin.content.movearts.p']="Zde máte možnost přesunout články z jedné kategorie do druhé.";
      $_lang['admin.content.movearts.text1']="Přesunout články z kategorie";
      $_lang['admin.content.movearts.text2']="do";
      $_lang['admin.content.movearts.badsource']="Zdrojová kategorie není platná.";
      $_lang['admin.content.movearts.badtarget']="Cílová kategorie není platná.";
      $_lang['admin.content.movearts.samecats']="Články lze přesouvat pouze mezi dvěma různými kategoriemi.";
      $_lang['admin.content.movearts.done']="Bylo přesunuto *moved* článků.";
      
      //polls
      $_lang['admin.content.polls.title']="Správa anket";
      $_lang['admin.content.polls.p']="Anketu upravíte kliknutím na otázku. Podle vašich práv můžete editovat pouze své ankety nebo i ankety ostatních uživatelů na nižší úrovni.";
      $_lang['admin.content.polls.new']="vytvořit novou anketu";
      $_lang['admin.content.polls.openid']="Otevřít anketu s ID";
      $_lang['admin.content.polls.locked']="uzamčená";
      $_lang['admin.content.polls.reset']="vynulovat hlasy";
      $_lang['admin.content.polls.filter']="Zobrazit pouze ankety od";
        $_lang['admin.content.polls.edit.title']="Úprava / vytváření ankety";
        $_lang['admin.content.polls.edit.p']="Upravujete stávající nebo vytváříte novou anketu.";
        $_lang['admin.content.polls.edit.error1']="nebyla zadána otázka";
        $_lang['admin.content.polls.edit.error2']="nebyly zadány žádné odpovědi";
      
      //boxes
      $_lang['admin.content.boxes.title']="Správa boxů";
      $_lang['admin.content.boxes.p']="Vyberte si sloupec, který chcete editovat (jsou zobrazeny pouze sloupce, ve kterých jsou nějaké boxy - tzn. sloupec vytvoříte tím, že do něj vložíte box). Každý motiv zobrazuje pouze určité sloupce (informace o nich by měly být poskytnuty spolu s motivem).";
      $_lang['admin.content.boxes.create']="vytvořit nový box";
      $_lang['admin.content.boxes.delete']="smazat box";
      $_lang['admin.content.boxes.saveboxeschanges']="Uložit změny v boxech";
      $_lang['admin.content.boxes.column']="Sloupec";
      $_lang['admin.content.boxes.totalboxes']="Počet boxů";
      $_lang['admin.content.boxes.edit.title']="Úprava boxů";
      $_lang['admin.content.boxes.new.title']="Nový box";
      
      //delete
      $_lang['admin.content.delete.title']="Odstranění položky";
      $_lang['admin.content.delete.p']="Položka bude nenávratně odstraněna i s veškerým jejím obsahem (komentáře, články, příspěvky)!";
      $_lang['admin.content.delete.contentlist']="Této položce náleží a bude odstraněno";
      $_lang['admin.content.delete.confirm']="Odstranit tuto položku";
      $_lang['admin.content.delete.norelated']="žádné související položky";
      $_lang['admin.content.delete.comments']="komentářů";
      $_lang['admin.content.delete.articles']="článků";
      $_lang['admin.content.delete.posts']="příspěvků";
      $_lang['admin.content.delete.images']="obrázků";
      
      //editsection
      $_lang['admin.content.editsection.title']="Úprava sekce";
      $_lang['admin.content.editsection.p']="Upravujete stávající nebo právě vytvořenou sekci.";
      
      //editcategory
      $_lang['admin.content.editcategory.title']="Úprava kategorie";
      $_lang['admin.content.editcategory.p']="Upravujete stávající nebo právě vytvořenou kategorii.";
      
      //editintersection
      $_lang['admin.content.editintersection.title']="Úprava rozcestníku";
      $_lang['admin.content.editintersection.p']="Úpravujete stávající nebo právě vytvořený rozcestník.";
      
      //editbook
      $_lang['admin.content.editbook.title']="Úprava knihy";
      $_lang['admin.content.editbook.p']="Upravujete stávající nebo právě vytvořenou knihu.";
      
      //editseparator
      $_lang['admin.content.editseparator.title']="Úprava oddělovače";
      $_lang['admin.content.editseparator.p']="Upravujete stávající nebo právě vytvořený oddělovač.";
      
      //editlink
      $_lang['admin.content.editlink.title']="Úprava odkazu";
      $_lang['admin.content.editlink.p']="Upravujete stávající nebo právě vytvořený odkaz.";
      
      //editgallery
      $_lang['admin.content.editgallery.title']="Úprava galerie";
      $_lang['admin.content.editgallery.p']="Upravujete stávající nebo právě vytvořenou galerii.";
      
        //manageimgs
        $_lang['admin.content.manageimgs.title']="Správa obrázků";
        $_lang['admin.content.manageimgs.p']="Spravujete obrázky galerie <q>*galtitle*</q>.";
        $_lang['admin.content.manageimgs.insert']="Vložit nový obrázek";
        $_lang['admin.content.manageimgs.moveallords']="Posouvání pořadových čísel";
        $_lang['admin.content.manageimgs.moveallords.cleanup']="Vyčistit pořadová čísla (odstranit mezery).";
        $_lang['admin.content.manageimgs.current']="Stávající obrázky";
        $_lang['admin.content.manageimgs.full']="Cesta k originálu";
        $_lang['admin.content.manageimgs.prev']="Cesta k náhledu";
        $_lang['admin.content.manageimgs.moveords']="vložit na začátek";
        $_lang['admin.content.manageimgs.autoprev']="automatický náhled";
        $_lang['admin.content.manageimgs.savechanges']="Uložit změny v obrázcích";
        $_lang['admin.content.manageimgs.delete']="odstranit obrázek";

    /*-- settings --*/
    $_lang['admin.settings.p']="Nastavení hlavních parametrů systému. Na pravé stráně od každé položky je stručně popsán její význam.";
    $_lang['admin.settings.saved']="Nastavení bylo uloženo.";
    
      //main
      $_lang['admin.settings.main']="Hlavní nastavení";
        $_lang['admin.settings.main.template']="Motiv"; $_lang['admin.settings.main.template.help']="motiv vzhledu pro zobrazení stránek";
        $_lang['admin.settings.main.language']="Jazyk"; $_lang['admin.settings.main.language.help']="jazyková mutace systému";
        $_lang['admin.settings.main.showpages']="Počet stran"; $_lang['admin.settings.main.showpages.help']="maximální počet stran zobrazených najednou v seznamu (liché číslo, minimálně 3)";
        $_lang['admin.settings.main.pagingmode']="Stránkování"; $_lang['admin.settings.main.pagingmode.help']="určuje místa zobrazení stránkování (v kategoriích, komentářích apod.)";
          $_lang['admin.settings.main.pagingmode.1']="pouze nahoře";
          $_lang['admin.settings.main.pagingmode.2']="nahoře i dole";
        $_lang['admin.settings.main.notpublicsite']="Neveřejné stránky"; $_lang['admin.settings.main.notpublicsite.help']="pokud je tato volba aktivována, musí být uživatel přihlášen, aby mohl prohlížet jakýkoliv obsah stránek";

      //info
      $_lang['admin.settings.info']="Informace o stránkách";
        $_lang['admin.settings.info.title']="Titulek"; $_lang['admin.settings.info.title.help']="titulek stránek";
        $_lang['admin.settings.info.description']="Popis"; $_lang['admin.settings.info.description.help']="stručný popis stránek";
        $_lang['admin.settings.info.keywords']="Klíčová slova"; $_lang['admin.settings.info.keywords.help']="klíčová slova oddělená čárkami";
        $_lang['admin.settings.info.author']="Autor"; $_lang['admin.settings.info.author.help']="autor nebo autoři stránek";
        $_lang['admin.settings.info.url']="Adresa stránek"; $_lang['admin.settings.info.url.help']="adresa ke kořenovému adresáři systému v absolutním tvaru (důležité)";
        $_lang['admin.settings.info.titleseparator']="Oddělení v titulku"; $_lang['admin.settings.info.titleseparator.help']="řetězec oddělující titulek stránek od titulku obsahu";

      //mods
      $_lang['admin.settings.mods']="Volitelné moduly a jejich nastavení";
        $_lang['admin.settings.mods.modrewrite']="Mod_rewrite"; $_lang['admin.settings.mods.modrewrite.help']="aktivace mod_rewrite modulu (přepisování adres v odkazech kvůli SEO optimalizaci)";
        $_lang['admin.settings.mods.wysiwyg']="Wysiwyg"; $_lang['admin.settings.mods.wysiwyg.help']="aktivace wysiwyg editoru <a href='http://tinymce.moxiecode.com/' target='_blank'>TinyMCE</a>";
        $_lang['admin.settings.mods.ulist']="Seznam uživatelů"; $_lang['admin.settings.mods.ulist.help']="povolit seznam uživatelů";
        $_lang['admin.settings.mods.registration']="Registrace"; $_lang['admin.settings.mods.registration.help']="povolit registraci uživatelů";
        $_lang['admin.settings.mods.search']="Vyhledávání"; $_lang['admin.settings.mods.search.help']="povolit vyhledávání na stránkách";
        $_lang['admin.settings.mods.comments']="Komentáře"; $_lang['admin.settings.mods.comments.help']="povolit zasílání komentářů k sekcím a článkům";
        $_lang['admin.settings.mods.messages']="Vzkazy"; $_lang['admin.settings.mods.messages.help']="povolit zasílání vzkazů mezi uživateli";
        $_lang['admin.settings.mods.captcha']="Kontrolní kód"; $_lang['admin.settings.mods.captcha.help']="používat kontrolní obrázek (<a href='http://cs.wikipedia.org/wiki/CAPTCHA' target='_blank'>CAPTCHA</a>)";
        $_lang['admin.settings.mods.bbcode']="BBCode"; $_lang['admin.settings.mods.bbcode.help']="povolit používání formátovacích značek <a href='http://cs.wikipedia.org/wiki/BBCode' target='_blank'>BBCode</a> v příspěvcích";
        $_lang['admin.settings.mods.smileys']="Smajlíci"; $_lang['admin.settings.mods.smileys.help']="povolit používání grafických smajlíků v příspěvcích";
        $_lang['admin.settings.mods.lightbox']="Lightbox"; $_lang['admin.settings.mods.lightbox.help']="používat integrovaný <a href='http://www.huddletogether.com/projects/lightbox2/' target='_blank'>Lightbox2</a> pro obrázky v galeriích";
        $_lang['admin.settings.mods.rss']="RSS"; $_lang['admin.settings.mods.rss.help']="povolit automatické generování <a href='http://cs.wikipedia.org/wiki/RSS' target='_blank'>RSS</a> zdroje pro nejnovější komentáře, články apod.";
        
        $_lang['admin.settings.mods.profileemail']="Zobrazovat e-mail"; $_lang['admin.settings.mods.profileemail.help']="povolit zobrazování e-mailové adresy uživatele v jeho profilu";
        $_lang['admin.settings.mods.commentsperpage']="Stránkování komentářů"; $_lang['admin.settings.mods.commentsperpage.help']="určuje maximální počet komentářů, které budou zobrazeny na jedné straně";
        $_lang['admin.settings.mods.messagesperpage']="Stránkování vzkazů"; $_lang['admin.settings.mods.messagesperpage.help']="určuje maximální počet vzkazů, které budou zobrazeny na jedné straně";
        $_lang['admin.settings.mods.postadmintime']="Doba správy příspěvku"; $_lang['admin.settings.mods.postadmintime.help']="určuje počet hodin od napsání příspěvku, kdy jej může jeho autor upravit nebo smazat";
        $_lang['admin.settings.mods.atreplace']="Nahrazování zavináče"; $_lang['admin.settings.mods.atreplace.help']="znak zavináče <q>@</q> v e-mailové adrese bude nahrazován tímto řetězcem (ochrana proti spamu)";
        $_lang['admin.settings.mods.mailerusefrom']="Nastavovat odesílatele"; $_lang['admin.settings.mods.mailerusefrom.help']="při aktivaci bude v e-mailech nastavován přímo odesílatel a ne pouze adresa pro odpověď (nemusí být podporováno!)";
        
      //iplog
      $_lang['admin.settings.iplog']="Časové limity";
        $_lang['admin.settings.iplog.maxloginattempts']="Pokusy o přihlášení"; $_lang['admin.settings.iplog.maxloginattempts.help']="určuje maximální počet nezdařilých pokusů o přihlášení za danou dobu (níže)";
        $_lang['admin.settings.iplog.maxloginexpire']="Další pokusy o přihlášení"; $_lang['admin.settings.iplog.maxloginexpire.help']="doba v minutách, po které se bude moci uživatel znovu pokusit o přihlášení, když překročí daný limit";
        $_lang['admin.settings.iplog.artreadexpire']="Přečtení článku"; $_lang['admin.settings.iplog.artreadexpire.help']="doba v minutách, po které se bude znovu započítávat přečtení článku";
        $_lang['admin.settings.iplog.artrateexpire']="Hodnocení článku"; $_lang['admin.settings.iplog.artrateexpire.help']="doba v minutách, po které bude možné znovu hodnotit článek";
        $_lang['admin.settings.iplog.pollvoteexpire']="Hlasování v anketě"; $_lang['admin.settings.iplog.pollvoteexpire.help']="doba v minutách, po které bude možné v anketě znovu hlasovat";
        $_lang['admin.settings.iplog.postsendexpire']="Zasílání příspěvku a vzkazů"; $_lang['admin.settings.iplog.postsendexpire.help']="minimální doba v sekundách, po jejíž uplynutí bude možné zaslat další příspěvek nebo vzkaz";

      //users
      $_lang['admin.settings.users']="Uživatelé";
        $_lang['admin.settings.users.defaultgroup']="Výchozí skupina"; $_lang['admin.settings.users.defaultgroup.help']="určuje skupinu, do které bude uživatel automaticky přiřazen po registraci";

      //admin
      $_lang['admin.settings.admin']="Administrace";
        $_lang['admin.settings.admin.intro']="Úvodní text"; $_lang['admin.settings.admin.intro.help']="Tento text (xhtml kód) bude zobrazen na úvodní straně administrace vedle informací o systému.";

      
    /*-- users and groups --*/
    $_lang['admin.users.p']="Zde máte možnost spravovat uživatelské skupiny a uživatele (nebo pouze jednu z těchto věcí v závislosti na vašem oprávnění). Některé skupiny jsou systémové a lze s nimi pracovat pouze omezeně. Také můžete vytvářet a upravovat pouze skupiny s nižší úrovní, než je úroveň skupiny, kde se práve nacházíte.";
    
      //groups
      $_lang['admin.users.groups']="Skupiny";
        $_lang['admin.users.groups.members']="Členové";
        $_lang['admin.users.groups.specialgroup.delnotice']="Systémovou skupinu nelze odstranit, budou odstraněni pouze její členové.";
        $_lang['admin.users.groups.specialgroup.editnotice']="Této systémové skupině nelze měnit všechny parametry.";
        $_lang['admin.users.groups.edittitle']="Úprava skupiny";
        $_lang['admin.users.groups.editp']="Upravujete stávající skupinu.";
        $_lang['admin.users.groups.deltitle']="Odstranění skupiny";
        $_lang['admin.users.groups.delp']="Odstraňujete stávající skupinu. Skupina bude odstraněna i se všemi jejími členy! Chcete-li je zachovat, <a href='index.php?p=users-move'>přesuňte je před odstraněním této skupiny do jiné</a> (přístupnost této funkce závisí na vašich oprávněních).";
        $_lang['admin.users.groups.level']="Úroveň";
        $_lang['admin.users.groups.icon']="Ikona";
        $_lang['admin.users.groups.blocked']="Blokovaná";
        $_lang['admin.users.groups.commonrights']="Obecná práva";
        $_lang['admin.users.groups.adminrights']="Administrace - přístup a základní moduly";
        $_lang['admin.users.groups.admincontentrights']="Administrace - práva ve správě obsahu";
          $_lang['admin.users.groups.changeusername']="Změnit vlastní jméno"; $_lang['admin.users.groups.changeusername.help']="právo úplně měnit své vlastní uživatelské jméno";
          $_lang['admin.users.groups.postcomments']="Psát komentáře"; $_lang['admin.users.groups.postcomments.help']="umožnit přidávání komentářů";
          $_lang['admin.users.groups.artrate']="Hodnotit články"; $_lang['admin.users.groups.artrate.help']="umožnit hodnocení článků";
          $_lang['admin.users.groups.pollvote']="Hlasovat v anketách"; $_lang['admin.users.groups.pollvote.help']="umožnit hlasování v anketách";
          $_lang['admin.users.groups.unlimitedpostaccess']="Bez limitů"; $_lang['admin.users.groups.unlimitedpostaccess.help']="zrušit časový limit pro správu a zasílání příspěvků";
          $_lang['admin.users.groups.administration']="Přístup do administrace"; $_lang['admin.users.groups.administration.help']="umožnit vstup do administrace";
          $_lang['admin.users.groups.adminsettings']="Změna nastavení systému"; $_lang['admin.users.groups.adminsettings.help']="právo měnit důležitá nastavení systému";
          $_lang['admin.users.groups.adminusers']="Správa uživatelů"; $_lang['admin.users.groups.adminusers.help']="umožnit správu uživatelů";
          $_lang['admin.users.groups.admingroups']="Správa skupin"; $_lang['admin.users.groups.admingroups.help']="umožnit správu skupin";
          $_lang['admin.users.groups.admincontent']="Správa obsahu"; $_lang['admin.users.groups.admincontent.help']="umožnit vstup do správy obsahu";
          $_lang['admin.users.groups.adminsection']="Pracovat se sekcemi"; $_lang['admin.users.groups.adminsection.help']="umožnit práci se sekcemi";
          $_lang['admin.users.groups.admincategory']="Pracovat s kategoriemi"; $_lang['admin.users.groups.admincategory.help']="umožnit práci s kategoriemi";
          $_lang['admin.users.groups.adminbook']="Pracovat s knihami"; $_lang['admin.users.groups.adminbook.help']="umožnit práci s knihami";
          $_lang['admin.users.groups.adminseparator']="Pracovat s oddělovači"; $_lang['admin.users.groups.adminseparator.help']="umožnit práci s oddělovači";
          $_lang['admin.users.groups.admingallery']="Pracovat s galeriemi"; $_lang['admin.users.groups.admingallery.help']="umožnit práci s galeriemi";
          $_lang['admin.users.groups.adminlink']="Pracovat s odkazy"; $_lang['admin.users.groups.adminlink.help']="umožnit práci s odkazy";
          $_lang['admin.users.groups.adminintersection']="Pracovat s rozcestníky"; $_lang['admin.users.groups.adminintersection.help']="umožnit práci s rozcestníky";
          $_lang['admin.users.groups.adminart']="Pracovat s články"; $_lang['admin.users.groups.adminart.help']="povolit přístup do správy článků";
          $_lang['admin.users.groups.adminallart']="Pracovat s cizími články"; $_lang['admin.users.groups.adminallart.help']="umožnit práci s články i od uživatelů na nižší úrovni";
          $_lang['admin.users.groups.adminchangeartauthor']="Měnit autora článku"; $_lang['admin.users.groups.adminchangeartauthor.help']="umožnit změnu autora článku";
          $_lang['admin.users.groups.adminpoll']="Pracovat s anketami"; $_lang['admin.users.groups.adminpoll.help']="umožnit práci s anketami";
          $_lang['admin.users.groups.adminpollall']="Pracovat s cizími anketami"; $_lang['admin.users.groups.adminpollall.help']="umožnit práci s anketami i od uživatelů na nižší úrovni";
          $_lang['admin.users.groups.adminbox']="Pracovat s boxy"; $_lang['admin.users.groups.adminbox.help']="umožnit práci s boxy";
          $_lang['admin.users.groups.adminconfirm']="Schvalovat články"; $_lang['admin.users.groups.adminconfirm.help']="povolit schvalování článků";
          $_lang['admin.users.groups.adminneedconfirm']="Články nutno schválit"; $_lang['admin.users.groups.adminneedconfirm.help']="články napsané členem této skupiny musí být před publikováním schváleny";
          $_lang['admin.users.groups.adminfman']="Souborový manažer"; $_lang['admin.users.groups.adminfman.help']="umožnit vstup do souborového manažera";
          $_lang['admin.users.groups.adminfmanlimit']="Práce pouze ve svém adresáři"; $_lang['admin.users.groups.adminfmanlimit.help']="umožnit práci pouze v adresáři <q>upload/uzivatelskejmeno/</q>";
          $_lang['admin.users.groups.adminfmanplus']="Pokročilý souborový manažer"; $_lang['admin.users.groups.adminfmanplus.help']="umožnit výstup z adresáře upload (pokud není zašrtnuta volba výše) a práci se serverovými skripty (!)";
          $_lang['admin.users.groups.adminhcmphp']="Povolit PHP kód"; $_lang['admin.users.groups.adminhcmphp.help']="povolit uživateli spouštění PHP kódu pomocí HCM modulů (!)";
          $_lang['admin.users.groups.adminbackup']="Zálohování a obnova databáze"; $_lang['admin.users.groups.adminbackup.help']="umožnit zálohování a obnovu databáze (!)";
          $_lang['admin.users.groups.adminmassemail']="Zasílání hromadných e-mailů"; $_lang['admin.users.groups.adminmassemail.help']="umožnit zasílání hromadných e-mailů";
          $_lang['admin.users.groups.adminbans']="Blokování IP adres"; $_lang['admin.users.groups.adminbans.help']="umožnit blokování IP adres";

      //users
      $_lang['admin.users.users']="Uživatelé";
        $_lang['admin.users.edituser']="Upravit uživatele";
        $_lang['admin.users.deleteuser']="Smazat uživatele";
        $_lang['admin.users.deleteuser.couldntdo']="Tohoto uživatele nelze odstranit.";
        $_lang['admin.users.functions']="Ostatní funkce";
        $_lang['admin.users.list']="Seznam uživatelů";
          $_lang['admin.users.list.p']="Uživatele upravíte kliknutím na jeho uživatelské jméno.";
          $_lang['admin.users.list.groupfilter']="Zobrazit pouze skupinu";
          $_lang['admin.users.list.totalusers']="Celkový počet uživatelů";
        $_lang['admin.users.move']="Přesouvání členů skupin";
          $_lang['admin.users.move.p']="Zde můžete přesunout všechny členy jedné skupiny do druhé. K této akci ale potřebujete být ve skupině s vyšší úrovní, než je úroveň zdrojové i cílové skupiny.";
          $_lang['admin.users.move.failed']="Členy skupiny nelze přesunout. Nedostatečné oprávnění.";
          $_lang['admin.users.move.same']="Zdrojová skupina je shodná s cílovou.";
          $_lang['admin.users.move.text1']="Přesunout všechny členy skupiny";
          $_lang['admin.users.move.text2']="do skupiny";
        $_lang['admin.users.edit.title']="Úprava / tvorba uživatele";
          $_lang['admin.users.edit.p']="Upravujete stávajícího nebo tvoříte nového uživatele. Povinné jsou pouze pole uživatelské jméno a e-mailová adresa. Pokud ale tvoříte nového uživatele, je nutné zadat i heslo (při upravování stávajícího uživatele heslo zadávejte pouze v případě, že jej chcete změnit).";
          $_lang['admin.users.edit.userexists']="uživatel se zvoleným jménem již existuje";
          $_lang['admin.users.edit.emailexists']="zvolená e-mailová adresa je již v systému zaregistrována";
          $_lang['admin.users.edit.badusername']="neplatné uživatelské jméno";
          $_lang['admin.users.edit.bademail']="e-mailová adresa nemá platný tvar";
          $_lang['admin.users.edit.passwordneeded']="při vytváření uživatele je nutné zadat heslo";


    /*-- other --*/
    $_lang['admin.other.p']="Vyberte si funkci, se kterou chcete pracovat.";
    $_lang['admin.other.backup.title']="Zálohování a obnova databáze";
      $_lang['admin.other.backup.backup']="Vytvoření nové zálohy";
      $_lang['admin.other.backup.backup.p']="Kliknutím na <q>Proveď</q> získáte soubor, ze kterého budete moci kdykoliv obnovit současný stav databáze.";
      $_lang['admin.other.backup.restore']="Obnovení dat ze stávající zálohy";
      $_lang['admin.other.backup.restore.p']="Pozor! Obnovení stavu databáze je nevratné (pokud nemáte aktuální zálohu).";
      $_lang['admin.other.backup.restore.notuploaded']="Nepodařilo se získat soubor zálohy (nebyl uploadován).";
      $_lang['admin.other.backup.restore.badextension']="Zvolený soubor nemá správnou příponu.";
      $_lang['admin.other.backup.restore.fileerror']="Zvolený soubor není platná záloha databáze nebo je poškozený.";
      $_lang['admin.other.backup.restore.queryerror']="Během obnovy nastala chyba a databáze bude pravděpodobně poškozená. Řešení: znovu nainstalujte databázi a použijte platnou zálohu.";
      $_lang['admin.other.backup.restore.badversion']="Záloha není kompatibilní s touto verzí systému.";
      $_lang['admin.other.backup.restore.success']="Databáze byla úspěšně obnovena. Pokračujte kliknutím na odkaz níže (budete se muset znovu přihlásit).";
    $_lang['admin.other.massemail.title']="Zaslání hromadného e-mailu";
      $_lang['admin.other.massemail.sender']="E-mail odesílatele";
      $_lang['admin.other.massemail.receivers']="Příjemci";
      $_lang['admin.other.massemail.ctype']="Typ obsahu";
      $_lang['admin.other.massemail.ctype.1']="Obyčejný text (text/plain)";
      $_lang['admin.other.massemail.ctype.2']="HTML kód (text/html)";
      $_lang['admin.other.massemail.text']="Obsah e-mailu";
      $_lang['admin.other.massemail.notext']="nebyl zadán obsah e-mailu";
      $_lang['admin.other.massemail.nosubject']="nebyl zadán předmět";
      $_lang['admin.other.massemail.badsender']="neplatná adresa odesílatele";
      $_lang['admin.other.massemail.noreceivers']="nebyli zvoleni žádní příjemci";
      $_lang['admin.other.massemail.send']="Hromadný e-mail byl odeslán *counter* příjemcům.";
      $_lang['admin.other.massemail.noreceiversfound']="Nebyli nalezeni žádní příjemci.";
    $_lang['admin.other.bans.title']="Blokování IP adres";
      $_lang['admin.other.bans.p']="Seznam blokovaných IP adres (jedna na řádek). Chcete-li blokovat určitý rozsah IP adres, zadejte pouze část adresy (například 127.0.1 když chcete blokovat adresy od 127.0.1.0 do 127.0.1.255).";
      $_lang['admin.other.bans.getuserip']="Zjistit IP adresy";


/*--- javascript ---*/
$_lang['javascript.confirm']="Opravdu chcete provést tuto akci?";
$_lang['javascript.alert.someempty']="Jedna nebo více položek formuláře nebylo vyplněno.";
$_lang['javascript.alert.toolong']="Vstup nemůže být delší.";



/*--- captcha ---*/
$_lang['captcha.input']="Kontrola";
$_lang['captcha.help']="tyto znaky přepište do pole kontrola";
$_lang['captcha.checkfailure']="chybně přepsané znaky z obrázku";



/*--- rss ---*/
$_lang['rss.linktitle']="RSS zdroj";
$_lang['rss.recentcomments']="Nejnovější komentáře";
$_lang['rss.recentposts']="Nejnovější příspěvky";
$_lang['rss.recentarticles']="Nejnovější články";



/*--- hcm ---*/
$_lang['hcm.player.alt']="Přehrávač vyžaduje nainstalovaný flash player.";
$_lang['hcm.mailform.text']="Zpráva";
$_lang['hcm.mailform.att']="Příloha";
$_lang['hcm.mailform.send']="Odeslat e-mail";
$_lang['hcm.mailform.sender']="Váš e-mail";
$_lang['hcm.mailform.info']="Tato e-mailová zpráva byla odeslána *time* ze stránek *url* počítačem *ip*.\nOdesílatel uvedl svou adresu jako: *sender*";
$_lang['hcm.mailform.msg.done']="Zpráva byla odeslána.";
$_lang['hcm.mailform.msg.failure']="Zpráva nebyla odeslána. Pravděpodobně jste nezadali platnou e-mailovou adresu nebo text zprávy.";
$_lang['hcm.mailform.msg.failure2']="Zprávu se nepodařilo odeslat.";
$_lang['hcm.poll.vote']="Hlasovat";
$_lang['hcm.poll.votes']="Počet hlasů";
$_lang['hcm.poll.locked']="hlasování skončilo";



/*--- misc ---*/
$_lang['errorlog.intro']="Během zpracovávání došlo k následujícím chybám:";
$_lang['category.noarts']="Tato kategorie neobsahuje žádné články.";
$_lang['gallery.noimages']="Tato galerie neobsahuje žádné obrázky.";
$_lang['imgprev.badimage']="Neplatny obrazek";

?>