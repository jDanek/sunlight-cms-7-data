<?php
 define('_indexroot','../');define('_administration','1');require(_indexroot."core/_core.php");_adminOutput();?>