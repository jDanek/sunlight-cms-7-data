<?php
 if(!defined('_core')){exit;}$output.="
<br />
<fieldset>
<legend>".$_lang['admin.other.backup.backup']."</legend>
<form action='remote/backup_db.php' method='post'>
<p>".$_lang['admin.other.backup.backup.p']."</p>
<input type='submit' value='".$_lang['global.do']."' />
</form>
</fieldset>
<br />

<fieldset>
<legend>".$_lang['admin.other.backup.restore']."</legend>
<form action='remote/restore_db.php' method='post' enctype='multipart/form-data'>
<p>".$_lang['admin.other.backup.restore.p']."</p>
<input type='file' name='backup' /> <input type='submit' value='".$_lang['global.do']."' onclick='return _sysconfirm();' />
</form>
</fieldset>
";?>
