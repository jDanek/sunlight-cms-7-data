<?php
 if(!defined('_core')){exit;}$mysqlver=mysql_get_server_info();if(mb_substr_count($mysqlver,"-")!=0){$mysqlver=mb_substr($mysqlver,0,strpos($mysqlver,"-"));}$software=getenv('SERVER_SOFTWARE');if(mb_strlen($software)>16){$software=substr($software,0,13)."...";}$output.="
<p>".$_lang['admin.index.p']."</p>

<div class='hr'><hr /></div>

<table class='hometable' cellspacing='15'>
<tr valign='top'>

<td width='159'>
<h2>".$_lang['admin.index.server']."</h2>
<p>
<strong>".$_lang['admin.index.server.url'].":</strong> ".getenv('SERVER_NAME')."<br />
<strong>".$_lang['admin.index.server.os'].":</strong> ".PHP_OS."<br />
<strong>".$_lang['admin.index.server.php'].":</strong> ".PHP_VERSION."<br />
<strong>".$_lang['admin.index.server.mysql'].":</strong> ".$mysqlver."<br />
<strong>".$_lang['admin.index.server.software'].":</strong> ".$software."
</p>
</td>

<td width='150'>
<h2>".$_lang['admin.index.system']."</h2>
<p>
<strong>".$_lang['admin.index.system.version'].":</strong> "._systemversion."<br />
<strong>".$_lang['admin.index.system.uptodate'].":</strong> <iframe src='http://sunlight-cms.net/feedback/version.php?ver="._systemversion."' id='versioncheck' frameborder='0' scrolling='no'></iframe><br />
<strong>".$_lang['admin.index.system.web'].":</strong> <a href='http://sunlight-cms.net/' target='_blank'>sunlight-cms.net</a>

</p>
</td>

"._condReturn(_adminintro!="","<td>"._parseHCM(_adminintro)."</td>")."

</tr>
</table>
";?>
