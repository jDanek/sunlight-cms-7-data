<?php
 if(!defined('_core')){exit;}$sysgroups_array=array(1,2,3);$msg=0;if(_loginright_admingroups){if(isset($_GET['newgroup'])){$newid=_getNewID("groups");mysql_query("INSERT INTO `"._mysql_prefix."-groups` (id,title,level,icon) VALUES ($newid,'".$_lang['global.newitem']."',0,'')");$msg=1;}}if(_loginright_admingroups){$groups="<table><tr><td><strong>".$_lang['global.name']."</strong></td><td><strong>".$_lang['admin.users.groups.members']."</strong></td><td><strong>".$_lang['global.action']."</strong></td></tr>";$query=mysql_query("SELECT id,title,icon,blocked,level FROM `"._mysql_prefix."-groups` ORDER BY level DESC");while($item=mysql_fetch_array($query)){$membercounter=mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-users` WHERE `group`=".$item['id']),0);$groups.="
  <tr>
  <td><a href='index.php?p=users-editgroup&amp;id=".$item['id']."' title='".$item['level']."'"._condReturn($item['blocked']==1," class='invisible'").">"._condReturn(in_array($item['id'],$sysgroups_array),"<img src='images/icons/limit.gif' alt='inf' class='icon' title='".$_lang['global.limited']."' />")."<strong>".$item['title']."</strong></a></td>
  <td>"._condReturn($item['icon']!="","<img src='"._indexroot."usericons/".$item['icon']."' alt='icon' class='groupicon' /> ").$item['title']._condReturn($item['id']!=2," (".$membercounter.")")."</td>
  <td><a href='index.php?p=users-delgroup&amp;id=".$item['id']."' title='".$_lang['global.delete']."'><img src='images/icons/delete.gif' alt='del' class='icon' /></a></td>
  </tr>";}$groups.="</table>";}else{$groups="";}switch($msg){case 1:$message=_formMessage(1,$_lang['global.done']);break;case 2:$message=_formMessage(2,$_lang['admin.users.groups.specialgroup.delnotice']);break;case 3:$message=_formMessage(3,$_lang['global.disallowed']);break;default:$message="";break;}$output.="
<p>".$_lang['admin.users.p']."</p>

".$message."

<table class='widetable'>
<tr valign='top'>

  "._condReturn(_loginright_adminusers,"
  <td"._condReturn(_loginright_admingroups," style='width: 40%;' class='rbor'").">
  <h2>".$_lang['admin.users.users']."</h2>
  <p class='bborder'><a href='index.php?p=users-edit'><img src='images/icons/new.gif' alt='new' class='icon' />".$_lang['global.create']."</a></p>

  <div class='lpad'>

    <form action='index.php' method='get' name='edituserform'"._jsCheckForm("edituserform",array("id")).">
    <input type='hidden' name='p' value='users-edit' />
    <strong>".$_lang['admin.users.edituser']."</strong><br /><input type='text' name='id' class='inputsmall' />
    <input type='submit' value='".$_lang['global.continue']."' />
    </form><br />

    <form action='index.php' method='get' name='deleteuserform'"._jsCheckForm("deleteuserform",array("id")).">
    <input type='hidden' name='p' value='users-delete' />
    <strong>".$_lang['admin.users.deleteuser']."</strong><br /><input type='text' name='id' class='inputsmall' />
    <input type='submit' value='".$_lang['global.do']."' onclick='return _sysconfirm();' />
    </form><br />
    
    <strong>".$_lang['admin.users.functions']."</strong>
    <ul>
    <li><a href='index.php?p=users-list'>".$_lang['admin.users.list']."</a></li>
    <li><a href='index.php?p=users-move'>".$_lang['admin.users.move']."</a></li>
    </ul>
  
  </div>
  
  </td>
  ")."


  "._condReturn(_loginright_admingroups,"<td>
  <h2>".$_lang['admin.users.groups']."</h2>
  <p class='bborder'><a href='index.php?p=users&amp;newgroup'><img src='images/icons/new.gif' alt='new' class='icon' />".$_lang['global.create']."</a></p>
  ".$groups."
  </td>
  ")."


</tr>
</table>
";?>
