<?php
 if(!defined('_core')){exit;}if(isset($_POST['text'])){$text=stripslashes($_POST['text']);$subject=stripslashes($_POST['subject']);$sender=$_POST['sender'];if(isset($_POST['receivers'])){$receivers=$_POST['receivers'];}else{$receivers=array();}$ctype=$_POST['ctype'];$errors=array();if($text==""){$errors[]=$_lang['admin.other.massemail.notext'];}if(@count($receivers)==0){$errors[]=$_lang['admin.other.massemail.noreceivers'];}if($subject==""){$errors[]=$_lang['admin.other.massemail.nosubject'];}if(!_validateEmail($sender)){$errors[]=$_lang['admin.other.massemail.badsender'];}if(count($errors)==0){$groups="";$counter=0;$groups_total=count($receivers);foreach($receivers as$item){$groups.="`group`=".intval($item);$counter++;if($counter!=$groups_total){$groups.=" OR ";}}$query=mysql_query("SELECT id FROM `"._mysql_prefix."-users` WHERE massemail=1 AND (".$groups.")");$counter=0;$packet_id=0;$receivers_packets=array();while($item=mysql_fetch_array($query)){$receivers_packets[$packet_id][]=$item['id'];if($counter==10){$counter=0;$packet_id++;}else{$counter++;}}if($ctype==1){$ctype="text/plain";}else{$ctype="text/html";}$headers="Content-Type: ".$ctype."; charset=utf-8\n"._condReturn(_mailerusefrom,"From: ".mb_substr($sender,0,mb_strpos($sender,"@"))." <".$sender.">","Reply-To: ".$sender."")."\n";$done=0;foreach($receivers_packets as$packet){$emails="";$emails_counter=0;foreach($packet as$item){$email=mysql_fetch_array(mysql_query("SELECT email FROM `"._mysql_prefix."-users` WHERE id=".$item));$emails.=$email['email'].",";$emails_counter++;}$emails=trim($emails,",");if(@mail(null,$subject,$text,"Bcc: ".$emails."\n".$headers)){$done+=$emails_counter;}}if($done!=0){$output.=_formMessage(1,str_replace("*counter*",$done,$_lang['admin.other.massemail.send']));$_POST=array();}else{$output.=_formMessage(2,$_lang['admin.other.massemail.noreceiversfound']);}}else{$output.=_formMessage(2,_eventList($errors,'errors'));}}$group_select="<select name='receivers[]' multiple='multiple' class='selectbig'>";$query=mysql_query("SELECT id,title FROM `"._mysql_prefix."-groups` WHERE id!=2 ORDER BY level DESC");while($item=mysql_fetch_array($query)){$group_select.="<option value='".$item['id']."'>".$item['title']." (".mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-users` WHERE `group`=".$item['id']." AND massemail=1"),0).")</option>\n";}$group_select.="</select>";$output.="
<br />
<form action='index.php?p=other-massemail' method='post'>
<table>

<tr>
<td class='rpad'><strong>".$_lang['admin.other.massemail.sender']."</strong></td>
<td><input type='text' name='sender'"._restoreValue("sender")." class='inputbig' /></td>
</tr>

<tr>
<td class='rpad'><strong>".$_lang['posts.subject']."</strong></td>
<td><input type='text' name='subject' class='inputbig'"._restoreValue("subject")." /></td>
</tr>

<tr valign='top'>
<td class='rpad'><strong>".$_lang['admin.other.massemail.receivers']."</strong></td>
<td>".$group_select."</td>
</tr>

<tr>
<td class='rpad'><strong>".$_lang['admin.other.massemail.ctype']."</strong></td>
<td>
  <select name='ctype' class='selectbig'>
  <option value='1'>".$_lang['admin.other.massemail.ctype.1']."</option>
  <option value='2'"._condReturn(isset($_POST['ctype'])and$_POST['ctype']==2," selected='selected'").">".$_lang['admin.other.massemail.ctype.2']."</option>
  </select>
</td>
</tr>

<tr valign='top'>
<td class='rpad'><strong>".$_lang['admin.other.massemail.text']."</strong></td>
<td><textarea name='text' class='areabig' rows='9' cols='94'>"._restoreValue("text",null,true)."</textarea></td>
</tr>

<tr><td></td>
<td><input type='submit' value='".$_lang['global.send']."' /></td>
</tr>

</table>
</form>
";?>
