<?php
 if(!defined('_core')){exit;}function _tmp_unavailableright($name){if(mb_substr($name,0,1)!="-"){$_negations=array("adminfmanlimit","adminneedconfirm");if(!in_array($name,$_negations)){return!constant('_loginright_'.$name);}else{return constant('_loginright_'.$name);}}else{return true;}}$levelconflict=false;$sysgroups_array=array(1,2);$unregistered_useable=array("postcomments","artrate","pollvote");$continue=false;if(isset($_GET['id'])){$id=intval($_GET['id']);$query=mysql_query("SELECT * FROM `"._mysql_prefix."-groups` WHERE id=".$id);if(mysql_num_rows($query)!=0){$query=mysql_fetch_array($query);$systemitem=in_array($query['id'],$sysgroups_array);if(_loginright_level>$query['level']){$continue=true;}else{$levelconflict=true;}}}if($continue){$rights_array=array("changeusername","postcomments","unlimitedpostaccess","artrate","pollvote","-".$_lang['admin.users.groups.adminrights'],"administration","adminsettings","adminusers","admingroups","adminfman","adminfmanlimit","adminfmanplus","adminhcmphp","adminbackup","adminmassemail","adminbans","-".$_lang['admin.users.groups.admincontentrights'],"admincontent","adminconfirm","adminneedconfirm","adminart","adminallart","adminchangeartauthor","adminsection","admincategory","adminbook","adminseparator","admingallery","adminlink","adminintersection","adminpoll","adminpollall","adminbox");$rights="";foreach($rights_array as$item){if(($id==2 and!in_array($item,$unregistered_useable))or($item{0}!="-"and _tmp_unavailableright($item))){continue;}if($item{0}!="-"){$rights.="
        <tr>
        <td><strong>".$_lang['admin.users.groups.'.$item]."</strong></td>
        <td><input type='checkbox' name='$item' value='1'"._checkboxActivate($query[$item])._inputDisable($id!=1)." /></td>
        <td class='lpad'>".$_lang['admin.users.groups.'.$item.'.help']."</td>
        </tr>
        ";}else{$rights.="</table></fieldset><fieldset><legend>".mb_substr($item,1)."</legend><table>";}}if(isset($_POST['title'])){$title=_safeStr(_htmlStr(trim($_POST['title'])));if($title==""){$title=$_lang['global.novalue'];}if($id!=2){$icon=_safeStr(_htmlStr(trim($_POST['icon'])));}if($id>2){$blocked=_checkboxLoad("blocked");}mysql_query("UPDATE `"._mysql_prefix."-groups`SET title='".$title."' WHERE id=".$id);if($id!=2){mysql_query("UPDATE `"._mysql_prefix."-groups`SET icon='".$icon."' WHERE id=".$id);}if($id>2){$level=intval($_POST['level']);if($level>_loginright_level){$level=_loginright_level-1;}if($level>=10000){$level=9999;}if($level<0){$level=0;}mysql_query("UPDATE `"._mysql_prefix."-groups`SET level=".$level." WHERE id=".$id);mysql_query("UPDATE `"._mysql_prefix."-groups`SET blocked=".$blocked." WHERE id=".$id);}if($id!=1){foreach($rights_array as$item){if(($id==2 and!in_array($item,$unregistered_useable))or _tmp_unavailableright($item)){continue;}mysql_query("UPDATE `"._mysql_prefix."-groups` SET ".$item."="._checkboxLoad($item)." WHERE id=".$id);}}define('_tmp_redirect','index.php?p=users-editgroup&id='.$id.'&saved');}$output.="
  <p class='bborder'>".$_lang['admin.users.groups.editp']."</p>
  "._condReturn(isset($_GET['saved']),_formMessage(1,$_lang['global.saved']))."
  "._condReturn($systemitem,_tmp_smallNote($_lang['admin.users.groups.specialgroup.editnotice']))."
  <form action='index.php?p=users-editgroup&amp;id=".$id."' method='post'>
  <table>

  <tr>
  <td><strong>".$_lang['global.name']."</strong></td>
  <td><input type='text' name='title' class='inputmedium' value='".$query['title']."' /></td>
  </tr>

  <tr>
  <td class='rpad'><strong>".$_lang['admin.users.groups.level']."</strong></td>
  <td><input type='text' name='level' class='inputmedium' value='".$query['level']."'"._inputDisable(!$systemitem)." /></td>
  </tr>
  
  "._condReturn($id!=2,"<tr><td><strong>".$_lang['admin.users.groups.icon']."</strong></td><td><input type='text' name='icon' class='inputmedium' value='".$query['icon']."' /></td></tr>")."

  <tr>
  <td class='rpad'><strong>".$_lang['admin.users.groups.blocked']."</strong></td>
  <td><input type='checkbox' name='blocked' value='1'"._checkboxActivate($query['blocked'])._inputDisable($id!=1 and$id!=2)." /></td>
  </tr>

  </table><br />

  <fieldset>
  <legend>".$_lang['admin.users.groups.commonrights']."</legend>
  <table>

  ".$rights."

  
  </table></fieldset><br />


  <br />
  <input type='submit' value='".$_lang['global.save']."' />&nbsp;&nbsp;<small>".$_lang['admin.content.form.thisid']." ".$id."</small>

  </form>
  ";}else{if($levelconflict==false){$output.=_formMessage(3,$_lang['global.badinput']);}else{$output.=_formMessage(3,$_lang['global.disallowed']);}}?>
