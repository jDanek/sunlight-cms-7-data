<?php
 if(!defined('_core')){exit;}$message="";$levelconflict=false;$continue=false;if(isset($_GET['id'])){$id=_safeStr(_anchorStr($_GET['id'],false));$query=mysql_query("SELECT id,`group`,username,blocked,email,avatar,icq,note FROM `"._mysql_prefix."-users` WHERE username='".$id."'");if(mysql_num_rows($query)!=0){$query=mysql_fetch_array($query);if(_levelCheck($query['id'])){$continue=true;}else{$levelconflict=true;}}}else{$continue=true;$id=null;$query=array("group"=>_defaultgroup,"username"=>"","blocked"=>0,"email"=>"@","avatar"=>"","icq"=>"","note"=>"");}$group_select='<select name="group"'._inputDisable(mb_strtolower(_loginname)!=mb_strtolower($query['username'])).'>';$gs_query=mysql_query("SELECT id,title,level FROM `"._mysql_prefix."-groups` WHERE id!=2 AND level<"._loginright_level." OR id="._loginright_group." ORDER BY level");if(mysql_num_rows($gs_query)!=0){while($item=mysql_fetch_array($gs_query)){if($item['id']==$query['group']){$selected=' selected="selected"';}else{$selected="";}$group_select.='<option value="'.$item['id'].'"'.$selected.'>'.$item['title'].'</option>';}}else{$group_select.="<option value='-1'># ".$_lang['global.nokit']."</option>";}$group_select.='</select>';if($continue){if(isset($_POST['username'])){$errors=array();$username=_safeStr(_anchorStr($_POST['username'],false));if(mb_strlen($username)>24){$username=mb_substr($username,0,24);}if($username==""){$errors[]=$_lang['admin.users.edit.badusername'];}if(mb_strtolower($username)==mb_strtolower($query['username'])){$username_change=false;}else{$username_change=true;if(mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-users` WHERE username='".$username."'"),0)!=0){$errors[]=$_lang['admin.users.edit.userexists'];}}$password=$_POST['password'];if($password!=""){$password=md5($password);}else{if($id!=null){$password=null;}else{$errors[]=$_lang['admin.users.edit.passwordneeded'];}}if(mb_strtolower($id)!=mb_strtolower(_loginname)){$group=intval($_POST['group']);$grouptest=mysql_query("SELECT level FROM `"._mysql_prefix."-groups` WHERE id=".$group);if(mysql_num_rows($grouptest)==0 or$group==2){$errors[]=$_lang['global.badinput'];}else{$grouptest=mysql_fetch_array($grouptest);if($grouptest['level']>=_loginright_level){$errors[]=$_lang['global.badinput'];}}}$email=trim($_POST['email']);if(!_validateEmail($email)){$errors[]=$_lang['admin.users.edit.bademail'];}if(mb_strtolower($email)!=mb_strtolower($query['email'])){if(mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-users` WHERE email='".$email."'"),0)!=0){$errors[]=$_lang['admin.users.edit.emailexists'];}}$email=_safeStr($email);$icq=intval(str_replace("-","",$_POST['icq']));$avatar=_safeStr(_htmlStr(trim($_POST['avatar'])));if(!_validateURL($avatar)){$avatar="";}$note=_safeStr(_htmlStr(mb_substr(_wsTrim($_POST['note']),0,1024)));$blocked=_checkboxLoad("blocked");if(count($errors)==0){if($id!=null){if($password!=null){mysql_query("UPDATE `"._mysql_prefix."-users` SET password='".$password."' WHERE username='".$id."'");if(mb_strtolower($id)==mb_strtolower(_loginname)){$_SESSION[_sessionprefix."password"]=$password;}}if(mb_strtolower($id)!=mb_strtolower(_loginname)){mysql_query("UPDATE `"._mysql_prefix."-users` SET `group`=".$group." WHERE username='".$id."'");}mysql_query("UPDATE `"._mysql_prefix."-users` SET email='".$email."' WHERE username='".$id."'");mysql_query("UPDATE `"._mysql_prefix."-users` SET icq=".$icq." WHERE username='".$id."'");mysql_query("UPDATE `"._mysql_prefix."-users` SET avatar='".$avatar."' WHERE username='".$id."'");mysql_query("UPDATE `"._mysql_prefix."-users` SET note='".$note."' WHERE username='".$id."'");if(mb_strtolower($id)!=mb_strtolower(_loginname)){mysql_query("UPDATE `"._mysql_prefix."-users` SET blocked=".$blocked." WHERE username='".$id."'");}if($username_change==true){mysql_query("UPDATE `"._mysql_prefix."-users` SET username='".$username."' WHERE username='".$id."'");$id=$username;}define('_tmp_redirect','index.php?p=users-edit&r=1&id='.$id);}else{$newid=_getNewID("users");mysql_query("INSERT INTO `"._mysql_prefix."-users` (id,`group`,username,password,registertime,activitytime,blocked,wysiwyg,ip,email,avatar,icq,note) VALUES (".$newid.",".$group.",'".$username."','".$password."',".time().",0,".$blocked.",0,'','".$email."','".$avatar."',".$icq.",'".$note."')");define('_tmp_redirect','index.php?p=users-edit&r=2&id='.$username);}}else{$message=_eventList($errors,'errors');}}$messages_code="";if(isset($_GET['r'])){switch($_GET['r']){case 1:$messages_code.=_formMessage(1,$_lang['global.saved']);break;case 2:$messages_code.=_formMessage(1,$_lang['global.created']);break;}}if($message!=""){$messages_code.=_formMessage(2,$message);}$output.="
<p class='bborder'>".$_lang['admin.users.edit.p']."</p>
".$messages_code."
<form action='index.php?p=users-edit"._condReturn($id!=null,"&amp;id=".$id)."' method='post' name='userform'"._jsCheckForm("userform",_condReturn($id!=null,array("username","email"),array("username","email","password"))).">
<table>

<tr>
<td><strong>".$_lang['login.username']."</strong></td>
<td><input type='text' name='username' class='inputsmall' value='".$query['username']."' maxlength='24' /></td>
</tr>

<tr>
<td><strong>".$_lang['login.password']."</strong></td>
<td><input type='text' name='password' class='inputsmall' /></td>
</tr>

<tr>
<td><strong>".$_lang['login.blocked']."</strong></td>
<td><input type='checkbox' name='blocked' value='1'"._checkboxActivate($query['blocked'])._inputDisable(mb_strtolower(_loginname)!=mb_strtolower($query['username']))." /></td>
</tr>

<tr>
<td><strong>".$_lang['global.group']."</strong></td>
<td>".$group_select."</td>
</tr>

<tr>
<td><strong>".$_lang['global.email']."</strong></td>
<td><input type='text' name='email' class='inputsmall' value='".$query['email']."' /></td>
</tr>

<tr>
<td><strong>".$_lang['global.icq']."</strong></td>
<td><input type='text' name='icq' class='inputsmall' value='"._condReturn($query['icq']!=0,$query['icq'],"")."' /></td>
</tr>

<tr>
<td><strong>".$_lang['global.avatar']."</strong></td>
<td><input type='text' name='avatar' class='inputmedium' value='".$query['avatar']."' /></td>
</tr>

<tr valign='top'>
<td><strong>".$_lang['global.note']."</strong></td>
<td><textarea name='note' class='areasmall' rows='5' cols='33'>".$query['note']."</textarea></td>
</tr>

<tr><td></td>
<td><input type='submit' value='"._condReturn(isset($_GET['id']),$_lang['global.save'],$_lang['global.create'])."' /></td>
</tr>

</table>
</form>
";}else{if($levelconflict==false){$output.=_formMessage(3,$_lang['global.baduser']);}else{$output.=_formMessage(3,$_lang['global.disallowed']);}}?>
