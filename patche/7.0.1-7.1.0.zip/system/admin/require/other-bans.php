<?php
 if(!defined('_core')){exit;}$message="";if(isset($_POST['banned'])){$banned=explode("\n",$_POST['banned']);$banned=_arrayRemoveValue($banned,null);$new_banned=array();foreach($banned as$item){$item=explode(".",$item);$item=_arrayRemoveValue($item,null);foreach($item as$index=>$isub){$isub=intval(trim($isub));if($isub<0){$isub=0;}if($isub>255){$isub=255;}$item[$index]=$isub;}$new_banned[]=implode(".",$item);}$new_banned=trim(implode("\n",array_unique($new_banned)));mysql_query("UPDATE `"._mysql_prefix."-settings` SET val='".$new_banned."' WHERE var='banned'");define('_tmp_redirect','index.php?p=other-bans&saved');}if(isset($_GET['saved'])){$message=_formMessage(1,$_lang['global.saved']);}$output.="
<p class='bborder'>".$_lang['admin.other.bans.p']."</p>
".$message."
<form action='index.php?p=other-bans' method='post'>
<textarea arows='25' cols='94' class='areabig' name='banned'>"._banned."</textarea><br /><br />
<input type='submit' value='".$_lang['global.save']."' />
</form>

<div class='hr'><hr /></div><br />

<h2>".$_lang['admin.other.bans.getuserip']."</h2><br />
<form action='index.php?p=other-bans' method='post'>
".$_lang['global.user'].": <input type='text' name='user' class='inputsmall'"._restoreValue("user")." /> <input type='submit' value='".$_lang['global.do']."' />
</form>
";if(isset($_POST['user'])){$user=_anchorStr($_POST['user'],false);$query=mysql_query("SELECT ip,id FROM `"._mysql_prefix."-users` WHERE username='".$user."'");if(mysql_num_rows($query)!=0){$query=mysql_fetch_array($query);$ips=array();$iquery=mysql_query("SELECT DISTINCT ip FROM `"._mysql_prefix."-posts` WHERE author=".$query['id']);while($iip=mysql_fetch_array($iquery)){$ips[]=$iip['ip'];}if(!in_array($query['ip'],$ips)){$ips[]=$query['ip'];}foreach($ips as$ip){$output.=$ip."<br />";}}else{$output.=_formMessage(2,$_lang['global.baduser']);}}?>
