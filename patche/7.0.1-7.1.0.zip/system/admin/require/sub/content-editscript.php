<?php
 if(!defined('_core')){exit;}if(isset($_POST['title'])and$continue){$save_array=array(array("title",false,1,true),array("intersection",false,2,false),array("ord",false,3,false),array("visible",true,0,false),array("public",true,0,false),array("intersectionperex",false,0,true),array("content",false,_condReturn($type!=6,0,1),true));$save_array=array_merge($save_array,$custom_array);foreach($save_array as$item){if($item[1]==false){if(!isset($_POST[$item[0]])){$_POST[$item[0]]="0";}switch($item[2]){case 0:$val=_safeStr($_POST[$item[0]]);break;case 1:$val=_safeStr(_htmlStr($_POST[$item[0]]));break;case 2:$val=intval($_POST[$item[0]]);break;case 3:$val=floatval($_POST[$item[0]]);break;}}else{$val=_checkboxLoad($item[0]);}$skip=false;switch($item[0]){case"content":$val=_removePHP($val);break;case"intersection":if(mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-root` WHERE id=".$val." AND type=7"),0)==0 or$type==7){$val=-1;}break;case"title":$val=trim($val);if($val==""){$val=$_lang['global.novalue'];}break;case"var1":switch($type){case 2:if($val<1 or$val>4){$val=1;}break;case 5:if($val<=0 and$val!=-1){$val=1;}break;}break;case"var2":switch($type){case 2:case 3:case 5:if($val<=0){$val=1;}break;}break;case"var3":switch($type){case 5:if($val<=0){$val=1;}if($val>1024){$val=1024;}break;}break;case"delcomments":if($type==1 and$val==1){mysql_query("DELETE FROM `"._mysql_prefix."-posts` WHERE home=".$id." AND type=1");}break;case"delposts":if($type==3 and$val==1){mysql_query("DELETE FROM `"._mysql_prefix."-posts` WHERE home=".$id." AND type=3");}break;}if($skip!=true){if($item[3]==true){$quotes="'";}else{$quotes="";}mysql_query("UPDATE `"._mysql_prefix."-root` SET ".$item[0]."=".$quotes.$val.$quotes." WHERE id=".$id);}}define('_tmp_redirect','index.php?p=content-edit'.$type_array[$type].'&id='.$id.'&saved');}if($continue!=true){$output.=_formMessage(3,$_lang['global.badinput']);}else{$intersection_select="<select name='intersection' class='selectmedium'><option value='-1' class='special'>".$_lang['admin.content.form.intersection.none']."</option>";$isquery=mysql_query("SELECT id,title FROM `"._mysql_prefix."-root` WHERE type=7 ORDER BY ord");while($item=mysql_fetch_array($isquery)){if($item['id']==$query['intersection']){$selected=" selected='selected'";}else{$selected="";}$intersection_select.="<option value='".$item['id']."'".$selected.">"._cutStr($item['title'],22)."</option>";}$intersection_select.="</select>";if(isset($_GET['new'])){$query['title']="";$query['visible']=1;$query['ord']=1;}$output.=_tmp_wysiwyg();if($custom_settings!=""){$custom_settings="<span class='customsettings'>".$custom_settings."</span>";}$output.="
<p class='bborder'>".$_lang['admin.content.edit'.$type_array[$type].'.p']."</p>
"._condReturn(isset($_GET['saved']),_formMessage(1,$_lang['global.saved']."&nbsp;&nbsp;<small>("._formatTime(time()).")</small>"))."
<form action='index.php?p=content-edit".$type_array[$type]."&amp;id=".$id."' method='post'>
<table>

<tr>
<td class='rpad'><strong>".$_lang['admin.content.form.title']."</strong></td>
<td><input type='text' name='title' value='".$query['title']."' class='inputmedium' /></td>
</tr>

"._condReturn($type!=7,"<tr><td class='rpad'><strong>".$_lang['admin.content.form.intersection']."</strong></td><td>".$intersection_select."</td></tr>")."

<tr>
<td class='rpad'><strong>".$_lang['admin.content.form.ord']."</strong></td>
<td><input type='text' name='ord' value='".$query['ord']."' class='inputmedium' /></td>
</tr>

"._condReturn($type!=4,"
<tr>
<td class='rpad'><strong>".$_lang['admin.content.form.intersectionperex']."</strong></td>
<td><input type='text' name='intersectionperex' value='"._htmlStr($query['intersectionperex'])."' class='inputbig' /></td>
</tr>

<tr valign='top'>
<td class='rpad'><strong>".$_lang['admin.content.form.'._condReturn($type!=6,'content','url')]."</strong> <a href='"._indexroot._linkRoot($query['id'])."' target='_blank'><img src='images/icons/loupe.gif' alt='prev' /></a></td>
<td>
"._condReturn($type!=6,"<textarea name='content' rows='25' cols='94' class='areabig' id='wysiwygtarget'>"._htmlStr($query['content'])."</textarea>","<input type='text' name='content' value='".$query['content']."' class='inputbig' />")."
</td>
</tr>

<tr>
<td class='rpad'><strong>".$_lang['admin.content.form.settings']."</strong></td>
<td>
<label><input type='checkbox' name='visible' value='1'"._checkboxActivate($query['visible'])." /> ".$_lang['admin.content.form.visible']."</label>&nbsp;&nbsp;
<label><input type='checkbox' name='public' value='1'"._checkboxActivate($query['public'])." /> ".$_lang['admin.content.form.public']."</label>&nbsp;&nbsp;
".$custom_settings."
</td>
</tr>
")."


<tr><td></td><td><br />
<input type='submit' value='".$_lang['global.savechanges']."' />&nbsp;&nbsp;<small>".$_lang['admin.content.form.thisid']." ".$query['id']."</small>
</td></tr>

</table>
</form>
";}?>
