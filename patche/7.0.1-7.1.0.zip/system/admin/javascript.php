<?php
 define('_indexroot','../');require(_indexroot."core/_core.php");?>


//select all
function _sys_fman_selectall(number){
var tmp=1;
  while(tmp<=number){
  eval("document.filelist.f"+tmp+".checked=true;");
  tmp+=1;
  }
return false;
}

//deselect all
function _sys_fman_deselectall(number){
var tmp=1;
  while(tmp<=number){
  eval("document.filelist.f"+tmp+".checked=false;");
  tmp+=1;
  }
return false;
}

//move selected
function _sys_fman_moveselected(){
newdir=prompt("<?php echo$_lang['admin.fman.selected.move.prompt'];?>:", '');
if(newdir!="" && newdir!=null){
document.filelist.action.value='move';
document.filelist.param.value=newdir;
document.filelist.submit();
}
}

//delete selected
function _sys_fman_deleteselected(){
if(confirm("<?php echo$_lang['admin.fman.selected.delete.confirm'];?>")){
document.filelist.action.value='deleteselected';
document.filelist.submit();
}
}

//add selected to gallery
function _sys_fman_addselectedtogallery(){
galid=prompt("<?php echo$_lang['admin.fman.selected.addtogallery.getid'];?>:", '');
if(galid!="" && galid!=null){
document.filelist.action.value='addtogallery';
document.filelist.param.value=galid;
document.filelist.submit();
}
}

//upload files
var totalfiles=1;

function _sys_addfile(){
  if(totalfiles!=128){
  totalfiles=totalfiles+1;
  document.getElementById('f'+totalfiles).innerHTML=document.getElementById('f'+totalfiles).innerHTML+"<br /><input type='file' name='f"+totalfiles+"' /> <a href=\"#\" onclick=\"return _sys_removefile("+totalfiles+");\"><?php echo$_lang['global.cancel'];?></a>";
  }
  else{
  alert('<?php echo$_lang['admin.fman.upload.nomorefiles'];?>');
  }
return false;
}

function _sys_removefile(id){
document.getElementById('f'+id).innerHTML="";
return false;
}