<?php
 if(!defined('_core')){exit;}$message="";$query=mysql_fetch_array(mysql_query("SELECT * FROM `"._mysql_prefix."-users` WHERE id="._loginid));if($query['icq']==0){$query['icq']="";}if($query['avatar']==""){$avatarsrc=_indexroot."templates/"._template."/images/system/no-avatar.gif";}else{$avatarsrc=$query['avatar'];}if(_loginright_administration){$admin="
  <fieldset>
  <legend>".$_lang['mod.settings.admin']."</legend>
  <label><input type='checkbox' name='wysiwyg' value='1'"._checkboxActivate($query['wysiwyg'])." /> ".$_lang['mod.settings.admin.wysiwyg']."</label>
  </fieldset>
  ";}else{$admin="";}if(isset($_POST['username'])){$errors=array();if(_checkboxLoad("selfremove")){$selfremove_confirm=md5($_POST['selfremove-confirm']);if($selfremove_confirm==$query['password']){if(_loginid!=0){_deleteUser(_loginid);$_SESSION=array();session_destroy();define('_tmp_redirect','index.php?m=login&r=4');$errors[]=0;}else{$errors[]=$_lang['mod.settings.selfremove.imposible'];}}else{$errors[]=$_lang['mod.settings.selfremove.failed'];}}$username=_safeStr(_anchorStr($_POST['username'],false));if($username==""){$errors[]=$_lang['admin.users.edit.badusername'];}$usernamechange=false;if($username!=_loginname){if(_loginright_changeusername==1 or mb_strtolower($username)==mb_strtolower(_loginname)){if(mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-users` WHERE username='".$username."' AND username!='"._loginname."'"),0)==0){$usernamechange=true;}else{$errors[]=$_lang['admin.users.edit.userexists'];}}else{$errors[]=$_lang['mod.settings.usernamechangedenied'];}}$email=trim($_POST['email']);if(!_validateEmail($email)){$errors[]=$_lang['admin.users.edit.bademail'];}if(mb_strtolower($email)!=mb_strtolower($query['email'])){if(mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-users` WHERE email='".$email."'"),0)!=0){$errors[]=$_lang['admin.users.edit.emailexists'];}}$email=_safeStr($email);$massemail=_checkboxLoad("massemail");if(_loginright_administration){$wysiwyg=_checkboxLoad("wysiwyg");}$icq=intval(str_replace("-","",$_POST['icq']));$avatar=_safeStr(_htmlStr(trim($_POST['avatar'])));if(!_validateURL($avatar)){$avatar="";}$passwordchange=false;if($_POST['currentpassword']!=""or$_POST['newpassword']!=""or$_POST['newpassword-confirm']!=""){$currentpassword=md5($_POST['currentpassword']);$newpassword=$_POST['newpassword'];$newpassword_confirm=$_POST['newpassword-confirm'];if($currentpassword==$query['password']){if($newpassword==$newpassword_confirm){if($newpassword!=""){$passwordchange=true;$newpassword=md5($newpassword);}else{$errors[]=$_lang['mod.settings.badnewpass'];}}else{$errors[]=$_lang['mod.settings.newpassnosame'];}}else{$errors[]=$_lang['mod.settings.badcurrentpass'];}}$note=_safeStr(_htmlStr(_wsTrim(mb_substr($_POST['note'],0,1024))));if(count($errors)==0){mysql_query("UPDATE `"._mysql_prefix."-users` SET email='".$email."' WHERE id="._loginid);mysql_query("UPDATE `"._mysql_prefix."-users` SET avatar='".$avatar."' WHERE id="._loginid);mysql_query("UPDATE `"._mysql_prefix."-users` SET icq='".$icq."' WHERE id="._loginid);mysql_query("UPDATE `"._mysql_prefix."-users` SET massemail=".$massemail." WHERE id="._loginid);mysql_query("UPDATE `"._mysql_prefix."-users` SET note='".$note."' WHERE id="._loginid);if(_loginright_administration){mysql_query("UPDATE `"._mysql_prefix."-users` SET wysiwyg=".$wysiwyg." WHERE id="._loginid);}if($passwordchange==true){mysql_query("UPDATE `"._mysql_prefix."-users` SET password='".$newpassword."' WHERE id="._loginid);$_SESSION[_sessionprefix."password"]=$newpassword;}if($usernamechange==true){mysql_query("UPDATE `"._mysql_prefix."-users` SET username='".$username."' WHERE id="._loginid);}define('_tmp_redirect','index.php?m=settings&saved');}else{$message=_formMessage(2,_eventList($errors,'errors'));}}if(isset($_GET['saved'])){$message=_formMessage(1,$_lang['global.saved']);}if(_template_autoheadings==1){$module="<h1>".$_lang['mod.settings']."</h1>";}else{$module="";}$module.="
<p><a href='index.php?m=profile&amp;id="._loginname."'>".$_lang['mod.settings.profilelink']." &gt;</a></p>
<p>".$_lang['mod.settings.p']."</p>".$message."
<form action='index.php?m=settings' method='post' name='setform'>

"._jsLimitLength(1024,"setform","note")."

  <fieldset>
  <legend>".$_lang['mod.settings.userdata']."</legend>
  <table class='profiletable'>

  <tr>
  <td><strong>".$_lang['login.username']."</strong> <span class='forced'>*</span></td>
  <td><input type='text' name='username' value='"._loginname."' class='inputsmall' maxlength='24' />"._condReturn(!_loginright_changeusername,"<span class='hint'>(".$_lang['mod.settings.userdata.namechangenote'].")</span>")."</td>
  </tr>

  <tr>
  <td><strong>".$_lang['global.email']."</strong> <span class='forced'>*</span></td>
  <td><input type='text' name='email' value='".$query['email']."' class='inputsmall'/> <label><input type='checkbox' name='massemail' value='1'"._checkboxActivate($query['massemail'])." /> ".$_lang['mod.settings.userdata.massemail']."</label></td>
  </tr>

  <tr>
  <td><strong>".$_lang['global.icq']."</strong></td>
  <td><input type='text' name='icq' value='".$query['icq']."' class='inputsmall' /></td>
  </tr>
  
  <tr valign='top'>
  <td><strong>".$_lang['global.note']."</strong></td>
  <td><textarea name='note' class='areasmall' rows='5' cols='33'>".$query['note']."</textarea></td>
  </tr>
  
  <tr><td></td>
  <td>"._getPostFormControls("setform","note")."</td>
  </tr>

  </table>
  </fieldset>


  <fieldset>
  <legend>".$_lang['mod.settings.avatar']."</legend>
  <input type='text' name='avatar' class='inputmedium' value='".$query['avatar']."' /><br /><br />
    <table>
    <tr valign='top'>
    <td width='106'><div class='avatar'><img src='".$avatarsrc."' alt='avatar' /></div></td>
    <td><p class='minip'>".$_lang['mod.settings.avatar.hint']."</p></td>
    </tr>
    </table>
  </fieldset>


  <fieldset>
  <legend>".$_lang['mod.settings.password']."</legend>
  <p class='minip'>".$_lang['mod.settings.password.hint']."</p>
  <table class='profiletable'>

  <tr>
  <td><strong>".$_lang['mod.settings.password.current']."</strong></td>
  <td><input type='password' name='currentpassword' class='inputsmall' /></td>
  </tr>

  <tr>
  <td><strong>".$_lang['mod.settings.password.new']."</strong></td>
  <td><input type='password' name='newpassword' class='inputsmall' /></td>
  </tr>

  <tr>
  <td><strong>".$_lang['mod.settings.password.new']." (".$_lang['global.check'].")</strong></td>
  <td><input type='password' name='newpassword-confirm' class='inputsmall' /></td>
  </tr>

  </table>
  </fieldset>
  
  ".$admin."
  
  <fieldset>
  <legend>".$_lang['mod.settings.selfremove']."</legend>
  <label><input type='checkbox' name='selfremove' value='1' onclick='if(checked==true){return _sysconfirm();}' /> ".$_lang['mod.settings.selfremove.box']."</label><br /><br />
  <div class='lpad'><strong>".$_lang['mod.settings.selfremove.confirm'].":</strong> <input type='password' name='selfremove-confirm' class='inputsmall' /></div>
  </fieldset>

<br />
<input type='submit' value='".$_lang['mod.settings.submit']."' />
<input type='reset' value='".$_lang['global.reset']."' onclick='return _sysconfirm();' />

</form>
";?>
