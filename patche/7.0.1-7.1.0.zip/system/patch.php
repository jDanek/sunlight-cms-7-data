<?php

require("access.php");
$connection=@mysql_connect($server, $user, $password);
define('_mysql_prefix', $prefix);
@mysql_query("set names `utf8`");
$db=@mysql_select_db($database);

  //check
  if(!$connection or !$db){
  echo "Pripojeni k databazi se nezdarilo.<hr /><pre>".mysql_error()."</pre>";
  exit;
  }
  
//patch
@mysql_query("ALTER TABLE `".$prefix."-groups` ADD `blocked` BOOL NOT NULL AFTER `icon` ;");
if(mysql_error()==null){echo "Databaze byla aktualizovana.";}else{echo "Nastala chyba.<hr /><pre>".mysql_error()."</pre>"; exit;}
if(!@unlink("patch.php")){echo " Smazte soubor <em>patch.php</em> ze serveru!";}

?>