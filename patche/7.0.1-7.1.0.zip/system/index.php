<?php
 define('_indexroot','./');require(_indexroot."core/_core.php");_indexOutput();?>