<?php
 define('_indexroot','../');define('_tmp_customheader','Content-type: application/javascript; charset=utf-8');require(_indexroot."core/_core.php");?>


//system alert message
function _sysalert(id){

  switch(id){
  case 1: text="<?php echo$_lang['javascript.alert.someempty'];?>"; break;
  case 2: text="<?php echo$_lang['javascript.alert.toolong'];?>"; break;
  }

alert(text);
}

//confirm dialog
function _sysconfirm(){
return confirm("<?php echo$_lang['javascript.confirm'];?>");
}

//replace at symbol
function _sysmai_lto(f) {
	var re = "<?php echo _atreplace;?>";
	var addr = f.innerHTML.replace(re,'@');
	f.href = 'mai'+'lt'+'o:'+addr;
	return true;
}

//add smiley
function _sysaddsmiley(fid, aid, sid){
eval("document."+fid+"."+aid+".value=document."+fid+"."+aid+".value+' *'+"+sid+"+'* ';");
return false;
}

//add bbcode tags
function _sysaddbbcode(fid, aid, tag){
eval("document."+fid+"."+aid+".value=document."+fid+"."+aid+".value+'['+'"+tag+"'+'][/'+'"+tag+"'+']';");
return false;
}

//hideshow
function _syshse(id, trigger) {
var el=document.getElementById(id);
if(el.style.display=='none' || el.style.display==''){el.style.display='block'; trigger.className="hs_opened";}
else{el.style.display='none'; trigger.className="hs_closed";}
return false;
}