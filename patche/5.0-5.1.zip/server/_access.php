<?php



$c_server="server";		//MySQL server
$c_user="uzivatel";			//MySQL uzivatel
$c_password="heslo";			//MySQL heslo
$c_database="databaze";	//MySQL databaze
$c_tabprefix="sunlight";	//Prefix jmen tabulek



?>
