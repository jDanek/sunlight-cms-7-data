<?php

/*--------------filtrovani znaku, anchor funkce--------------*/
function anchor($input, $lower=true){

  /*odstraneni diakritiky*/
  $input=strtr($input, " �����؝����������������������������ž�����", "-eeEErRtTzZuUuUuUiIoOaAsSdDyYcCnNaAlLlLrRoO");

  /*odfiltrovani nepovolenych znaku*/
  $letterpos=0;
  $output="";
  while($letterpos<=strlen($input)){
  $letter=substr($input, $letterpos, 1);
  if($letter=="A" or $letter=="a" or $letter=="B" or $letter=="b" or $letter=="C" or $letter=="c" or $letter=="D" or $letter=="d" or $letter=="E" or $letter=="e" or $letter=="F" or $letter=="f" or $letter=="G" or $letter=="g" or $letter=="H" or $letter=="h" or $letter=="I" or $letter=="i" or $letter=="J" or $letter=="j" or $letter=="K" or $letter=="k" or $letter=="L" or $letter=="l" or $letter=="M" or $letter=="m" or $letter=="N" or $letter=="n" or $letter=="O" or $letter=="o" or $letter=="P" or $letter=="p" or $letter=="Q" or $letter=="q" or $letter=="R" or $letter=="r" or $letter=="S" or $letter=="s" or $letter=="T" or $letter=="t" or $letter=="U" or $letter=="u" or $letter=="V" or $letter=="v" or $letter=="W" or $letter=="w" or $letter=="X" or $letter=="x" or $letter=="Y" or $letter=="y" or $letter=="Z" or $letter=="z" or $letter=="0" or $letter=="1" or $letter=="2" or $letter=="3" or $letter=="4" or $letter=="5" or $letter=="6" or $letter=="7" or $letter=="8" or $letter=="9" or $letter=="_" or $letter=="-" or $letter=="."){$output.=$letter;}
  $letterpos++;
  }
  
  /*odfiltrovani opakovanych pomlcek, podtrzitek a tecek*/
  $count=0;
  $double="--";
  while($count!=3){
  
  $letterpos=0;
  while($letterpos<=strlen($output)){
  $letter=substr($output, $letterpos, 2);
    if($letter==$double){
    $output_start=substr($output, 0, $letterpos+1);
    $output_end=substr($output, $letterpos+2);
    $output=$output_start.$output_end;
    $letterpos-=1;
    }
  $letterpos++;
  }
  
  /*odstraneni pomlcek, podtrzitek a tecek ze zacatku a konce*/
  $letterpos=0;
  while($letterpos<=strlen($output)){
  if(substr($output, 0, 1)=="-"){$output=substr($output, 1); $letterpos=-1;}
  if(substr($output, -1)=="-"){$output=substr($output, 0, -1); $letterpos=-1;}
  if(substr($output, 0, 1)=="_"){$output=substr($output, 1); $letterpos=-1;}
  if(substr($output, -1)=="_"){$output=substr($output, 0, -1); $letterpos=-1;}
  if(substr($output, 0, 1)=="."){$output=substr($output, 1); $letterpos=-1;}
  if(substr($output, -1)=="."){$output=substr($output, 0, -1); $letterpos=-1;}
  $letterpos++;
  }

  $count++;
  if($count==1){$double="__";}
  else{$double="..";}
  
  }

if($lower==true){$output=strtolower($output);}
return $output;

}




/*--------------formatovani data--------------*/
function formatdate($timestamp){
$output=@getdate($timestamp);
if(strlen($output['hours'])==1){$output['hours']="0".$output['hours'];}
if(strlen($output['minutes'])==1){$output['minutes']="0".$output['minutes'];}
$output=$output['mday'].".".$output['mon'].". ".$output['year']." ".$output['hours'].":".$output['minutes'];
return $output;
}




/*--------------generovani hesla--------------*/
function password_generate($length=8){
$output="";
for($index=0; $index<$length; $index++){
   if(mt_rand(0,1)==0){
   $symbol=chr(mt_rand(97,122));
   if(mt_rand(0,1)==0){$symbol=strtoupper($symbol);}
   }
   else{
   $symbol=mt_rand(0,9);
   }
$output.=$symbol;
}
return $output;
}




/*--------------validace emailu--------------*/
function validate_email($email) {

  if (!ereg("^[^@]{1,64}@[^@]{1,255}$", $email)) {
    return false;
  }
  $email_array = explode("@", $email);
  $local_array = explode(".", $email_array[0]);
  for ($i = 0; $i < sizeof($local_array); $i++) {
     if (!ereg("^(([A-Za-z0-9!#$%&#038;'*+/=?^_`{|}~-][A-Za-z0-9!#$%&#038;'*+/=?^_`{|}~\.-]{0,63})|(\"[^(\\|\")]{0,62}\"))$", $local_array[$i])) {
      return false;
    }
  }
  if (!ereg("^\[?[0-9\.]+\]?$", $email_array[1])) {
    $domain_array = explode(".", $email_array[1]);
    if (sizeof($domain_array) < 2) {
        return false;
    }
    for ($i = 0; $i < sizeof($domain_array); $i++) {
      if (!ereg("^(([A-Za-z0-9][A-Za-z0-9-]{0,61}[A-Za-z0-9])|([A-Za-z0-9]+))$", $domain_array[$i])) {
        return false;
      }
    }
  }
  return true;
}




/*--------------cteni z jazykoveho souboru--------------*/
$langfile=root."modules/language/".langfile.".slf";
define('langfile_load', true);

if(!file_exists($langfile)){
$langfile_default=root."modules/language/default.slf";
  if(!file_exists($langfile_default)){
  define('langfile_load', false);
  }
  else{
  $langfile=$langfile_default;
  }
}

  if(langfile_load==true){define('langfilecontent', file_get_contents($langfile));}
  else{define('langfilecontent', "");}

function lang($input, $param='r', $langfile=langfilecontent, $failed=langfile_load){

  /*vyhledani fraze v souboru*/
  if($failed!=false){
  $langfile=langfilecontent;
  $startpos=strpos($langfile, "<$input>");
  $endpos=strpos($langfile, "</$input>");
  }

  /*nalezeni a vypis*/
  if($startpos!==false and $endpos!==false and $failed!=false){
  $start=$startpos+strlen("<$input>");
  $end=$endpos-$start;
  $langfile=substr($langfile, $start, $end);
     switch($param){
     case 'r': return $langfile; break;
     case 'e': echo $langfile; break;
      }
  }
  else{
     $lerror="LANGFILE_ERROR";
     switch($param){
     case 'r': return $lerror; break;
     case 'e': echo $lerror; break;
     }
  }

}




/*--------------zkracovani textu--------------*/
function textpart($input){
$length=strlen($input);
$input=substr($input, 0, 256);
$input=strip_tags($input);
if($length>128){$input=$input."...";}
return $input;
}




/*--------------zpracovani refereru--------------*/
function referer($return=false){
$referer=$_SERVER['HTTP_REFERER'];
  if($referer!=""){
  if($return==false){echo $referer;}else{return $referer;}
  }
  else{
  if($return==false){echo root;}else{return root;}
  }
}




/*--------------generovani bezpecnostniho kodu--------------*/

  /*generovani*/
  function code_generate($length) {
  $x=0;
  $code="";
  while($x!=$length){
  $code.=mt_rand(1, 9);
  $x++;
  }
  $code=$code;
  
  $x=0;
  $output="";
  while($x!=$length){
  $output.=strrev(ord(substr($code, $x, 1))+4)."-";
  $x++;
  }
  $output=substr($output, 0, strlen($output)-1);
  $output=strrev($output);
  return $output;
  }

  /*dekodovani*/
  function code_decode($input){
  $input=strrev($input);
  $tokenize=strtok($input, "-");
  while($tokenize){
  $step=chr(strrev($tokenize)-4);
  $output.=$step;
  $tokenize=strtok("-");
  }

  return $output;
  }




/*--------------rozpoznani nebezpecne pripony--------------*/
function isscript($input){
$output=true;
$input=trim($input);
$dotpos=strrpos($input, ".")+1;
$pripona=substr($input, $dotpos);
$pripona=strtolower($pripona);

switch($pripona){
case "php":
case "php3":
case "php4":
case "php5":
case "phtml":
case "py":
case "asp":
case "cgi":
case "shtml":
case "htaccess":
break;
default: $output=false; break;
}

return $output;
}




/*--------------rozpoznani editovatelneho souboru--------------*/
function istextfile($input){
$input=trim($input);
$dotpos=strrpos($input, ".")+1;
$pripona=substr($input, $dotpos);
$pripona=strtolower($pripona);

switch($pripona){
case "php":
case "php3":
case "php4":
case "php5":
case "phtml":
case "py":
case "asp":
case "cgi":
case "shtml":
case "htaccess":
case "txt":
case "html":
case "htm":
case "xhtml":
case "inc":
case "ini":
case "cfg":
case "xml":
case "inf":
case "css":
case "diz":
case "nfo":
$output=true; break;
default: $output=false; break;
}
return $output;
}




/*--------------funkce pro rewrite--------------*/

  function artrewrite($id, $anchor, $addroot=true){
    if($addroot==true){$rroot=root;}else{$rroot="";}
    if(rewrite==1){$anchor=anchor($anchor); return $rroot.artprefix."-$anchor-$id".rewritesuffix;}
    else{return $rroot."index.php?art=$id";}
  }

  function secrewrite($id, $anchor, $addroot=true){
    if($addroot==true){$rroot=root;}else{$rroot="";}
    if(rewrite==1){$anchor=anchor($anchor); return $rroot.secprefix."-$anchor-$id".rewritesuffix;}
    else{return $rroot."index.php?str=$id&tp=1";}
  }

  function catrewrite($id, $anchor, $page, $addroot=true){
    if($addroot==true){$rroot=root;}else{$rroot="";}
    if(rewrite==1){$anchor=anchor($anchor); return $rroot.catprefix."-$anchor-$id-$page".rewritesuffix;}
    else{return $rroot."index.php?str=$id&tp=2&s=$page";}
  }

  function bookrewrite($id, $anchor, $page, $addroot=true){
    if($addroot==true){$rroot=root;}else{$rroot="";}
    if(rewrite==1){$anchor=anchor($anchor); return $rroot.bookprefix."-$anchor-$id-$page".rewritesuffix;}
    else{return $rroot."index.php?str=$id&tp=3&s=$page";}
  }

  function modrewrite($name, $nogetparams=false, $separator=false, $addroot=true){
    if($addroot==true){$rroot=root;}else{$rroot="";}
    if(rewrite==1){if($separator==true and $nogetparams==false){$separator="?";}else{$separator="";} return $rroot.modprefix."-$name".rewritesuffix.$separator;}
    else{if($separator==true and $nogetparams==false){$separator="&";}else{$separator="";} if($nogetparams==true){$params="";}else{$params="?str=$name&tp=4";} return $rroot."index.php$params".$separator;}
  }
  
    function modrewrite_getinputs($name){
    if(rewrite!=1){return "<input type='hidden' name='str' value='$name'><input type='hidden' name='tp' value='4'>";}
    }



/*--------------parsovani WM Code--------------*/
function parsebbcode($input){

$output="##".$input;

$bbcode_tags=array(
"b",
"i",
"u",
"q",
"pre",
"red",
"green",
"blue",
"big",
"small",
"url",
"email",
"img"
);

$bbcode_num=0;
while($bbcode_num<=count($bbcode_tags)-1){

$bbcode_tag=$bbcode_tags[$bbcode_num];
$bbcode_starttag="[$bbcode_tag]";
$bbcode_endtag="[/$bbcode_tag]";

  /*lokalizace tagu, spocitani vyskytu*/
  $tcount=substr_count($output, $bbcode_starttag);
  $tparserrepeat=0;

  while($tparserrepeat<$tcount){

  $tpos1=strpos($output, $bbcode_starttag);
  $tpos2=strpos($output, $bbcode_endtag);
  $tparam=substr($output, $tpos1+strlen($bbcode_starttag), $tpos2-($tpos1+strlen($bbcode_starttag)));
  $tparam=trim($tparam);
  $tresult="";

  if($tpos1 and $tpos2 and $tpos2>$tpos1 and $tparam!=""){

  $start=substr($output, 0, $tpos1);
  $end=substr($output, $tpos2+strlen($bbcode_endtag));

  /*parsovani tagu*/

  switch($bbcode_num){

  //b
  case 0:
  $tresult=$start."<b>".$tparam."</b>".$end;
  break;

  //i
  case 1:
  $tresult=$start."<i>".$tparam."</i>".$end;
  break;

  //u
  case 2:
  $tresult=$start."<u>".$tparam."</u>".$end;
  break;

  //q
  case 3:
  $tresult=$start."<q>".$tparam."</q>".$end;
  break;

  //pre
  case 4:
  $tresult=$start."<pre>".$tparam."</pre>".$end;
  break;

  //red
  case 5:
  $tresult=$start."<font style='color:red;'>".$tparam."</font>".$end;
  break;

  //green
  case 6:
  $tresult=$start."<font style='color:green;'>".$tparam."</font>".$end;
  break;

  //blue
  case 7:
  $tresult=$start."<font style='color:blue;'>".$tparam."</font>".$end;
  break;

  //big
  case 8:
  $tresult=$start."<big>".$tparam."</big>".$end;
  break;

  //small
  case 9:
  $tresult=$start."<small>".$tparam."</small>".$end;
  break;

  //url
  case 10:
  $tresult=$start."<a href='".$tparam."' target='_blank' rel='nofollow'>$tparam</a>".$end;
  break;

  //email
  case 11:
  $tresult=$start."<a href='mailto:".$tparam."'>$tparam</a>".$end;
  break;

  //img
  case 12:
  $tresult=$start."<img src='".$tparam."'>".$end;
  break;

  }

  if($tresult!=""){$output=$tresult;}

  }
  else{
    /*odfiltrovani neuzavreneho tagu*/
    if($tpos1){
    $start=substr($output, 0, $tpos1);
    $end=substr($output, $tpos1+strlen($bbcode_starttag));
    $output=$start.$end;
    }
  }

  $tparserrepeat++;
  }

$bbcode_num++;
}


  /*navraceni vystupu parseru*/
  $output=substr($output, 2);
  return $output;
}




/*--------------filtrovani WM Code--------------*/
function stripbbcode($input){

$output="##".$input;

$bbcode_tags=array("b", "i", "u", "q", "pre", "red", "green", "blue", "big", "small", "url", "email", "img");

$bbcode_num=0;
while($bbcode_num<=count($bbcode_tags)-1){

$bbcode_tag=$bbcode_tags[$bbcode_num];
$bbcode_starttag="[$bbcode_tag]";
$bbcode_endtag="[/$bbcode_tag]";

  /*lokalizace tagu, spocitani vyskytu*/
  $tcount=substr_count($output, $bbcode_starttag);
  $tparserrepeat=0;

  while($tparserrepeat<$tcount){

  $tpos1=strpos($output, $bbcode_starttag);
  $tpos2=strpos($output, $bbcode_endtag);
  $tparam=substr($output, $tpos1+strlen($bbcode_starttag), $tpos2-($tpos1+strlen($bbcode_starttag)));
  $tparam=trim($tparam);
  $tresult="";

  if($tpos1 and $tpos2 and $tpos2>$tpos1 and $tparam!=""){

  $start=substr($output, 0, $tpos1);
  $end=substr($output, $tpos2+strlen($bbcode_endtag));

  /*filtrovani tagu*/
  $tresult=$start.$tparam.$end;
  $output=$tresult;

  }
  else{
    /*odfiltrovani neuzavreneho tagu*/
    if($tpos1){
    $start=substr($output, 0, $tpos1);
    $end=substr($output, $tpos1+strlen($bbcode_starttag));
    $output=$start.$end;
    }
  }

  $tparserrepeat++;
  }

$bbcode_num++;
}


  /*navraceni vystupu parseru*/
  $output=substr($output, 2);
  return $output;
}




/*--------------parsovani HCM modulu--------------*/
function parsehcm($input, $php=false){

  $output="##".$input;

  $hcm_array=array(
  "latart",
  "latart2",
  "latcom",
  "mailform",
  "php",
  "gallery",
  "gallery2",
  "randimg",
  "randtxt",
  "filelist",
  "mrart",
  "mrart2",
  "randart",
  "randart2",
  "fulltextbox",
  "vote",
  "brart",
  "brart2",
  "menu",
  "loginform",
  "latcom2",
  "sbox",
  "gallery3"
  );

  $hcm_num=0;
  while($hcm_num<=count($hcm_array)-1){
  
  $hcm_item=$hcm_array[$hcm_num];
  $hcm_item_starttag="[hcm:$hcm_item]";
  $hcm_item_endtag="[/hcm:$hcm_item]";

    /*lokalizace tagu, spocitani vyskytu*/
    $mcount=substr_count($output, $hcm_item_starttag);
    $mparserrepeat=0;

    while($mparserrepeat<$mcount){

    $mpos1=strpos($output, $hcm_item_starttag);
    $mpos2=strpos($output, $hcm_item_endtag);
    $mparam=substr($output, $mpos1+strlen($hcm_item_starttag), $mpos2-($mpos1+strlen($hcm_item_starttag)));
    $mparam=trim($mparam);
    $mresult="";

    if($mpos1 and $mpos2 and $mpos2>$mpos1 and ($mparam!="" or $hcm_num==14 or $hcm_num==18 or $hcm_num==19)){

    $start=substr($output, 0, $mpos1);
    $end=substr($output, $mpos2+strlen($hcm_item_endtag));
    
    /*parsovani modulu*/
    
    switch($hcm_num){


      //latart
      case 0:
      $mparam=explode(",", $mparam);
      if(count($mparam)==1 or count($mparam)==2){
      $mparam[0]=intval($mparam[0]);
      if(isset($mparam[1])){$mparam[1]=intval($mparam[1]); $catlimit=" AND home=".$mparam[1];}else{$catlimit="";}
      
        $mdata=@mysql_query("SELECT title,perex,id,author,date,opened,comment FROM `".tabprefix."-articles` WHERE visible=1".futureart."$catlimit ORDER BY ".artorder." DESC LIMIT 0, ".$mparam[0]);
        $mtmp="";

        while($mitem=@mysql_fetch_array($mdata)){

          /*spocitani komentaru*/
          $a_commentscount_code="";
          if($mitem['comment']==1 and comment==1){
          $a_commentscount=@mysql_query("SELECT id FROM `".tabprefix."-comments` WHERE home=".$mitem['id']." AND tp=2");
          $a_commentscount_number=0;
          while($commentscount_item=@mysql_fetch_array($a_commentscount)){
          $a_commentscount_number++;
          }
          $a_commentscount_code=" | <b>".lang('article_totalcomments', 'r').":</b> $a_commentscount_number";
          }

          /*zobrazeni poctu precteni*/
          if(artread==1){$a_opened_code=" | <b>".lang('article_read', 'r').":</b> ".$mitem['opened']."x";}
          else{$a_opened_code="";}

          $author=@mysql_fetch_array(@mysql_query("SELECT name,realname FROM `".tabprefix."-users` WHERE id=".$mitem['author']));
          if(artrealname==1 and $author['realname']!=""){$authoranchor=$author['realname'];}
          else{$authoranchor=$author['name'];}

          $mitem['date']=formatdate($mitem['date']);
          $mtmp.="<a href='".artrewrite($mitem['id'], $mitem['title'])."' class='title'>".$mitem['title']."</a><p class='cperex'>".$mitem['perex']."</p><div class='cinfo'><b>".lang('article_author', 'r').":</b> $authoranchor | <b>".lang('article_posted', 'r').":</b> ".$mitem['date'].$a_opened_code.$a_commentscount_code."</div>\n";
        }
        $mresult=$start."<div>".$mtmp."</div>".$end;
      
      }
      break;
      
      
      //latart2
      case 1:
      $mparam=explode(",", $mparam);
      if(count($mparam)==1 or count($mparam)==2){
      $mparam[0]=intval($mparam[0]);
      if(isset($mparam[1])){$mparam[1]=intval($mparam[1]); $catlimit=" AND home=".$mparam[1];}else{$catlimit="";}
      
        $mtmp="";
        $mdata=@mysql_query("SELECT title,id FROM `".tabprefix."-articles` WHERE visible=1".futureart."$catlimit ORDER BY ".artorder." DESC LIMIT 0, ".$mparam[0]);
        while($mitem=@mysql_fetch_array($mdata)){
        $mtmp.="<a href='".artrewrite($mitem['id'], $mitem['title'])."'><b>".$mitem['title']."</b></a><hr size='1' color='".linecolor."'>\n";
        }
        $mresult=$start."<div>".$mtmp."</div>".$end;
      
      }
      break;

      
      //latcom
      case 2:
      $mparam=intval($mparam);

          $comments=@mysql_query("SELECT tp,home,author,text,subject FROM `".tabprefix."-comments` ORDER BY id DESC LIMIT $mparam");
          $mtmp="";
          while($comment=@mysql_fetch_array($comments)){

          /*spocitani komentaru*/
          $commentscount=@mysql_query("SELECT id FROM `".tabprefix."-comments` WHERE home=".$comment['home']." AND tp=".$comment['tp']);
          $commentscount_number=0;
          while(@mysql_fetch_array($commentscount)){
          $commentscount_number++;
          }

          /*sestaveni odkazu*/
          $failed=false;

          switch($comment['tp']){

          case 1:
          $title=@mysql_query("SELECT anchor FROM `".tabprefix."-menu` WHERE id=".$comment['home']);
          $title=@mysql_fetch_array($title);
          $title=$title['anchor'];
          $id=$comment['home'];
          $linkhref=secrewrite($id, $title);
          break;

          case 2:
          $title=@mysql_query("SELECT title FROM `".tabprefix."-articles` WHERE id=".$comment['home'].futureart);
          $title=@mysql_fetch_array($title);
          $title=$title['title'];
          $id=$comment['home'];
          $linkhref=artrewrite($id, $title);
          break;

          }

          $c_author=@mysql_query("SELECT name FROM `".tabprefix."-users` WHERE id=".$comment['author']);
          $c_author=@mysql_fetch_array($c_author);
          $c_author=$c_author['name'];

          $mtmp.="<a href='$linkhref' class='title'>$title: ".$comment['subject']."</a><p class='cperex'>".textpart(stripbbcode($comment['text']))."</p><div class='cinfo'><b>".lang('article_totalcomments', 'r').":</b> $commentscount_number | <b>".lang('article_composter', 'r').":</b> $c_author</div>\n";


      }

      $mresult=$start."<div>".$mtmp."</div>".$end;
      break;
      
      
      //mailform
      case 3:
      $mparam=addslashes($mparam);
      $mparam=strtr($mparam, "@", "#");
      $codecheck=code_generate(4);

      $mtmp="
      <form action='".root."modules/hcm/mailform.php' method='post'>
      <input type='hidden' name='receiver' value='$mparam'>
      <input type='hidden' name='codecheckr' value='$codecheck'>

      <table>

      <tr>
      <td><b>".lang('global_youremail', 'r')."</b></td>
      <td><input type='text' name='sender' class='ifieldsmall' maxlength='128' value='@'></td>
      </tr>

      <tr>
      <td><b>".lang('global_subject', 'r')."</b></td>
      <td><input type='text' name='subject' class='ifieldsmall' maxlength='128'></td>
      </tr>

      <tr valign='top'>
      <td><b>".lang('global_text', 'r')."</b></td>
      <td><textarea name='text' class='itextsmall' id='itext'></textarea></td>
      </tr>

      <tr>
      <td><b>".lang('global_codecheck', 'r')."</b></td>
      <td><input type='text' name='codecheck' maxlength='8' class='ifieldsmall'></td>
      </tr>

      <tr>
      <td></td>
      <td><img src='".root."modules/kod.php?n=".$codecheck."' alt='".lang('global_codecheckhelp', 'r')."' title='".lang('global_codecheckhelp', 'r')."' class='codecheck'></td>
      </tr>

      <tr>
      <td></td>
      <td>
      <input type='submit' value='".lang('global_send', 'r')."'>
      <input type='reset' value='".lang('global_reset', 'r')."'>
      </td>
      </tr>

      </table>
      </form>
      ";
      
      $mresult=$start."<div>".$mtmp."</div>".$end;
      break;
      
      
      //php
      case 4:
      if($php==true){
      eval($mparam);
      $mresult=$start.$end;
      }
      break;
      
      
      //gallery
      case 5:
      $mparam=@explode(",",$mparam);

      $dir=trim($mparam[0]);
      $width=intval(trim($mparam[1]));
      
      if(count($mparam)==2 and $width>0 and $width<=2048){
      
        if(substr($dir, -1)!="/"){$dir.="/";}
        if(file_exists(root.$dir) and is_dir(root.$dir)){


        /*nacteni obsahu slozky*/
        $handle=opendir(root.$dir);
        $gcode_array=array();
        $index=0;

        while($item=readdir($handle)){
        $suffix=strrpos($item, ".");
        $suffix=substr($item, $suffix+1);
        $suffix=strtolower($suffix);
        if($item=="." or $item==".." or is_dir(root.$dir.$item) or !($suffix=="jpeg" or $suffix=="jpg" or $suffix=="gif" or $suffix=="png")){continue;}
        $gcode_array[$index]=$item;
        $index++;
        }
        closedir($handle);

        /*sestaveni vystupu*/
        $index=0;
        $gcode="";
        natsort($gcode_array);
        reset($gcode_array);
        while($index<=count($gcode_array)-1){
        $item_size=ceil(filesize(root.$dir.$gcode_array[$index])/1024);
        $gcode.="<a href='".root."$dir".$gcode_array[$index]."' target='_blank' title='".$gcode_array[$index]." | ".$item_size."kB'><img src='".root."modules/hcm/galimg.php?f=$dir".$gcode_array[$index]."&w=$width'></a>\n";
        $index++;
        }
        
        
        }

        $mresult=$start."<div>".$gcode."</div>".$end;
        
      }
      break;
      
      
      //gallery2
      case 6:
      if(substr($mparam, -1)!="/"){$mparam.="/";}
      $dir=$mparam;
      $fulldir=$dir."full/";
      $prevdir=$dir."prev/";

      if(file_exists(root.$dir) and is_dir(root.$dir) and file_exists(root.$fulldir) and is_dir(root.$fulldir) and file_exists(root.$prevdir) and is_dir(root.$prevdir)){

      /*nacteni obsahu slozky*/
      $gcode_array=array();
      $index=0;
      $handle=opendir(root.$fulldir);
      
      while($item=readdir($handle)){
      $suffix=strrpos($item, ".");
      $suffix=substr($item, $suffix+1);
      $suffix=strtolower($suffix);
      if($item=="." or $item==".." or is_dir(root.$fulldir.$item) or !($suffix=="jpeg" or $suffix=="jpg" or $suffix=="gif" or $suffix=="png") or !file_exists(root.$prevdir.$item)){continue;}
      $gcode_array[$index]=$item;
      $index++;
      }
      closedir($handle);

      /*sestaveni vystupu*/
      $index=0;
      $gcode="";
      natsort($gcode_array);
      reset($gcode_array);
      while($index<=count($gcode_array)-1){
      $item_size=ceil(filesize(root.$fulldir.$gcode_array[$index])/1024);
      $gcode.="<a href='".root."$fulldir".$gcode_array[$index]."' target='_blank' title='".$gcode_array[$index]." | ".$item_size."kB'><img src='".root."$prevdir".$gcode_array[$index]."' border='0'></a>\n";
      $index++;
      }
      

      }

      $mresult=$start."<div>".$gcode."</div>".$end;
      break;
      
      
      //randimg
      case 7:
      if(substr($mparam, -1)!="/"){$mparam.="/";}
      $dir=$mparam;

      if(file_exists(root.$dir) and is_dir(root.$dir)){

      $handle=opendir(root.$dir);
      $items=array();
      $itemnum=0;
      while($item=readdir($handle)){
      $suffix=strrpos($item, ".");
      $suffix=substr($item, $suffix+1);
      $suffix=strtolower($suffix);
      if($item=="." or $item==".." or is_dir(root.$item) or !($suffix=="jpeg" or $suffix=="jpg" or $suffix=="gif" or $suffix=="png")){continue;}
      $items[$itemnum]=$item;
      $itemnum++;
      }

      closedir($handle);

      if($itemnum!=0){
      $ritem=array_rand($items);
      $rname=$items[$ritem];
      $mresult=$start."<img src='".root.$dir.$rname."'>".$end;
      }

      }
      break;
      
      
      //randtxt
      case 8:
      if(substr($mparam, -1)!="/"){$mparam.="/";}
      $dir=$mparam;

      if(file_exists(root.$dir) and is_dir(root.$dir)){

      $handle=opendir(root.$dir);
      $items=array();
      $itemnum=0;
      while($item=readdir($handle)){
      $suffix=strrpos($item, ".");
      $suffix=substr($item, $suffix+1);
      $suffix=strtolower($suffix);
      if($item=="." or $item==".." or is_dir(root.$item) or !($suffix=="txt" or $suffix=="html" or $suffix=="htm")){continue;}
      $items[$itemnum]=$item;
      $itemnum++;
      }

      closedir($handle);

      if($itemnum!=0){
      $ritem=array_rand($items);
      $rname=$items[$ritem];
      $rcontent=file_get_contents(root.$dir.$rname);
      $mresult=$start.$rcontent.$end;
      }

      }
      break;
      
      
      //filelist
      case 9:
      if(substr($mparam, -1)!="/"){$mparam.="/";}
      $dir=$mparam;

      if(file_exists(root.$dir) and is_dir(root.$dir)){
      $mtmp="";
      $handle=opendir(root.$mparam);
      $filelist=array();
      $index=0;
        while($item=readdir($handle)){
        if($item=="." or $item==".." or is_dir(root.$dir.$item)){continue;}
        $filelist[$index]=$item;
        $index++;
        }
        
        natsort($filelist);
        reset($filelist);
        foreach($filelist as $item){
        $mtmp.="<a href='".root.$dir.$item."' target='_blank'>$item</a><br>\n";
        }

      closedir($handle);
      }

      $mresult=$start."<div>".$mtmp."</div>".$end;
      break;
      
      
      //mrart
      case 10:
      $mparam=explode(",", $mparam);
      if(count($mparam)==1 or count($mparam)==2){
      $mparam[0]=intval($mparam[0]);
      if(isset($mparam[1])){$mparam[1]=intval($mparam[1]); $catlimit=" AND home=".$mparam[1];}else{$catlimit="";}

        $mdata=@mysql_query("SELECT title,perex,id,author,date,opened,comment FROM `".tabprefix."-articles` WHERE opened!=0 AND visible=1".futureart."$catlimit ORDER BY opened DESC LIMIT 0, ".$mparam[0]);
        $mtmp="";
        while($mitem=@mysql_fetch_array($mdata)){

          /*spocitani komentaru*/
          $a_commentscount_code="";
          if($mitem['comment']==1 and comment==1){
          $a_commentscount=@mysql_query("SELECT id FROM `".tabprefix."-comments` WHERE home=".$mitem['id']." AND tp=2");
          $a_commentscount_number=0;
          while($commentscount_item=@mysql_fetch_array($a_commentscount)){
          $a_commentscount_number++;
          }
          $a_commentscount_code=" | <b>".lang('article_totalcomments', 'r').":</b> $a_commentscount_number";
          }

          /*zobrazeni poctu precteni*/
          if(artread==1){$a_opened_code=" | <b>".lang('article_read', 'r').":</b> ".$mitem['opened']."x";}
          else{$a_opened_code="";}

          $author=@mysql_fetch_array(@mysql_query("SELECT name,realname FROM `".tabprefix."-users` WHERE id=".$mitem['author']));
          if(artrealname==1 and $author['realname']!=""){$authoranchor=$author['realname'];}
          else{$authoranchor=$author['name'];}

          $mitem['date']=formatdate($mitem['date']);
          $mtmp.="<a href='".artrewrite($mitem['id'], $mitem['title'])."' class='title'>".$mitem['title']."</a><p class='cperex'>".$mitem['perex']."</p><div class='cinfo'><b>".lang('article_author', 'r').":</b> $authoranchor | <b>".lang('article_posted', 'r').":</b> ".$mitem['date'].$a_opened_code.$a_commentscount_code."</div>\n";

        }
        $mresult=$start."<div>".$mtmp."</div>".$end;
      
      }
      break;
      
      
      //mrart2
      case 11:
      $mparam=explode(",", $mparam);
      if(count($mparam)==1 or count($mparam)==2){
      $mparam[0]=intval($mparam[0]);
      if(isset($mparam[1])){$mparam[1]=intval($mparam[1]); $catlimit=" AND home=".$mparam[1];}else{$catlimit="";}

        $mtmp="";
        $mdata=@mysql_query("SELECT title,id FROM `".tabprefix."-articles` WHERE opened!=0 AND visible=1".futureart."$catlimit ORDER BY opened DESC LIMIT 0, ".$mparam[0]);
        while($mitem=@mysql_fetch_array($mdata)){
        $mtmp.="<a href='".artrewrite($mitem['id'], $mitem['title'])."'><b>".$mitem['title']."</b></a><hr size='1' color='".linecolor."'>\n";
        }
        $mresult=$start."<div>".$mtmp."</div>".$end;

      }
      break;
      
      
      //randart
      case 12:
      $mparam=explode(",", $mparam);
      if(count($mparam)==1 or count($mparam)==2){
      $mparam[0]=intval($mparam[0]);
      if(isset($mparam[1])){$mparam[1]=intval($mparam[1]); $catlimit=" AND home=".$mparam[1];}else{$catlimit="";}

        $mdata=@mysql_query("SELECT title,perex,id,author,date,opened,comment FROM `".tabprefix."-articles` WHERE visible=1".futureart."$catlimit ORDER BY RAND() DESC LIMIT 0, ".$mparam[0]);
        $mtmp="";
        while($mitem=mysql_fetch_array($mdata)){

          /*spocitani komentaru*/
          $a_commentscount_code="";
          if($mitem['comment']==1 and comment==1){
          $a_commentscount=@mysql_query("SELECT id FROM `".tabprefix."-comments` WHERE home=".$mitem['id']." AND tp=2");
          $a_commentscount_number=0;
          while($commentscount_item=@mysql_fetch_array($a_commentscount)){
          $a_commentscount_number++;
          }
          $a_commentscount_code=" | <b>".lang('article_totalcomments', 'r').":</b> $a_commentscount_number";
          }

          /*zobrazeni poctu precteni*/
          if(artread==1){$a_opened_code=" | <b>".lang('article_read', 'r').":</b> ".$mitem['opened']."x";}
          else{$a_opened_code="";}

          $author=@mysql_fetch_array(@mysql_query("SELECT name,realname FROM `".tabprefix."-users` WHERE id=".$mitem['author']));
          if(artrealname==1 and $author['realname']!=""){$authoranchor=$author['realname'];}
          else{$authoranchor=$author['name'];}

          $mitem['date']=formatdate($mitem['date']);
          $mtmp.="<a href='".artrewrite($mitem['id'], $mitem['title'])."' class='title'>".$mitem['title']."</a><p class='cperex'>".$mitem['perex']."</p><div class='cinfo'><b>".lang('article_author', 'r').":</b> $authoranchor | <b>".lang('article_posted', 'r').":</b> ".$mitem['date'].$a_opened_code.$a_commentscount_code."</div>\n";

        }
        $mresult=$start."<div>".$mtmp."</div>".$end;

      }
      break;
      
      
      //randart2
      case 13:
      $mparam=explode(",", $mparam);
      if(count($mparam)==1 or count($mparam)==2){
      $mparam[0]=intval($mparam[0]);
      if(isset($mparam[1])){$mparam[1]=intval($mparam[1]); $catlimit=" AND home=".$mparam[1];}else{$catlimit="";}

        $mtmp="";
        $mdata=@mysql_query("SELECT title,id FROM `".tabprefix."-articles` WHERE visible=1".futureart."$catlimit ORDER BY RAND() LIMIT 0, ".$mparam[0]);
        while($mitem=@mysql_fetch_array($mdata)){
        $mtmp.="<a href='".artrewrite($mitem['id'], $mitem['title'])."'><b>".$mitem['title']."</b></a><hr size='1' color='".linecolor."'>\n";
        }
        $mresult=$start."<div>".$mtmp."</div>".$end;

      }
      break;
      
      //fulltextbox
      case 14:
      include(root."modules/hcm/fulltextbox.php");
      $mresult=$start.$mtmp.$end;
      break;
      
      //vote
      case 15:
      $mparam=@explode(",",$mparam);
      if(count($mparam)==2 or count($mparam)==3){
      
        $vid=intval(trim($mparam[0]));
        $boxwidth=intval(trim($mparam[1])); if($boxwidth<100){$boxwidth=100;}
        if(isset($mparam[2])){$float=trim($mparam[2]);}else{$float="none";}
        if($float!="left" and $float!="right" and $float!="none"){$float="none";}

        $mtmp="";
        include(root."modules/hcm/vote.php");
        $mresult=$start.$mtmp.$end;
      
      }
      break;
      
      
      //brart
      case 16:
      $mparam=explode(",", $mparam);
      if(count($mparam)==1 or count($mparam)==2){
      $mparam[0]=intval($mparam[0]);
      if(isset($mparam[1])){$mparam[1]=intval($mparam[1]); $catlimit=" AND home=".$mparam[1];}else{$catlimit="";}

        $mdata=@mysql_query("SELECT title,perex,id,author,date,opened,comment FROM `".tabprefix."-articles` WHERE visible=1 AND rate_total!=0".futureart."$catlimit ORDER BY rate_total LIMIT 0, ".$mparam[0]);
        $mtmp="";
        while($mitem=@mysql_fetch_array($mdata)){

          /*spocitani komentaru*/
          $a_commentscount_code="";
          if($mitem['comment']==1 and comment==1){
          $a_commentscount=@mysql_query("SELECT id FROM `".tabprefix."-comments` WHERE home=".$mitem['id']." AND tp=2");
          $a_commentscount_number=0;
          while($commentscount_item=@mysql_fetch_array($a_commentscount)){
          $a_commentscount_number++;
          }
          $a_commentscount_code=" | <b>".lang('article_totalcomments', 'r').":</b> $a_commentscount_number";
          }

          /*zobrazeni poctu precteni*/
          if(artread==1){$a_opened_code=" | <b>".lang('article_read', 'r').":</b> ".$mitem['opened']."x";}
          else{$a_opened_code="";}

          $author=@mysql_fetch_array(@mysql_query("SELECT name,realname FROM `".tabprefix."-users` WHERE id=".$mitem['author']));
          if(artrealname==1 and $author['realname']!=""){$authoranchor=$author['realname'];}
          else{$authoranchor=$author['name'];}

          $mitem['date']=formatdate($mitem['date']);
          $mtmp.="<a href='".artrewrite($mitem['id'], $mitem['title'])."' class='title'>".$mitem['title']."</a><p class='cperex'>".$mitem['perex']."</p><div class='cinfo'><b>".lang('article_author', 'r').":</b> $authoranchor | <b>".lang('article_posted', 'r').":</b> ".$mitem['date'].$a_opened_code.$a_commentscount_code."</div>\n";

        }
        $mresult=$start."<div>".$mtmp."</div>".$end;

      }
      break;
      
      
      //brart2
      case 17:
      $mparam=explode(",", $mparam);
      if(count($mparam)==1 or count($mparam)==2){
      $mparam[0]=intval($mparam[0]);
      if(isset($mparam[1])){$mparam[1]=intval($mparam[1]); $catlimit=" AND home=".$mparam[1];}else{$catlimit="";}

        $mtmp="";
        $mdata=@mysql_query("SELECT title,id FROM `".tabprefix."-articles` WHERE visible=1 AND rate_total!=0".futureart."$catlimit ORDER BY rate_total LIMIT 0, ".$mparam[0]);
        while($mitem=@mysql_fetch_array($mdata)){
        $mtmp.="<a href='".artrewrite($mitem['id'], $mitem['title'])."'><b>".$mitem['title']."</b></a><hr size='1' color='".linecolor."'>\n";
        }
        $mresult=$start."<div>".$mtmp."</div>".$end;

      }
      break;
      

      //menu
      case 18:
      if($mparam!=""){
      $limits=@explode(",", $mparam);
        if(count($limits)==2){
        $limit=true;
        $lstart=intval(trim($limits[0]));
        $lend=intval(trim($limits[1]));
        }
        else{
        $limit=false;
        }
      }
      else{
      $limit=false;
      }

      include(root."modules/hcm/menu.php");
      $mresult=$start.$mtmp.$end;
      break;
      
      
      //loginform
      case 19:
      $refer=1;
      include(root."modules/hcm/loginform.php");
      $mresult=$start.$mtmp.$end;
      break;
      
      
      
      //latcom2
      case 20:
      $mparam=intval($mparam);

          $comments=@mysql_query("SELECT tp,home,author,text,subject FROM `".tabprefix."-comments` ORDER BY id DESC LIMIT $mparam");
          $mtmp="";
          while($comment=@mysql_fetch_array($comments)){

          /*spocitani komentaru*/
          $commentscount=@mysql_query("SELECT id FROM `".tabprefix."-comments` WHERE home=".$comment['home']." AND tp=".$comment['tp']);
          $commentscount_number=0;
          while(@mysql_fetch_array($commentscount)){
          $commentscount_number++;
          }

          /*sestaveni odkazu*/
          $failed=false;

          switch($comment['tp']){

          case 1:
          $title=@mysql_query("SELECT anchor,visible FROM `".tabprefix."-menu` WHERE id=".$comment['home']);
          $title=@mysql_fetch_array($title);
          if($title['visible']==1){
          $title=$title['anchor'];
          $id=$comment['home'];
          $linkhref=secrewrite($id, $title);
          }
          else{
          $failed=true;
          }
          break;

          case 2:
          $title=@mysql_query("SELECT title,visible FROM `".tabprefix."-articles` WHERE id=".$comment['home'].futureart);
          $title=@mysql_fetch_array($title);
          if($title['visible']==1){
          $title=$title['title'];
          $id=$comment['home'];
          $linkhref=artrewrite($id, $title);
          }
          else{
          $failed=true;
          }
          break;

          }

          if($failed==false){$mtmp.="<a href='$linkhref'><b>$title</b> ($commentscount_number)</a><br>\n";}


      }

      $mresult=$start."<div>".$mtmp."</div>".$end;
      break;
      
      
      //sbox
      case 21:
      $mparam=@explode(",",$mparam);

      $id=intval(trim($mparam[0]));
      $boxheight=intval(trim($mparam[1]));
      if($boxheight<100){$boxheight=100;}
      $mtmp="";

      include(root."modules/hcm/sbox.php");

      $mresult=$start.$mtmp.$end;
      break;
      

      //gallery3
      case 22:
      $mparam=@explode(",",$mparam);

      $dir=trim($mparam[0]);
      $width=intval(trim($mparam[1]));
      $anchor=trim($mparam[2]);

      if(count($mparam)==3 and $anchor!="" and $width>0 and $width<=2048){
      $gcode="<a href='".modrewrite("gallery", false, true)."dir=$dir&width=$width'>$anchor</a>";
      $mresult=$start."<div>".$gcode."</div>".$end;
      }

      break;
      


    }
    
    if($mresult!=""){$output=$mresult;}

    }
    else{
      /*odfiltrovani neuzavreneho tagu*/
      if($mpos1){
      $start=substr($output, 0, $mpos1);
      $end=substr($output, $mpos1+strlen($hcm_item_starttag));
      $output=$start.$end;
      }
    }
    
    $mparserrepeat++;
    }

  $hcm_num++;
  }
  
  /*navraceni vystupu parseru*/
  $output=substr($output, 2);
  return $output;

}




/*--------------filtrovani HCM modulu--------------*/
function striphcm($input, $php=false){

  $output="##".$input;
  $hcm_array=array("latart", "latart2", "latcom", "mailform", "php", "gallery", "gallery2", "randimg", "randtxt", "filelist", "mrart", "mrart2", "randart", "randart2", "fulltextbox", "vote", "brart", "brart2", "menu", "loginform", "latcom2", "sbox", "gallery3");
  $hcm_num=0;
  while($hcm_num<=count($hcm_array)-1){

  $hcm_item=$hcm_array[$hcm_num];
  $hcm_item_starttag="[hcm:$hcm_item]";
  $hcm_item_endtag="[/hcm:$hcm_item]";

    /*lokalizace tagu, spocitani vyskytu*/
    $mcount=substr_count($output, $hcm_item_starttag);
    $mparserrepeat=0;

    while($mparserrepeat<$mcount){

    $mpos1=strpos($output, $hcm_item_starttag);
    $mpos2=strpos($output, $hcm_item_endtag);
    $mparam=substr($output, $mpos1+strlen($hcm_item_starttag), $mpos2-($mpos1+strlen($hcm_item_starttag)));
    $mparam=trim($mparam);
    $mresult="";

    if($mpos1 and $mpos2 and $mpos2>$mpos1 and ($mparam!="" or $hcm_num==14 or $hcm_num==18 or $hcm_num==19)){

    $start=substr($output, 0, $mpos1);
    $end=substr($output, $mpos2+strlen($hcm_item_endtag));

    /*filtrovani tagu*/
    $mresult=$start.$end;
    $output=$mresult;

    }
    else{
      /*odfiltrovani neuzavreneho tagu*/
      if($mpos1){
      $start=substr($output, 0, $mpos1);
      $end=substr($output, $mpos1+strlen($hcm_item_starttag));
      $output=$start.$end;
      }
    }

    $mparserrepeat++;
    }

  $hcm_num++;
  }

  /*navraceni vystupu parseru*/
  $output=substr($output, 2);
  return $output;

}

?>
