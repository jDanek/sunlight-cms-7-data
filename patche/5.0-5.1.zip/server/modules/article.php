<?php

/*-----nacteni autora-----*/
$a_author=@mysql_query("SELECT name,realname FROM `".tabprefix."-users` WHERE id=".$a_content['author']);
$a_author=@mysql_fetch_array($a_author);
if($st_artrealname==1 and $a_author['realname']!=""){$a_authoranchor=$a_author['realname'];}
else{$a_authoranchor=$a_author['name'];}

/*-----nacteni promennych-----*/
$a_id=$a_content['id'];
$a_title=$a_content['title'];
$a_perex=$a_content['perex'];
$a_code=$a_content['code'];
$a_date=$a_content['date'];
$a_date=formatdate($a_date);
$a_home=$a_content['home'];
$a_opened=$a_content['opened'];

/*-----zpracovani hodnoceni-----*/
if($a_content['rate_allow']==1 and $st_artrate==1){
  if($a_content['rate_counter']==0 or $a_content['rate_total']==0){
  $a_rating=lang('global_notrated', 'r');
  }
  else{
  $a_rating=round($a_content['rate_total']/$a_content['rate_counter'], 1)." (".lang('global_total', 'r')." ".$a_content['rate_counter']." ".lang('global_votes', 'r').")";
  }
  $a_ratingcode="
  <b>".lang('article_rating', 'r').":</b> ".$a_rating."<br>
  <b>".lang('article_rate', 'r').":</b>&nbsp;
  <a href='".modrewrite("articlerate", false, true)."r=1&id=$a_id'>1</a> |
  <a href='".modrewrite("articlerate", false, true)."r=2&id=$a_id'>2</a> |
  <a href='".modrewrite("articlerate", false, true)."r=3&id=$a_id'>3</a> |
  <a href='".modrewrite("articlerate", false, true)."r=4&id=$a_id'>4</a> |
  <a href='".modrewrite("articlerate", false, true)."r=5&id=$a_id'>5</a> ".lang('article_rate_help', 'r')."<br>
  ";
}
else{
$a_ratingcode="";
}

/*-----zjisteni nazvu kategorie-----*/
$kategorie=@mysql_query("SELECT anchor FROM `".tabprefix."-menu` WHERE id=$a_home");
$kategorie=@mysql_fetch_array($kategorie);
$kategorie=$kategorie['anchor'];

/*-----zapocitani zobrazeni-----*/
$a_readlog=explode("|", $_SESSION[systemuid.'readlog']);
$a_readlognum=0;
$a_readlogfound=false;
while($a_readlognum<=count($a_readlog)){
$a_readlogitem=$a_readlog[$a_readlognum];
if($a_readlogitem==$a_id){$a_readlogfound=true; break;}
$a_readlognum++;
}

  /*vlozeni do logu a pripocteni pocitadla*/
  if($a_readlogfound==false){
  $_SESSION[systemuid.'readlog'].="|$a_id";
  @mysql_query("UPDATE `".tabprefix."-articles` SET opened=opened+1 WHERE id=$a_id");
  }


/*-----zobrazeni id clanku pro redaktory a administratory-----*/
if(isset($_SESSION[systemuid.'login_aindicator'])){
$a_showidcode="\n<b><i>".lang('article_id', 'r').":</i></b> $a_id<br>";
}
else{
$a_showidcode="";
}

/*-----zobrazeni poctu precteni-----*/
if($st_artread==1){$a_readcode="<b>".lang('article_read', 'r').":</b> ".$a_opened."x<br>";}
else{$a_readcode="";}

echo lang('article_category', 'r')."
: <a href='".catrewrite($a_home, $kategorie, 1)."'>$kategorie</a>
<hr size='1' color='$st_linecolor'>
<h1>$a_title</h1>
<p class='aperex'>$a_perex</p>
".parsehcm($a_code)."
<p class='ainfo'>
<b>".lang('article_author', 'r').":</b> <a href='".modrewrite("viewprofile", false, true)."id=".$a_author['name']."'>$a_authoranchor</a><br>
<b>".lang('article_posted', 'r').":</b> $a_date<br>
$a_readcode
$a_ratingcode
$a_showidcode
</p>";

  if($a_comment==1 and $st_comment==1){
  include("modules/comment.php");
  }

?>
