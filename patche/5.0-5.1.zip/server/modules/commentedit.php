<?php

/*nacteni cid*/
if(isset($_GET['cid'])){
$cid=$_GET['cid'];
$cid=intval($cid);
}
else{
$cid=-1;
}
$done=0;


/*kontrola loginu*/

  /*nacteni autora*/
  $c_data=@mysql_query("SELECT author,date,text,subject FROM `".tabprefix."-comments` WHERE id=$cid");
  $c_data=@mysql_fetch_array($c_data);

  $c_author=$c_data['author'];
  if($c_author!=-2){
  $c_author_rights=@mysql_query("SELECT rights FROM `".tabprefix."-users` WHERE id=$c_author");
  $c_author_rights=@mysql_fetch_array($c_author_rights);
  $c_author_rights=$c_author_rights['rights'];
  }
  else{
  $c_author_rights=0;
  }

  /*smazani z db*/
  if($login_indicator==1 and $c_author!="" and (($c_author==$login_id and time()-$c_data['date']<=$st_postadmintimeout) or ($login_rights==1 or $login_rights==2))){

  $continue=false;
  switch($c_author_rights){
  case 0: $continue=true; break;
  case 1: if($login_rights==2 or $login_id==$c_author){$continue=true;} break;
  case 2: if($login_id==$c_author or $login_id==0){$continue=true;} break;
  }

  if($continue==true){
  
    /*ulozeni*/
    if(isset($_POST['mod_text'])){
    
    /*nacteni promennych*/
    $ic_text=$_POST['mod_text'];
    $ic_subject=$_POST['mod_subject'];

    /*kontrola a uprava promennych*/

      /*aplikace maximalni delky*/
      $ic_text=substr($ic_text, 0, 2048);
      $ic_subject=substr($ic_subject, 0, 32);

      /*aplikace znakovych filtru*/
      $ic_text=strtr($ic_text, $trans);
      $ic_subject=strtr($ic_subject, $trans);

      /*odstraneni mezer*/
      $ic_text=trim($ic_text);
      $ic_subject=trim($ic_subject);

      /*kontrola zadani*/
      if($ic_text!="" and $ic_subject!=""){
      $valid=true;
      }
      else{
      $valid=false;
      }
      
    /*ulozeni do db*/
    if($valid==true){
    @mysql_query("UPDATE `".tabprefix."-comments` SET text='$ic_text' WHERE id=$cid");
    @mysql_query("UPDATE `".tabprefix."-comments` SET subject='$ic_subject' WHERE id=$cid");
    $done=1;
    }
    else{
    $msg=lang('global_msg_badinput', 'r');
    $done=0;
    }

    }
    else{
    $done=0;
    }

  }

  }

include("msg.php");

?>


<h1><?php lang('comment_edit', 'e'); ?></h1>
<hr size="1" color="<?php echo $st_linecolor; ?>">

<?php
if($continue!=true){
echo "<b>".lang('global_denied', 'r')."</b>";
}
else{

  /*----hlaska o provedeni nebo formular pro editaci----*/
  if($done==1){
  
  /*hotovo*/
    $home=@mysql_query("SELECT home,tp FROM `".tabprefix."-comments` WHERE id=$cid");
    $home=@mysql_fetch_array($home);

    switch($home['tp']){

    case 1:
    $anchor=@mysql_query("SELECT anchor FROM `".tabprefix."-menu` WHERE id=".$home['home']);
    $anchor=@mysql_fetch_array($anchor);
    $backlink=secrewrite($home['home'], $anchor['anchor']);
    break;
    
    case 2:
    $anchor=@mysql_query("SELECT title FROM `".tabprefix."-articles` WHERE id=".$home['home']);
    $anchor=@mysql_fetch_array($anchor);
    $backlink=artrewrite($home['home'], $anchor['title']);
    break;
    
    }
  
  echo "<p>".lang('global_actiondone', 'r')."<br>&lt; <a href='$backlink'>".lang('global_goback', 'r')."</a></p>";
  }
  else{

  /*formular*/
  $itext_maxlength=2048;
  $itext_form="commentform";
  include("modules/itext.php");
  
  echo "
  <script language='javascript' type='text/javascript'>
  function s(id){
  document.commentform.mod_text.value=document.commentform.mod_text.value+' *'+id+'* ';
  }
  </script>
  
  <form action='".modrewrite("commentedit", false, true)."cid=$cid' method='post' name='commentform' onsubmit=\"if(document.commentform.subject.value=='' ||  document.commentform.text.value==''){alert('".lang('global_somethingwrong', 'r')."'); return false;}\">

  <table>

  <tr>
  <td>".lang('global_subject', 'r').":</td>
  <td><input type='mod_text' maxlength='32' name='mod_subject' class='ifield' value='".strtr($c_data['subject'], $trans)."'></td>
  </tr>

  <tr valign='top'>
  <td>".lang('global_text', 'r').":</td>
  <td><textarea name='mod_text' class='itext' id='itext'>".$c_data['text']."</textarea></td>
  </tr>

  <tr>
  <td></td>
  <td>
  <input type='submit' value='".lang('global_save', 'r')." &gt;'>
  <input type='reset' value='".lang('global_reset', 'r')."' onclick=\"return ask();\">
  &nbsp;
  <a href=\"javascript:s('01');\"><img src=\"modules/templates/$st_template/pics/smileys/01.gif\" alt=\"01\"></a>
  <a href=\"javascript:s('02');\"><img src=\"modules/templates/$st_template/pics/smileys/02.gif\" alt=\"02\"></a>
  <a href=\"javascript:s('03');\"><img src=\"modules/templates/$st_template/pics/smileys/03.gif\" alt=\"03\"></a>
  <a href=\"javascript:s('04');\"><img src=\"modules/templates/$st_template/pics/smileys/04.gif\" alt=\"04\"></a>
  <a href=\"javascript:s('05');\"><img src=\"modules/templates/$st_template/pics/smileys/05.gif\" alt=\"05\"></a>
  <a href=\"javascript:s('06');\"><img src=\"modules/templates/$st_template/pics/smileys/06.gif\" alt=\"06\"></a>
  <a href=\"javascript:s('07');\"><img src=\"modules/templates/$st_template/pics/smileys/07.gif\" alt=\"07\"></a>
  <a href=\"javascript:s('08');\"><img src=\"modules/templates/$st_template/pics/smileys/08.gif\" alt=\"08\"></a>
  </td>
  </tr>

  </table>

  </form>
  ";
  
  }

}
?>
