<?php

 /*parametry*/
$redirect="";
$refer=intval($_GET['refer']);

/*prihlaseni*/
if(isset($_POST['password'])){

/*nacteni post promennych*/

  /*heslo*/
  if($_POST['crypted']==0 or $_POST['cryptedpass']==""){
  $password=$_POST['password'];
  $password=md5($password);
  }
  else{
  $password=$_POST['cryptedpass'];
  }
  
$name=$_POST['name'];
$name=addslashes($name);

/*kontrola spravnosti*/
$userdata=@mysql_query("SELECT id,name,rights,password FROM `".tabprefix."-users` WHERE name='$name'");
$userdata=@mysql_fetch_array($userdata);

$continue=true;

if($userdata['name']!=""){

  /*kontrola hesla*/
  if($userdata['password']!=$password){
  $msg=lang('global_msg_wrongpass', 'r');
  $continue=false;
  }

}
else{
$msg=lang('global_msg_wrongpass', 'r');
$continue=false;
}

if($continue==true){

/*zaznamenani casu prihlaseni*/
@mysql_query("UPDATE `".tabprefix."-users` SET lastlogin=".time()." WHERE id=".$userdata['id']);

/*nastaveni sessions a presmerovani*/
session_start();
$_SESSION[systemuid.'login_indicator']=1;
$_SESSION[systemuid.'login_id']=$userdata['id'];

  /*navrat*/
  $referer=$_SERVER['HTTP_REFERER'];
  if($referer!="" and $refer==1 and !isset($_POST['loginmodulereferer'])){
  $redirect=$referer;
  }
  else{
    if(isset($_POST['loginmodulereferer']) and $refer!=-1){
    $loginmodulereferer=$_POST['loginmodulereferer'];
    $redirect=$loginmodulereferer;
    }
    else{
    $redirect="./";
    }
  }

}
}

include("msg.php");

?>


<h1><?php lang('global_login', 'e'); ?></h1>

<?php
if($redirect==""){
  if($login_indicator!=1){
  $loginmodulerefer=true;
  $loginlostpassword=true;
  include("modules/loginform.php");
  }
  else{
  lang('login_noneed', 'e');
  }
}
else{
echo "
<p>".lang('login_done', 'r')." <a href='$redirect'>".lang('global_continuehere', 'r')."</a></p>
<script type='text/javascript' language='javascript'>
document.location=\"$redirect\";
</script>
";
}
?>
