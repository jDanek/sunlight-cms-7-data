<?php

if($login_indicator==1){

/*nacteni stavajicich uziv. dat*/
$userdata=@mysql_query("SELECT name,realname,password,email,sex,year,month,note FROM `".tabprefix."-users` WHERE id=$login_id");
$userdata=@mysql_fetch_array($userdata);
$userdata['email']=strtr($userdata['email'], $atback);


/*ulozeni nastaveni*/
if(isset($_POST['mod_email'])){

  /*nacteni promennych*/
  $realname=$_POST['mod_realname'];
  $realname=substr($realname, 0, 42);
  $realname=strtr($realname, $trans);
  $newpassword=$_POST['mod_newpassword'];
  $newpassword2=$_POST['mod_newpassword2'];
  $actualpass=$_POST['mod_actualpassword'];
  $email=$_POST['mod_email'];
  $email=trim($email);
  $note=$_POST['mod_note'];
  $note=trim($note);
  $note=strtr($note, $trans);
  $note=substr($note, 0, 255);

    /*pohlavi*/
    $sex=$_POST['mod_sex'];
    $sex=intval($sex);
    if(!($sex==-1 or $sex==0 or $sex==1)){$sex=-1;}

    /*mesic*/
    $month=$_POST['mod_month'];
    $month=intval($month);
    if(!($month>=1 or $month<=12 or $month==-1)){$month=-1;}

    /*rok*/
    $year=$_POST['mod_year'];
    $year=intval($year);
    if(!($year>=date("Y")-110 or $year<=date("Y") or $year==-1)){$year=-1;}

    /*deaktivace*/
    if($year==-1 xor $month==-1){$year=-1; $month=-1;}
  
  if($login_rights==2){$newname=$_POST['mod_newname']; $newname=substr($newname, 0, 20); $newname=anchor($newname, false);}
  else{$newname=" ";}
  
  /*kontrola a ulozeni*/
  if($newpassword==$newpassword2){
  
  $namecheck=@mysql_query("SELECT name FROM `".tabprefix."-users` WHERE name='$newname'");
  $namecheck=@mysql_fetch_array($namecheck);
  $namecheck=$namecheck['name'];

  if(validate_email($email) and $newname!="" and ($namecheck=="" or $namecheck==$login_name)){
  
  $emailcheck=@mysql_query("SELECT name FROM `".tabprefix."-users` WHERE email='$email'");
  $emailcheck=mysql_fetch_array($emailcheck);
  $emailcheck=$emailcheck['name'];
  
  if($emailcheck=="" or $emailcheck==$userdata['name']){

    /*kontrola puvodniho hesla*/
    $continue=true;
    if($newpassword==""){
    $newpassword=$userdata['password'];
    }
    else{
      if(md5($actualpass)==$userdata['password']){
      $newpassword=md5($newpassword);
      }
      else{
      $continue=false;
      }
    }
  
    if($continue==true){
    
    /*aktualizace v db*/
    @mysql_query("UPDATE `".tabprefix."-users` SET realname='$realname' WHERE id=$login_id");
    @mysql_query("UPDATE `".tabprefix."-users` SET email='$email' WHERE id=$login_id");
    @mysql_query("UPDATE `".tabprefix."-users` SET note='$note' WHERE id=$login_id");
    @mysql_query("UPDATE `".tabprefix."-users` SET password='$newpassword' WHERE id=$login_id");
    @mysql_query("UPDATE `".tabprefix."-users` SET year=$year WHERE id=$login_id");
    @mysql_query("UPDATE `".tabprefix."-users` SET month=$month WHERE id=$login_id");
    @mysql_query("UPDATE `".tabprefix."-users` SET sex=$sex WHERE id=$login_id");

    if($login_rights==2 and $newname!=$login_name){
    @mysql_query("UPDATE `".tabprefix."-users` SET name='$newname' WHERE id=$login_id");
    }

    /*data a zprava*/

      /*nacteni novych uziv. dat*/
      $userdata=@mysql_query("SELECT name,realname,password,email,sex,year,month,note FROM `".tabprefix."-users` WHERE id=$login_id");
      $userdata=@mysql_fetch_array($userdata);
      $userdata['email']=strtr($userdata['email'], $atback);

    $msg=lang('global_settingssaved', 'r');
    
    }
    else{
    $msg=lang('global_msg_nosame', 'r');
    }
    
    }
    else{
    $msg=lang('global_msg_mailexists', 'r');
    }

  }
  else{
    if($namecheck!="" and $namecheck!=$login_name){
    $msg=lang('global_msg_userexists', 'r');
    }
    else{
    $msg=lang('global_msg_someempty', 'r');
    }
  }

  }
  else{
  $msg=lang('global_msg_nosame', 'r');
  }

}

include("modules/msg.php");
include("modules/settings_form.php");

}
else{
echo "
<a href='./'>".lang('global_backtomain')."</a>
<script type='text/javascript' language='javascript'>
document.location='./';
</script>
";
}


?>
