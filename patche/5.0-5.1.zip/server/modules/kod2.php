<?php
$root="../";
define('root', "../");
include("funcload.php");

$img=imagecreate(26,10);
$n=$_GET['n'];
$n=code_decode($n);

/*barvy*/
$bg=imagecolorallocate($img, 255, 255, 255);
$cerna=imagecolorallocate($img, 0, 0, 0);

/*vypis textu*/
imagestring($img, 2, 1, -2, $n, $cerna);

/*odeslani a ukonceni*/
header("Content-type: image/PNG");
imagepng($img);
imagedestroy($img);
?>
