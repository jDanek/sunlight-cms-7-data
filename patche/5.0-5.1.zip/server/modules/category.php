<?php
echo "<h1>$kategorie</h1>";

/*strankovani*/
if(isset($_GET['s'])){
$startpage=$_GET['s'];
$startpage=intval($startpage);
if($startpage!=0){$startpage-=1;}
}
else{
$startpage=0;
}

/*seznam stran*/
$strany=@mysql_query("SELECT id FROM `".tabprefix."-articles` WHERE home=$c_str AND visible=1$st_futureart");
$pocetstran=0;

  /*spocitani stran*/
  while($strana=@mysql_fetch_array($strany)){$pocetstran++;}
  if($pocetstran==0){$pocetstran=1;}
  $pocetstran=$pocetstran/$st_limit;
  $pocetstran=ceil($pocetstran);

/*vypis stran*/
if($startpage>9){$strana=$startpage-5;}
else{$strana=0;}
$odkazu=0;
$back=$startpage-10;
$forward=$startpage+10;
$strankovani="<hr size='1' color='$st_linecolor'><div class='strany'>".lang('global_page', 'r').": ";

if($startpage>=10){$strankovani.="<a href='".catrewrite($c_str, $kategorie, $back)."'>&lt;</a> ";}

while($strana<$pocetstran and $odkazu<=$st_maxpages){
$odkazu++;
$stranaanchor=$strana+1;

if($strana==$startpage){$strankovani.="<a href='".catrewrite($c_str, $kategorie, $stranaanchor)."' class='active'>$stranaanchor</a> ";}
else{$strankovani.="<a href='".catrewrite($c_str, $kategorie, $stranaanchor)."'>$stranaanchor</a> ";}
$strana++;
}

if($startpage<=$pocetstran-10){$strankovani.="<a href='".catrewrite($c_str, $kategorie, $forward)."'>&gt;</a> ";}
$strankovani.="</div>\n";

if($st_pagingmode==1 or $st_pagingmode==3){echo $strankovani;}

echo "<hr size='1' color='$st_linecolor'>";

/*vypis seznamu clanku*/
$start=$startpage*$st_limit;
$articlecontent=@mysql_query("SELECT id,title,perex,date,author,opened,comment FROM `".tabprefix."-articles` WHERE home=$c_str AND visible=1$st_futureart ORDER BY $st_artorder DESC LIMIT $start,$st_limit");

$jsouclanky=false;
while($item=@mysql_fetch_array($articlecontent)){
if($jsouclanky==false){$jsouclanky=true;}

/*nacteni autora*/
$a_author=@mysql_query("SELECT name,realname FROM `".tabprefix."-users` WHERE id=".$item['author']);
$a_author=@mysql_fetch_array($a_author);
if($st_artrealname==1 and $a_author['realname']!=""){$a_authoranchor=$a_author['realname'];}
else{$a_authoranchor=$a_author['name'];}

$a_id=$item['id'];
$a_title=$item['title'];
$a_perex=$item['perex'];
$a_author=$a_author['name'];
$a_date=$item['date'];
$a_date=formatdate($a_date);
$a_comment=$item['comment'];
$a_opened=$item['opened'];

  /*spocitani komentaru*/
  $a_commentscount_code="";
  if($a_comment==1 and $st_comment==1){
  $a_commentscount=@mysql_query("SELECT id FROM `".tabprefix."-comments` WHERE home=$a_id AND tp=2");
  $a_commentscount_number=0;
  while(@mysql_fetch_array($a_commentscount)){
  $a_commentscount_number++;
  }
  $a_commentscount_code=" | <b>".lang('article_totalcomments', 'r').":</b> $a_commentscount_number";
  }
  
  /*zobrazeni poctu precteni*/
  if($st_artread==1){$a_opened_code=" | <b>".lang('article_read', 'r').":</b> ".$a_opened."x";}
  else{$a_opened_code="";}

/*vypis clanku*/
echo "<a href='".artrewrite($a_id, $a_title)."' class='title'>$a_title</a><p class='cperex'>$a_perex</p><div class='cinfo'><b>".lang('article_author', 'r').":</b> $a_authoranchor | <b>".lang('article_posted', 'r').":</b> ".$a_date.$a_opened_code.$a_commentscount_code."</div>\n";
}

if(($st_pagingmode==2 or $st_pagingmode==3) and $jsouclanky==true){echo $strankovani;}

/*hlaska o zadnych clancich*/
if($jsouclanky==false){
if($startpage==0){lang('content_nocatkit', 'e');}
else{lang('global_wrongpage', 'e');}
}
?>
