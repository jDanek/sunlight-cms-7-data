<?php
echo "&lt; <a href='".referer(true)."'>".lang('global_goback', 'r')."</a><br><br>";
lang('bbcode_help_page', 'e');
?>
