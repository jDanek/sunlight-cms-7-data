<?php

if(isset($_GET['id']) and $_GET['id']!=""){

$id=$_GET['id'];
$id=anchor($id, false);
if($id==anchor(lang('global_fableduser', 'r'), false)){$id="";}

}
else{
$id="";
}

?>

<h1><?php lang('viewprofile_title', 'e'); ?></h1>

<form action="<?php echo modrewrite("viewprofile", true) ?>" method="get">
<?php echo modrewrite_getinputs("viewprofile"); ?>
<b><?php lang('global_user', 'e'); ?></b>&nbsp;
<input type="text" name="id" size="20" value="<?php echo $id; ?>">
<input type="submit" value="<?php lang('global_view', 'e'); ?> &gt;">
</form>
<br>

<?php
if($id!=""){

$userdata=@mysql_query("SELECT id,name,realname,rights,email,sex,year,month,note,lastlogin FROM `".tabprefix."-users` WHERE name='$id'");
$userdata=@mysql_fetch_array($userdata);

  if($userdata['name']!=""){
  
  $userdata['email']=strtr($userdata['email'], $at);
  
  /*-----pocet zaslanych clanku a hodnoceni autora-----*/
  if($userdata['rights']==1 or $userdata['rights']==2){

    $userart_data=@mysql_query("SELECT id,rate_counter,rate_total,rate_allow FROM `".tabprefix."-articles` WHERE author=".$userdata['id'].$st_futureart);
    $userart_count=0;
    $authorrate_total=0;
    $authorrate_counter=0;
    while($userart_data_row=@mysql_fetch_array($userart_data)){
    if($userart_data_row['rate_allow']==1 and $st_artrate==1){
    $authorrate_total+=$userart_data_row['rate_total'];
    $authorrate_counter+=$userart_data_row['rate_counter'];
    }
    $userart_count++;
    }
    
    if($userart_count!=0){$userart_count_showlink=" - <a href='".modrewrite("viewarticles", false, true)."id=$id'>".lang('global_show', 'r')."</a>";}
    else{$userart_count_showlink="";}
    
    $userart="
    \n<tr>
    <td class='main'>".lang('viewprofile_userart', 'r')."</td>
    <td>".$userart_count.$userart_count_showlink."</td>
    </tr>

    ";
    
    if($st_artrate==1){
    if($authorrate_counter!=0){$authorrate_result=round($authorrate_total/$authorrate_counter, 1);}
    else{$authorrate_result=lang('global_notrated', 'r');}
    $authorrate="
    \n<tr>
    <td class='main'>".lang('global_authorrate', 'r')."</td>
    <td>$authorrate_result</td>
    </tr>
    ";
    }

  }
  else{
  $userart="";
  $authorrate="";
  }

  /*-----textove vyjadreni prav, nastaveni hvezdy-----*/
  switch($userdata['rights']){
  case 0: $userdata['rights']=lang('global_reader', 'r'); $star=""; break;
  case 1: $userdata['rights']=lang('global_redactor', 'r'); $star="c"; break;
  case 2: if($userdata['id']!=0){$userdata['rights']=lang('global_administrator', 'r'); $star="b";}else{$userdata['rights']=lang('global_mainadministrator', 'r'); $star="a";} break;
  }
  if($star!=""){$star="<img src='modules/templates/$st_template/pics/stars/$star.gif' class='star'> ";}
  
  /*-----textove vyjadreni pohlavi-----*/
  switch($userdata['sex']){
  case -1: $userdata['sex']="-"; break;
  case 0: $userdata['sex']=lang('global_sex_male', 'r'); break;
  case 1: $userdata['sex']=lang('global_sex_female', 'r'); break;
  }
  
  /*-----vypocet veku-----*/
  if($userdata['year']!=-1 and $userdata['month']!=-1){
  $userdata['age']=(date("Y")+(date("n")/12))-($userdata['year']+($userdata['month']/12));
  $userdata['age']=round($userdata['age']);
  }
  else{
  $userdata['age']="-";
  }
  
  /*-----spocitani komentaru-----*/
  $userdata_comments=@mysql_query("SELECT id,home,tp FROM `".tabprefix."-comments` WHERE author=".$userdata['id']);
  $userdata_totalcomments=0;
  while($userdata_comment=@mysql_fetch_array($userdata_comments)){
  
    $failed=false;
    if($userdata_comment['tp']==2){
    $adate=@mysql_query("SELECT date FROM `".tabprefix."-articles` WHERE id=".$userdata_comment['home']);
    $adate=@mysql_fetch_array($adate);
    $adate=$adate['date'];
    if($adate>time()){$failed=true;}
    }
    
    if($failed==false){$userdata_totalcomments++;}

  }
  
  if($userdata_totalcomments!=0){
  $totalcomments_showlink=" - <a href='".modrewrite("viewcomments", false, true)."author=$id'>".lang('global_show', 'r')."</a>";
  }
  else{
  $totalcomments_showlink="";
  }
  
  /*-----zpracovani poznamky-----*/
  $userdata_note=$userdata['note'];
  if($userdata_note==""){
  $userdata_note="-";
  }
  else{
  $userdata_note=nl2br(parsebbcode($userdata_note));
  $userdata_note=strtr($userdata_note, $smajlici);
  }
  
  /*-----zpracovani skutecneho jmena-----*/
  if($userdata['realname']==""){
  $userdata['realname']="-";
  }
  
  /*-----nastaveni zobrazovani emailu-----*/
  if($st_showmail==1){
  $usermail="
  <tr>
  <td class='main'>".lang('global_email', 'r')."</td>
  <td><a href='mailto:".$userdata['email']."'>".$userdata['email']."</a></td>
  </tr>";
  }
  else{
  $usermail="";
  }

  /*-----nastaveni zobrazovani casu posl. prihlaseni-----*/
  if($st_showlastlogin==1){
  $userlastlogin="
  <tr>
  <td class='main'>".lang('global_lastlogin', 'r')."</td>
  <td>".formatdate($userdata['lastlogin'])."</td>
  </tr>";
  }
  else{
  $userlastlogin="";
  }
  
  /*-----zobrazeni odkazu pro editaci-----*/
  if($login_indicator==1){
    if($userdata['id']==$login_id){
    $editlink="<br><a href='".modrewrite("settings")."'>".lang('viewprofile_editlink', 'r')." &gt;</a>";
    }
    else{
    $editlink="";
    }
  }
  else{
  $editlink="";
  }

  /*-----vypis tabulky-----*/
  echo "
  <div id='viewprofile'>
  
  <fieldset>
  <legend><b>".lang('viewprofile_userdata', 'r')."</b></legend>
  <table>

  <tr>
  <td class='main'>".lang('global_user', 'r')."</td>
  <td>".$userdata['name']."</td>
  </tr>
  
  <tr>
  <td class='main'>".lang('global_rights', 'r')."</td>
  <td>$star".$userdata['rights']."</td>
  </tr>

  $userlastlogin
  $usermail
  $authorrate
  $userart
  <tr>
  <td class='main'>".lang('global_totalcomments', 'r')."</td>
  <td>".$userdata_totalcomments.$totalcomments_showlink."</td>
  </tr>
  
  </table>
  </fieldset>
  

  <fieldset>
  <legend><b>".lang('viewprofile_personaldata', 'r')."</b></legend>
  <table>

  <tr>
  <td class='main'>".lang('global_realname', 'r')."</td>
  <td>".$userdata['realname']."</td>
  </tr>
  
  <tr>
  <td class='main'>".lang('global_age', 'r')."</td>
  <td>".$userdata['age']."</td>
  </tr>
  
  <tr>
  <td class='main'>".lang('global_sex', 'r')."</td>
  <td>".$userdata['sex']."</td>
  </tr>
  
  <tr valign='top'>
  <td class='main'>".lang('global_note', 'r')."</td>
  <td class='note'>".$userdata_note."</td>
  </tr>

  </table>
  </div>
  
  $editlink
  ";
  
  }
  else{
  lang('global_msg_usernotexists', 'e');
  }
  
  
  }
  else{
  lang('global_msg_usernotexists', 'e');
  }

?>
