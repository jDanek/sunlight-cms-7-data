<?php

/*nacteni bid*/
if(isset($_GET['pid'])){
$pid=$_GET['pid'];
$pid=intval($pid);
}
else{
$pid=-1;
}
$done=0;


/*kontrola loginu*/

  /*nacteni autora*/
  $sbox_data=@mysql_query("SELECT author,date FROM `".tabprefix."-sboxes-posts` WHERE id=$pid");
  $sbox_data=@mysql_fetch_array($sbox_data);
  
  $post_author=$sbox_data['author'];
  if($post_author!=-1){
  $post_author_rights=@mysql_query("SELECT rights FROM `".tabprefix."-users` WHERE id=$post_author");
  $post_author_rights=@mysql_fetch_array($post_author_rights);
  $post_author_rights=$post_author_rights['rights'];
  }
  else{
  $post_author_rights=0;
  }

  /*smazani z db*/
  if($login_indicator==1 and $post_author!="" and (($post_author==$login_id and time()-$sbox_data['date']<=$st_postadmintimeout) or ($login_rights==1 or $login_rights==2))){
  
  $continue=false;
  switch($post_author_rights){
  case 0: $continue=true; break;
  case 1: if($login_rights==2 or $login_id==$post_author){$continue=true;} break;
  case 2: if($login_id==$post_author or $login_id==0){$continue=true;} break;
  }

  if($continue==true){
  @mysql_query("DELETE FROM `".tabprefix."-sboxes-posts` WHERE id=$pid");
  $done=1;
  }

  }


include("msg.php");
?>


<h1><?php lang('post_delete', 'e'); ?></h1>
<hr size="1" color="<?php echo $st_linecolor; ?>">

<?php
if($done!=1){
echo "<b>".lang('global_denied', 'r')."</b>";
}
else{
echo "<p>".lang('global_actiondone', 'r')."<br>&lt; <a href='".referer(true)."'>".lang('global_goback', 'r')."</a></p>";
}
?>
