<?php
if($itext_name==""){$itext_name="itext";}
if($itext_form==""){$itext_form="form";}
?>

<script type='text/javascript' language='javascript'>
document.onkeyup=proces;
document.onmouseup=proces;
document.onmousedown=proces;
function proces()
{
value=document.<?php echo $itext_form; ?>.<?php echo $itext_name; ?>.value;
len=<?php echo $itext_maxlength; ?>-value.length;
if(len<0){
document.<?php echo $itext_form; ?>.<?php echo $itext_name; ?>.value=document.<?php echo $itext_form; ?>.<?php echo $itext_name; ?>.value.substring(0,<?php echo $itext_maxlength; ?>);
alert('<?php lang('global_inputtoolong', 'e'); ?>');
}
}
</script>
