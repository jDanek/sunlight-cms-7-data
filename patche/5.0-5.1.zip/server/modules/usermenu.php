<?php
if($u_spacer==""){$u_spacer="&nbsp;|&nbsp;";}
if($u_hideusername==true){$u_username="";}else{$u_username="[$login_name]";}

if($login_indicator==1){
/*menu prihlaseneho*/
if($st_comment!=1){$u_lcomlink="";}else{$u_lcomlink="$u_spacer<a href='".modrewrite("viewcomments")."'>$u_prefix".lang('usermenu_lastcomments', 'r')."</a>";}
echo "
<a href='modules/logout.php'>$u_prefix".lang('usermenu_logout', 'r')." $u_username</a>$u_spacer
<a href='".modrewrite("settings")."'>$u_prefix".lang('usermenu_settings', 'r')."</a>$u_spacer
<a href='".modrewrite("viewprofile", false, true)."id=$login_name'>$u_prefix".lang('usermenu_viewprofile', 'r')."</a>
$u_lcomlink
";
}
else{
/*menu odhlaseneho*/
if($st_registration==1){$u_reglink="$u_spacer<a href='".modrewrite("register")."'>$u_prefix".lang('usermenu_register', 'r')."</a>";}else{$u_reglink="";}
echo "
<a href='".modrewrite("login")."'>$u_prefix".lang('usermenu_login', 'r')."</a>
$u_reglink
";
}

/*menu pro vsechny*/
echo "
$u_spacer<a href='".modrewrite("userlist")."'>$u_prefix".lang('usermenu_userlist', 'r')."</a>
";

?>
