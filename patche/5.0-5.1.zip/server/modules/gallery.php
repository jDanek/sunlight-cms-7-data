<?php

/*nacteni parametru*/
if(isset($_GET['dir']) and isset($_GET['width'])){
$dir=trim($_GET['dir']);
$width=intval(trim($_GET['width']));
if(substr($dir, -1)!="/"){$dir.="/";}
if($width<0 or $width>2048 or !file_exists(root.$dir) or !is_dir(root.$dir)){exit;}
}
else{
exit;
}

?>


<h1><?php lang('hcm_gallery_title', 'e'); ?></h1>
<hr color="<?php echo $st_linecolor; ?>" size="1">

<?php

/*----------ZPRACOVANI VSTUPNICH PARAMETRU STRANKOVANI----------*/
if(isset($_GET['s'])){
$startpage=$_GET['s'];
$startpage=intval($startpage);
if($startpage!=0){$startpage-=1;}
}
else{
$startpage=0;
}
$start=$startpage*$st_limit;

/*----------VYPIS OBRAZKU----------*/

/*otevreni slozky*/
$handle=opendir(root.$dir);
$gcode_array=array();
$index=0;

/*nacteni a serazeni obsahu*/
while($item=readdir($handle)){
$suffix=strrpos($item, ".");
$suffix=substr($item, $suffix+1);
$suffix=strtolower($suffix);
if($item=="." or $item==".." or is_dir(root.$dir.$item) or !($suffix=="jpeg" or $suffix=="jpg" or $suffix=="gif" or $suffix=="png")){continue;}
$gcode_array[$index]=$item;
$index++;
}
closedir($handle);
natsort($gcode_array);
reset($gcode_array);

/*vypis*/
$naslo=0;
while($naslo<=count($gcode_array)-1){
$naslo++;

  if($naslo>$start and $naslo<=$start+$st_limit){
  $item_size=ceil(filesize(root.$dir.$gcode_array[$naslo])/1024);
  echo "<a href='".root."$dir".current($gcode_array)."' target='_blank' title='".current($gcode_array)." | ".$item_size."kB'><img src='".root."modules/hcm/galimg.php?f=$dir".current($gcode_array)."&w=$width'></a>\n";

  }

next($gcode_array);
}


/*----------VYPIS STRAN----------*/
if($naslo!=0){

$pocetstran=$naslo;
$pocetstran=$pocetstran/$st_limit;
$pocetstran=ceil($pocetstran);

if($startpage>=0 and $startpage<=$pocetstran-1){

if($startpage>9){$strana=$startpage-5;}
else{$strana=0;}
$odkazu=0;
$back=$startpage-10;
$forward=$startpage+10;
echo "<hr color='$st_linecolor' size='1'><div class='strany'><b>".lang('global_page', 'r')."</b>: ";
if($startpage>=10){echo "<a href='".modrewrite("gallery", false, true)."dir=$dir&width=$width&s=$back".$getauthor."'>&lt;</a> ";}

while($strana<$pocetstran and $odkazu<=$st_maxpages){
$odkazu++;
$stranaanchor=$strana+1;
if($strana==$startpage){echo "<a href='".modrewrite("gallery", false, true)."dir=$dir&width=$width&s=$stranaanchor".$getauthor."' class='active'>$stranaanchor</a> ";}
else{echo "<a href='".modrewrite("gallery", false, true)."dir=$dir&width=$width&s=$stranaanchor".$getauthor."'>$stranaanchor</a> ";}
$strana++;
}

if($startpage<=$pocetstran-10){echo "<a href='".modrewrite("gallery", false, true)."dir=$dir&width=$width&s=$forward".$getauthor."'>&gt;</a> ";}

echo "</div>";

}
else{
lang('global_wrongpage', 'e');
}

}
else{
lang('hcm_gallery_nokit', 'e');
}

?>
