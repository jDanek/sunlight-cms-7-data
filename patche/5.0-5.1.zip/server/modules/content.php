<?php

/*funkce*/
function content_regonlyform(){
echo "<h1>".lang('global_onlyreg_title')."</h1>\n<p>".lang('global_onlyreg_p')."</p>";
$refer=1;
include("modules/loginform.php");
}

if($st_regonly==0 or ($st_regonly==1 and $login_indicator==1)){


  /*----------CLANEK----------*/
  if(isset($_GET['art'])){
    /*nacteni dat*/
    $a_art=$_GET['art'];
    $a_art=intval($a_art);
    $a_content=@mysql_query("SELECT * FROM `".tabprefix."-articles` WHERE id=$a_art");
    $a_content=@mysql_fetch_array($a_content);
    $a_comment=$a_content['comment'];

    /*modul*/
    if($a_comment=="" or ($a_content['date']>time() and !isset($_SESSION[systemuid.'login_aindicator']))){
      lang('content_notfound', 'e');
    }
    else{
      $c_regonly=@mysql_query("SELECT regonly FROM `".tabprefix."-menu` WHERE id=".$a_content['home']);
      $c_regonly=@mysql_fetch_array($c_regonly);
      $c_regonly=$c_regonly['regonly'];
      if($c_regonly==0 or ($c_regonly==1 and $login_indicator==1)){include("modules/article.php");}
      else{content_regonlyform();}
    }
  }
  else{


  /*----------PARAMETRY NEBO UVODNI STRANA----------*/
  $continue=true;

  if($_GET['str']!="" and ($_GET['tp']==1 or $_GET['tp']==2 or $_GET['tp']==3 or $_GET['tp']==4)){
  $c_tp=$_GET['tp'];
  $c_tp=intval($c_tp);
  $c_str=$_GET['str'];
  if($c_tp!=4){$c_str=intval($c_str);}
  }
  else {include("modules/mainpage.php");}

  /*----------ROZLISENI OBSAHU A VYPISY----------*/
  if($continue==true){
  switch($c_tp){

  /*----------SEKCE----------*/
  case "1":
    /*nacteni dat*/
    $codecontent=@mysql_query("SELECT home,code,comment FROM `".tabprefix."-sections` WHERE home=$c_str");
    $codecontent=@mysql_fetch_array($codecontent);
    $c_comment=$codecontent['comment'];
    $c_home=$codecontent['home'];

    /*modul*/
    if($codecontent['comment']!=""){
      $c_regonly=@mysql_query("SELECT regonly FROM `".tabprefix."-menu` WHERE id=$c_home");
      $c_regonly=@mysql_fetch_array($c_regonly);
      $c_regonly=$c_regonly['regonly'];
      if($c_regonly==0 or ($c_regonly==1 and $login_indicator==1)){include("modules/section.php");}
      else{content_regonlyform();}
    }
    else{
      lang('content_notfound', 'e');
    }
  break;


  /*----------KATEGORIE----------*/
  case "2":
    /*nacteni dat*/
    $kategorie=@mysql_query("SELECT anchor FROM `".tabprefix."-menu` WHERE id=$c_str AND type=2");
    $kategorie=@mysql_fetch_array($kategorie);
    $kategorie=$kategorie['anchor'];

    /*modul*/
    if($kategorie!=""){
      $c_regonly=@mysql_query("SELECT regonly FROM `".tabprefix."-menu` WHERE id=$c_str");
      $c_regonly=@mysql_fetch_array($c_regonly);
      $c_regonly=$c_regonly['regonly'];
      if($c_regonly==0 or ($c_regonly==1 and $login_indicator==1)){include("modules/category.php");}
      else{content_regonlyform();}
    }
    else{
      lang('content_notfound', 'e');
    }
  break;


  /*----------KNIHA----------*/
  case "3":
    /*nacteni dat*/
    $kniha=@mysql_query("SELECT anchor FROM `".tabprefix."-menu` WHERE id=$c_str");
    $kniha=@mysql_fetch_array($kniha);
    $kniha=$kniha['anchor'];

    /*modul*/
    if($kniha!=""){
      $c_regonly=@mysql_query("SELECT regonly FROM `".tabprefix."-menu` WHERE id=$c_str");
      $c_regonly=@mysql_fetch_array($c_regonly);
      $c_regonly=$c_regonly['regonly'];
      if($c_regonly==0 or ($c_regonly==1 and $login_indicator==1)){include("modules/book.php");}
      else{content_regonlyform();}
    }
    else{
    lang('content_notfound', 'e');
    }
  break;


  /*----------MODUL----------*/
  case "4":
  
  switch($c_str){
  case "vote":
  case "articlerate":
  case "bookdel":
  case "sboxdel":
  case "bookedit":
  case "commentdel":
  case "commentedit":
  case "fulltext":
  case "login":
  case "register":
  case "settings":
  case "userlist":
  case "viewarticles":
  case "viewcomments":
  case "viewprofile":
  case "bbcodehelp":
  case "lostpassword":
  case "gallery":
  $continue=true; break;
  default: $continue=false;
  }

  $modul="modules/$c_str.php";
  if(file_exists($modul) and $continue==true){include($modul);}
  else{lang('content_notfound', 'e');}
  break;


  }
  }

  }

}
else{
content_regonlyform();
}

?>
