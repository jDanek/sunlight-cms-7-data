<h1><?php lang('settings_title', 'e'); ?></h1>
<?php if($login_rights==2){echo "<p>".lang('settings_p_special', 'r')."</p>";}else{echo "<br>";} ?>

<?php
/*javascript pro delku poznamky*/
$itext_maxlength=255;
$itext_name="note";
include("modules/itext.php");
?>

<form action="<?php echo modrewrite("settings"); ?>" method="post" name="form">

<fieldset>
<legend><b><?php lang('settings_updata', 'e'); ?></b></legend>
<p class="mini"><?php lang('settings_updata_p', 'e'); ?></p>
<table>

<?php
/*pole pro zmenu jmena*/
if($login_rights==2){
echo "<tr>
<td><b>".lang('global_username', 'r')."</b> <span class='markstar'>*</span></td>
<td><input type='text' name='mod_newname' size='20' maxlength='20' value='".$userdata['name']."'></td>
</tr>
";
}
?>

<tr>
<td><b><?php lang('global_realname', 'e'); ?></b></td>
<td><input type="text" name="mod_realname" size="20" maxlength="42" value="<?php echo $userdata['realname']; ?>"></td>
</tr>

<tr>
<td><b><?php lang('global_email', 'e'); ?></b> <span class="markstar">*</span></td>
<td>
<input type="text" name="mod_email" size="20" value="<?php echo $userdata['email']; ?>"></td>
</tr>

<tr>
<td><b><?php lang('global_borndate', 'e'); ?></b></td>
<td>

  <select name="mod_month">
  <option value='-1'>-</option>
  <?php
  $x=1;
  while($x<=12){
  if($x<10){$x="0$x";}
  if($x!=$userdata['month']){echo "<option value='$x'>$x</option>\n";}
  else{echo "<option value='$x' selected>$x</option>\n";}
  $x++;
  }
  ?>
  </select>&nbsp;

  <select name="mod_year">
  <option value='-1'>-</option>
  <?php
  $x=date("Y");
  while($x>=date("Y")-110){
  if($x!=$userdata['year']){echo "<option value='$x'>$x</option>\n";}
  else{echo "<option value='$x' selected>$x</option>\n";}
  $x--;
  }
  ?>
  </select>&nbsp;<small><?php lang('settings_borndate_help', 'e'); ?></small>

</td>
</tr>

<tr>
<td><b><?php lang('global_sex', 'e'); ?></b></td>
<td>
<?php
switch($userdata['sex']){
case -1: $sex_undefined=" selected"; $sex_male=""; $sex_female=""; break;
case 0: $sex_undefined=""; $sex_male=" selected"; $sex_female=""; break;
case 1: $sex_undefined=""; $sex_male=""; $sex_female=" selected"; break;
}
?>
<select name="sex">
<option value="-1"<?php echo $sex_undefined; ?>>-</option>
<option value="0"<?php echo $sex_male; ?>><?php lang('global_sex_male', 'e'); ?></option>
<option value="1"<?php echo $sex_female; ?>><?php lang('global_sex_female', 'e'); ?></option>
</select>
</td>
</tr>

</table>
</fieldset>


<fieldset>
<legend><b><?php lang('settings_password', 'e'); ?></b></legend>
<p class="mini"><?php lang('settings_password_p', 'e'); ?></p>
<table>

<tr>
<td><b><?php lang('global_actualpass', 'e'); ?></b></td>
<td><input type="password" name="mod_actualpassword" size="20" maxlength="255"></td>
</tr>

<tr>
<td><b><?php lang('global_newpass', 'e'); ?></b></td>
<td><input type="password" name="mod_newpassword" size="20" maxlength="255"></td>
</tr>

<tr>
<td><b><?php lang('global_newpass', 'e'); ?> <?php lang('global_check', 'e'); ?></b></td>
<td><input type="password" name="mod_newpassword2" size="20" maxlength="255"></td>
</tr>

</table>
</fieldset>


<fieldset>
<legend><b><?php lang('settings_other', 'e'); ?></b></legend>
<p class="mini"><?php lang('settings_other_p', 'e'); ?></p>
<table>

<tr valign="top">
<td><b><?php lang('global_note', 'e'); ?></b>&nbsp;</td>
<td>
<script language='javascript' type='text/javascript'>
function s(id){
document.form.mod_note.value=document.form.mod_note.value+' *'+id+'* ';
}
</script>
<textarea type="text" name="mod_note" class="itextsmall"><?php echo $userdata['note']; ?></textarea>
</td>
</tr>

<tr><td></td>
<td>
<a href="javascript:s('01');"><img src="modules/templates/<?php echo $st_template; ?>/pics/smileys/01.gif" alt="01"></a>
<a href="javascript:s('02');"><img src="modules/templates/<?php echo $st_template; ?>/pics/smileys/02.gif" alt="02"></a>
<a href="javascript:s('03');"><img src="modules/templates/<?php echo $st_template; ?>/pics/smileys/03.gif" alt="03"></a>
<a href="javascript:s('04');"><img src="modules/templates/<?php echo $st_template; ?>/pics/smileys/04.gif" alt="04"></a>
<a href="javascript:s('05');"><img src="modules/templates/<?php echo $st_template; ?>/pics/smileys/05.gif" alt="05"></a>
<a href="javascript:s('06');"><img src="modules/templates/<?php echo $st_template; ?>/pics/smileys/06.gif" alt="06"></a>
<a href="javascript:s('07');"><img src="modules/templates/<?php echo $st_template; ?>/pics/smileys/07.gif" alt="07"></a>
<a href="javascript:s('08');"><img src="modules/templates/<?php echo $st_template; ?>/pics/smileys/08.gif" alt="08"></a>
</td></tr>

</table>
</fieldset>


<input type="submit" value="<?php lang('global_save', 'e'); ?> &gt;">
<input type="reset" value="<?php lang('global_reset', 'e'); ?>" onclick="return ask();">


</form>
