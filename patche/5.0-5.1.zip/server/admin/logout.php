<?php

if($securitylogout==false){
$root="../";
include("../_connect.php");
}

session_start();
unset($_SESSION[systemuid.'login_aindicator']);
unset($_SESSION[systemuid.'login_aid']);

if($securitylogout==false){
header("location: index.php?out");
exit;
}

?>
