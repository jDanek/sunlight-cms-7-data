<?php

@mysql_query("ALTER TABLE `".tabprefix."-users` ADD `lastlogin` BIGINT NOT NULL ;");
@mysql_query("INSERT INTO `".tabprefix."-settings` ( `variable` , `value` ) VALUES ('showlastlogin', '1');");
@mysql_query("INSERT INTO `".tabprefix."-settings` ( `variable` , `value` ) VALUES ('lostpass', '1');");
@mysql_query("UPDATE `".tabprefix."-settings` SET value='default' WHERE variable='langfile';");
@mysql_query("UPDATE `".tabprefix."-settings` SET variable='regonly' WHERE variable='onlyregcon';");
@mysql_query("ALTER TABLE `".tabprefix."-menu` ADD `regonly` TINYINT NOT NULL ;");

?>
