<?php






























































class ClassLoader
{




protected $debug = false;

protected $pathCache = array();

protected $baseNamespaces = array();

protected $prefixes = array();

protected $classMap = array();








public function register()
{
return spl_autoload_register(array($this, 'loadClass'));
}





public function getDebug()
{
return $this->debug;
}






public function setDebug($debug)
{
$this->debug = (bool)$debug;
return $this;
}





public function clearPathCache()
{
$this->pathCache = array();
return $this;
}











public function registerBaseNamespace($baseNamespace, $paths, $pathsNormalized = false)
{
$this->baseNamespaces[$baseNamespace] = array((array)$paths, $pathsNormalized);
return $this;
}







public function registerBaseNamespaces(array $baseNamespaces, $pathsNormalized = false)
{
foreach($baseNamespaces as $baseNamespace => $paths) {
$this->baseNamespaces[$baseNamespace] = array((array)$paths, $pathsNormalized);
}
return $this;
}








public function registerPrefix($prefix, $paths, $pathsNormalized = false)
{
$this->prefixes[$prefix] = array((array)$paths, $pathsNormalized, strlen($prefix));
return $this;
}







public function registerPrefixes(array $prefixPaths, $pathsNormalized = false)
{
foreach($prefixPaths as $prefix => $paths) {
$this->prefixes[$prefix] = array((array)$paths, $pathsNormalized, strlen($prefix));
}
return $this;
}







public function registerClass($className, $classFile)
{
$this->classMap[$className] = $classFile;
return $this;
}






public function registerClassMap(array $classes)
{
$this->classMap = $classes + $this->classMap;
return $this;
}






public function clear()
{
$this->baseNamespaces =
$this->prefixes =
$this->pathCache =
array()
;
return $this;
}









public function loadClass($className)
{
$file = $this->find($className, false);
if(null !== $file) {


try {
include_once $file;
} catch(Exception $e) {
throw new RuntimeException(sprintf('An error occured while loading class "%s" from file "%s"', $className, $file), 0, $e);
}


if($this->debug && !class_exists($className, false) && !interface_exists($className, false) && (!function_exists('trait_exists') || !trait_exists($className, false))) {
throw new RuntimeException(sprintf('Class, interface or trait "%s" was not found in file "%s" - possible invalid name or namespace?', $className, $file));
}

}
}








public function find($className, $exceptionOnFailure = true)
{

if(isset($this->pathCache[$className])) {
return $this->pathCache[$className];
}


if(isset($this->classMap[$className])) {
return $this->classMap[$className];
}


$slash = strpos($className, '\\');
$lastSlash = strrpos($className, '\\');
$bareClassName = ((false === $lastSlash) ? $className : substr($className, $lastSlash + 1));
$baseNamespace = ((false === $lastSlash) ? null : substr($className, 0, $slash));
$namespace = ((false === $lastSlash) ? '' : substr($className, 0, $lastSlash));


$paths = null;
if(isset($baseNamespace, $this->baseNamespaces[$baseNamespace])) {


if(!$this->baseNamespaces[$baseNamespace][1]) {
$this->normalizePaths($this->baseNamespaces[$baseNamespace]);
}
$paths = $this->baseNamespaces[$baseNamespace][0];


if(false !== $slash && $slash !== $lastSlash) {
$namespace = substr($namespace, $slash + 1);
} else {
$namespace = '';
}

} elseif(isset($baseNamespace, $this->prefixes[$baseNamespace])) {


if(!$this->prefixes[$baseNamespace][1]) {
$this->normalizePaths($this->prefixes[$baseNamespace]);
}
$paths = $this->prefixes[$baseNamespace][0];

} else {


foreach($this->prefixes as $prefix => $prefixData) {
if(0 === strncmp($className, $prefix, $prefixData[2])) {
if(!$prefixData[1]) {
unset($prefixData);
$this->normalizePaths($this->prefixes[$prefix]);
}
$paths = $this->prefixes[$prefix][0];
break;
}
}

}


if(null !== $paths) {


$validPath = false;
for($i = 0; isset($paths[$i]); ++$i) {
$path = $this->composePath($paths[$i], $namespace, $bareClassName);
if(is_file($path)) {
$validPath = true;
break;
}
}


if($validPath) {
return $this->pathCache[$className] = $path;
}

}


if($exceptionOnFailure) {
throw new RuntimeException(sprintf('Could not find path for "%s"', $className));
}
}








public function composePath($basePath, $namespacePart, $classPart = null)
{
return
$basePath
.(('' !== $namespacePart) ? DIRECTORY_SEPARATOR.str_replace('\\', DIRECTORY_SEPARATOR, $namespacePart) : '')
.((null !== $classPart) ? DIRECTORY_SEPARATOR.str_replace('_', DIRECTORY_SEPARATOR, $classPart).'.php' : '')
;
}








protected function normalizePaths(&$entry)
{

for($i = 0; isset($entry[0][$i]); ++$i) {
$entry[0][$i] = rtrim(str_replace(array('\\', '/'), DIRECTORY_SEPARATOR, $entry[0][$i]), DIRECTORY_SEPARATOR);
}


$entry[1] = true;
}

}