<?php





class TreeManager
{




protected $table;

protected $idColumn;

protected $parentColumn;

protected $levelColumn;

protected $depthColumn;











public function __construct($table, $idColumn = null, $parentColumn = null, $levelColumn = null, $depthColumn = null)
{
$this->table = $table;
$this->idColumn = $idColumn ?: 'id';
$this->parentColumn = $parentColumn ?: 'node_parent';
$this->levelColumn = $levelColumn ?: 'node_level';
$this->depthColumn = $depthColumn ?: 'node_depth';
}










public function checkParent($nodeId, $parentNodeId)
{
return null === $parentNodeId || !in_array($parentNodeId, $this->getChildren($nodeId, true)) && $nodeId != $parentNodeId;
}







public function create(array $data, $refresh = true)
{
if(array_key_exists($this->levelColumn, $data) || array_key_exists( $this->depthColumn, $data)) {
throw new \InvalidArgumentException(sprintf('Sloupce "%s" a "%s" nelze manualne definovat', $this->levelColumn, $this->depthColumn));
}
$data += array(
$this->parentColumn => null,
$this->levelColumn => 0,
$this->depthColumn => 0,
);

$nodeId = DB::insert($this->table, $data, true);
if($refresh) {
$this->doRefresh($nodeId);
}
return $nodeId;
}








public function update($nodeId, array $changeset, $refresh = true)
{
if(array_key_exists($this->levelColumn, $changeset) || array_key_exists($this->depthColumn, $changeset)) {
throw new \InvalidArgumentException(sprintf('Sloupce "%s" a "%s" nelze manualne menit', $this->levelColumn, $this->depthColumn));
}
DB::update($this->table, $this->idColumn.'='.DB::val($nodeId), $changeset);
if($refresh && array_key_exists($this->parentColumn, $changeset)) {
if(!$this->checkParent($nodeId, $changeset[$this->parentColumn])) {
throw new \RuntimeException(sprintf('Uzel "%s" neni platnym nadrazenym uzlem pro "%s"', $changeset[$this->parentColumn], $nodeId));
}
$this->doRefresh($nodeId);
}
return $this;
}







public function delete($nodeId, $orphanRemoval = true)
{
if($orphanRemoval) {
$children = $this->getChildren($nodeId);
$this->deleteSet($this->idColumn, $children);
}
$rootNodeId = $this->getRoot($nodeId);
DB::query('DELETE FROM `'.$this->table.'` WHERE '.$this->idColumn.'='.DB::val($nodeId));
if($nodeId != $rootNodeId) {
$this->doRefreshDepth($rootNodeId, true);
}
return $this;
}






public function purge($nodeId)
{
$this->deleteSet($this->idColumn, $this->getChildren($nodeId));
$this->doRefreshDepth($nodeId);
return $this;
}






public function refresh($nodeId = null)
{
$this->doRefresh($nodeId);
return $this;
}






public function purgeOrphaned($refresh = true)
{
do {
$orphaned = DB::query('SELECT n.'.$this->idColumn.',n.'.$this->parentColumn.' FROM `'.$this->table.'` n LEFT JOIN `'.$this->table.'` p ON(n.'.$this->parentColumn.'=p.'.$this->idColumn.') WHERE n.'.$this->parentColumn.' IS NOT NULL AND p.id IS NULL');
$orphanedCount = DB::size($orphaned);
while($row = DB::row($orphaned)) {


$this->deleteSet($this->idColumn, $this->getChildren($row[$this->idColumn], true));


DB::query('DELETE FROM `'.$this->table.'` WHERE '.$this->idColumn.'='.DB::val($row[$this->idColumn]).' OR '.$this->parentColumn.'='.DB::val($row[$this->parentColumn]));

}
DB::free($orphaned);
} while($orphanedCount > 0);

if($refresh) {
$this->doRefresh(null);
}

return $this;
}









protected function getLevel($nodeId, array &$parents = null)
{
$level = 0;
$parents = array();
if(null === $nodeId) {
return 0;
}
do {
$node = DB::query_row('SELECT '.$this->parentColumn.' FROM `'.$this->table.'` WHERE '.$this->idColumn.'='.DB::val($nodeId));
if(false === $node) {
throw new \RuntimeException(sprintf('Neexistujici uzel "%s"', $nodeId));
}

$hasParent = (null !== $node[$this->parentColumn]);
if($hasParent) {
$nodeId = $node[$this->parentColumn];
$parents[] = $nodeId;
if(++$level > 200) {
throw new \RuntimeException(sprintf('Dosazen limit 200 urovni zanoreni u nadrazeneho uzlu "%s" - rekurzivni data v tabulce?', $node[$this->parentColumn]));
}
}
} while($hasParent);

return $level;
}





protected function getRoot($nodeId)
{
$parents = array();
$this->getLevel($nodeId, $parents);
if(!empty($parents)) {
return end($parents);
}
return $nodeId;
}







protected function getChildren($nodeId, $emptyArrayOnFailure = false)
{

$node = DB::query_row('SELECT '.$this->depthColumn.' FROM `'.$this->table.'` WHERE id='.DB::val($nodeId));
if(false === $node) {
if($emptyArrayOnFailure) {
return array();
}
throw new \RuntimeException(sprintf('Neexistujici uzel "%s"', $nodeId));
}
if(0 == $node[$this->depthColumn]) {

return array();
}


$sql = 'SELECT ';
for($i = 0; $i < $node[$this->depthColumn]; ++$i) {
if(0 !== $i) {
$sql .= ',';
}
$sql .= 'n'.$i.'.id';
}

$sql .= ' FROM `'.$this->table.'` r';
$parentAlias = 'r';
for($i = 0; $i < $node[$this->depthColumn]; ++$i) {
$nodeAlias = 'n'.$i;
$sql .= sprintf(
' LEFT OUTER JOIN `%s` %s ON(%2$s.%s=%s.%s)',
$this->table,
$nodeAlias,
$this->parentColumn,
$parentAlias,
$this->idColumn
);
$parentAlias = $nodeAlias;
}
$sql .= ' WHERE r.'.$this->idColumn.'='.DB::val($nodeId);


$query = DB::query($sql);
$childrenMap = array();
while($row = DB::rown($query)) {
for($i = 0; isset($row[$i]); ++$i) {
$childrenMap[$row[$i]] = true;
}
}
DB::free($query);

return array_keys($childrenMap);
}





protected function doRefresh($currentNodeId)
{

$currentNodeParents = array();
$currentNodeLevel = $this->getLevel($currentNodeId, $currentNodeParents);


$queue = array(
array(
$currentNodeId,
$currentNodeLevel,
),
);
$levelset = array();
if(null !== $currentNodeId) {
$levelset[$currentNodeLevel] = array($currentNodeId => true);
}


for($i = 0; isset($queue[$i]); ++$i) {


if(null !== $queue[$i][0]) {
$childCondition = $this->parentColumn.'='.DB::val($queue[$i][0]);
$childrenLevel = $queue[$i][1] + 1;
} else {
$childCondition = $this->parentColumn.' IS NULL';
$childrenLevel = 0;
}
$children = DB::query('SELECT '.$this->idColumn.','.$this->levelColumn.' FROM `'.$this->table.'` WHERE '.$childCondition);
while($child = DB::row($children)) {
if($childrenLevel != $child[$this->levelColumn]) {
if(isset($levelset[$childrenLevel][$child[$this->idColumn]])) {
throw new \RuntimeException(sprintf('Rekurzivni zavislost na uzlu "%s"', $child[$this->idColumn]));
}
$levelset[$childrenLevel][$child[$this->idColumn]] = true;
}
$queue[] = array($child[$this->idColumn], $childrenLevel);
}

DB::free($children);
unset($queue[$i]);

}


foreach($levelset as $newLevel => $childrenMap) {
$this->updateSet($this->idColumn, array_keys($childrenMap), array($this->levelColumn => $newLevel));
}


$topNodeId = end($currentNodeParents);
if(false === $topNodeId) {
$topNodeId = $currentNodeId;
}
$this->doRefreshDepth($topNodeId, true);
}






protected function doRefreshDepth($currentNodeId, $isRootNode = null)
{

$rootNodeId = $currentNodeId;
if(true !== $isRootNode && null !== $currentNodeId) {
$rootNodeId = $this->getRoot($currentNodeId);
}


$queue = array(
array(
$rootNodeId,
0,
array(),
),
);
$depthmap = array();


for($i = 0; isset($queue[$i]); ++$i) {


if(null !== $queue[$i][0]) {
$childCondition = $this->parentColumn.'='.DB::val($queue[$i][0]);
} else {
$childCondition = $this->parentColumn.' IS NULL';
}
$children = DB::query($s = 'SELECT '.$this->idColumn.','.$this->depthColumn.' FROM `'.$this->table.'` WHERE '.$childCondition);
if(DB::size($children) > 0) {

if(null !== $queue[$i][0]) {
$childParents = array_merge(array($queue[$i][0]), $queue[$i][2]);
} else {
$childParents = $queue[$i][2];
}
while($child = DB::row($children)) {
$queue[] = array($child[$this->idColumn], $child[$this->depthColumn], $childParents);
}
}
DB::free($children);


if(null !== $queue[$i][0] && !isset($depthmap[$queue[$i][0]])) {
$depthmap[$queue[$i][0]] = 0;
}
for($j = 0; isset($queue[$i][2][$j]); ++$j) {
$currentDepth = $j + 1;
if(!isset($depthmap[$queue[$i][2][$j]]) || $depthmap[$queue[$i][2][$j]] < $currentDepth) {
$depthmap[$queue[$i][2][$j]] = $currentDepth;
}
}
unset($queue[$i]);

}


foreach($depthmap as $nodeId => $newDepth) {
DB::update($this->table, $this->idColumn.'='.DB::val($nodeId), array($this->depthColumn => $newDepth));
}
}








protected function updateSet($column, array $set, array $changeset, $maxPerQuery = 100)
{
if(!empty($set)) {
foreach(array_chunk($set, $maxPerQuery) as $chunk) {
DB::update(
$this->table,
$column.' IN('.DB::arr($chunk).')',
$changeset,
null
);
}
}
}







protected function deleteSet($column, array $set, $maxPerQuery = 100)
{
if(!empty($set)) {
foreach(array_chunk($set, $maxPerQuery) as $chunk) {
DB::query('DELETE FROM `'.$this->table.'` WHERE '.$column.' IN('.DB::arr($chunk).')');
}
}
}

}