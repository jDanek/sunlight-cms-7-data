<?php





class Color
{



protected $r, $g, $b, $h, $l, $s;









function Color($color = array(0, 0, 0), $type = 0)
{
if($type === 0) {
list($this->r, $this->g, $this->b) = $color;
list($this->h, $this->l, $this->s) = $this->rgb_to_hls($color[0], $color[1], $color[2]);
} else {
list($this->h, $this->l, $this->s) = $color;
list($this->r, $this->g, $this->b) = $this->hls_to_rgb($color[0], $color[1], $color[2]);
}
}










public function setRGB($r, $g, $b)
{
list($this->h, $this->l, $this->s) = $this->rgb_to_hls($r, $g, $b);
list($this->r, $this->g, $this->b) = func_get_args();
}







public function setHLS($h, $l, $s)
{
list($this->r, $this->g, $this->b) = $this->hls_to_rgb($h, $l, $s);
list($this->h, $this->l, $this->s) = func_get_args();
}







public function setChannel($channel, $value)
{

if(!isset($this->$channel)) return false;
$value = (int)$value;


$this->$channel = $value;
if($channel === 'r' || $channel === 'g' || $channel === 'b') list($this->h, $this->l, $this->s) = $this->rgb_to_hls($this->r, $this->g, $this->b);
else list($this->r, $this->g, $this->b) = $this->hls_to_rgb($this->h, $this->l, $this->s);
return true;
}






public function getChannel($channel)
{
if(isset($this->$channel)) return $this->$channel;
}





public function getRGB()
{
return array($this->r, $this->g, $this->b);
}





public function getRGBStr()
{
return sprintf('#%02x%02x%02x', $this->r, $this->g, $this->b);
}





public function getHLS()
{
array($this->h, $this->l, $this->s);
}











protected function hls_to_rgb($h, $l, $s)
{

$args = array('h', 'l', 's');
for($i = 0; $i < 3; ++$i)
if(${$args[$i]} < 0) ${$args[$i]} = 0;
elseif(${$args[$i]} > 255) ${$args[$i]} = 255;


$h = 360 * $h / 255;
$l = ($l - 127) / 255;
$s = $s / 255;
$c = (1 - abs(2 * $l)) * $s;
$hx = $h / 60;
$x = $c * (1 - abs(fmod($hx, 2) - 1));
if($hx >= 0 && $hx < 1) $rgb = array($c, $x, 0);
elseif($hx >= 1 && $hx < 2) $rgb = array($x, $c, 0);
elseif($hx >= 2 && $hx < 3) $rgb = array(0, $c, $x);
elseif($hx >= 3 && $hx < 4) $rgb = array(0, $x, $c);
elseif($hx >= 4 && $hx < 5) $rgb = array($x, 0, $c);
else $rgb = array($c, 0, $x);
$m = $l - $c * .5;
for($i = 0; $i < 3; ++$i) $rgb[$i] = $this->num_range(floor(($rgb[$i] + $m) * 255 + 127), 0, 255);
return $rgb;
}








protected function rgb_to_hls($r, $g, $b)
{

$args = array('r', 'g', 'b');
for($i = 0; $i < 3; ++$i)
if(${$args[$i]} < 0) ${$args[$i]} = 0;
elseif(${$args[$i]} > 255) ${$args[$i]} = 255;


$M = max($r, $g, $b);
$m = min($r, $g, $b);
$l = .5 * ($M + $m);
$c = $M - $m;
if($c === 0) return array(0, $l, 0);
if($M === $r) $hx = fmod(($g - $b) / $c, 6);
elseif($M === $g) $hx = ($b - $r) / $c + 2;
else $hx = ($r - $g) / $c + 4;
$h = round($hx * 60 / 360 * 255);
$s = round($c / (1 - abs(2 * ($l - 127) / 255)));
$l = round($l);
return array($h, $l, $s);
}








protected function num_range($num, $min, $max)
{
if(isset($min) && $num < $min) return $min;
if(isset($max) && $num > $max) return $max;
return $num;
}


}
