<?php






class TreeReader
{




protected $table;

protected $childrenIndex;

protected $idColumn;

protected $parentColumn;

protected $levelColumn;

protected $depthColumn;












public function __construct($table, $childrenIndex = null, $idColumn = null, $parentColumn = null, $levelColumn = null, $depthColumn = null)
{
$this->table = $table;
$this->childrenIndex = $childrenIndex ?: 'children';
$this->idColumn = $idColumn ?: 'id';
$this->parentColumn = $parentColumn ?: 'node_parent';
$this->levelColumn = $levelColumn ?: 'node_level';
$this->depthColumn = $depthColumn ?: 'node_depth';
}











public function getPath(array $columns, $nodeId, $nodeLevel = null)
{
return $this->loadPath($columns, $nodeId, $nodeLevel);
}










public function getTree(array $columns, $nodeId = null, $nodeDepth = null, $sortBy = null, $sortAsc = true)
{

$nodes = $this->loadTree($columns, $nodeId, $nodeDepth);


$tree = array();
$childrenMap = array();
foreach($nodes as &$node) {

$node[$this->childrenIndex] = array();


if(null !== $node[$this->parentColumn]) {

if($node[$this->depthColumn] > 0) {
$nodeIndex = array_push($childrenMap[$node[$this->parentColumn]], $node) - 1;
$childrenMap[$node[$this->idColumn]] = &$childrenMap[$node[$this->parentColumn]][$nodeIndex][$this->childrenIndex];
} else {
$childrenMap[$node[$this->parentColumn]][] = $node;
}

} else {

$childrenMap[$node[$this->idColumn]] = &$tree[array_push($tree, $node) - 1][$this->childrenIndex];
}

}


if(null !== $sortBy) {
$cmpFunction = function($a, $b) use($sortBy, $sortAsc) {
return strnatcmp($a[$sortBy], $b[$sortBy]) * ($sortAsc ? 1 : -1);
};
foreach($childrenMap as &$children) {
usort($children, $cmpFunction);
}
usort($tree, $cmpFunction);
}

return $tree;
}










public function getFlatTree(array $columns, $nodeId = null, $nodeDepth = null, $sortBy = null, $sortAsc = true)
{

$tree = $this->getTree($columns, $nodeId, $nodeDepth, $sortBy, $sortAsc);
if(empty($tree)) {
return array();
}


$list = array();
$stack = array();
$frame = array($tree, 0);
do {

for($i = $frame[1]; isset($frame[0][$i]); ++$i) {


$children = $frame[0][$i][$this->childrenIndex];
unset($frame[0][$i][$this->childrenIndex]);


$list[] = $frame[0][$i];


if(!empty($children)) {

$stack[] = array($frame[0], $i + 1);
$frame = array($children, 0);
continue 2;
}

}

$frame = array_pop($stack);

} while(null !== $frame);

return $list;
}











public function loadTree(array $columns, $nodeId = null, $nodeDepth = null)
{

if(null === $nodeDepth) {
if(null === $nodeId) {
$nodeDepth = DB::query_row('SELECT MAX('.$this->depthColumn.') '.$this->depthColumn.' FROM `'.$this->table.'` WHERE '.$this->levelColumn.'=0');
} else {
$nodeDepth = DB::query_row('SELECT '.$this->depthColumn.' FROM `'.$this->table.'` WHERE '.$this->idColumn.'='.DB::val($nodeId));
}
if(false === $nodeDepth) {

throw new \RuntimeException(
(null === $nodeId)
? 'Nepodarilo se zjistit hloubku stromu'
: sprintf('Neexistujici uzel "%s"', $nodeId)
);
}
if(null === $nodeDepth[$this->depthColumn]) {

return array();
}
$nodeDepth = $nodeDepth[$this->depthColumn];
}


$columns = array_merge(
array($this->idColumn, $this->parentColumn, $this->levelColumn, $this->depthColumn),
$columns
);
$columnCount = sizeof($columns);


$sql = 'SELECT ';
for($i = 0; $i < $columnCount; ++$i) {
if(0 !== $i) {
$sql .= ',';
}
$sql .= 'r.'.$columns[$i];
}
for($i = 0; $i < $nodeDepth; ++$i) {
for($j = 0; $j < $columnCount; ++$j) {
$sql .= ',n'.$i.'.'.$columns[$j];
}
}

$sql .= ' FROM `'.$this->table.'` r';
$parentAlias = 'r';
for($i = 0; $i < $nodeDepth; ++$i) {
$nodeAlias = 'n'.$i;
$sql .= sprintf(
' LEFT OUTER JOIN `%s` %s ON(%2$s.%s=%s.%s)',
$this->table,
$nodeAlias,
$this->parentColumn,
$parentAlias,
$this->idColumn
);
$parentAlias = $nodeAlias;
}
$sql .= ' WHERE r.';
if(null === $nodeId) {
$sql .= $this->levelColumn.'=0';
} else {
$sql .= $this->idColumn.'='.DB::val($nodeId);
}


$nodeMap = array();
$query = DB::query($sql);
while($row = DB::rown($query)) {
for($i = 0; isset($row[$i]); $i += $columnCount) {
if(!isset($nodeMap[$row[$i]])) {
$nodeMap[$row[$i]] = array();
for($j = 0; $j < $columnCount; ++$j) {
$nodeMap[$row[$i]][$columns[$j]] = $row[$i + $j];
}
}
}
}
DB::free($query);


$levelColumn = $this->levelColumn;
usort($nodeMap, function($a, $b) use($levelColumn) {
if($a[$levelColumn] > $b[$levelColumn]) {
return 1;
}
if($a[$levelColumn] == $b[$levelColumn]) {
return 0;
}
return -1;
});

return $nodeMap;
}








public function loadPath(array $columns, $nodeId, $nodeLevel = null)
{

if(null === $nodeLevel) {
$nodeLevel = DB::query_row('SELECT '.$this->levelColumn.' FROM `'.$this->table.'` WHERE '.$this->idColumn.'='.DB::val($nodeId));
if(false === $nodeLevel) {
throw new \RuntimeException(sprintf('Neexistujici uzel "%s"', $nodeId));
}
$nodeLevel = $nodeLevel[$this->levelColumn];
}


$columns = array_merge(
array($this->idColumn, $this->parentColumn, $this->levelColumn, $this->depthColumn),
$columns
);
$columnCount = sizeof($columns);


$sql = 'SELECT ';
for($i = 0; $i <= $nodeLevel; ++$i) {
for($j = 0; $j < $columnCount; ++$j) {
if(0 !== $i || 0 !== $j) {
$sql .= ',';
}
$sql .= 'n'.$i.'.'.$columns[$j];
}
}
$sql .= ' FROM `'.$this->table.'` n0';
for($i = 1; $i <= $nodeLevel; ++$i) {
$sql .= sprintf(
_nl.' JOIN `%s` n%s ON(n%2$s.%s=n%s.%s)',
$this->table,
$i,
$this->idColumn,
$i - 1,
$this->parentColumn
);
}
$sql .= ' WHERE n0.'.$this->idColumn.'='.DB::val($nodeId);


$nodes = array();
$nodeIndex = 0;
$query = DB::query($sql);
$row = DB::rown($query);
for($i = $nodeLevel * $columnCount; isset($row[$i]); $i -= $columnCount) {
for($j = 0; $j < $columnCount; ++$j) {
$nodes[$nodeIndex][$columns[$j]] = $row[$i + $j];
}
++$nodeIndex;
}
DB::free($query);

return $nodes;
}

}