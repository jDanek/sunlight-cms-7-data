<?php

define('_indexroot', './');
require _indexroot."require/load.php";




_checkKeys('_POST', array('content'));
echo _parsePost(strval($_POST['content']));