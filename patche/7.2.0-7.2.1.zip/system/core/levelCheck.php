<?php

/*---- check source and target level ----*/

function _levelCheck($targetuserid){

//load level
$group=mysql_fetch_array(mysql_query("SELECT `group`,id FROM `"._mysql_prefix."-users` WHERE id=".$targetuserid));
$level=mysql_fetch_array(mysql_query("SELECT level FROM `"._mysql_prefix."-groups` WHERE id=".$group['group']));

//check
if(_loginright_level>$level['level'] or (_loginright_level==$level['level'] and $group['id']==_loginid)){return true;}
else{return false;}

}

?>