<?php

/*---- print boxes code ----*/

function _templateBoxes($column=1){

$output="\n";

if(!_notpublicsite or _loginindicator){

  //public
  if(_loginindicator){$public="";}
  else{$public=" AND public=1";}

  //code
  if(_template_boxes_parent!=""){$output.="<"._template_boxes_parent.">\n";}
  $query=mysql_query("SELECT title,content FROM `"._mysql_prefix."-boxes` WHERE visible=1 AND `column`=".$column.$public." ORDER BY ord");
    while($item=mysql_fetch_array($query)){

      //make title code
      $title="<"._template_boxes_title." class='box-title'>".$item['title']."</"._template_boxes_title.">\n";

    /*title outside*/ if(_template_boxes_title_inside==0 and $title!=""){$output.=$title;}
    /*item starttag*/ if(_template_boxes_item!=""){$output.="<"._template_boxes_item." class='box-item'>\n";}
    /*title inside*/  if(_template_boxes_title_inside==1 and $title!=""){$output.=$title;}
    /*content*/       $output.=_parseHCM($item['content']);
    /*item endtag*/   if(_template_boxes_item!=""){$output.="\n</"._template_boxes_item.">";}
    /*bottomtag*/     if(_template_boxes_bottom==1){$output.="<"._template_boxes_item." class='box-bottom'></"._template_boxes_item.">\n\n";}else{$output.="\n\n";}
    ;
    }
  if(_template_boxes_parent!=""){$output.="</"._template_boxes_parent.">\n";}
  
}

//print output
echo $output;

}

?>