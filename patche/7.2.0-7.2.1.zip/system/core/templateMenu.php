<?php

/*---- create and return menu content ----*/

function _templateMenu($ord_start=null, $ord_end=null){
global $_shid_total;
$output="";
if(defined("_indexOutput_pid")){$pid=_indexOutput_pid;}else{$pid=-1;}
if(!_notpublicsite or _loginindicator){

  //limit
  if($ord_start===null or $ord_end===null){$ord_limit="";}
  else{$ord_limit=" AND ord>=".intval($ord_start)." AND ord<=".intval($ord_end);}

  //make content
  $query=mysql_query("SELECT id,type,title,var1,var2 FROM `"._mysql_prefix."-root` WHERE visible=1 AND intersection=-1 AND type!=4".$ord_limit." ORDER BY ord");
  $output.="<"._template_menu_parent." class='menu'>";
  $firstclass=" class='first'";
    while($item=mysql_fetch_array($query)){
    
      if(!($item['type']==7 and $item['var2']==1)){
        if($item['id']==$pid){$class=" class='act'";}else{$class="";}
        if($item['type']==6 and $item['var1']==1){$target=" target='_blank'";}else{$target="";}
        $link="<a href='"._linkRoot($item['id'])."'".$class.$target.">".$item['title']."</a>";
      }
      else{
        $_shid_total+=1;
        $shid=$_shid_total;
        $link="<a href='"._linkRoot($item['id'])."' class='hs_closed' onclick=\"return _syshse('sh".$shid."', this)\">".$item['title']."</a><ul class='hs_content' id='sh".$shid."'>";
        $iquery=mysql_query("SELECT id,title FROM `"._mysql_prefix."-root` WHERE intersection=".$item['id']." AND visible=1 ORDER BY ord");
        
          while($iitem=mysql_fetch_array($iquery)){
          if($iitem['id']==$pid){$class=" class='act'";}else{$class="";}
          $link.="<li><a href='"._linkRoot($iitem['id'])."'".$class.">".$iitem['title']."</a></li>";
          }
        $link.="</ul>";
      }

    $output.="<"._template_menu_child.$firstclass.">".$link."</"._template_menu_child.">\n";
    if($firstclass!=""){$firstclass="";}
    }
  
  $output.="</"._template_menu_parent.">";
  
}

return $output;

}

?>