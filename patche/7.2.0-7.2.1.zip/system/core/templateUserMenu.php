<?php

/*---- print user menu content ----*/

function _templateUserMenu($echo=true){
global $_lang;

$output="";

  if(_template_usermenu_parent!=""){$output.="<"._template_usermenu_parent.">";}

  if(!_loginindicator){
  /*login*/     $output.=_template_usermenu_item_start."<a href='"._indexroot."index.php?m=login'>".$_lang['usermenu.login']."</a>"._template_usermenu_item_end;
  if(_registration){/*register*/  $output.=_template_usermenu_item_start."<a href='"._indexroot."index.php?m=reg'>".$_lang['usermenu.registration']."</a>"._template_usermenu_item_end;}
  }
  else{
  /*messages*/  if(_messages){$messages_count=mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-messages` WHERE receiver="._loginid." AND readed=0"), 0); if($messages_count!=0){$messages_count=" [".$messages_count."]";}else{$messages_count="";} $output.=_template_usermenu_item_start."<a href='"._indexroot."index.php?m=messages'>".$_lang['usermenu.messages'].$messages_count."</a>"._template_usermenu_item_end;}
  /*settings*/  $output.=_template_usermenu_item_start."<a href='"._indexroot."index.php?m=settings'>".$_lang['usermenu.settings']._condReturn(_template_usermenu_showusername, " ["._loginname."]")."</a>"._template_usermenu_item_end;
  /*logout*/    $output.=_template_usermenu_item_start."<a href='"._indexroot."remote/logout.php?_return=".urlencode(_indexOutput_url)."'>".$_lang['usermenu.logout']._condReturn(_template_usermenu_showusername, " ["._loginname."]")."</a>"._template_usermenu_item_end;
  }
  
  if(_ulist and (!_notpublicsite or _loginindicator)){
  /*ulist*/   $output.=_template_usermenu_item_start."<a href='"._indexroot."index.php?m=ulist'>".$_lang['usermenu.ulist']."</a>"._template_usermenu_item_end;
  }
  
  if(_template_usermenu_parent!=""){$output.="</"._template_usermenu_parent.">";}

if(_template_usermenu_trim==1){$output=trim($output); $output=trim($output, _template_usermenu_item_start); $output=trim($output, _template_usermenu_item_end);}
if($echo){echo $output;}else{return $output;}
}

?>