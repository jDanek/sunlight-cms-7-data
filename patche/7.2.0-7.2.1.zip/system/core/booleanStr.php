<?php

/*---- return boolean value of given number ----*/

function _booleanStr($input){
if($input==true){return "true";}else{return "false";}
}

?>