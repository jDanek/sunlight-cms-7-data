<?php

/*---- iplog update ----*/

function _iplogUpdate($type, $var=null){
$querybasic="SELECT * FROM `"._mysql_prefix."-iplog` WHERE ip='"._userip."' AND type=".$type;
$newid=_getNewID("iplog");

  switch($type){
  
    //login
    case 1:
    $query=mysql_query($querybasic);
      if(mysql_num_rows($query)!=0){
      $query=mysql_fetch_array($query);
      mysql_query("UPDATE `"._mysql_prefix."-iplog` SET var=".($query['var']+1)." WHERE id=".$query['id']);
      }
      else{
      mysql_query("INSERT INTO `"._mysql_prefix."-iplog` (id,ip,type,time,var) VALUES (".$newid.",'"._userip."',1,".time().",1)");
      }
    break;
    
    //artread
    case 2:
    mysql_query("INSERT INTO `"._mysql_prefix."-iplog` (id,ip,type,time,var) VALUES (".$newid.",'"._userip."',2,".time().",".$var.")");
    break;
    
    //artrate
    case 3:
    mysql_query("INSERT INTO `"._mysql_prefix."-iplog` (id,ip,type,time,var) VALUES (".$newid.",'"._userip."',3,".time().",".$var.")");
    break;

    //pollvote
    case 4:
    mysql_query("INSERT INTO `"._mysql_prefix."-iplog` (id,ip,type,time,var) VALUES (".$newid.",'"._userip."',4,".time().",".$var.")");
    break;

    //postsend
    case 5:
    mysql_query("INSERT INTO `"._mysql_prefix."-iplog` (id,ip,type,time,var) VALUES (".$newid.",'"._userip."',5,".time().",0)");
    break;

  }

}

?>