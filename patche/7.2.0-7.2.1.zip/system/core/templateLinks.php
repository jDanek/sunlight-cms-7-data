<?php

/*---- print links ----*/

function _templateLinks(){
global $_lang;
echo "<a href='http://sunlight-cms.net/'>SunLight CMS</a>"._condReturn(!_adminlinkprivate or (_loginindicator and _loginright_administration), " "._template_listinfoseparator." <a href='"._indexroot."admin/index.php'>".$_lang['admin.link']."</a>");
}

?>