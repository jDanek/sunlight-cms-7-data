<?php


/*---- return article output ----*/

function _articleOutput($id){
global $_lang;

$query=mysql_fetch_array(mysql_query("SELECT * FROM `"._mysql_prefix."-articles` WHERE id=".$id));
$home1_public=mysql_fetch_array(mysql_query("SELECT public FROM `"._mysql_prefix."-root` WHERE id=".$query['home1'])); $home1_public=$home1_public['public'];
if($query['home2']!=-1){$home2_public=mysql_fetch_array(mysql_query("SELECT public FROM `"._mysql_prefix."-root` WHERE id=".$query['home2'])); $home2_public=$home2_public['public'];}else{$home2_public=1;}
if($query['home3']!=-1){$home3_public=mysql_fetch_array(mysql_query("SELECT public FROM `"._mysql_prefix."-root` WHERE id=".$query['home3'])); $home3_public=$home3_public['public'];}else{$home3_public=1;}

  if(_publicAccess($query['public']) and _publicAccess($home1_public) and _publicAccess($home2_public) and _publicAccess($home3_public)){
  $content="";

    /*-- navigation --*/
    if($query['visible']==1){
    $content.=$_lang['article.category'].": ";
      for($i=1; $i<=3; $i++){
        if($query['home'.$i]!=-1){
        $hometitle=mysql_fetch_array(mysql_query("SELECT title FROM `"._mysql_prefix."-root` WHERE id=".$query['home'.$i]));
        $content.="<a href='"._linkRoot($query['home'.$i])."'>".$hometitle['title']."</a>";
        }
        if($i!=3 and $query['home'.($i+1)]!=-1){$content.=", ";}
      }
    $content.="<div class='hr'><hr /></div>";
    }

    /*-- title --*/
    $title=$query['title'];
    if(_template_autoheadings){
    $content.="<h1>".$title."</h1>";
    }
    
    /*-- perex --*/
    $content.="<p class='article-perex'>"._parseHCM($query['perex'])."</p>";
    
    /*-- content --*/
    $content.=_parseHCM($query['content']);
    
    /*-- info --*/

      //preload contents
      $info=array(
      "basicinfo"=>null,
      "idlink"=>null,
      "rateresults"=>null,
      "rateform"=>null,
      "infobox"=>null
      );
      
        //basic info
        if($query['showinfo']==1){
          $info['basicinfo']="
          <strong>".$_lang['article.author'].":</strong> "._linkUser($query['author'])."<br />
          <strong>".$_lang['article.posted'].":</strong> "._formatTime($query['time'])."<br />
          <strong>".$_lang['article.readed'].":</strong> ".$query['readed']."x
          ";
        }
        
        //ID link
        if(_loginright_adminart){
        $info['idlink']=_condReturn($info['basicinfo']!=null, "<br />")."<strong>".$_lang['article.id'].":</strong> <a href='admin/index.php?p=content-articles-edit&id=".$id."&returnid=load&returnpage=1'>".$id."</a>";
        }
        
        //rate results
        if($query['rateon']==1){
        if($query['ratenum']!=0){$rate=(round($query['ratesum']/$query['ratenum']))."% (".$_lang['article.rate.num']." ".$query['ratenum']."x)";}else{$rate=$_lang['article.rate.nodata'];}
        $info['rateresults']=_condReturn($info['basicinfo']!=null or $info['idlink']!=null, "<br />")."<strong>".$_lang['article.rate'].":</strong> ".$rate;
        }
        
        //rate form
        $rateform_used=false;
        if($query['rateon']==1 and _loginright_artrate and _iplogCheck(3, $query['id'])){
        $info['rateform']=
        "<strong>".$_lang['article.rate.do'].":</strong>
        <form action='"._indexroot."remote/artrate.php' method='post'>
        <input type='hidden' name='id' value='".$query['id']."' />
        <select name='r'>
        ";

          for($x=0; $x<=100; $x+=10){
          if($x==50){$selected=" selected='selected'";}else{$selected="";}
          $info['rateform'].="<option value='".$x."'".$selected.">".$x."%</option>";
          }

        $info['rateform'].="
        </select>&nbsp;
        <input type='submit' value='".$_lang['global.do']."' />
        </form>
        ";
        }
        
        //infobox
        if($query['infobox']!=""){
        $info['infobox']=_parseHCM($query['infobox']);
        }
        
      //make code
      if(count(_arrayRemoveValue($info, null))!=0){
      
        //table-start
        $content.="
        <a name='ainfo'></a>
        <table class='article-info'>
        <tr valign='top'>
        ";
        
          //first cell
          if($info['basicinfo']!=null or $info['idlink']!=null or $info['rateresults']!=null or ($info['infobox']!=null and $info['rateform']!=null)){
          $content.="<td>".$info['basicinfo'].$info['idlink'].$info['rateresults'];
          
            //add rateform if infobox is taken
            if($info['rateform']!=null and ($info['infobox']!=null or $info['basicinfo']==null)){
            $content.=_condReturn($info['basicinfo']!=null/* or $info['idlink']!=null or $info['rateresults']!=null*/, "<br />")."<br />".$info['rateform'];
            $rateform_used=true;
            }
            
          $content.="</td>";
          
          }
          
          //second cell
          if($info['infobox']!=null or ($rateform_used==false and $info['rateform']!=null)){
          $content.="<td>";
            if($info['infobox']!=null){$content.=$info['infobox'];}
            if($rateform_used==false){$content.=$info['rateform'];}
          $content.="</td>";
          }

        //table end
        $content.="</tr></table>";
        
      }
      
    
    //comments
    if($query['comments']==1 and _comments){$content.=_commentsOutput(2, $id);}
    
    //incerase readed
    if($query['confirmed']==1 and _iplogCheck(2, $id)){
    mysql_query("UPDATE `"._mysql_prefix."-articles` SET readed=".($query['readed']+1)." WHERE id=".$id);
    _iplogUpdate(2, $id);
    }




  }
  else{
  $form=_uniForm("notpublic");
  $content=$form[0];
  $title=$form[1];
  }

return array($content, $title);
}

?>