<?php

/*---- return if checkbox is checked ----*/

function _checkboxLoad($input){
if(isset($_POST[$input])){return 1;}else{return 0;}
}

?>