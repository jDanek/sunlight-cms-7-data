<?php

/*---- return formatted posts ----*/

function _commentsOutput($type, $home, $vars=null){
global $_lang;

  /*--- customize ---*/
  switch($type){

    //section comments
    case 1:
    $subclass="comments";
    $title=$_lang['posts.comments'];
    $addlink=$_lang['posts.addcomment'];
    $nopostsmessage=$_lang['posts.nocomments'];
    $postsperpage=_commentsperpage;
    $canpost=_loginright_postcomments;
    $replynote=true;
    break;
    
    //article comments
    case 2:
    $subclass="comments";
    $title=$_lang['posts.comments'];
    $addlink=$_lang['posts.addcomment'];
    $nopostsmessage=$_lang['posts.nocomments'];
    $postsperpage=_commentsperpage;
    $canpost=_loginright_postcomments;
    $replynote=true;
    break;
    
    //book posts
    case 3:
    $subclass="book";
    $title=null;
    $addlink=$_lang['posts.addpost'];
    $nopostsmessage=$_lang['posts.noposts'];
    $postsperpage=$vars[0];
    $canpost=$vars[1];
    $replynote=true;
    break;

  }

  /*--- head ---*/
  $output="
  <a name='posts'></a>
  <div class='posts-".$subclass."'>
  ";
  
  if($title!=null){$output.="<h2>".$title._linkRss($home, $type)."</h2>";}
  
  $output.="<div class='posts-form'>";
  
  /*--- form or add link ---*/
  if(isset($_GET['addpost']) or isset($_GET['replyto'])){
  
    //load replyto param
    if(isset($_GET['replyto'])){$reply=intval($_GET['replyto']); if($replynote){$output.="<p>".$_lang['post.replynote']." (<a href='"._indexOutput_url."#posts'>".$_lang['global.cancel']."</a>).</p>";}}
    else{$reply=-1;}
  
    //submit form or login
    if($canpost){
    $form=_uniForm("postform", array('posttype'=>$type, 'posttarget'=>$home, 'xhome'=>$reply));
    $output.=$form[0];
    }
    else{
      $loginform=_uniForm("login", array('return'=>-1, 'returnpath'=>_indexOutput_url), true);
      $output.="<p>".$_lang['posts.loginrequired']."</p>".$loginform[0];
    }

  }
  else{
  $output.="<a href='"._addGetToLink(_indexOutput_url, "addpost")."#posts'>".$addlink." &gt;</a>";
  }

  $output.="</div>";

    //return message
    if(isset($_GET['r'])){
      switch($_GET['r']){
      case 0: $output.=_formMessage(2, $_lang['posts.failed']); break;
      case 1: $output.=_formMessage(1, $_lang['posts.added']); break;
      case 2: $output.=_formMessage(2, str_replace("*postsendexpire*", _postsendexpire, $_lang['posts.limit'])); break;
      }
    }

  $output.="<div class='hr'><hr /></div>";
  
  /*--- comments ---*/
  $paging=_resultPaging(_indexOutput_url, $postsperpage, "posts", "type=".$type." AND xhome=-1 AND home=".$home, "#posts");
  $output.=$paging[0];

  $query=mysql_query("SELECT * FROM `"._mysql_prefix."-posts` WHERE type=".$type." AND xhome=-1 AND home=".$home." ORDER BY id DESC ".$paging[1]);
  if(mysql_num_rows($query)!=0){
    while($item=mysql_fetch_array($query)){

      //load author's name
      if($item['guest']==""){$author=_linkUser($item['author'], "post-author");}
      else{$author="<span class='post-author-guest' title='".$item['ip']."'>".$item['guest']."</span>";}
      
      //action links
      $actlinks=" <span class='post-actions'>";
        $actlinks.="<a href='"._addGetToLink(_indexOutput_url, "replyto=".$item['id'])."#posts'>".$_lang['posts.reply']."</a>";
        if(_postAccess($item)){$actlinks.=" <a href='index.php?m=editpost&amp;id=".$item['id']."'>".$_lang['global.edit']."</a>";}
      $actlinks.="</span>";
      
      //post
      $output.="<div class='post-head'>".$author.", <span class='post-subject'>".$item['subject']."</span> <span class='post-info'>("._formatTime($item['time']).")</span>".$actlinks."</div><p class='post-body'>"._parsePost($item['text'])."</p>\n";
      
        //answers
        $answers=mysql_query("SELECT * FROM `"._mysql_prefix."-posts` WHERE type=".$type." AND home=".$home." AND xhome=".$item['id']." ORDER BY id");
        while($answer=mysql_fetch_array($answers)){
        
            //load author's name
            if($answer['guest']==""){$author=_linkUser($answer['author'], "post-author");}
            else{$author="<span class='post-author-guest' title='".$answer['ip']."'>".$answer['guest']."</span>";}

            //action links
            if(_postAccess($item)){$actlinks=" <span class='post-actions'><a href='index.php?m=editpost&amp;id=".$answer['id']."'>".$_lang['global.edit']."</a></span>";}
            else{$actlinks="";}
        
        $output.="<div class='post-answer'><div class='post-head'>".$author." ".$_lang['posts.replied']." <span class='post-info'>("._formatTime($answer['time']).")</span>".$actlinks."</div><p class='post-body'>"._parsePost($answer['text'])."</p></div>\n";
        }

    }
    
  if(_pagingmode==2){$output.="<br />".$paging[0];}
  }
  else{
  $output.="<p>".$nopostsmessage."</p>";
  }


$output.="</div>";
return $output;
}

?>