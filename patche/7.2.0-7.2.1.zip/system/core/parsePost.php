<?php

/*---- return parsed post text (bbcode tags, smileys etc.) ----*/
class Simple_BB_Code{
	//General Tags
	var $tags = array('code' => 'span class=\'pre\'', 'b' => 'strong','i' => 'em','u' => 'span style="text-decoration:underline"','quote' => 'blockquote','s' => 'span style="text-decoration: line-through"');
	//Tags that must be mapped to diffierent parts
	var $mapped = array('url' => array('a','href',true),'img' => array('img','src',false));
	//Tags with atributes
	var $tags_with_att = array('color' => array('font','color'),'size' => array('font','size'),'url' => array('a','href'));
	//Config Variables
	//Convert new line charactes to linebreaks?
	var $convert_newlines = true;
	//auto link urls(http and ftp), and email addresses?
	var $auto_links = true;
	//Internal Storage
	var $_code = '';
	function Simple_BB_Code($new=true,$parse=true,$links=true){
		$this->convert_newlines = $new;
		$this->auto_links = $links;
	}
	function parse($code){
		$this->_code = $code;
		$this->_strip_html();
		$this->_parse_tags();
		$this->_parse_mapped();
		$this->_parse_tags_with_att();
		$this->_parse_links();
		$this->_convert_nl();
		return $this->_code;
	}
	function _strip_html(){
		$this->_code = strip_tags($this->_code);
	}
	function _convert_nl(){
		if($this->convert_newlines){
			$this->_code = nl2br($this->_code);
		}
	}
	function _parse_tags(){
		foreach($this->tags as $old=>$new){
			$ex = explode(' ',$new);
			$this->_code = preg_replace('/\['.$old.'\](.+?)\[\/'.$old.'\]/is','<'.$new.'>$1</'.$ex[0].'>',$this->_code);
		}
	}
	function _parse_mapped(){
		foreach($this->mapped as $tag=>$data){
			$reg = '/\['.$tag.'\](.+?)\[\/'.$tag.'\]/is';
			if($data[2]){
				$this->_code = preg_replace($reg,'<'.$data[0].' '.$data[1].'="$1">$1</'.$data[0].'>',$this->_code);
			}
			else{
				$this->_code = preg_replace($reg,'<'.$data[0].' '.$data[1].'="$1" alt="img" />',$this->_code);
			}
		}
	}
	function _parse_tags_with_att(){
		foreach($this->tags_with_att as $tag=>$data){
			$this->_code = preg_replace('/\['.$tag.'=(.+?)\](.+?)\[\/'.$tag.'\]/is','<'.$data[0].' '.$data[1].'="$1">$2</'.$data[0].'>',$this->_code);
		}
	}
	function _parse_links(){
		if($this->auto_links){
			$this->_code = preg_replace('/([^"])(http:\/\/|ftp:\/\/)([^\s,]*)/i','$1<a href="$2$3" target="_blank" rel="nofollow">$2$3</a>',$this->_code);
			$this->_code = preg_replace('/([^"])([A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4})/i','$1<a href="mailto:$2">$2</a>',$this->_code);
		}
	}
}




function _parsePost($input){
$output=$input;

//parse bb code
if(_bbcode){
  $bb = new Simple_BB_Code();
  $output=$bb->parse($output);
}

//parse smileys
if(_smileys){
  $smileys_tags=array("*1*", "*2*", "*3*", "*4*", "*5*", "*6*", "*7*", "*8*", "*9*", "*10*");
  $smileys_imgs=array(
  "<img class='post-smiley' alt='1' src='"._indexroot."templates/"._template."/images/smileys/1.gif' />",
  "<img class='post-smiley' alt='2' src='"._indexroot."templates/"._template."/images/smileys/2.gif' />",
  "<img class='post-smiley' alt='3' src='"._indexroot."templates/"._template."/images/smileys/3.gif' />",
  "<img class='post-smiley' alt='4' src='"._indexroot."templates/"._template."/images/smileys/4.gif' />",
  "<img class='post-smiley' alt='5' src='"._indexroot."templates/"._template."/images/smileys/5.gif' />",
  "<img class='post-smiley' alt='6' src='"._indexroot."templates/"._template."/images/smileys/6.gif' />",
  "<img class='post-smiley' alt='7' src='"._indexroot."templates/"._template."/images/smileys/7.gif' />",
  "<img class='post-smiley' alt='8' src='"._indexroot."templates/"._template."/images/smileys/8.gif' />",
  "<img class='post-smiley' alt='9' src='"._indexroot."templates/"._template."/images/smileys/9.gif' />",
  "<img class='post-smiley' alt='10' src='"._indexroot."templates/"._template."/images/smileys/10.gif' />"
  );
  $output=str_replace($smileys_tags, $smileys_imgs, $output);
}

return $output;
}

?>