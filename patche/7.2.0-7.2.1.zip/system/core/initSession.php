<?php

/*---- initialize and check sessions ----*/

function _initSession(){
@session_start();
$result=0;

  //array of rights
  $rights_array=array(
  "level",
  "administration",
  "adminsettings",
  "adminusers",
  "admingroups",
  "admincontent",
  "adminsection",
  "admincategory",
  "adminbook",
  "adminseparator",
  "admingallery",
  "adminlink",
  "adminintersection",
  "adminart",
  "adminallart",
  "adminchangeartauthor",
  "adminpoll",
  "adminpollall",
  "adminbox",
  "adminconfirm",
  "adminneedconfirm",
  "adminfman",
  "adminfmanlimit",
  "adminfmanplus",
  "adminhcmphp",
  "adminbackup",
  "adminmassemail",
  "adminbans",
  "changeusername",
  "unlimitedpostaccess",
  "postcomments",
  "artrate",
  "pollvote"
  );

  //check session if exists
  if(isset($_SESSION[_sessionprefix."user"]) and isset($_SESSION[_sessionprefix."password"])){
  
    //checks
    $id=intval($_SESSION[_sessionprefix."user"]);
    $pass=$_SESSION[_sessionprefix."password"];
    $query=mysql_query("SELECT * FROM `"._mysql_prefix."-users` WHERE id=".$id);

      $continue=false;
      if(mysql_num_rows($query)!=0){
      $query=mysql_fetch_array($query);
      $groupblock=mysql_fetch_array(mysql_query("SELECT blocked FROM `"._mysql_prefix."-groups` WHERE id=".$query['group']));
        if($query['password']==$pass and $query['blocked']==0 and $groupblock['blocked']==0){
        $continue=true;
        }
      }

      //destroy invalid session
      if($continue!=true){
      $_SESSION=array();
      session_destroy();
      if(_administration!=1){header("location: "._indexroot."index.php?m=login&r=3");}
      else{header("location: "._indexroot."admin/index.php?r=3");}
      }

    //constants if valid session
    if($continue){
    $result=1;
    define('_loginid', $query['id']);
    define('_loginname', $query['username']);
    define('_loginemail', $query['email']);
    define('_loginwysiwyg', $query['wysiwyg']);
    define('_loginlanguage', $query['language']);
    define('_loginright_group', $query['group']);
    
      //depending on group
      $query=mysql_fetch_array(mysql_query("SELECT * FROM `"._mysql_prefix."-groups` WHERE id=".$query['group']));

            //major admin level
            if(_loginid==0){$query['level']=10001;}

        foreach($rights_array as $item){
        define('_loginright_'.$item, $query[$item]);
        }
    
      //act time
      mysql_query("UPDATE `"._mysql_prefix."-users` SET activitytime='".time()."', ip='".$_SERVER['REMOTE_ADDR']."' WHERE id="._loginid);

    }
  
  }
  else{

  //guest constants
  define('_loginid', -1);
  define('_loginname', '');
  define('_loginemail', '');
  define('_loginwysiwyg', 0);
  define('_loginlanguage', '*');
  define('_loginright_group', 2);
  
    //depending on group
    $query=mysql_fetch_array(mysql_query("SELECT * FROM `"._mysql_prefix."-groups` WHERE id=2"));

      foreach($rights_array as $item){
      define('_loginright_'.$item, $query[$item]);
      }
  }
  
  //define login indicator constant
  define('_loginindicator', $result);

}

?>