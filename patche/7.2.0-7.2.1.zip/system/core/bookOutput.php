<?php

/*---- return book output ----*/

function _bookOutput($id){
global $_lang;


$query=mysql_fetch_array(mysql_query("SELECT * FROM `"._mysql_prefix."-root` WHERE id=".$id));

//title, text
$title=$query['title'];
$content="";
if(_template_autoheadings){
$content.="<h1>".$query['title']._linkRSS($id, 3)."</h1>"._parseHCM($query['content']);
}
else{
$content.=_linkRSS($id, 4);
  if($query['content']!=""){
  $content.=_parseHCM($query['content']);
  }
}

//posts
$content.=_commentsOutput(3, $id, array($query['var2'], $query['var1']==1 or _loginindicator));
      

return array($content, $title);
}

?>