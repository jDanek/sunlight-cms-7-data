<?php

/*---- parse ".." elements in path ----*/

function _parsePath($path){
$path=_arrayRemoveValue(explode("/", trim($path, "/")), ".");
$loop=true;

  while($loop){

  $moverindex=-1;

    for($i=count($path)-1; $i>=0; $i--){
    if($path[$i]==".."){$moverindex=$i; break;}
    }

    if($moverindex!=-1){

      $collision=-1;

        for($i=$moverindex-1; $i>=0; $i--){
        if($path[$i]!=".."){$collision=$i; break;}
        }

        if($collision!=-1){
        $path=_arrayRemoveKey($path, $moverindex, true);
        $path=_arrayRemoveKey($path, $collision, true);
        $path=_arrayRemoveKey($path, -1);
        }
        else{
        $loop=false;
        }

    }
    else{
      $loop=false;
    }

  }

$output=implode("/", $path)."/";
if($output=="/"){$output="./";}
return $output;
}


?>