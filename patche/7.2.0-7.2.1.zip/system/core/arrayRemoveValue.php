<?php

/*---- remove keys with given value from an array ----*/

function _arrayRemoveValue($array, $value_remove, $preserve_keys=false){
$output=array();
if(is_array($array)){
  foreach($array as $key=>$value){
    if($value!=$value_remove){
      if(!$preserve_keys){$output[]=$value;}
      else{$output[$key]=$value;}
    }
  }
}
return $output;
}

?>