<?php

/*---- escape string for safe use in sql query ----*/

function _safeStr($input){
if(get_magic_quotes_gpc()==1){return mysql_escape_string(stripslashes($input));}
else{return mysql_escape_string($input);}
}

?>