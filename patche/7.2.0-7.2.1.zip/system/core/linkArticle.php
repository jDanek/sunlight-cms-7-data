<?php

/*---- url to article ----*/

function _linkArticle($id){

if(_modrewrite!=1){
  return "index.php?a=".$id;
}
else{
  $anchor=mysql_fetch_array(mysql_query("SELECT title FROM `"._mysql_prefix."-articles` WHERE id=".$id));
  return _anchorStr($anchor['title']).".a".$id._linksuffix;
}

}

?>