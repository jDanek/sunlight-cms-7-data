<?php

/*---- return filename and params of current script ----*/

function _currentScript($headerformat=false){

return
basename($_SERVER['PHP_SELF']).
_condReturn(
$_SERVER['QUERY_STRING']!="",
"?"._condReturn($headerformat==false, _htmlStr($_SERVER['QUERY_STRING']), $_SERVER['QUERY_STRING'])
);

}

?>