<?php

/*---- cut string to desired length ----*/

function _cutStr($string, $length, $convert_entities=true){
if($convert_entities){$string=_htmlStrUndo($string);}
if(mb_strlen($string)>$length){$string=mb_substr($string, 0, $length-3)."...";}
if($convert_entities){$string=_htmlStr($string);}
return $string;
}

?>