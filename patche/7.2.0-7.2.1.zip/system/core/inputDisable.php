<?php

/*---- return disable param depending on given conditions ----*/

function _inputDisable($cond){
if($cond!=true){return " disabled='disabled'";}
}

?>