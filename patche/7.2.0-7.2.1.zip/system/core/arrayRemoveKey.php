<?php

/*---- remove given index from an array ----*/

function _arrayRemoveKey($array, $key_remove, $preserve_keys=false){
$output=array();
if(is_array($array)){
  foreach($array as $key=>$value){
    if($key!=$key_remove){
      if(!$preserve_keys){$output[]=$value;}
      else{$output[$key]=$value;}
    }
  }
}
return $output;
}

?>