<?php

/*---- display error message and die ----*/

function _systemFailure($msg){
echo "<hr />\n<h1 style='color:#ff0000;'>Chyba</h1>\n<p>$msg</p>\n<hr />";
exit;
}

?>