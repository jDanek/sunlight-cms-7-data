<?php

/*---- anchor string for mod rewrite ----*/

function _anchorStr($input, $lower=true){

  //diacritics
  $input=str_replace(
  array("é", "ě", "É", "Ě", "ř", "Ř", "ť", "Ť", "ž", "Ž", "ú", "Ú", "ů", "Ů", "ü", "Ü", "í", "Í", "ó", "Ó", "á", "Á", "š", "Š", "ď", "Ď", "ý", "Ý", "č", "Č", "ň", "Ň", "ä", "Ä", "ĺ", "Ĺ", "ľ", "Ľ", "ŕ", "Ŕ", "ö", "Ö"),
  array("e", "e", "E", "E", "r", "R", "t", "T", "z", "Z", "u", "U", "u", "U", "u", "U", "i", "I", "o", "O", "a", "A", "s", "S", "d", "D", "y", "Y", "c", "C", "n", "N", "a", "A", "l", "L", "l", "L", "r", "R", "o", "O"),
  $input
  );

  //spaces
  $input=str_replace(" ", "-", $input);

  //disallowed symbols
  $output="";
  $len=mb_strlen($input);
  for($x=0; $x<$len; $x++){
  $char=mb_substr($input, $x, 1);
  if(in_array($char, array("A","a","B","b","C","c","D","d","E","e","F","f","G","g","H","h","I","i","J","j","K","k","L","l","M","m","N","n","O","o","P","p","Q","q","R","r","S","s","T","t","U","u","V","v","W","w","X","x","Y","y","Z","z","0","1","2","3","4","5","6","7","8","9",".","-"))){$output.=$char;}
  }

  //doubled symbols
  $output=preg_replace('|--+|', '-', $output);
  $output=preg_replace('|\.\.+|', '.', $output);
  $output=preg_replace('|\.-+|', '.', $output);
  $output=preg_replace('|-\.+|', '-', $output);
  
  //trim
  $output=trim($output, "-_.");

  //convert to lower-case
  if($lower==true){
  $output=mb_strtolower($output);
  }

  //return
  return $output;

}

?>