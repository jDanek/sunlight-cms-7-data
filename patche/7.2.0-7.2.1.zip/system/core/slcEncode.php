<?php

/*---- encode string ----*/

function _slcEncode($string){
$output="";

//num-level
$len=mb_strlen($string);
  for($x=0; $x<$len; $x++){
  $output.=ord(mb_substr($string, $x, 1))+$x.".";
  }
$output=trim($output, ".");

//compress-level
$output=@strrev(@base64_encode(@gzdeflate($output)));

//return
return $output;

}

?>