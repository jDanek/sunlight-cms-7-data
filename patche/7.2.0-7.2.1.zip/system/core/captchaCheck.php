<?php

/*---- check captcha ----*/

function _captchaCheck(){

if(_captcha and !_loginindicator){
  $cpk=str_replace("O", "0", mb_strtoupper(_slcDecode($_POST['_cpk'])));
  $cp=str_replace("O", "0", mb_strtoupper($_POST['_cp']));
  return $cpk==$cp;
}
else{
  return true;
}

}

?>