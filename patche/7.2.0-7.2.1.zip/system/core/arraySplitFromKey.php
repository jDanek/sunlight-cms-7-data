<?php

/*---- split keys of array into one ----*/

function _arraySplitFromKey($array, $keyfrom){
$output=array();
$counter=0;

if(is_array($array)){
  foreach($array as $key=>$value){

    if($counter>$keyfrom){
      if(!isset($output[$keyfrom])){$output[$keyfrom]=null;}
      $output[$keyfrom].=",".$value;
    }
    else{
      $output[]=$value;
    }

  $counter++;
  }
}
  
return $output;
}

?>