<?php

/*---- return current postdata as hidden inputs ----*/

function _savePostdata(){
$output="";
foreach($_POST as $key=>$value){$output.="<input type='hidden' name='"._htmlStr($key)."' value='"._htmlStr($value)."' />\n";}
return $output;
}

?>