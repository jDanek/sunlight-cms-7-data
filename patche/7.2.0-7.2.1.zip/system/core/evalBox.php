<?php

/*---- eval php code inside function ----*/

function _evalBox($code){
$output=null;
eval($code);
return $output;
}


?>