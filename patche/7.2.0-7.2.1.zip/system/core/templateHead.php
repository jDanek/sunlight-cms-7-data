<?php

/*---- print head content ----*/

function _templateHead(){

  //title
  if(_titletype==1){$title=_title.' '._titleseparator.' '._indexOutput_title;}
  else{$title=_indexOutput_title.' '._titleseparator.' '._title;}

global $_lang;
echo '<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<meta http-equiv="Content-Script-Type" content="text/javascript" />
<meta name="keywords" content="'._keywords.'" />
<meta name="description" content="'._description.'" />
<meta name="author" content="'._author.'" />
<meta name="generator" content="SunLight CMS '._systemversion.'" />
<meta name="robots" content="index, follow" />
<link href="'._indexroot.'templates/'._template.'/style.css" type="text/css" rel="stylesheet" />';

if(_lightbox){
echo '
<link rel="stylesheet" href="'._indexroot.'remote/lightbox/style.css" type="text/css" media="screen" />
<script type="text/javascript" src="'._indexroot.'remote/lightbox/prototype.js"></script>
<script type="text/javascript" src="'._indexroot.'remote/lightbox/scriptaculous.js?load=effects"></script>
<script type="text/javascript" src="'._indexroot.'remote/lightbox/lightbox.js"></script>';
}

if(_rss){
echo '
<link rel="alternate" type="application/rss+xml" href="'._indexroot.'remote/rss.php?tp=4&amp;id=-1" title="'.$_lang['rss.recentarticles'].'" />
<link rel="alternate" type="application/rss+xml" href="'._indexroot.'remote/rss.php?tp=5&amp;id" title="'.$_lang['rss.recentposts'].'" />';
}

echo '
<script type="text/javascript" src="'._indexroot.'remote/javascript.php"></script>
<title>'.$title.'</title>
';
}

?>