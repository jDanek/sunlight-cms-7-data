<?php

/*---- limit length of form input ----*/

function _jsLimitLength($maxlength, $form, $name){
return "
<script type='text/javascript'>
//<![CDATA[
document.onkeyup=proces;
document.onmouseup=proces;
document.onmousedown=proces;

function proces(){
value=document.$form.$name.value;
len=$maxlength-value.length;
  if(len<0){
  st=document.$form.$name.scrollTop;
  document.$form.$name.value=document.$form.$name.value.substring(0,$maxlength);
  document.$form.$name.scrollTop=st;
  _sysalert(2);
  }
}

//]]>
</script>
";
}

?>