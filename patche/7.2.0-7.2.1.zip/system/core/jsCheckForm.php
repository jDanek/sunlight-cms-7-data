<?php


/*---- check form fields by javascript ----*/

function _jsCheckForm($form, $inputs){
global $_lang;

//make code
$output=" onsubmit=\"if(";
$count=count($inputs);
for($x=1; $x<=$count; $x++){
$output.=$form.".".$inputs[$x-1].".value==''";
if($x!=$count){$output.=" || ";}
}
$output.="){_sysalert(1); return false;}\"";

//return
return $output;

}

?>