<?php

/*---- display form message ----*/

function _formMessage($type, $string){
return "<div class='message".$type."'>$string</div>";
}

?>