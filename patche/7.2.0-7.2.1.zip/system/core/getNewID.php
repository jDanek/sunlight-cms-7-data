<?php

/*---- get new id ----*/

function _getNewID($table){
$newid=mysql_query("SELECT id FROM `"._mysql_prefix."-".$table."` ORDER BY id DESC LIMIT 1");
if(mysql_num_rows($newid)==0){return 1;}
else{$newid=mysql_fetch_array($newid); return $newid['id']+1;}
}

?>