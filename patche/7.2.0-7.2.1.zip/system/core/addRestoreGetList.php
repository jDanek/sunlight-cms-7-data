<?php

/*---- make list of get variables for restore ----*/

function _addRestoreGetList($url, $array){

  //separate symbol in url
  if(mb_substr_count($url, "?")==0){$url.="?";}
  else{$url.="&";}

  //list
  foreach($array as $key=>$item){
  $url.="_formData[".$key."]=".$item."&";
  }

return mb_substr($url, 0, mb_strlen($url)-1);
}

?>