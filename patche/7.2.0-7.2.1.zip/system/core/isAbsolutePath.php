<?php

/*---- return true if given path is absolute ----*/

function _isAbsolutePath($path){
$path=parse_url($path);
return isset($path['scheme']);
}

?>