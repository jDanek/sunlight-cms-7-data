<?php

/*---- grant access if public or registered user ----*/

function _publicAccess($public){
  if($public==1 or ($public==0 and _loginindicator)){return true;}
  else{return false;}
}

?>