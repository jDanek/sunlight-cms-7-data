<?php

/*---- remove slashes from end of a string ----*/

function _removeSlashesFromEnd($string){
while(mb_substr($string, -1)=="/"){$string=mb_substr($string, 0, mb_strlen($string)-1);}
return $string;
}

?>