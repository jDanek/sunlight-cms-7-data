<?php

/*---- validate url ----*/

function _validateURL($uri){
return preg_match('/^(http|https|ftp):\/\/[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,6}((:[0-9]{1,5})?\/.*)?$/i' ,$uri);
}

?>