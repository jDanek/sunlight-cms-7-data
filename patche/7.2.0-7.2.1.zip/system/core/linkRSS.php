<?php

/*---- url to rss feed ----*/

function _linkRSS($id, $type, $space=true){
global $_lang;
if($space){$space=" ";}else{$space="";}
if(_rss){return $space."<a href='"._indexroot."remote/rss.php?tp=".$type."&amp;id=".$id."' target='_blank' title='".$_lang['rss.linktitle']."'><img src='"._indexroot."templates/"._template."/images/icons/rss.gif' alt='rss' class='icon' /></a>";}
}

?>