<?php

/*---- delete user ----*/

function _deleteUser($id){
if($id!=0){
  $username=mysql_fetch_array(mysql_query("SELECT username FROM `"._mysql_prefix."-users` WHERE id=".$id));
  mysql_query("DELETE FROM `"._mysql_prefix."-users` WHERE id=".$id);
  mysql_query("UPDATE `"._mysql_prefix."-posts` SET guest='".$username['username']."' WHERE author=".$id);
  mysql_query("UPDATE `"._mysql_prefix."-posts` SET author=-1 WHERE author=".$id);
  mysql_query("UPDATE `"._mysql_prefix."-articles` SET author=0 WHERE author=".$id);
  mysql_query("DELETE FROM `"._mysql_prefix."-messages` WHERE receiver=".$id." OR sender=".$id);
}
}

?>