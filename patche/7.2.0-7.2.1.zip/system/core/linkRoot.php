<?php

/*---- url to root item ----*/

function _linkRoot($id){

  if(_modrewrite!=1){
    return "index.php?p=".$id;
  }
  else{
    $anchor=mysql_fetch_array(mysql_query("SELECT title FROM `"._mysql_prefix."-root` WHERE id=".$id));
    return _anchorStr($anchor['title']).".p".$id._linksuffix;
  }

}

?>