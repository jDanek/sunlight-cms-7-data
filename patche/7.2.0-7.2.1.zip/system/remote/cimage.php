<?php

//core
define('_indexroot', '../');
require(_indexroot."core/_core.php");

//create image, decode number
$imgw=65; $imgh=22;
$img=imagecreate($imgw, $imgh);
$cpk=_slcDecode($_GET['cpk']);

//colors
$bg=imagecolorallocate($img, 255, 255, 255);
$dark=imagecolorallocate($img, 150, 150, 150);
$normal=imagecolorallocate($img, 200, 200, 200);
$bright=imagecolorallocate($img, 225, 225, 225);

//normal dots
$pocet=0;
while($pocet<=200){
imagesetpixel($img, mt_rand(0, $imgw-1), mt_rand(0, $imgh), $normal);
$pocet++;
}

//bright dots
$pocet=0;
while($pocet<=60){
imagesetpixel($img, mt_rand(0, $imgw), mt_rand(0, $imgh), $bright);
$pocet++;
}

//dark dots
$pocet=0;
while($pocet<=20){
imagesetpixel($img, mt_rand(0, $imgw), mt_rand(0, $imgh), $dark);
$pocet++;
}

//normal lines
$pocet=0;
while($pocet<=5){
imageline($img, mt_rand(0, $imgw), mt_rand(0, $imgh), mt_rand(0, $imgw), mt_rand(0, $imgh), $normal);
$pocet++;
}

//border
imagerectangle($img, 0, 0, $imgw-1, $imgh-1, $normal);

//text
imagestring($img, 5, 10, 3, $cpk, $dark);

//return image
header("Content-type: image/PNG");
imagepng($img);
imagedestroy($img);

?>