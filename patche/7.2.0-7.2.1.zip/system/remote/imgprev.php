<?php

/*--- initialize core ---*/
define('_indexroot', '../');
require(_indexroot."core/_core.php");

/*--- load url ---*/
$continue=false;
if(isset($_GET['id'])){

$extensions=array("jpg", "jpeg", "png", "gif");

  if(!isset($_GET['c'])){
  $id=intval($_GET['id']);
  $imgdata=mysql_query("SELECT full,home FROM `"._mysql_prefix."-images` WHERE id=".$id);
    if(mysql_num_rows($imgdata)!=0){
    $imgdata=mysql_fetch_array($imgdata);
    $galdata=mysql_fetch_array(mysql_query("SELECT var3 FROM `"._mysql_prefix."-root` WHERE id=".$imgdata['home']));
    $url=pathinfo($imgdata['full']);
    if(!isset($url['extension'])){$url['extension']="";}
    $fname=_indexroot.$imgdata['full'];
    $newheight=$galdata['var3'];
      if(@file_exists($fname) and $newheight<=1024 and in_array(mb_strtolower($url['extension']), $extensions)){$continue=true;}
    }
  }
  else{
  $id=_indexroot._slcDecode($_GET['id'], true);
  $url=pathinfo($id);
  if(!isset($url['extension'])){$url['extension']="";}
  $fname=$id;
  if(isset($_GET['h'])){$newheight=intval($_GET['h']);}else{$newheight=96;}
    if(@file_exists($fname) and $newheight<=1024 and in_array(mb_strtolower($url['extension']), $extensions)){$continue=true;}
  }

}


if($continue){

  /*load image*/
  switch(mb_strtolower($url['extension'])){
  case "jpg": case "jpeg": $source=@imagecreatefromjpeg($fname); break;
  case "png": $source=@imagecreatefrompng($fname); break;
  case "gif": $source=@imagecreatefromgif($fname); break;
  }

  /*compute new width*/
  list($width, $height)=getimagesize($fname);
  $newwidth=round(($width/$height)*$newheight);

  /*create thumb*/
  $result=imagecreatetruecolor($newwidth, $newheight);
  imagecopyresampled($result, $source, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);

}
else{
$result=imagecreate(192, $newheight);
$bg=imagecolorallocate($result, 255, 255, 255);
$text=imagecolorallocate($result, 150, 150, 150);
imagestring($result, 5, 5, 5, $_lang['imgprev.badimage'], $text);
}

/*--- image output ---*/
header("Cache-Control: max-age=1200, must-revalidate");
header("Expires: ".gmdate("D, d M Y H:i:s", time()+1200)." GMT");
header("Content-type: image/jpeg");
imagejpeg($result);
imagedestroy($result);
exit;

?>