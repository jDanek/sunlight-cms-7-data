<?php

/*--- core ---*/
define('_indexroot', '../');
require(_indexroot."core/_core.php");

/*--- post ---*/
$continue=false;

  /*-- load variables --*/
  
    //guest name or user id
    if(_loginindicator){
    $guest="";
    $author=_loginid;
    }
    else{
    $guest=$_POST['guest'];
    if(mb_strlen($guest)>24){$guest=mb_substr($guest, 0, 24);}
    $guest=_anchorStr($guest);
    $author=-1;
    }
    
  $posttarget=intval($_POST['_posttarget']);
  $posttype=intval($_POST['_posttype']);
  $xhome=intval($_POST['_xhome']);
  $text=_safeStr(_htmlStr(_wsTrim(_cutStr($_POST['text'], 3072, false))));
  if($xhome==-1){$subject=_safeStr(_htmlStr(_wsTrim(_cutStr($_POST['subject'], 22, false))));}else{$subject="";}

    //fill empty
    if($subject=="" and $xhome==-1){$subject="-";}
    if($guest=="" and !_loginindicator){$guest=$_lang['posts.anonym'];}

  /*-- check target --*/
  switch($posttype){

      //section comment
      case 1:

        //check section
        $tdata=mysql_query("SELECT public,var1 FROM `"._mysql_prefix."-root` WHERE id=".$posttarget." AND type=1");
          if(mysql_num_rows($tdata)!=0){
          $tdata=mysql_fetch_array($tdata);
            if(_publicAccess($tdata['public']) and $tdata['var1']==1){
            $continue=true;
            }
          }

      break;
      
      //article comment
      case 2:
      
        //check article
        $tdata=mysql_query("SELECT public,comments FROM `"._mysql_prefix."-articles` WHERE id=".$posttarget);
          if(mysql_num_rows($tdata)!=0){
          $tdata=mysql_fetch_array($tdata);
            if(_publicAccess($tdata['public']) and $tdata['comments']==1){
            $continue=true;
            }
          }
      
      break;
      
      //book post
      case 3:
      
        //check book
        $tdata=mysql_query("SELECT public,var1 FROM `"._mysql_prefix."-root` WHERE id=".$posttarget." AND type=3");
          if(mysql_num_rows($tdata)!=0){
          $tdata=mysql_fetch_array($tdata);
            if(_publicAccess($tdata['public']) and _publicAccess($tdata['var1'])){
            $continue=true;
            }
          }
      
      break;

  }
  
  /*-- check post for answer --*/
  if($xhome!=-1){
  $continue2=false;
  $ptest=mysql_query("SELECT xhome FROM `"._mysql_prefix."-posts` WHERE id=".$xhome." AND home=".$posttarget);
    if(mysql_num_rows($ptest)!=0){
    $ptest=mysql_fetch_array($ptest);
      if($ptest['xhome']==-1){$continue2=true;}
    }
  }
  else{
  $continue2=true;
  }
  
  /*-- save post --*/
  if($continue and $continue2 and $text!="" and _captchaCheck()){
    if(_iplogCheck(5)){
      $newid=_getNewID("posts");
      mysql_query("INSERT INTO `"._mysql_prefix."-posts` (id,type,home,xhome,subject,text,author,guest,time,ip) VALUES (".$newid.",".$posttype.",".$posttarget.",".$xhome.",'".$subject."','".$text."',".$author.",'".$guest."',".time().",'"._userip."')");
      if(!_loginright_unlimitedpostaccess){_iplogUpdate(5);}
      $return=1;
    }
    else{
    $return=2;
    }
  }
  else{
  $return=0;
  }

/*--- header ---*/
$_GET['_return']=_addGetToLink($_GET['_return'], "&r=".$return);
_returnHeader();

?>