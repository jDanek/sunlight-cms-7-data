<?php

/*--- core ---*/
if(!defined('_core')){
define('_indexroot', '../');
require(_indexroot."core/_core.php");
}

/*--- destroy sessions ---*/
if(_loginindicator==1){
$_SESSION[_sessionprefix."user"]=null;
$_SESSION[_sessionprefix."password"]=null;
$_SESSION=array();
unset($_SESSION[_sessionprefix."user"]);
unset($_SESSION[_sessionprefix."user"]);
session_destroy();
}

/*--- header ---*/
if(!isset($logout_noreturn)){_returnHeader();}

?>