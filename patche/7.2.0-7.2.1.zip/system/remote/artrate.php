<?php

/*--- core ---*/
define('_indexroot', '../');
require(_indexroot."core/_core.php");

/*--- rate ---*/

  //load vars
  $id=intval($_POST['id']);
  $r=round($_POST['r']/10)*10;
  
  //checks
  $continue=true;
  
    //article, iplog
    $query=mysql_query("SELECT confirmed,rateon,time FROM `"._mysql_prefix."-articles` WHERE id=".$id);
    if(mysql_num_rows($query)!=0){
    $query=mysql_fetch_array($query);
    if($query['time']>time() or $query['confirmed']!=1 or $query['rateon']!=1 or !_iplogCheck(3, $id)){$continue=false;}
    }
    else{
    $continue=false;
    }
    
    //rate value
    if($r>100 or $r<0){$continue=false;}
    
  //rate
  if($continue){
  mysql_query("UPDATE `"._mysql_prefix."-articles` SET ratenum=ratenum+1 WHERE id=".$id);
  mysql_query("UPDATE `"._mysql_prefix."-articles` SET ratesum=ratesum+".$r." WHERE id=".$id);
  _iplogUpdate(3, $id);
  }
  
  //return
  if($continue){$aurl=_linkArticle($id);}else{$aurl="";}
  header("location: "._indexroot.$aurl."#ainfo");
  


?>