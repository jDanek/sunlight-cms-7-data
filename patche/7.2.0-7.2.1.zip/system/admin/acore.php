<?php

/*-- core check, init vars --*/
if(!defined('_core')){exit;}
define('_indexOutput_url', 'index.php');

/*-- wysiwyg --*/
function _tmp_wysiwyg(){
if(_wysiwyg and _loginwysiwyg){return file_get_contents(_indexroot."admin/modules/tinymce.slam");}
}

/*-- list of types --*/
function _tmp_getTypeArray(){
return array(
1=>"section",
2=>"category",
3=>"book",
4=>"separator",
5=>"gallery",
6=>"link",
7=>"intersection"
);
}
$type_array=_tmp_getTypeArray();

/*-- small note --*/
function _tmp_smallNote($str){
return "<p class='note'><img src='images/icons/note.gif' alt='note' class='icon' />".$str."</p>";
}

/*-- poll access query clause --*/
function _tmp_pollAccess($csep=true){
if($csep){$csep=" AND ";}else{$csep="";}
return _condReturn(!_loginright_adminallart, $csep."author="._loginid, $csep."(author="._loginid." OR (SELECT level FROM `"._mysql_prefix."-groups` WHERE id=(SELECT `group` FROM `"._mysql_prefix."-users` WHERE id=`"._mysql_prefix."-polls`.author))<"._loginright_level.")");
}

/*-- article access query clause --*/
function _tmp_artAccess(){
if(_loginright_adminallart){return " AND (author="._loginid." OR (SELECT level FROM `"._mysql_prefix."-groups` WHERE id=(SELECT `group` FROM `"._mysql_prefix."-users` WHERE id=`"._mysql_prefix."-articles`.author))<"._loginright_level.")";}
else{return " AND author="._loginid;}
}

/*-- article link --*/
function _tmp_articleEditLink($art, $ucnote=true){
global $_lang;
$output="";

 //class
  $class="";
  if($art['visible']==0 and $art['public']==1){$class=" class='invisible'";}
  if($art['visible']==1 and $art['public']==0){$class=" class='notpublic'";}
  if($art['visible']==0 and $art['public']==0){$class=" class='invisible-notpublic'";}

  //link
  $output.="<a href='"._indexroot._linkArticle($art['id'])."' target='_blank'".$class.">";
  if($art['time']<=time()){$output.="<strong>";}
  $output.=$art['title'];
  if($art['time']<=time()){$output.="</strong>";}
  $output.="</a>";

  //unconfirmed note
  if($art['confirmed']!=1 and $ucnote){$output.="&nbsp;&nbsp;<small>(".$_lang['global.unconfirmed'].")</small>";}

return $output;
}

/*-- category select --*/
function _tmp_categorySelect($name, $selected, $allowempty, $emptycustomcaption=null){
global $_lang;
$return="<select name='".$name."' class='ae-artselect'>";
$cats=mysql_query("SELECT id,title,type FROM `"._mysql_prefix."-root` WHERE (type=2 OR type=7) AND intersection=-1 ORDER BY ord");
if(mysql_num_rows($cats)!=0){
if($allowempty){if($emptycustomcaption==null){$emptycustomcaption=$_lang['admin.content.form.category.none'];} $return.="<option value='-1' class='special'># ".$emptycustomcaption."</option>";}
  while($cat=mysql_fetch_array($cats)){
    if($cat['type']==2){
      if($cat['id']==$selected){$sel=" selected='selected'";}else{$sel="";}
      $return.="<option value='".$cat['id']."'".$sel.">"._cutStr($cat['title'], 22)."</option>";
    }
    else{
    $icats=mysql_query("SELECT id,title,type FROM `"._mysql_prefix."-root` WHERE type=2 AND intersection=".$cat['id']." ORDER BY ord");
      if(mysql_num_rows($icats)!=0){
      $return.="<optgroup label='".$cat['title']."'>";
        while($icat=mysql_fetch_array($icats)){
        if($icat['id']==$selected){$sel=" selected='selected'";}else{$sel="";}
        $return.="<option value='".$icat['id']."'".$sel.">"._cutStr($icat['title'], 22)."</option>";
        }
      $return.="</optgroup>";
      }
    }
  }
}
else{$return.="<option value='-1'>".$_lang['global.nokit']."</option>";}
$return.="</select>";
return $return;
}

/*-- author select --*/
function _tmp_authorSelect($name, $selected, $gcond, $class=null, $emptycustomcaption=null){
if($class!=null){$class=" class='".$class."'";}
$return="<select name='".$name."'".$class.">";
$query=mysql_query("SELECT id,title,level FROM `"._mysql_prefix."-groups` WHERE ".$gcond." ORDER BY level DESC");
if($emptycustomcaption!=null){$return.="<option value='-1' class='special'># ".$emptycustomcaption."</option>";}
  while($item=mysql_fetch_array($query)){
  $users=mysql_query("SELECT id,username FROM `"._mysql_prefix."-users` WHERE `group`=".$item['id']." AND (".$item['level']."<"._loginright_level." OR id="._loginid.")");
    if(mysql_num_rows($users)!=0){
    $return.="<optgroup label='".$item['title']."'>";
      while($user=mysql_fetch_array($users)){
      if($selected==$user['id']){$sel=" selected='selected'";}else{$sel="";}
      $return.="<option value='".$user['id']."'".$sel.">".$user['username']."</option>";
      }
    $return.="</optgroup>";
    }

  }
$return.="</select>";
return $return;
}

/*-- edit time --*/
function _tmp_editTime($timestamp, $updatebox=false, $updateboxchecked=false){
global $_lang;
$timestamp=getdate($timestamp);
$return="<input type='text' size='1' maxlength='2' name='tday' value='".$timestamp['mday']."' />.<input type='text' size='1' maxlength='2' name='tmonth' value='".$timestamp['mon']."' />&nbsp;&nbsp;<input type='text' size='3' maxlength='4' name='tyear' value='".$timestamp['year']."' />&nbsp;&nbsp;<input type='text' size='1' maxlength='2' name='thour' value='".$timestamp['hours']."' />:<input type='text' size='1' maxlength='2' name='tminute' value='".$timestamp['minutes']."' />:<input type='text' size='1' maxlength='2' name='tsecond' value='".$timestamp['seconds']."' />&nbsp;&nbsp;<small>".$_lang['admin.content.form.timehelp']."</small>";
  if($updatebox){
  if($updateboxchecked){$updateboxchecked=" checked='checked'";}else{$updateboxchecked=null;}
  $return.="&nbsp;&nbsp;<label><input type='checkbox' name='tupdate' value='1'".$updateboxchecked." /> ".$_lang['admin.content.form.timeupdate']."</label>";
  }
return $return;
}

function _tmp_loadTime($default){
if(!_checkboxLoad('tupdate')){
  $day=intval($_POST['tday']);
  $month=intval($_POST['tmonth']);
  $year=intval($_POST['tyear']);
  $hour=intval($_POST['thour']);
  $minute=intval($_POST['tminute']);
  $second=intval($_POST['tsecond']);
  if(checkdate($month, $day, $year) and $hour>=0 and $hour<24 and $minute>=0 and $minute<60 and $second>=0 and $second<60){return mktime($hour, $minute, $second, $month, $day, $year);}
  else{return $default;}
}
else{
return time();
}
}

?>