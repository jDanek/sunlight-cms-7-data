<?php

/*--- core test ---*/
if(!defined('_core')){exit;}

/*--- customize and require editscript --*/
$type=4;
require("require/sub/content-editscript-init.php");
require("require/sub/content-editscript.php");

?>