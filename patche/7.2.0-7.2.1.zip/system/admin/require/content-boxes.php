<?php

/*--- core test ---*/
if(!defined('_core')){exit;}

/*--- output ---*/
$output.="<p class='bborder'>".$_lang['admin.content.boxes.p']."</p>
<p><a href='index.php?p=content-boxes-new'><img src='images/icons/new.gif' alt='new' class='icon' />".$_lang['admin.content.boxes.create']."</a></p><br />

<table class='widetable'>
<tr><td><strong>".$_lang['admin.content.boxes.column']."</strong></td><td><strong>".$_lang['admin.content.boxes.totalboxes']."</strong></td></tr>
";

  $query=mysql_query("SELECT DISTINCT `column` FROM `"._mysql_prefix."-boxes` ORDER BY `column`");
  while($item=mysql_fetch_array($query)){
  $output.="<tr><td><a href='index.php?p=content-boxes-edit&amp;c=".$item['column']."' class='block'><strong>".$item['column']."</strong></a></td><td>".mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-boxes` WHERE `column`=".$item['column']), 0)."</td></tr>\n";
  }
  
$output.="</table>";

?>