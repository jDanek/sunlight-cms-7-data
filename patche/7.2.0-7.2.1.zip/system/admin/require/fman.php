<?php

/*---- core test ----*/

if(!defined('_core')){exit;}


/*---- init functions ----*/

function _tmp_cparam($value, $encoded=true){
if($encoded){$value=@base64_decode($value);}
return str_replace("/", "", $value);
}

function _tmp_mparam($value, $urlencode=true){
$output=base64_encode($value);
if($urlencode){$output=urlencode($output);}
return $output;
}

function _tmp_issafefile($filename){
  if(!_loginright_adminfmanplus){
    $filename=pathinfo($filename);
    if(!isset($filename['extension'])){$filename['extension']="";}
    return !in_array($filename['extension'], array("php", "php3", "php4", "php5", "phtml", "shtml", "asp", "py", "cgi", "htaccess"));
  }
  else{
  return true;
  }
}

function _tmp_deletefolder($dirname, $only_empty=false){
   if (!@is_dir($dirname))
       return false;
   $dscan = array(realpath($dirname));
   $darr = array();
   while (!empty($dscan)) {
       $dcur = array_pop($dscan);
       $darr[] = $dcur;
       if ($d=@opendir($dcur)) {
           while ($f=@readdir($d)) {
               if ($f=='.' || $f=='..')
                   continue;
               $f=$dcur.'/'.$f;
               if (@is_dir($f))
                   $dscan[] = $f;
               else
                   @unlink($f);
           }
           closedir($d);
       }
   }
   $i_until = ($only_empty)? 1 : 0;
   for ($i=count($darr)-1; $i>=$i_until; $i--) {
       @rmdir($darr[$i]);

   }
   return (($only_empty)? (count(scandir)<=2) : (!@is_dir($dirname)));
}


/*---- init vars ----*/

$continue=true;
$message="";
$action_code="";
if(!_loginright_adminfmanlimit){$defdir="../upload/";}
else{$defdir="../upload/"._loginname."/";}

  //dir
  if(isset($_GET['dir'])){
    $dir=str_replace("\\", "/", $_GET['dir']);
    if(mb_substr($dir, -1, 1)!="/"){$dir.="/";}
    if(!_loginright_adminfmanplus){if(mb_substr_count($dir, "..")>1){$dir=$defdir;}}
    if(!_loginright_adminfmanplus or _loginright_adminfmanlimit){if(mb_substr($dir, 0, mb_strlen($defdir))!=$defdir){$dir=$defdir;}}
    if(!@file_exists($dir) or !@is_dir($dir)){$dir=$defdir;}
  }
  else{
  $dir=$defdir;
  }

  //create defdir
  if(!(@file_exists($defdir) and @is_dir($defdir))){
  $test=@mkdir($defdir);
    if(!$test){$continue=false; $output.=_formMessage(3, $_lang['admin.fman.msg.defdircreationfailure']); @chmod($defdir, 0777);}
  }
  
  $url_base="index.php?p=fman&amp;";
  $url=$url_base."dir=".$dir;


/*---- actions, output ----*/
if($continue){

    /*--- post actions ---*/
    if(isset($_POST['action'])){

    switch($_POST['action']){
    
    //upload
    case "upload":
    $total=0;
    $done=0;
      foreach($_FILES as $item){
      $name=_tmp_cparam($item['name'], false);
      $tmp_name=$item['tmp_name'];
        if(_tmp_issafefile($name) and !@file_exists($dir.$name)){
          if(@move_uploaded_file($tmp_name, $dir.$name)){$done++;}
        }
      $total++;
      }
    $tfrom=array("*done*", "*total*");
    $tto=array($done, $total);
    if($done==$total){$micon=1;}else{$micon=2;}
    $message=_formMessage($micon, str_replace($tfrom, $tto, $_lang['admin.fman.msg.upload.done']));
    break;
    
    //new folder
    case "newfolder":
    $name=_tmp_cparam($_POST['name'], false);
    if(!@file_exists($dir.$name)){
      $test=@mkdir($dir.$name);
        if($test){$message=_formMessage(1, $_lang['admin.fman.msg.newfolder.done']); @chmod($dir.$name, 0777);}
        else{$message=_formMessage(2, $_lang['admin.fman.msg.newfolder.failure']);}
    }
    else{
    $message=_formMessage(2, $_lang['admin.fman.msg.newfolder.failure2']);
    }
    break;
    
    //delete
    case "delete":
    $name=_tmp_cparam($_POST['name']);
      if(@file_exists($dir.$name)){
        if(!@is_dir($dir.$name)){
          if(_tmp_issafefile($name)){
            if(@unlink($dir.$name)){$message=_formMessage(1, $_lang['admin.fman.msg.delete.done']);}
            else{$message=_formMessage(2, $_lang['admin.fman.msg.delete.failure']);}
          }
          else{
          $message=_formMessage(2, $_lang['admin.fman.msg.disallowedextension']);
          }
        }
        else{
          _tmp_deletefolder($dir.$name);
          if(!@file_exists($dir.$name)){$message=_formMessage(1, $_lang['admin.fman.msg.delete.done']);}
          else{$message=_formMessage(2, $_lang['admin.fman.msg.delete.failure']);}
        }
      }
    break;
    
    //rename
    case "rename":
    $name=_tmp_cparam($_POST['name']);
    $newname=_tmp_cparam($_POST['newname'], false);
      if(@file_exists($dir.$name)){
        if(!@file_exists($dir.$newname)){
          if(_tmp_issafefile($newname) and _tmp_issafefile($name)){
            if(@rename($dir.$name, $dir.$newname)){$message=_formMessage(1, $_lang['admin.fman.msg.rename.done']);}
            else{$message=_formMessage(2, $_lang['admin.fman.msg.rename.failure']);}
          }
          else{
          $message=_formMessage(2, $_lang['admin.fman.msg.disallowedextension']);
          }
        }
        else{
          $message=_formMessage(2, $_lang['admin.fman.msg.exists']);
        }
      }
    break;
    
    //edit
    case "edit":
    $name=_tmp_cparam($_POST['name'], false);
    $content=stripslashes($_POST['content']);
    if(_tmp_issafefile($name)){
      $file=@fopen($dir.$name, "w");
        if($file){
          @fwrite($file, $content);
          fclose($file);
          $message=_formMessage(1, $_lang['admin.fman.msg.edit.done']."&nbsp;&nbsp;<small>("._formatTime(time()).")</small>");
        }
        else{
          $message=_formMessage(2, $_lang['admin.fman.msg.edit.failure']);
        }
    }
    else{
    $message=_formMessage(2, $_lang['admin.fman.msg.disallowedextension']);
    }
    break;
    
    //move
    case "move":
    $newdir=_arrayRemoveValue(explode("/", $_POST['param']), null);
    $newdir=implode("/", $newdir);
    if(mb_substr($newdir, -1, 1)!="/"){$newdir.="/";}
    $newdir=_parsePath($dir.$newdir);
    if(_loginright_adminfmanplus or mb_substr($newdir, 0, mb_strlen($defdir))==$defdir){
      $done=0;
      $total=0;

        foreach($_POST as $var=>$val){
        if($var=="action" or $var=="param"){continue;}
        $val=_tmp_cparam($val);
          if(@file_exists($dir.$val) and !@file_exists($newdir.$val) and !@is_dir($dir.$val) and _tmp_issafefile($val)){
            if(@rename($dir.$val, $newdir.$val)){$done++;}
          }

        $total++;
        }

      $tfrom=array("*done*", "*total*");
      $tto=array($done, $total);
      if($done==$total){$micon=1;}else{$micon=2;}
      $message=_formMessage($micon, str_replace($tfrom, $tto, $_lang['admin.fman.msg.move.done']));
    }
    else{
    $message=_formMessage(2, $_lang['admin.fman.msg.rootlimit']);
    }
    break;
    
    //delete selected
    case "deleteselected":
    $done=0;
    $total=0;

      foreach($_POST as $var=>$val){
      if($var=="action" or $var=="param"){continue;}
      $val=_tmp_cparam($val);
        if(@file_exists($dir.$val) and !@is_dir($dir.$val) and _tmp_issafefile($val)){
          if(@unlink($dir.$val)){$done++;}
        }

      $total++;
      }

    $tfrom=array("*done*", "*total*");
    $tto=array($done, $total);
    if($done==$total){$micon=1;}else{$micon=2;}
    $message=_formMessage($micon, str_replace($tfrom, $tto, $_lang['admin.fman.msg.deleteselected.done']));
    break;
    
    //add selected to gallery
    case "addtogallery":
    if(_loginright_admingallery and _loginright_admincontent){
    
      //load and init vars
      $counter=0;
      $allowed_extensions=array("png", "jpeg", "jpg", "gif");
      $galid=intval($_POST['param']);

      //add images
      if(mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-root` WHERE id=".$galid." AND type=5"), 0)!=0){

        //load smaller order number
        $smallerord=mysql_query("SELECT ord FROM `"._mysql_prefix."-images` WHERE home=".$galid." ORDER BY ord LIMIT 1");
        if(mysql_num_rows($smallerord)!=0){$smallerord=mysql_fetch_array($smallerord); $smallerord=$smallerord['ord'];}
        else{$smallerord=1;}
        
        //move order numbers
        mysql_query("UPDATE `"._mysql_prefix."-images` SET ord=ord+".(count($_POST)-2)." WHERE home=".$galid);

        //cycle
        foreach($_POST as $var=>$val){
        if($var=="action" or $var=="param"){continue;}
        $val=_tmp_cparam($val);
        $ext=pathinfo($val);
        if(isset($ext['extension'])){$ext=mb_strtolower($ext['extension']);}else{$ext="";}
          if(@file_exists($dir.$val) and !@is_dir($dir.$val) and in_array($ext, $allowed_extensions)){
            $newid=_getNewID("images");
            mysql_query("INSERT INTO `"._mysql_prefix."-images` (id,home,ord,title,prev,full) VALUES(".$newid.",".$galid.",".($smallerord+$counter).",'','*auto*','".mb_substr($dir.$val, 3)."')");
            $counter++;
          }
        }
        
        //message
        $message=_formMessage(1, str_replace("*done*", $counter, $_lang['admin.fman.selected.addtogallery.done']));
        
      }
      else{
      $message=_formMessage(2, $_lang['admin.fman.selected.addtogallery.failure']);
      }
      
    }
    break;

  }
  
  }

  /*--- get actions ---*/
  if(isset($_GET['a'])){

    //switch
    switch($_GET['a']){

      //new folder
      case "newfolder":
      $action_submit="global.create";
      $action_acbonus="";
      $action_title="admin.fman.menu.createfolder";
      $action_code="
      <tr>
      <td class='rpad'><strong>".$_lang['global.name'].":</strong></td>
      <td><input type='text' name='name' class='inputsmall' maxlength='64' /></td>
      </tr>
      ";
      break;
    
      //delete
      case "delete":
      if(isset($_GET['name'])){
        $name=$_GET['name'];
        $action_submit="global.do";
        $action_acbonus="";
        $action_title="admin.fman.delete.title";
        $action_code="
        <tr>
        <td colspan='2'>".str_replace("*name*", _htmlStr(_tmp_cparam($name)), $_lang['admin.fman.delask'])."<input type='hidden' name='name' value='"._htmlStr($name)."' /></td>
        </tr>
        ";
      }
      break;
      
      //rename
      case "rename":
      if(isset($_GET['name'])){
        $name=$_GET['name'];
        $action_submit="global.do";
        $action_acbonus="";
        $action_title="admin.fman.rename.title";
        $action_code="
        <tr>
        <td class='rpad'><strong>".$_lang['admin.fman.newname'].":</strong></td>
        <td><input type='text' name='newname' class='inputsmall' maxlength='64' value='"._htmlStr(_tmp_cparam($name))."' /><input type='hidden' name='name' value='"._htmlStr($name)."' /></td>
        </tr>
        ";
      }
      break;
      
      //edit
      case "edit":

        //init
        $continue=false;
        if(isset($_GET['name'])){
        $name=$_GET['name'];
        $dname=_tmp_cparam($name);
          if(@file_exists($dir.$dname)){
            if(_tmp_issafefile($dname)){
              $new=false;
              $continue=true;
              $content=@file_get_contents($dir.$dname);
            }
            else{
            $message=_formMessage(2, $_lang['admin.fman.msg.disallowedextension']);
            }
          }
        }
        else{
        $name="bmV3LnR4dA==";
        $content="";
        $new=true;
        $continue=true;
        }
      
        //form
        if($continue){
        $action_submit="global.save";
        $action_acbonus=_condReturn(!$new, "&amp;a=edit&amp;name=".$name, "");
        $action_title="admin.fman.edit.title";
        $action_code="
        <tr>
        <td class='rpad'><strong>".$_lang['global.name']."</strong></td>
        <td><input type='text' name='name' class='inputmedium' maxlength='64' value='"._htmlStr(_tmp_cparam($name))."' />&nbsp;&nbsp;<small>"._condReturn(!$new, $_lang['admin.fman.edit.namenote'], $_lang['admin.fman.edit.namenote2'])."</small></td>
        </tr>

        <tr valign='top'>
        <td class='rpad'><strong>".$_lang['admin.content.form.content']."</strong></td>
        <td><textarea rows='25' cols='94' class='areabig' name='content' wrap='off'>"._htmlStr($content)."</textarea></td>
        </tr>
        ";
        }
      
      break;
      
      //upload
      case "upload":
      $action_submit="global.send";
      $action_acbonus="";
      $action_title="admin.fman.menu.upload";
      $action_code="
      <tr valign='top'>
      <td class='rpad'><strong>".$_lang['admin.fman.file'].":</strong></td>
      <td><input type='file' name='f0' />&nbsp;&nbsp;<a href='#' onclick='return _sys_addfile();'>".$_lang['admin.fman.upload.addfile']."</a>";
      
        $files=2;
        while($files<=128){
        $action_code.="<span id=\"f".$files."\"></span>";
        $files++;
        }
      
      $action_code.="</td></tr>";
      break;

    }

    //complete code
    if($action_code!=""){
    $action_code="
    <div id='fman-action'>
    <h2>".$_lang[$action_title]."</h2>
    <form action='".$url.$action_acbonus."' method='post' enctype='multipart/form-data'>
    <input type='hidden' name='action' value='".$_GET['a']."' />
    <table>
    ".$action_code."

      <tr>
      <td></td>
      <td><input type='submit' value='".$_lang[$action_submit]."' />&nbsp;&nbsp;<a href='".$url."'>".$_lang['global.cancel']."</a></td>
      </tr>
    
    </table>
    </form>
    </div>
    ";
    }

  }

  /*--- output ---*/
  
    //menu, action
    $output.=$message."
    <a name='top'></a>
    <p class='fman-menu'>
    <a href='".$url."&amp;a=upload'>".$_lang['admin.fman.menu.upload']."</a>
    <a href='".$url."&amp;a=edit'>".$_lang['admin.fman.menu.createfile']."</a>
    <a href='".$url."&amp;a=newfolder'>".$_lang['admin.fman.menu.createfolder']."</a>
    <a href='".$url_base."dir=".$defdir."'>".$_lang['admin.fman.menu.home']."</a>
    <strong>".$_lang['admin.fman.currentdir'].":</strong> ".$dir."
    </p>

    ".$action_code;
    
    //list
    $output.="
    <form class='cform' action='".$url."' method='post' name='filelist'>
    <input type='hidden' name='action' value='-1' />
    <input type='hidden' name='param' value='-1' />
    <table id='fman-list'>
    <tr><td width='60%'></td><td width='15%'></td><td width='25%'></td></tr>
    ";
    
    $highlight=false;
    
      //folders
      $handle=@opendir($dir);
      $items=array();
      while($item=@readdir($handle)){if(@is_dir($dir.$item) and $item!="." and $item!=".."){$items[]=$item;}}
      natsort($items); $items=array_merge(array(".."), $items);
      foreach($items as $item){

        //parent link or dir
        if($item==".."){
        	if(mb_substr($dir, mb_strlen($dir)-3, 3)!="../" and $dir!="./"){
          	$dirhref=mb_substr($dir, 0, mb_strrpos($dir, '/'));
          	$dirhref=mb_substr($dirhref, 0, mb_strrpos($dirhref, '/'));
        	}
        	else{
          	$dirhref=$dir."..";
          	if (!(@file_exists($dirhref))){continue;}
        	}
        }
        else{
          $dirhref=$dir.$item;
        }

      if($highlight){$hl_class=" class='hl'";}else{$hl_class="";}

      $output.="
      <tr".$hl_class.">
      <td colspan='"._condReturn($item=="..", "3", "2")."'><a href='".$url_base."dir=".$dirhref."/'><img src='images/icons/fman/directory.gif' alt='dir' class='icon' />"._htmlStr(_cutStr($item, 64, false))."</a></td>
      "._condReturn($item!="..", "<td class='actions'><a href='".$url."&amp;a=delete&amp;name="._tmp_mparam($item)."'>".$_lang['global.delete']."</a> | <a href='".$url."&amp;a=rename&amp;name="._tmp_mparam($item)."'>".$_lang['admin.fman.rename']."</a></td>")."
      </tr>
      ";
      
      $highlight=!$highlight;
      }
      
      $output.="<tr><td colspan='3'>&nbsp;</td></tr>";
    
      //files
      rewinddir($handle);
      $items=array();
      while($item=@readdir($handle)){if(!@is_dir($dir.$item) and $item!=".."){$items[]=$item;}}
      natsort($items);
      $filecounter=0;
      $sizecounter=0;
      foreach($items as $item){
      $filecounter++;

        //icon
        $iteminfo=pathinfo($item);
        if(!isset($iteminfo['extension'])){$iteminfo['extension']="";}
        $ext=mb_strtolower($iteminfo['extension']);
        $icon="other";
        if(in_array($ext, array("rar", "zip", "tar", "gz", "tgz", "7z", "cab", "xar", "xla", "777", "alz", "arc", "arj", "bz", "bz2", "bza", "bzip2", "dz", "gza", "gzip", "lzma", "lzs", "lzo", "s7z", "taz", "tbz", "tz", "tzip"))){$icon="archive";}
        else{
        if(in_array($ext, array("jpg", "jpeg", "png", "gif", "bmp", "jp2", "psd", "cpt", "cdr", "tga", "pcx", "tif", "ppf", "pct", "pic", "ai"))){$icon="image";}
        else{
        if(in_array($ext, array("php", "php3", "php4", "php5", "phtml", "py", "asp", "cgi", "shtml", "htaccess", "txt", "nfo", "rtf", "html", "htm", "xhtml", "css", "js", "ini", "bat", "inf", "me", "slam", "inc"))){$icon="editable";}
        else{
        if(in_array($ext, array("wav", "mp3", "mid", "rmi", "wma", "mpeg", "mpg", "wmv", "3gp", "mp4", "m4a", "xac", "aif", "au", "avi", "voc", "snd", "vox", "ogg", "flac", "mov", "aac", "vob", "amr", "asf", "rm", "ra", "ac3"))){$icon="media";}
        else{
        if(in_array($ext, array("exe", "com", "bat", "dll"))){$icon="executable";}
        }
        }
        }
        }


      $filesize=@filesize($dir.$item);

      if($highlight){$hl_class=" class='hl'";}else{$hl_class="";}

      $output.="
      <tr".$hl_class.">
      <td><input type='checkbox' name='f".$filecounter."' value='"._tmp_mparam($item, false)."' /> <a href='".$dir._htmlStr($item)."' target='_blank'><img src='images/icons/fman/".$icon.".gif' alt='file' class='icon' />"._htmlStr(_cutStr($item, 64, false))."</a></td>
      <td>".(round($filesize/1024))."kB</td>
      <td class='actions'>"._condReturn(_tmp_issafefile($item), "<a href='".$url."&amp;a=delete&amp;name="._tmp_mparam($item)."'>".$_lang['global.delete']."</a> | <a href='".$url."&amp;a=rename&amp;name="._tmp_mparam($item)."'>".$_lang['admin.fman.rename']."</a>"._condReturn($icon=="editable", " | <a href='".$url."&amp;a=edit&amp;name="._tmp_mparam($item)."'>".$_lang['admin.fman.edit']."</a>"))."</td>
      </tr>
      ";
      
      $sizecounter+=$filesize;

      $highlight=!$highlight;
      }
      
      
    $output.="
    </table>
    </form>
    
    <p class='fman-menu'>
    <span><strong>".$_lang['admin.fman.filecounter'].":</strong> ".$filecounter." <small>(".round($sizecounter/1024)."kB)</small></span>
    <a href='#' onclick='return _sys_fman_selectall(".$filecounter.")'>".$_lang['admin.fman.selectall']."</a>
    <a href='#' onclick='return _sys_fman_deselectall(".$filecounter.")'>".$_lang['admin.fman.deselectall']."</a>
    <strong>".$_lang['admin.fman.selected'].":</strong>&nbsp;&nbsp;
    <a href='#' onclick='return _sys_fman_moveselected()'>".$_lang['admin.fman.selected.move']."</a>
    <a href='#' onclick='return _sys_fman_deleteselected()'>".$_lang['admin.fman.selected.delete']."</a>
    <a href='#top'><big>&uarr;</big></a>
    </p>
    ";
    
      //extra functions
      if(_loginright_admingallery and _loginright_admincontent){
      $output.="
      <p class='fman-menu2'>
      <strong>".$_lang['admin.fman.extra'].":</strong>&nbsp;&nbsp;<a href='#' onclick='return _sys_fman_addselectedtogallery()'>".$_lang['admin.fman.selected.addtogallery']."</a>
      </p>
      ";
      }

}

?>