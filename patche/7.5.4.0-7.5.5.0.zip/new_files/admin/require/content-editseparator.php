<?php
/* ---  kontrola jadra  --- */
if (!defined('_core')) {
    exit;
}

/* ---  nastaveni a vlozeni skriptu pro upravu stranky  --- */
$type = 4;
require 'require/sub/content-editscript-init.php';
require 'require/sub/content-editscript.php';
