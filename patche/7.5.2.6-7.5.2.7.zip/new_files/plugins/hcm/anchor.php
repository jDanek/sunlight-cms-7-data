<?php

if(!defined('_core')) {
exit;
}


function _HCM_anchor($nazev = '')
{
if(_modrewrite) {
return _path.'#'.$nazev;
} else {
return '#'.$nazev;
}
}
