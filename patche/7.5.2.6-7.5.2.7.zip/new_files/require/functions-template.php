<?php

if(!defined('_core')) {
exit;
}








function _templateBoxes($column = 1, $return = false)
{

$output = "\n";

if(!_notpublicsite or _loginindicator) {


if(_loginindicator) $public = "";
else $public = " AND public=1";


if(_template_boxes_parent != "") $output .= "<"._template_boxes_parent.">\n";
$query = DB::query("SELECT title,content,class FROM `"._mysql_prefix."-boxes` WHERE visible=1 AND `column`=".$column.$public." ORDER BY ord");
while($item = DB::row($query)) {


if($item['title'] != "") $title = "<"._template_boxes_title." class='box-title'>".$item['title']."</"._template_boxes_title.">\n";
else $title = "";


if(_template_boxes_title_inside == 0 and $title != "") $output .= $title;


if(_template_boxes_item != "") $output .= "<"._template_boxes_item." class='box-item".(isset($item['class']) ? ' '.$item['class'] : '')."'>\n";


if(_template_boxes_title_inside == 1 and $title != "") $output .= $title;


$output .= _xsrfAutoProtect(_parseHCM($item['content']));


if(_template_boxes_item != "") $output .= "\n</"._template_boxes_item.">";


if(_template_boxes_bottom == 1) $output .= "<"._template_boxes_item." class='box-bottom'></"._template_boxes_item.">\n\n";
else $output .= "\n\n";

}
if(_template_boxes_parent != "") $output .= "</"._template_boxes_parent.">\n";

}


if($return) return $output;
echo $output;

}







function _templateContent($return = false)
{


$output = '';
$extend_args = _extendArgs($output);
_extend('call', 'tpl.content.before', $extend_args);
$output .= _indexOutput_content;
_extend('call', 'tpl.content.after', $extend_args);


if(!$return) echo $output;
else return $output;

}





function _templateHead()
{


$title = null;
_extend('call', 'tpl.title', array('title' => &$title, 'head' => true));
if(!isset($title)) {
if(_titletype == 1) $title = _title.' '._titleseparator.' '._indexOutput_title;
else $title = _indexOutput_title.' '._titleseparator.' '._title;
}

$extend_output = '';
$extendOutputArgs = _extendArgs($extend_output);
_extend('call', 'tpl.head.meta', $extendOutputArgs);

global $_lang;
if(_modrewrite) echo "<base href=\""._url."/\" />\n";
echo '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="keywords" content="'.(defined('_indexOutput_keywords') ? _indexOutput_keywords : _keywords).'" />
<meta name="description" content="'.(defined('_indexOutput_description') ? _indexOutput_description : _description).'" />'.((_author !== '') ? '
<meta name="author" content="'._author.'" />' : '').'
<meta name="generator" content="SunLight CMS '._systemversion.' '.$GLOBALS['__sys_state'][_systemstate]._systemstate_revision.'" />
<meta name="robots" content="index, follow" />'.$extend_output.'
<link href="'._indexroot.'plugins/templates/'._template.'/style/system.css?'._cacheid.'" type="text/css" rel="stylesheet" />
<link href="'._indexroot.'plugins/templates/'._template.'/style/layout.css?'._cacheid.'" type="text/css" rel="stylesheet" />
<script type="text/javascript">/* <![CDATA[ */var sl_indexroot=\''._indexroot.'\';/* ]]> */</script>
<script type="text/javascript" src="'._indexroot.'remote/jscript.php?'._cacheid.'&amp;'._language.'"></script>';

$extend_output = '';
_extend('call', 'tpl.head', $extendOutputArgs);
echo $extend_output;

if(_lightbox) {
$extend_output = '';
_extend('call', 'tpl.lightbox', $extendOutputArgs);
if('' === $extend_output) {
echo '
<link rel="stylesheet" href="'._indexroot.'remote/lightbox/style.css?'._cacheid.'" type="text/css" media="screen" />
<script type="text/javascript" src="'._indexroot.'remote/lightbox/script.js?'._cacheid.'"></script>';
} else {
echo $extend_output;
}
}

if(_rss) {
echo '
<link rel="alternate" type="application/rss+xml" href="'._indexroot.'remote/rss.php?tp=4&amp;id=-1" title="'.$_lang['rss.recentarticles'].'" />';
}

if(_favicon) {
echo '
<link rel="shortcut icon" href="./favicon.ico?'._cacheid.'" />';
}

echo '
<title>'.$title.'</title>
';
}






function _templateLinks($left_separator = false)
{
global $_lang;
if($left_separator) {
echo " "._template_listinfoseparator." ";
}
echo "<a href='http://sunlight.shira.cz/'>SunLight CMS</a>".((!_adminlinkprivate or (_loginindicator and _loginright_administration)) ? " "._template_listinfoseparator." <a href='"._indexroot."admin/index.php'>".$_lang['admin.link']."</a>" : '');
}







function _templateImage($path)
{
return _indexroot."plugins/templates/"._template."/images/".$path;
}









function _templateMenu($ord_start = null, $ord_end = null, $parent_class = 'menu')
{
$output = "";
if(defined("_indexOutput_pid")) $pid = _indexOutput_pid;
else $pid = -1;

if(!_notpublicsite or _loginindicator) {


if($ord_start === null or $ord_end === null) $ord_limit = $inter_ord_limit = "";
else {
$ord_limit = " AND page.ord>=".intval($ord_start)." AND page.ord<=".intval($ord_end);
$inter_ord_limit = " AND inter.ord>=".intval($ord_start)." AND inter.ord<=".intval($ord_end);
}


$tree = array();
$query = DB::query("SELECT page.id,page.type,page.title,page.title_seo,page.var1,page.var2,page.intersection FROM `"._mysql_prefix."-root` AS page LEFT JOIN `"._mysql_prefix."-root` AS inter ON(page.intersection=inter.id) WHERE page.visible=1 AND page.type!=4 AND (inter.id IS NULL".$ord_limit." OR inter.var2=1".$inter_ord_limit.") ORDER BY page.intersection,page.ord");
while($item = DB::row($query)) {
if($item['intersection'] == -1) $tree[$item['id']] = $item;
else {
if(!isset($tree[$item['intersection']]['children'])) $tree[$item['intersection']]['children'] = array();
$tree[$item['intersection']]['children'][] = $item;
}
}
DB::free($query);


$output .= "<"._template_menu_parent." class='".$parent_class."'>\n";
$counter = 0;
$last = sizeof($tree) - 1;
foreach($tree as $item) {


$classes = array();
_extend('call', 'tpl.menu.item', array('item' => &$item, 'classes' => &$classes, 'sub' => false));


if(empty($item['children'])) {


if($item['id'] == $pid) $classes[] = 'act';
if($item['type'] == 6 and $item['var1'] == 1) {
$target = " target='_blank'";
} else {
$target = "";
}
$link = "<a href='"._linkRoot($item['id'], $item['title_seo'])."'".$target.">".$item['title']."</a>";

} else {


$icounter = 0;
$ilast = sizeof($item['children']) - 1;
$childactive = false;

$link_sublistitems = '';
foreach($item['children'] as $iitem) {
_extend('call', 'tpl.menu.item', array('item' => &$iitem, 'sub' => true));
$classes[] = 'menu-item-'.str_replace('/', '_', $iitem['title_seo']);
if($iitem['id'] == $pid) {
$classes[] = 'act';
$childactive = true;
}
if($icounter === 0) $classes[] = 'first';
if($icounter !== 0 && $icounter === $ilast) $classes[] = 'last';
if($iitem['type'] == 6 and $iitem['var1'] == 1) {
$target = " target='_blank'";
} else {
$target = "";
}
$link_sublistitems .= "    <li".(!empty($classes) ? ' class="'.implode(' ', $classes).'"' : '')."><a href='"._linkRoot($iitem['id'], $iitem['title_seo'])."'".$target.">".$iitem['title']."</a></li>\n";
$classes = array();
++$icounter;
}

if(!$childactive && $item['id'] == $pid) $childactive = true;
$classes[] = 'menu-dropdown';
if($childactive || $item['id'] == $pid) $classes[] = 'act';

$link = "<a href='"._linkRoot($item['id'], $item['title_seo'])."' class='menu-dropdown-link'>".$item['title']."</a>";
if($link_sublistitems !== '') $link .= "\n<ul class='menu-dropdown-list'>
".$link_sublistitems."</ul>\n";

}

$classes[] = 'menu-item-'.str_replace('/', '_', $item['title_seo']);
if($counter === 0) $classes[] = 'first';
if($counter !== 0 && $counter === $last) $classes[] = 'last';
$output .= "<"._template_menu_child.(!empty($classes) ? ' class="'.implode(' ', $classes).'"' : '').">".$link."</"._template_menu_child.">\n";
++$counter;

}

$output .= "</"._template_menu_parent.">";

}

return $output;

}






function _templateTitle($return = false)
{


$title = null;
_extend('call', 'tpl.title', array('title' => &$title, 'head' => false));
if(!isset($title)) $title = _indexOutput_title;


if($return) return $title;
echo $title;

}






function _templateUserMenu($return = false)
{
global $_lang;

$output = "";

if(_template_usermenu_parent != "") $output .= "<"._template_usermenu_parent.">\n";

$extend_args = _extendArgs($output);
_extend('call', 'tpl.usermenu.first', $extend_args);

if(!_loginindicator) {

$output .= _template_usermenu_item_start."<a href='"._indexroot."index.php?m=login&amp;login_form_return=".urlencode($_SERVER['REQUEST_URI'])."' class='usermenu-item-login'>".$_lang['usermenu.login']."</a>"._template_usermenu_item_end."\n";
if(_registration) {

$output .= _template_usermenu_item_start."<a href='"._indexroot."index.php?m=reg' class='usermenu-item-reg'>".$_lang['usermenu.registration']."</a>"._template_usermenu_item_end."\n";
}
} else {

if(_messages) {
$messages_count = DB::result(DB::query("SELECT COUNT(id) FROM `"._mysql_prefix."-pm` WHERE (receiver="._loginid." AND receiver_deleted=0 AND receiver_readtime<update_time) OR (sender="._loginid." AND sender_deleted=0 AND sender_readtime<update_time)"), 0);
if($messages_count != 0) {
$messages_count = " [".$messages_count."]";
} else {
$messages_count = "";
}
$output .= _template_usermenu_item_start."<a href='"._indexroot."index.php?m=messages' class='usermenu-item-messages'>".$_lang['usermenu.messages'].$messages_count."</a>"._template_usermenu_item_end."\n";
}

$output .= _template_usermenu_item_start."<a href='"._indexroot."index.php?m=settings' class='usermenu-item-settings'>".$_lang['usermenu.settings']."</a>"._template_usermenu_item_end."\n";
_extend('call', 'tpl.usermenu.beforelogout', $extend_args);

$output .= _template_usermenu_item_start."<a href='"._xsrfLink(_indexroot."remote/logout.php?_return=".urlencode($_SERVER['REQUEST_URI']))."' class='usermenu-item-logout'>".$_lang['usermenu.logout'].(_template_usermenu_showusername ? " ["._loginname."]" : '')."</a>"._template_usermenu_item_end."\n";
}

if(_ulist and (!_notpublicsite or _loginindicator)) {

$output .= _template_usermenu_item_start."<a href='"._indexroot."index.php?m=ulist' class='usermenu-item-ulist'>".$_lang['usermenu.ulist']."</a>"._template_usermenu_item_end."\n";
}

_extend('call', 'tpl.usermenu.last', $extend_args);

if(_template_usermenu_parent != "") $output .= "</"._template_usermenu_parent.">\n";

if(_template_usermenu_trim == 1) {
$output = trim($output);
$output = trim($output, _template_usermenu_item_start);
$output = trim($output, _template_usermenu_item_end);
}


if($return) return $output;
echo $output;

}






function _templatePageID()
{
return _indexOutput_pid;
}






















function _templatePageType()
{
return _indexOutput_ptype;
}






function _templatePageIsIndex()
{
return (_indexOutput_pid == _index_page_id && _indexOutput_ptype !== 'article' && _indexOutput_ptype !== 'module' && _indexOutput_ptype !== 'custom');
}












function _templateGetRequest()
{
if(isset($_GET['m'])) return array('m', strval($_GET['m']));
elseif(_modrewrite && isset($_GET['_rwp'])) return ((_indexOutput_ptype === '') ? array('x', strval($_GET['_rwp'])) : array(((_indexOutput_ptype === 'article') ? 'a' : 'p'), strval($_GET['_rwp']), $GLOBALS['query']['id']));
elseif(_templatePageIsIndex()) return array('p', $GLOBALS['query']['title_seo']);
elseif(!_modrewrite && isset($_GET['p'])) return array('p', strval($_GET['p']), $GLOBALS['query']['id']);
elseif(!_modrewrite && isset($_GET['a'])) return array('a', strval($_GET['a']), $GLOBALS['query']['id']);
return array('x', null);
}







function _templateFileOverload($fname, $full_path = false)
{
if(isset($fname) && !$full_path) $fname = _indexroot.'plugins/templates/'._template.'/'.$fname.'.php';
$GLOBALS['__template_overload'] = $fname;
}







function _templateAutoTitle($no_title_modules = null)
{


if(_template_autoheadings) return;


$hidden = true;
$request = _templateGetRequest();
if(null === $no_title_modules) $no_title_modules = array('topic' => 0, 'locktopic' => 1, 'stickytopic' => 2, 'movetopic' => 3, 'editpost' => 4);
if($request[0] === 'm' && !isset($no_title_modules[$request[1]]) || $request[0] === 'p' && ($GLOBALS['query']['intersection'] != -1 || $GLOBALS['query']['visible'] == 0)) {

$hidden = false;
} elseif($request[0] === 'a') return;


echo '<h1'.($hidden ? ' class="hidden"' : '').'>'._templateTitle(true).'</h1>'._nl;

}
