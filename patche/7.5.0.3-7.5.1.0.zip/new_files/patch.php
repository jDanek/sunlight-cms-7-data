<?php

// pripojeni k db
require 'config.php';
$con = @mysql_connect($server, $user, $password);
if(!is_resource($con)) die('Nepodarilo se pripojit k databazi!<br>'.mysql_error());
if(!@mysql_select_db($database)) die('Nepodarilo se zvolit aktualni databazi!');
mysql_query('SET NAMES `utf8`');

// zjisteni verze db
$q = mysql_query('SELECT val FROM `'.$prefix.'-settings` WHERE var=\'dbversion\'');
if(!is_resource($q) || mysql_num_rows($q) !== 1) die('Nepodarilo se zjistit verzi databaze!');
$q = mysql_fetch_assoc($q);
$q = $q['val'];

// kontrola verze db
if($q !== '7.5.0') {
    if($q === '7.5.1') die('Patch byl jiz aplikovan, smazte soubor patch.php!');
    die('Nespravna verze databaze!');
}

// priprava sql dotazu
$sql = array();
$sql[] = 'UPDATE `'.$prefix.'-settings` SET `val` = \'7.5.1\' WHERE `var` = \'dbversion\'';
$sql[] = 'ALTER TABLE `'.$prefix.'-root` ADD `type_idt` VARCHAR( 16 ) NULL DEFAULT NULL AFTER `type`';
$sql[] = 'ALTER TABLE `'.$prefix.'-groups` ADD `adminpluginpage` BOOLEAN NOT NULL AFTER `adminforum`';
$sql[] = 'UPDATE `'.$prefix.'-groups` SET `adminpluginpage` = \'1\' WHERE `id` = 1';
$sql[] = 'ALTER TABLE `'.$prefix.'-groups` ADD `stickytopics` BOOLEAN NOT NULL AFTER `locktopics`';
$sql[] = 'UPDATE `'.$prefix.'-groups` SET `stickytopics` = \'1\' WHERE `id` = 1';
$sql[] = 'ALTER TABLE `'.$prefix.'-posts` ADD `sticky` BOOLEAN NOT NULL DEFAULT \'0\' AFTER `bumptime`, ADD INDEX ( `sticky` )';
$sql[] = 'ALTER TABLE `'.$prefix.'-posts` ADD `flag` INT UNSIGNED NOT NULL DEFAULT \'0\' AFTER `sticky`, ADD INDEX ( `flag` )';
$sql[] = 'ALTER TABLE `'.$prefix.'-root` ADD `events` VARCHAR( 96 ) NULL DEFAULT NULL AFTER `autotitle`';
$sql[] = 'ALTER TABLE `'.$prefix.'-groups` ADD `movetopics` BOOLEAN NOT NULL AFTER `stickytopics`';
$sql[] = 'UPDATE `'.$prefix.'-groups` SET `movetopics` = \'1\' WHERE `id` =1';
$sql[] = 'ALTER TABLE `'.$prefix.'-images` CHANGE `title` `title` VARCHAR( 64 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL';
$sql[] = 'UPDATE `'.$prefix.'-groups` SET `administration` = \'0\',`selfdestruction` = \'0\' WHERE `id` =2';


// provedeni
for($i = 0; isset($sql[$i]); ++$i) {
    mysql_query($sql[$i]);
    $error = mysql_error();
    if(!empty($error)) {
        echo 'Chyba pri aktualizaci databaze!<br><br>Chyba:'.$error.'<br><br>SQL dotaz:<br>'.$sql[$i];
        echo '<br /><br />';
        echo "Pozor! Pro pripadny dotaz na oficialni diskusi nebo jinde si tuto chybovou hlasku okopirujte!";
        die;
    }
}

// ok
echo 'OK! Databaze byla aktualizovana na verzi 7.5.1.';
if(!@unlink(__FILE__)) echo '<br>Smazte soubor patch.php!';
