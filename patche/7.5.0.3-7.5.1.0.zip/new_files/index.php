<?php


if(!defined('_index_noinit')) {
define('_indexroot', './');
require _indexroot."require/load.php";
}


require _indexroot."require/functions-template.php";



$notpublic_form = false;
$notpublic_form_wholesite = false;
$found = true;


if(!empty($_POST) && !_xsrfCheck()) {


$output = '';
require _indexroot.'require/xsrfscreen.php';
$output = _xsrfAutoProtect($output);
define('_indexOutput_title', $_lang['xsrf.title']);
define('_indexOutput_content', $output);

} elseif(_publicAccess(!_notpublicsite) or (isset($_GET['m']) and in_array($_GET['m'], array("login", "reg", "lostpass")))) {


if(isset($_GET['m'])) {
$mid = strval($_GET['m']);
if(_loginindicator or !in_array($mid, array("settings", "editpost", "messages"))) {


$ok = true;
$nologin = false;
$custom = false;
$file = null;
switch($mid) {


case "login":
define('_indexOutput_title', $_lang['login.title']);
break;


case "ulist":
if(_ulist) define('_indexOutput_title', $_lang['admin.users.list']);
else $ok = false;
break;


case "reg":
if(_registration and !_loginindicator) define('_indexOutput_title', $_lang['mod.reg']);
else {
$ok = false;
$nologin = true;
}
break;


case "lostpass":
if(_lostpass and !_loginindicator) define('_indexOutput_title', $_lang['mod.lostpass']);
else {
$ok = false;
$nologin = true;
}
break;


case "profile":
define('_indexOutput_title', $_lang['mod.profile']);
break;


case "profile-arts":
define('_indexOutput_title', $_lang['mod.profile.arts']);
break;


case "profile-posts":
define('_indexOutput_title', $_lang['mod.profile.posts']);
break;


case "settings":
define('_indexOutput_title', $_lang['mod.settings']);
break;


case "editpost":
define('_indexOutput_title', $_lang['mod.editpost']);
break;


case "locktopic":
define('_indexOutput_title', $_lang['mod.locktopic']);
break;


case "stickytopic":
define('_indexOutput_title', $_lang['mod.stickytopic']);
break;


case "movetopic":
define('_indexOutput_title', $_lang['mod.movetopic']);
break;


case "messages":
if(_messages) define('_indexOutput_title', $_lang['mod.messages']);
else $ok = false;
break;


case "search":
if(_search) define('_indexOutput_title', $_lang['mod.search']);
else $ok = false;
break;


case "topic":

break;


default:

$title = null;
_extend('call', 'mod.custom.'.$mid, array('file' => &$file, 'title' => &$title));
if(isset($file, $title)) {

$custom = true;
define('_indexOutput_title', $title);
} else $ok = false;
break;

}


if($ok) {


$module = '';
define('_indexOutput_ptype', 'module');
define('_indexOutput_pid', $mid);
if($mid !== 'topic') define('_indexOutput_url', "index.php?m=".$mid);


$extend_args = _extendArgs($module, array('mid' => $mid, 'custom' => &$custom, 'file' => &$file));
_extend('call', 'mod.'.$mid.'.pre', $extend_args);


require $custom ? $file : _indexroot.'require/mod/'.$mid.'.php';
_extend('call', 'mod.'.$mid.'.post', $extend_args);


$module = _xsrfAutoProtect($module);


define('_indexOutput_content', $module);

} elseif($nologin) {

define('_indexOutput_title', $_lang['nologin.title']);
define('_indexOutput_content', (_template_autoheadings ? "<h1>"._indexOutput_title."</h1>" : '')._formMessage(1, $_lang['nologin.msg']));

}

} else {
$notpublic_form = true;
}
}

else {


if(_modrewrite && isset($_GET['_rwp'])) {

$type = null;
$ids = $_GET['_rwp'];
$rewritten = true;
} elseif(isset($_GET['a'])) {

$type = 1;
$ids = $_GET['a'];
$rewritten = false;
} elseif(isset($_GET['p'])) {

$type = 0;
$ids = $_GET['p'];
$rewritten = false;
} else {

$type = 0;
$ids = null;
$rewritten = null;
}


if(isset($ids)) $ids = strval($ids);
$continue = true;


do {


if($type !== 1) {
$query = DB::row(DB::query("SELECT page.*,inter.id AS inter_id,inter.title_seo AS inter_title_seo, inter.public AS inter_public,inter.level AS inter_level,inter.var2 AS inter_var2 FROM `"._mysql_prefix."-root` AS page LEFT JOIN `"._mysql_prefix."-root` AS inter ON(page.intersection=inter.id) WHERE page.type!=4 AND ".(isset($ids) ? 'page.`title_seo`=\''.DB::esc($ids).'\'' : 'page.`id`='._index_page_id).' LIMIT 1'));
if($query === false) {

if(!isset($ids)) {


$continue = false;


if(_index_page_id != 0) {
$query = DB::row(DB::query('SELECT * FROM `'._mysql_prefix.'-root` WHERE `type`!=4 AND `intersection`=-1 AND `visible`=1 ORDER BY `ord` LIMIT 1'));
if($query === false) $fix_id = 0;
else {

$fix_id = $query['id'];
$continue = true;
}
DB::query('UPDATE `'._mysql_prefix.'-settings` SET `val`='.$fix_id.' WHERE `var`=\'index_page_id\'');
}

}
if($type === 0 || !$continue) break;
} else {

$type = 0;
break;
}
}


$query = DB::row(DB::query("SELECT * FROM `"._mysql_prefix."-articles` WHERE `title_seo`='".DB::esc($ids)."' LIMIT 1"));
$type = 1;

} while(false);



if($continue) {
if($query !== false) {

if($type === 0) {




$id = $query['id'];
define('_indexOutput_url', _linkRoot($id, $query['title_seo']));
define('_indexOutput_pid', $id);


if(_modrewrite && isset($ids) && !$rewritten) {
parse_str($_SERVER['QUERY_STRING'], $redir_query);
unset($redir_query['p']);
define('_redirect_to', _url.'/'._addGetToLink(_indexOutput_url, _buildQuery($redir_query), false));
} elseif(isset($ids) && $id == _index_page_id) {

define('_redirect_to', _url.'/');
} else {


if(_publicAccess($query['public'], $query['level']) && (!isset($query['inter_id']) || _publicAccess($query['inter_public'], $query['inter_level']))) {


$backlink = "";
if(isset($query['inter_id']) && $query['visible'] == 1 && _template_intersec_backlink && $query['inter_var2'] != 1) {
$backlink = "<a href='"._linkRoot($query['inter_id'], $query['inter_title_seo'])."' class='backlink'>&lt; ".$_lang['global.return']."</a>";
}


if(null !== $query['events']) {
$query['events'] = _parseStr($query['events']);
for($i = 0; isset($query['events'][$i]); ++$i) {
$event = explode(':', $query['events'][$i]);
_extend('call', 'page.event.'.$event[0], array('args' => array_slice($event, 1), 'query' => &$query));
}
}


$plugin = false;
$pluginerr = false;
switch($query['type']) {
case 1:
define('_indexOutput_ptype', 'section');
break;
case 2:
define('_indexOutput_ptype', 'category');
break;
case 3:
define('_indexOutput_ptype', 'book');
break;
case 5:
define('_indexOutput_ptype', 'gallery');
break;
case 6:
define('_indexOutput_ptype', 'link');
break;
case 7:
define('_indexOutput_ptype', 'intersection');
break;
case 8:
define('_indexOutput_ptype', 'forum');
break;

case 9:


$plugin = true;
$pluginerr = true;


if(null === $query['type_idt']) break;


$pluginfile = null;
_extend('call', 'ppage.'.$query['type_idt'].'.show', array('file' => &$pluginfile, 'query' => &$query));
if(null === $pluginfile) break;


$pluginerr = false;
define('_indexOutput_ptype', $query['type_idt']);
break;

}

if(!$pluginerr) {


$title = '';
$content = '';


$file = null;
$extend_args = _extendArgs($content, array('query' => &$query));
_extend('call', 'page.all.pre', $extend_args);
_extend('call', 'page.'._indexOutput_ptype.'.pre', _extendArgs($content, array('query' => &$query, 'file' => &$file)));


if($query['keywords'] !== '') define('_indexOutput_keywords', $query['keywords']);
if($query['description'] !== '') define('_indexOutput_description', $query['description']);


require (isset($file) ? $file : ($plugin ? $pluginfile : _indexroot.'require/page/'._indexOutput_ptype.'.php'));
_extend('call', 'page.'._indexOutput_ptype.'.post', $extend_args);
$content = _xsrfAutoProtect($content);


define('_indexOutput_title', $title);
define('_indexOutput_content', $backlink.$content);

} else {


define('_indexOutput_title', $_lang['index.pagerr.title']);
define('_indexOutput_content', $backlink._formMessage(3, sprintf($_lang['index.pagerr.p'], $query['type_idt'])));

}

} else {
$notpublic_form = true;
}
}
} else {




$access = _articleAccess($query);
$id = $query['id'];
define('_indexOutput_url', _linkArticle($id, $query['title_seo']));
define('_indexOutput_ptype', 'article');


if(_modrewrite && !$rewritten) {
parse_str($_SERVER['QUERY_STRING'], $redir_query);
unset($redir_query['a']);
define('_redirect_to', _url.'/'._addGetToLink(_indexOutput_url, _buildQuery($redir_query), false));
} else {


if($access == 1) {


$content = '';


$file = null;
$extend_args = _extendArgs($content, array('query' => &$query));
_extend('call', 'article.pre', _extendArgs($content, array('query' => &$query, 'file' => &$file)));


if($query['keywords'] !== '') define('_indexOutput_keywords', $query['keywords']);
if($query['description'] !== '') define('_indexOutput_description', $query['description']);


require (isset($file) ? $file : _indexroot."require/page/article.php");
_extend('call', 'article.post', $extend_args);


$content = _xsrfAutoProtect($content);


define('_indexOutput_content', $content);
define('_indexOutput_title', $title);

} elseif($access == 2) {
$notpublic_form = true;
}

}


}

} else {




if(_modrewrite) $q = DB::row(DB::query('SELECT new FROM `'._mysql_prefix.'-redir` WHERE old=\''.DB::esc($ids).'\' AND active=1'));
else $q = false;
if($q !== false) define('_redirect_to', _url.'/'._linkRoot(-1, $q['new']));
elseif(!$rewritten && is_numeric($ids)) {

$ids = intval($ids);
$query = DB::row(DB::query('SELECT `id`,`title_seo` FROM `'._mysql_prefix.'-'.(($type === 0) ? 'root' : 'articles').'` WHERE `id`='.$ids));
if($query !== false) {

define('_redirect_to', _url.'/'.(($type === 0) ? _linkRoot($query['id'], $query['title_seo']) : _linkArticle($query['id'], $query['title_seo'])));
}
} elseif($rewritten || $type === 0) {

$title = $content = null;
_extend('call', 'index.notfound.hook', array('output' => &$content, 'title' => &$title, 'ids' => $ids));
if(isset($title, $content)) {
define('_indexOutput_ptype', 'custom');
define('_indexOutput_title', $title);
$content = _xsrfAutoProtect($content);
define('_indexOutput_content', $content);

}
}


}

} else {

define('_indexOutput_content', (_template_autoheadings ? "<h1>".$_lang['global.error404.title']."</h1>" : '')._formMessage(2, $_lang['global.nokit']));
define('_indexOutput_title', $_lang['global.error404.title']);
}

}


} else {
$notpublic_form = true;
$notpublic_form_wholesite = true;
}



if(!defined('_indexOutput_pid')) define('_indexOutput_pid', -1);
if(!defined('_indexOutput_ptype')) define('_indexOutput_ptype', '');
if(!defined('_indexOutput_url')) define('_indexOutput_url', _indexroot);



if(!defined('_indexOutput_content')) {
if(!$notpublic_form) {
$content_404 = (_template_autoheadings ? "<h1>".$_lang['global.error404.title']."</h1>" : '')._formMessage(2, $_lang['global.error404']);
_extend('call', 'index.notfound', _extendArgs($content_404));
$content_404 = _xsrfAutoProtect($content_404);
define('_indexOutput_content', $content_404);
define('_indexOutput_title', $_lang['global.error404.title']);
$found = false;
} else {
$form = _uniForm("notpublic", array($notpublic_form_wholesite));
_extend('call', 'index.notpublic', _extendArgs($form[0]));
$form[0] = _xsrfAutoProtect($form[0]);
define('_indexOutput_content', $form[0]);
define('_indexOutput_title', $form[1]);
}
}



if(!defined('_redirect_to')) {
if(!$found) header("HTTP/1.1 404 Not Found");
if(isset($__template_overload) && file_exists($__template_overload)) require $__template_overload;
else require _indexroot."plugins/templates/"._template."/template.php";
} else {
header("HTTP/1.1 301 Moved Permanently");
header("Location: "._redirect_to);
exit;
}
