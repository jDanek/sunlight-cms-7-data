<?php

// pripojeni k db
require 'access.php';
$con = @mysql_connect($server, $user, $password);
if(!is_resource($con)) die('Nepodarilo se pripojit k databazi!<br>'.mysql_error());
if(!@mysql_select_db($database)) die('Nepodarilo se zvolit aktualni databazi!');

// zjisteni verze db
$q = mysql_query('SELECT val FROM `'.$prefix.'-settings` WHERE var=\'dbversion\'');
if(!is_resource($q) || mysql_num_rows($q) !== 1) die('Nepodarilo se zjistit verzi databaze!');
$q = mysql_fetch_assoc($q);
$q = $q['val'];

// kontrola verze db
if($q !== '7.4.3') {
    if($q === '7.4.4') die('Patch byl jiz aplikovan, smazte soubor patch.php!');
    die('Nespravna verze databaze!');
}

// priprava sql dotazu
$sql = array();
$sql[] = 'UPDATE `'.$prefix.'-settings` SET `val` = \'7.4.4\' WHERE `var` = \'dbversion\'';
$sql[] = 'INSERT INTO `'.$prefix.'-settings` (`var`,`val`) VALUES (\'show_avatars\', \'0\')';
$sql[] = 'INSERT INTO `'.$prefix.'-settings` (`var` ,`val`)VALUES (\'accactexpire\', \'1200\')';
$sql[] = 'INSERT INTO `'.$prefix.'-settings` (`var` ,`val`)VALUES (\'registration_confirm\', \'0\')';
$sql[] = 'INSERT INTO `'.$prefix.'-settings` (`var`, `val`) VALUES (\'sysmail\', \'\')';
$sql[] = 'INSERT INTO `'.$prefix.'-settings` (`var`, `val`) VALUES (\'lostpassexpire\', \'1800\')';
$sql[] = 'INSERT INTO `'.$prefix.'-settings` (`var`, `val`) VALUES (\'cacheid\', \'0\')';
$sql[] = 'CREATE TABLE IF NOT EXISTS `'.$prefix.'-user-activation` (`id` int(11) NOT NULL AUTO_INCREMENT,`code` varchar(23) NOT NULL,`expire` int(11) NOT NULL,`group` int(11) NOT NULL,`username` tinytext NOT NULL,`password` tinytext NOT NULL,`salt` tinytext NOT NULL,`massemail` tinyint(1) NOT NULL,`ip` tinytext NOT NULL,`email` tinytext NOT NULL,PRIMARY KEY (`id`),KEY `code` (`code`),KEY `expire` (`expire`)) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1';
$sql[] = 'ALTER TABLE `'.$prefix.'-users` AUTO_INCREMENT =0';

// provedeni
for($i = 0; isset($sql[$i]); ++$i) {
    mysql_query($sql[$i]);
    $error = mysql_error();
    if(!empty($error)) die('Chyba pri aktualizaci databaze!<br><br>Chyba:'.$error.'<br><br>SQL dotaz:<br>'.$sql[$i]);
}

// ok
echo 'OK! Databaze byla aktualizovana na verzi 7.4.4.';
if(!@unlink(__FILE__)) echo '<br>Smazte soubor patch.php!';

?>