<?php
/*---- kontrola jadra ----*/
if(!defined('_core')) {
	exit;
}


/*---- vypis kodu boxu daneho sloupce ----*/

function _templateBoxes($column = 1, $return = false)
{

	$output = "\n";

	if(!_notpublicsite or _loginindicator) {

		//verejny
		if(_loginindicator) {
			$public = "";
		} else {
			$public = " AND public=1";
		}

		//obsah
		if(_template_boxes_parent != "") {
			$output .= "<"._template_boxes_parent.">\n";
		}
		$query = mysql_query("SELECT title,content FROM `"._mysql_prefix."-boxes` WHERE visible=1 AND `column`=".$column.$public." ORDER BY ord");
		while($item = mysql_fetch_assoc($query)) {

			//kod titulku
			if($item['title'] != "") {
				$title = "<"._template_boxes_title." class='box-title'>".$item['title']."</"._template_boxes_title.">\n";
			} else {
				$title = "";
			}

			/*titulek venku*/
			if(_template_boxes_title_inside == 0 and $title != "") {
				$output .= $title;
			}
			/*starttag polozky*/
			if(_template_boxes_item != "") {
				$output .= "<"._template_boxes_item." class='box-item'>\n";
			}
			/*titulek vevnitr*/
			if(_template_boxes_title_inside == 1 and $title != "") {
				$output .= $title;
			}
			/*obsah*/
			$output .= _parseHCM($item['content']);
			/*endtag polozky*/
			if(_template_boxes_item != "") {
				$output .= "\n</"._template_boxes_item.">";
			}
			/*spodek boxu*/
			if(_template_boxes_bottom == 1) {
				$output .= "<"._template_boxes_item." class='box-bottom'></"._template_boxes_item.">\n\n";
			} else {
				$output .= "\n\n";
			}
			;
		}
		if(_template_boxes_parent != "") {
			$output .= "</"._template_boxes_parent.">\n";
		}

	}

	//vypis vysledku
	if(!$return) {
		echo $output;
	} else {
		return $output;
	}

}


/*---- vypis obsahu ----*/

function _templateContent($return = false)
{
	if(!$return) {
		echo _indexOutput_content;
	} else {
		return _indexOutput_content;
	}
}


/*---- vypis obsahu xhtml hlavicky ----*/

function _templateHead()
{

	//titulek
	if(_titletype == 1) {
		$title = _title.' '._titleseparator.' '._indexOutput_title;
	} else {
		$title = _indexOutput_title.' '._titleseparator.' '._title;
	}

	global $_lang;
	echo '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<meta http-equiv="Content-Script-Type" content="text/javascript" />
<meta name="keywords" content="'._keywords.'" />
<meta name="description" content="'._description.'" />'.((_author !== '') ? '
<meta name="author" content="'._author.'" />' : '').'
<meta name="generator" content="SunLight CMS '._systemversion.'" />
<meta name="robots" content="index, follow" />
<link href="'._indexroot.'templates/'._template.'/style/system.css?'._cacheid.'" type="text/css" rel="stylesheet" />
<link href="'._indexroot.'templates/'._template.'/style/layout.css?'._cacheid.'" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="'._indexroot.'remote/jscript.php?'._cacheid.'"></script>';

	if(_lightbox) {
		echo '
<link rel="stylesheet" href="'._indexroot.'remote/lightbox/style.css?'._cacheid.'" type="text/css" media="screen" />
<script type="text/javascript" src="'._indexroot.'remote/lightbox/script.js?'._cacheid.'"></script>';
	}

	if(_rss) {
		echo '
<link rel="alternate" type="application/rss+xml" href="'._indexroot.'remote/rss.php?tp=4&amp;id=-1" title="'.$_lang['rss.recentarticles'].'" />';
	}

	if(_favicon) {
		echo '
<link rel="shortcut icon" href="./favicon.ico?'._cacheid.'" />';
	}

	echo '
<title>'.$title.'</title>
';
}


/*---- vypis odkazu ----*/

function _templateLinks($left_separator = false)
{
	global $_lang;
	if($left_separator) {
		echo " "._template_listinfoseparator." ";
	}
	echo "<a href='http://sunlight.shira.cz/'>SunLight CMS</a>".((!_adminlinkprivate or (_loginindicator and _loginright_administration)) ? " "._template_listinfoseparator." <a href='"._indexroot."admin/index.php'>".$_lang['admin.link']."</a>" : '');
}


/*---- sestaveni adresy k obrazku motivu ----*/

function _templateImage($path)
{
	return _indexroot."templates/"._template."/images/".$path;
}


/*---- sestaveni kodu menu ----*/

function _templateMenu($ord_start = null, $ord_end = null)
{
	global $__shid_total, $_lang;
	$output = "";
	if(defined("_indexOutput_pid")) {
		$pid = _indexOutput_pid;
	} else {
		$pid = -1;
	}
	if(!_notpublicsite or _loginindicator) {

		//limit
		if($ord_start === null or $ord_end === null) {
			$ord_limit = "";
		} else {
			$ord_limit = " AND ord>=".intval($ord_start)." AND ord<=".intval($ord_end);
		}

		//obsah menu
		$query = mysql_query("SELECT id,type,title,var1,var2 FROM `"._mysql_prefix."-root` WHERE visible=1 AND intersection=-1 AND type!=4".$ord_limit." ORDER BY ord");
		$output .= "<"._template_menu_parent." class='menu'>\n";
		$counter = 0;
		$last = mysql_num_rows($query) - 1;
		while($item = mysql_fetch_assoc($query)) {

			$classes = array();
			if(!($item['type'] == 7 and $item['var2'] == 1)) {
				if($item['id'] == $pid) $classes[] = 'act';
				if($item['type'] == 6 and $item['var1'] == 1) {
					$target = " target='_blank'";
				} else {
					$target = "";
				}
				$link = "<a href='"._linkRoot($item['id'])."'".$target.">".$item['title']."</a>";
			} else {
				$__shid_total += 1;
				$shid = $__shid_total;
				$iquery = mysql_query("SELECT id,type,title,var1 FROM `"._mysql_prefix."-root` WHERE intersection=".$item['id']." AND visible=1 ORDER BY ord");
				$icounter = 0;
				$ilast = mysql_num_rows($iquery) - 1;
				$childactive = false;

				if($ilast !== -1) {
					$link_sublistitems = '';
					while($iitem = mysql_fetch_assoc($iquery)) {
						$classes[] = 'menu-item-'.$iitem['id'];
						if($iitem['id'] == $pid) {
							$classes[] = 'act';
							$childactive = true;
						}
						if($icounter === 0) $classes[] = 'first';
						if($icounter !== 0 && $icounter === $ilast) $classes[] = 'last';
						if($iitem['type'] == 6 and $iitem['var1'] == 1) {
							$target = " target='_blank'";
						} else {
							$target = "";
						}
						$link_sublistitems .= "<li".(!empty($classes) ? ' class="'.implode(' ', $classes).'"' : '')."><a href='"._linkRoot($iitem['id'])."'".$target.">".$iitem['title']."</a></li>";
						$classes = array();
						++$icounter;
					}
					if(!$childactive and $item['id'] == $pid) {
						$childactive = true;
					}
				} else $link_sublistitems = '<li class="first">'.$_lang['global.nokit'].'</li>';
				if($childactive || $item['id'] == $pid) $classes[] = 'act';

				$link = "<a href='"._linkRoot($item['id'])."' class='hs_".($childactive ? 'opened' : 'closed').(($item['id'] == $pid) ? ' act' : '')."' onclick=\"return _sysHideShow('sh".$shid."', this)\">".$item['title']."</a>
<ul class='hs_content".($childactive ? '' : ' hs_hidden')."' id='sh".$shid."'>
".$link_sublistitems."
</ul>\n";
			}

			$classes[] = 'menu-item-'.$item['id'];
			if($counter === 0) $classes[] = 'first';
			if($counter !== 0 && $counter === $last) $classes[] = 'last';
			$output .= "<"._template_menu_child.(!empty($classes) ? ' class="'.implode(' ', $classes).'"' : '').">".$link."</"._template_menu_child.">\n";
			++$counter;

		}

		$output .= "</"._template_menu_parent.">";

	}

	return $output;

}


/*---- vypis titulku aktualni stranky ----*/

function _templateTitle()
{
	echo _indexOutput_title;
}


/*---- vypis kodu uzivatelskeho menu ----*/

function _templateUserMenu($return = false)
{
	global $_lang;

	$output = "";

	if(_template_usermenu_parent != "") {
		$output .= "<"._template_usermenu_parent.">\n";
	}

	if(!_loginindicator) {
		/*prihlaseni*/
		$output .= _template_usermenu_item_start."<a href='"._indexroot."index.php?m=login' class='usermenu-item-login'>".$_lang['usermenu.login']."</a>"._template_usermenu_item_end."\n";
		if(_registration) {
			/*registrace*/
			$output .= _template_usermenu_item_start."<a href='"._indexroot."index.php?m=reg' class='usermenu-item-reg'>".$_lang['usermenu.registration']."</a>"._template_usermenu_item_end."\n";
		}
	} else {
		/*vzkazy*/
		if(_messages) {
			$messages_count = mysql_result(mysql_query("SELECT COUNT(id) FROM `"._mysql_prefix."-messages` WHERE receiver="._loginid." AND readed=0"), 0);
			if($messages_count != 0) {
				$messages_count = " [".$messages_count."]";
			} else {
				$messages_count = "";
			}
			$output .= _template_usermenu_item_start."<a href='"._indexroot."index.php?m=messages' class='usermenu-item-messages'>".$_lang['usermenu.messages'].$messages_count."</a>"._template_usermenu_item_end."\n";
		}
		/*nastaveni*/
		$output .= _template_usermenu_item_start."<a href='"._indexroot."index.php?m=settings' class='usermenu-item-settings'>".$_lang['usermenu.settings']."</a>"._template_usermenu_item_end."\n";
		/*odhlaseni*/
		$output .= _template_usermenu_item_start."<a href='"._indexroot."remote/logout.php?_return=".urlencode(_indexOutput_url)."' class='usermenu-item-logout'>".$_lang['usermenu.logout'].(_template_usermenu_showusername ? " ["._loginname."]" : '')."</a>"._template_usermenu_item_end."\n";
	}

	if(_ulist and (!_notpublicsite or _loginindicator)) {
		/*uziv. menu*/
		$output .= _template_usermenu_item_start."<a href='"._indexroot."index.php?m=ulist' class='usermenu-item-ulist'>".$_lang['usermenu.ulist']."</a>"._template_usermenu_item_end."\n";
	}

	if(_template_usermenu_parent != "") {
		$output .= "</"._template_usermenu_parent.">\n";
	}

	if(_template_usermenu_trim == 1) {
		$output = trim($output);
		$output = trim($output, _template_usermenu_item_start);
		$output = trim($output, _template_usermenu_item_end);
	}
	if(!$return) {
		echo $output;
	} else {
		return $output;
	}

}


/*---- zjisteni id aktualni stranky ----*/

function _templatePageID()
{
	return _indexOutput_pid;
}


/*---- zjisteni typu aktualni stranky ----*/

function _templatePageType()
{
	return _indexOutput_ptype;
}

?>