<?php

if(!defined('_core')) {
exit;
}


function _HCM_mailto($email = "")
{
return _mailto($email);
}