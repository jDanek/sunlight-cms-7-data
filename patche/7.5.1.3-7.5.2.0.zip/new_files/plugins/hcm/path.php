<?php

if(!defined('_core')) {
exit;
}


function _HCM_path($absolutni = false)
{
return ($absolutni ? _url : '')._path;
}
