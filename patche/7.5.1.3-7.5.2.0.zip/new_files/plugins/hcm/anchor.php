<?php

if(!defined('_core')) {
exit;
}


function _HCM_anchor($nazev = '')
{
return _path.'#'.$nazev;
}
