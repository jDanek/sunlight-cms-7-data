<?php

if(!defined('_core')) {
exit;
}


$message = "";
$infopage = false;

function _admin_boolSelect($name, $type2 = false)
{
global $_lang;
return "
<select name='".$name."'>
<option value='-1'>".(($type2 == false) ? $_lang['admin.content.artfilter.f1.bool.doesntmatter'] : $_lang['global.nochange'])."</option>
<option value='1'>".$_lang['admin.content.artfilter.f1.bool.mustbe']."</option>
<option value='0'>".$_lang['admin.content.artfilter.f1.bool.mustntbe']."</option>
</select>&nbsp;
";
}


if(isset($_POST['category'])) {


$category = intval($_POST['category']);
$author = intval($_POST['author']);
$time = _loadTime('time', time());
$ba = intval($_POST['ba']);
$public = intval($_POST['public']);
$visible = intval($_POST['visible']);
$confirmed = intval($_POST['confirmed']);
$comments = intval($_POST['comments']);
$rateon = intval($_POST['rateon']);
$showinfo = intval($_POST['showinfo']);
$new_category = intval($_POST['new_category']);
$new_author = intval($_POST['new_author']);
$new_public = intval($_POST['new_public']);
$new_visible = intval($_POST['new_visible']);
if(_loginright_adminconfirm) {
$new_confirmed = intval($_POST['new_confirmed']);
}
$new_comments = intval($_POST['new_comments']);
$new_rateon = intval($_POST['new_rateon']);
$new_showinfo = intval($_POST['new_showinfo']);
$new_delete = _checkboxLoad("new_delete");
$new_resetrate = _checkboxLoad("new_resetrate");
$new_delcomments = _checkboxLoad("new_delcomments");
$new_resetread = _checkboxLoad("new_resetread");


if($new_category != -1) {
if(DB::result(DB::query("SELECT COUNT(id) FROM `"._mysql_prefix."-root` WHERE id=".$new_category." AND type=2"), 0) == 0) {
$new_category = -1;
}
}
if($new_author != -1) {
if(DB::result(DB::query("SELECT COUNT(id) FROM `"._mysql_prefix."-users` WHERE id=".$new_author), 0) == 0) {
$new_author = -1;
}
}


$params = array("category", "author", "time", "public", "visible", "confirmed", "comments", "rateon", "showinfo");
$cond = "";


foreach($params as $param) {

$skip = false;
if($param == "category" or $param == "author" or $param == "time") {

switch($param) {

case "category":
if($$param != "-1") {
$cond .= _sqlArticleWhereCategories($$param);
} else {
$skip = true;
}
break;

case "author":
if($$param != "-1") {
$cond .= $param."=".$$param;
} else {
$skip = true;
}
break;

case "time":
switch($ba) {
case 1:
$operator = ">";
break;
case 2:
$operator = "=";
break;
case 3:
$operator = "<";
break;
default:
$skip = true;
break;
}
if(!$skip) {
$cond .= 'art.'.$param.$operator.$$param;
}
break;

}

} else {

switch($$param) {
case "1":
$cond .= $param."=1";
break;
case "0":
$cond .= $param."=0";
break;
default:
$skip = true;
break;
}
}

if(!$skip) {
$cond .= " AND ";
}

}


if($cond == "") {
$cond = 1;
} else {
$cond = mb_substr($cond, 0, mb_strlen($cond) - 5);
}


$query = DB::query("SELECT art.id,art.title,art.title_seo,cat.title_seo AS cat_title_seo FROM `"._mysql_prefix."-articles` AS art JOIN `"._mysql_prefix."-root` AS cat ON(cat.id=art.home1) WHERE ".$cond);
$found = DB::size($query);
if($found != 0) {
if(!_checkboxLoad("_process")) {
$infopage = true;
} else {
$boolparams = array("public", "visible", "comments", "rateon", "showinfo");
if(_loginright_adminconfirm) {
$boolparams[] = "confirmed";
}
while($item = DB::row($query)) {


if($new_delcomments or $new_delete) {
DB::query("DELETE FROM `"._mysql_prefix."-posts` WHERE type=2 AND home=".$item['id']);
}


if($new_delete) {
DB::query("DELETE FROM `"._mysql_prefix."-articles` WHERE id=".$item['id']);
continue;
}


if($new_resetrate) {
DB::query("UPDATE `"._mysql_prefix."-articles` SET ratenum=0, ratesum=0 WHERE id=".$item['id']);
DB::query("DELETE FROM `"._mysql_prefix."-iplog` WHERE type=3 AND var=".$item['id']);
}


if($new_resetread) {
DB::query("UPDATE `"._mysql_prefix."-articles` SET readed=0 WHERE id=".$item['id']);
}


if($new_category != -1) {
DB::query("UPDATE `"._mysql_prefix."-articles` SET home1=".$new_category.", home2=-1, home3=-1 WHERE id=".$item['id']);
}


if($new_author != -1) {
DB::query("UPDATE `"._mysql_prefix."-articles` SET author=".$new_author." WHERE id=".$item['id']);
}


foreach($boolparams as $param) {
$paramvar = "new_".$param;
$paramval = $$paramvar;
if($paramval == 0 or $paramval == 1) {
DB::query("UPDATE `"._mysql_prefix."-articles` SET ".$param."=".$paramval." WHERE id=".$item['id']);
}
}

}
$message = _formMessage(1, $_lang['global.done']);
}
} else {
$message = _formMessage(2, $_lang['admin.content.artfilter.f1.noresult']);
}

}


$output .= "
<p class='bborder'>".$_lang['admin.content.artfilter.p']."</p>
".$message."
<form action='index.php?p=content-artfilter' method='post'>
";

if(!$infopage) {
$output .= "
<h2>".$_lang['admin.content.artfilter.f1.title']."</h2>
<p>".$_lang['admin.content.artfilter.f1.p']."</p>
<table>

<tr>
<td class='rpad'><strong>".$_lang['article.category']."</strong></td>
<td>"._admin_rootSelect("category", 2, -1, true, $_lang['global.any2'])."</td>
</tr>

<tr>
<td class='rpad'><strong>".$_lang['article.author']."</strong></td>
<td>"._admin_authorSelect("author", -1, "adminart=1", "selectmedium", $_lang['global.any'])."</td>
</tr>

<tr>
<td class='rpad'><strong>".$_lang['article.posted']."</strong></td>
<td>

<select name='ba'>
<option value='0'>".$_lang['admin.content.artfilter.f1.time0']."</option>
<option value='1'>".$_lang['admin.content.artfilter.f1.time1']."</option>
<option value='2'>".$_lang['admin.content.artfilter.f1.time2']."</option>
<option value='3'>".$_lang['admin.content.artfilter.f1.time3']."</option>
</select>

"._editTime('time', -1)."

</td>
</tr>

<tr valign='top'>
<td class='rpad'><strong>".$_lang['admin.content.form.settings']."</strong></td>
<td>
"._admin_boolSelect("public").$_lang['admin.content.form.public']."<br />
"._admin_boolSelect("visible").$_lang['admin.content.form.visible']."<br />
"._admin_boolSelect("confirmed").$_lang['admin.content.form.confirmed']."<br />
"._admin_boolSelect("comments").$_lang['admin.content.form.comments']."<br />
"._admin_boolSelect("rateon").$_lang['admin.content.form.artrate']."<br />
"._admin_boolSelect("showinfo").$_lang['admin.content.form.showinfo']."
</td>
</tr>

</table>

<br /><div class='hr'><hr /></div><br />

<h2>".$_lang['admin.content.artfilter.f2.title']."</h2>
<p>".$_lang['admin.content.artfilter.f2.p']."</p>
<table>

<tr>
<td class='rpad'><strong>".$_lang['article.category']."</strong></td>
<td>"._admin_rootSelect("new_category", 2, -1, true, $_lang['global.nochange'])."</td>
</tr>

<tr>
<td class='rpad'><strong>".$_lang['article.author']."</strong></td>
<td>"._admin_authorSelect("new_author", -1, "adminart=1", "selectmedium", $_lang['global.nochange'])."</td>
</tr>

<tr valign='top'>
<td class='rpad'><strong>".$_lang['admin.content.form.settings']."</strong></td>
<td>
"._admin_boolSelect("new_public", true).$_lang['admin.content.form.public']."<br />
"._admin_boolSelect("new_visible", true).$_lang['admin.content.form.visible']."<br />
".(_loginright_adminconfirm ? _admin_boolSelect("new_confirmed", true).$_lang['admin.content.form.confirmed']."<br />" : '')."
"._admin_boolSelect("new_comments", true).$_lang['admin.content.form.comments']."<br />
"._admin_boolSelect("new_rateon", true).$_lang['admin.content.form.artrate']."<br />
"._admin_boolSelect("new_showinfo", true).$_lang['admin.content.form.showinfo']."
</td>
</tr>

<tr valign='top'>
<td class='rpad'><strong>".$_lang['global.action']."</strong></td>
<td>
<label><input type='checkbox' name='new_delete' value='1' /> ".$_lang['global.delete']."</label><br />
<label><input type='checkbox' name='new_resetrate' value='1' /> ".$_lang['admin.content.form.resetartrate']."</label><br />
<label><input type='checkbox' name='new_delcomments' value='1' /> ".$_lang['admin.content.form.delcomments']."</label><br />
<label><input type='checkbox' name='new_resetread' value='1' /> ".$_lang['admin.content.form.resetartread']."</label>
</td>
</tr>

</table>

<br /><div class='hr'><hr /></div><br />

<input type='submit' value='".$_lang['mod.search.submit']."' />
";
} else {
$output .= _getPostdata()."
<input type='hidden' name='_process' value='1' />
"._formMessage(1, str_replace("*found*", $found, $_lang['admin.content.artfilter.f1.infotext']))."
<ul>";

$counter = 0;
while($r = DB::row($query)) {
if($counter >= 30) {
$output .= "<li><em>... (+".($found - $counter).")</em></li>\n";
break;
}
$output .= "<li><a href='"._indexroot._linkArticle($r['id'], $r['title_seo'], $r['cat_title_seo'])."' target='_blank'>".$r['title']."</a></li>\n";
++$counter;
}

$output .="</ul>
<input type='submit' value='".$_lang['global.do2']."' />&nbsp;&nbsp;<a href='index.php?p=content-artfilter'>".$_lang['global.cancel']."</a>
";
}

$output .= "</form>";