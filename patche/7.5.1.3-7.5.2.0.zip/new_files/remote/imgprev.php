<?php

define('_indexroot', '../');
define('_header', '');
session_cache_limiter('private_no_expire');
require _indexroot."require/load.php";


$continue = false;
if(isset($_GET['id'])) {
if(!isset($_GET['c'])) {


$id = intval($_GET['id']);
$imgdata = DB::query_row("SELECT img.full,img.home,gal.public AS gal_public,gal.level AS gal_level,gal.var4 AS gal_imgw,gal.var3 AS gal_imgh,inter.public AS inter_public,inter.level AS inter_level FROM `"._mysql_prefix."-images` AS img JOIN `"._mysql_prefix."-root` AS gal ON(gal.id=img.home) LEFT JOIN `"._mysql_prefix."-root` AS inter ON(gal.intersection!=-1 AND gal.intersection=inter.id) WHERE img.id=".$id);


if($imgdata === false) die;


if(!_publicAccess($imgdata['gal_public'], $imgdata['gal_level']) || isset($imgdata['inter_public']) && !_publicAccess($imgdata['inter_public'], $imgdata['inter_level'])) return;


if(isset($_GET['h'])) {

$output_x = (isset($_GET['w']) ? intval($_GET['w']) : null);
$output_y = intval($_GET['h']);
if(isset($output_x) && ($output_x < 4 || $output_x > 512) || $output_y < 4 || $output_y > 512) die;
} else {

$output_x = $imgdata['gal_imgw'];
$output_y = $imgdata['gal_imgh'];
}
$output_fname = _indexroot.$imgdata['full'];

} else {


$output_x = (isset($_GET['w']) ? intval($_GET['w']) : null);
$output_y = intval($_GET['h']);
$output_fname = _indexroot.base64_decode($_GET['id']);


if(!@file_exists($output_fname) || isset($output_x) && ($output_x < 4 || $output_x > 512) || $output_y < 4 || $output_y > 512) die;

}

}




$load = _pictureLoad($output_fname);
if(!$load[0]) {

_checkGD($load[3], true);
die;
}


if(!isset($output_x)) {
$output_x = round(imagesx($load[2]) / imagesy($load[2]) * $output_y);
if($output_x < 1) die;
if($output_x > 512) $output_x = 512;
}


$resize = _pictureResize($load[2], array('mode' => 'zoom', 'x' => $output_x, 'y' => $output_y));
if(!$resize[0]) die;
if(!$resize[3]) imagedestroy($load[2]);



header("Content-type: image/jpeg");
header("Expires: ".gmdate("D, d M Y H:i:s", time() + 86400)." GMT");
imagejpeg($resize[2], null, 85);
imagedestroy($resize[2]);
die;