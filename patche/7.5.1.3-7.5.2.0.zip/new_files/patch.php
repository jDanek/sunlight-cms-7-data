<?php

// pripojeni k db
require 'config.php';
$con = @mysql_connect($server, $user, $password);
if(!is_resource($con)) die('Nepodarilo se pripojit k databazi!<br>'.mysql_error());
if(!@mysql_select_db($database)) die('Nepodarilo se zvolit aktualni databazi!');
mysql_query('SET NAMES `utf8`');

// zjisteni verze db
$q = mysql_query('SELECT val FROM `'.$prefix.'-settings` WHERE var=\'dbversion\'');
if(!is_resource($q) || mysql_num_rows($q) !== 1) die('Nepodarilo se zjistit verzi databaze!');
$q = mysql_fetch_assoc($q);
$q = $q['val'];

// kontrola verze db
if($q !== '7.5.1') {
    die('Nespravna verze databaze!');
}

// priprava sql dotazu
$sql = array();
$sql[] = 'ALTER TABLE `'.$prefix.'-root` CHANGE `title_seo` `title_seo` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL , CHANGE `events` `events` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL';
$sql[] = 'ALTER TABLE `'.$prefix.'-articles` CHANGE `title_seo` `title_seo` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL';
$sql[] = 'ALTER TABLE `'.$prefix.'-redir` CHANGE  `old`  `old` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL , CHANGE  `new`  `new` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL';


// provedeni
for($i = 0; isset($sql[$i]); ++$i) {
    mysql_query($sql[$i]);
    $error = mysql_error();
    if(!empty($error)) {
        echo 'Chyba pri aktualizaci databaze!<br><br>Chyba:'.$error.'<br><br>SQL dotaz:<br>'.$sql[$i];
        echo '<br /><br />';
        echo "Pozor! Pro pripadny dotaz na oficialni diskusi nebo jinde si tuto chybovou hlasku okopirujte!";
        die;
    }
}

// ok
echo 'OK! Databaze byla aktualizovana na verzi 7.5.2.';
if(!@unlink(__FILE__)) echo '<br>Smazte soubor patch.php!';
