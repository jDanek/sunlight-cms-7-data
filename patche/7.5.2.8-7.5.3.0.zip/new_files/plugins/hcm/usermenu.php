<?php

if (!defined('_core')) {
exit;
}


function _HCM_usermenu()
{
return _templateUserMenu(true);
}
