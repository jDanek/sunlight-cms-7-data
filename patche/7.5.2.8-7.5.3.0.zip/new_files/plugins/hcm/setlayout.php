<?php

if (!defined('_core')) {
exit;
}


function _HCM_setlayout($name = null, $abs = false)
{
_templateFileOverload($name, $abs == true);
}
