<?php

if (!defined('_core')) {
exit;
}


function _HCM_smileys($text = "")
{
return _parsePost($text, true, false, false);
}
