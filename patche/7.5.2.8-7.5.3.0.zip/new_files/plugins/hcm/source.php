<?php

if (!defined('_core')) {
exit;
}


function _HCM_source($kod = "")
{
return "<div class='pre'>" . nl2br(_htmlStr(trim($kod))) . "</div>";
}
