<?php

if (!defined('_core')) {
exit;
}


function _HCM_phpsource($kod = "")
{
return "<div class='pre php-source'>" . highlight_string($kod, true) . "</div>";
}
