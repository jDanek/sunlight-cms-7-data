<?php








function _pluginSaveConfig($plugin, $cfg, $fname = 'config')
{
return file_put_contents(_plugin_dir . $plugin . '/' . $fname . '.php', '<?php return ' . var_export($cfg, true) . ';');
}







function _pluginLoadConfig($plugin, $fname = 'config')
{
return @include(_plugin_dir . $plugin . '/' . $fname . '.php');
}
