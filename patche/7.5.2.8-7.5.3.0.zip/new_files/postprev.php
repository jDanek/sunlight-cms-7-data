<?php

require './require/load.php';
SL::init('./');



_checkKeys('_POST', array('content'));
echo _parsePost(_htmlStr(strval($_POST['content'])));
