<?php





class LangPack implements ArrayAccess
{


protected $key;

protected $dir;

protected $list;

protected $loaded = false;







public function __construct($key, $dir, array $list = null)
{
$this->key = $key;
$this->dir = $dir;
$this->list = $list;
}






public function offsetExists($offset)
{
$this->load();

return array_key_exists($offset, $GLOBALS['_lang'][$this->key]);
}






public function offsetGet($offset)
{
$this->load();

if (array_key_exists($offset, $GLOBALS['_lang'][$this->key])) {
return $GLOBALS['_lang'][$this->key][$offset];
} else {
return null;
}
}







public function offsetSet($offset, $value)
{
throw new BadMethodCallException;
}







public function offsetUnset($offset)
{
throw new BadMethodCallException;
}




public function load()
{
if ($this->loaded) {
throw new RuntimeException;
}


if (_loginindicator and _language_allowcustom and _loginlanguage != "") {
$language = _loginlanguage;
} else {
$language = _language;
}


$path = $this->dir . $language . '.php';


if (null !== $this->list && !in_array($language, $this->list) || null === $this->list && !file_exists($path)) {
$path = $this->dir . 'default.php';
}


$GLOBALS['_lang'][$this->key] = (array) include $path;

$this->loaded = true;
}

}
