<?php





class dbdump
{


protected $_import_tmap;






public function exportData($tables = null)
{

if (!isset($tables)) $tables = $this->_get_tables();


$file = _tmpFile();


$null = chr(0);
$nullv = chr(1);
$prefix_len = (strlen(_mysql_prefix) + 1);


$ver = _checkVersion('database', null, true);
$ver = end($ver);
fwrite($file[0], $ver . $null);


for ($i = 0; isset($tables[$i]); ++$i) {


$q = DB::query('SELECT * FROM `' . $tables[$i] . '`');
if (DB::size($q) === 0) {

DB::free($q);
continue;
}


$collist = true;
fwrite($file[0], substr($tables[$i], $prefix_len) . $null);

while ($r = DB::row($q)) {


if ($collist) {
$collist = false;
fwrite($file[0], implode($null, array_keys($r)) . $null . $null);
}


foreach($r as $c) fwrite($file[0], (isset($c) ? DB::esc($c) : $nullv) . $null);

}

fwrite($file[0], $null);
DB::free($q);
$r = null;

}


return $file;
}






public function importData($stream)
{

global $_lang;
$err = null;
$this->_import_tmap = array();


if (is_string($stream)) {
$file = $stream;
$stream = new KZipStream(null, array(KZip::FILE_TOADD, $file, null));
unset($file);
}


$null = chr(0);
$nullv = chr(1);
$version = '';


do {


$offset = 0;
while (true) {
++$offset;
$byte = $stream->read(1);
if ($byte === $null) {

break;
} else {
$version .= $byte;
}
if ($offset > 32) {
$err = $_lang['dbdump']['dataerror'];
break 2;
}
}


if (!_checkVersion('database', $version)) {
$err = $_lang['dbdump']['badversion'];
break;
}


$tables = array();
$q = DB::query('SHOW TABLES LIKE \'' . _mysql_prefix . '-%\'');
while($r = DB::rown($q)) $tables[$r[0]] = true;
DB::free($q);
unset($r);


$max_size = DB::query('SHOW VARIABLES LIKE \'max_allowed_packet\'');
if (DB::size($max_size) !== 1) {
$err = $_lang['dbdump']['maxpacket'];
break;
}
$max_size = DB::result($max_size, 0, 1);
$max_size -= 128;
$max_size = floor(($max_size - 128) * 0.9);


$memlimit = _phpIniLimit('memory_limit');
if (isset($memlimit)) {
$avail_mem = $memlimit - memory_get_usage() - 131072;
if ($max_size > $avail_mem) $max_size = $avail_mem;
unset($avail_mem);
}
if ($max_size < 32768) {
$err = $_lang['dbdump']['memory'];
break;
}


DB::query('SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO"');


$reset = true;
$skipped_tables = array();
$stream_buffer = '';
$stream_buffer_i = 0;


while (true) {


if ($reset) {
$phase = 0;
$table = '';
$column = '';
$columns = array();
$columns_size = 0;
$values = array();
$value = '';
$value_counter = 0;
$sql = '';
$sql_len = 0;
$sql_buffer = '';
$sql_buffer_len = 0;
$skipping_table = false;
$reset = false;
}


if (!isset($stream_buffer[$stream_buffer_i])) {
if ($stream->eof()) break;
$stream_buffer = $stream->read();
$stream_buffer_i = 0;
if ($stream_buffer === '') break;
}
$byte = $stream_buffer[$stream_buffer_i];
++$stream_buffer_i;


switch ($phase) {


case 0:


if ($byte === $null) {

$phase = 1;
if (!isset($tables[_mysql_prefix . '-' . $table])) {
$skipping_table = true;
$skipped_tables[] = $table;
}
break;
}


$table .= $byte;
break;


case 1:


if ($byte === $null) {
if ($column === '') {


if (!$skipping_table) $columns = '`' . implode('`,`', $columns) . '`';


$phase = 2;

} else {

if (!$skipping_table) $columns[] = $column;
++$columns_size;
$column = '';
}
break;
}


$column .= $byte;
break;


case 2:


if ($byte === $null) {
if ($value_counter === 0 && $value === '') {


$reset = true;


if ($sql_buffer !== '' && !$skipping_table) {
$import = $this->_db_import($table, $columns, $sql_buffer, $sql_buffer_len);
if (isset($import)) {
$err = _htmlStr($import);
break 3;
}
}

} else {


++$value_counter;
$values[] = $value;
$value = '';


if ($value_counter === $columns_size) {

if (!$skipping_table) {


$sql = '(';
for ($i = 0, $lastcol = ($columns_size - 1); isset($values[$i]); ++$i) {
if ($values[$i] === $nullv) $sql .= 'NULL';
else $sql .= '\'' . $values[$i] . '\'';
if ($i !== $lastcol) $sql .= ',';
}
$sql .= ')';


$sql_len = strlen($sql);
if ($sql_buffer_len + $sql_len + 1 >= $max_size) {
$this->_db_import($table, $columns, $sql_buffer, $sql_buffer_len);
if (isset($import)) {
$err = _htmlStr($import);
break 3;
}
} else {


if ($sql_buffer !== '') {
$sql_buffer .= ',';
++$sql_buffer_len;
}


$sql_buffer .= $sql;
$sql_buffer_len += $sql_len;

}


$sql = '';
$sql_len = 0;

}

$value_counter = 0;
$values = array();

}

}
break;
}


$value .= $byte;
break;

}

}


DB::query('SET SQL_MODE=""');

} while (false);


$this->_import_tmap = null;


if (!isset($err)) return array(true, $skipped_tables);
return array(false, $err);
}






public function exportTables($tables = null)
{

if (!isset($tables)) $tables = $this->_get_tables();


$file = _tmpFile();


$sep = chr(0);
$prefix = chr(1);
$prefix_off = strlen(_mysql_prefix) + 1;
for ($i = 0; isset($tables[$i]); ++$i) {
$q = DB::rown(DB::query('SHOW CREATE TABLE `' . $tables[$i] . '`'));
$table = substr($tables[$i], $prefix_off);
fwrite($file[0], 'DROP TABLE IF EXISTS `' . $prefix . '-' . $table . '`' . $sep);
fwrite($file[0], str_replace('CREATE TABLE `' . $tables[$i] . '`', 'CREATE TABLE `' . $prefix . '-' . $table . '`', $q[1]) . $sep);
}


return $file;
}






public function importTables($data)
{

$sql = '';
$sep = chr(0);
$prefix = chr(1);
$num = 0;
for ($i = 0; isset($data[$i]); ++$i) {


$char = $data[$i];


if ($char === $sep) {
DB::query($sql, true);
$sql = '';
++$num;
if (($err = DB::error()) !== '') return array(false, $GLOBALS['_lang']['dbdump']['tablesqlerr'], $err);
continue;
}


if ($char === $prefix) {
$sql .= _mysql_prefix;
continue;
}


$sql .= $char;

}


return array(true, $num);
}





protected function _db_import($table, $columns, &$sql_buffer, &$sql_buffer_len)
{

if (!isset($this->_import_tmap[$table])) {
DB::query('TRUNCATE TABLE `' . _mysql_prefix . '-' . $table . '`');
$this->_import_tmap[$table] = true;
}


DB::query('INSERT INTO `' . _mysql_prefix . '-' . $table . '` (' . $columns . ') VALUES ' . $sql_buffer, true);
if (($err = DB::error()) !== '') return $err;


$sql_buffer = '';
$sql_buffer_len = 0;
}





protected function _get_tables()
{
$tables = array();
$q = DB::query('SHOW TABLES LIKE \'' . _mysql_prefix . '-%\'');
while($r = DB::rown($q)) $tables[] = $r[0];
DB::free($q);

return $tables;
}

}
