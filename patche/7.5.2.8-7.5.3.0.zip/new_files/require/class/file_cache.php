<?php









class FileCache
{


protected $path;

protected $verifyBoundFiles = true;






public function __construct($path)
{
$this->path = $path;
}








public function has($category, $name)
{
$metaPath = $this->composePath($category, $name) . '.meta';
return is_file($metaPath) && $this->validateMeta(include $metaPath);
}









public function get($category, $name, &$metaData = null)
{
$basePath = $this->composePath($category, $name);
if (is_file($metaPath = $basePath . '.meta')) {
if ($this->validateMeta($metaData = include $metaPath)) {
return include $basePath . '.data';
} else {
$this->remove($category, $name);
}
}

return false;
}









public function getMeta($category, $name, $validate = true)
{
$metaPath = $this->composePath($category, $name) . '.meta';
if (is_file($metaPath)) {
$metaData = include $metaPath;
if (!$validate || $this->validateMeta($metaData)) {
return $metaData;
} else {
$this->remove($category, $name);
}
}

return false;
}
















public function put($category, $name, $data, array $options = null)
{
list($path, $filename) = $this->composePath($category, $name, true);


$metaData = array(
'category' => $category,
'name' => $name,
'bound_files' => isset($options['bound_files']) ? $this->compileBoundFiles($options['bound_files']) : null,
'expires' => isset($options['ttl']) ? time() + $options['ttl'] : null,
'time' => time(),
);
if (isset($options['meta'])) {
$metaData += $options['meta'];
}


if (!is_dir($path)) {
mkdir($path, 0700, true);
}


file_put_contents($path . DIRECTORY_SEPARATOR . $filename . '.meta', $this->serialize($metaData));


file_put_contents($path . DIRECTORY_SEPARATOR . $filename . '.data', $this->serialize($data));

return true;
}








public function remove($category, $name)
{
$basePath = $this->composePath($category, $name);
if (is_file($metaPath = $basePath . '.meta')) {
unlink($metaPath);
}
if (is_file($dataPath = $basePath . '.data')) {
unlink($dataPath);
}

return true;
}







public function clear($category = null)
{
$path = $this->path . ((null === $category) ? '' : DIRECTORY_SEPARATOR . $category);
if (!is_dir($path)) {

return true;
}
$recursiveDirectoryIteratorFlags = FilesystemIterator::CURRENT_AS_FILEINFO | FilesystemIterator::SKIP_DOTS;
foreach(
new RecursiveIteratorIterator(
new RecursiveDirectoryIterator($path, $recursiveDirectoryIteratorFlags),
RecursiveIteratorIterator::CHILD_FIRST
) as $item
) {


if ($item->isDir()) {

rmdir($item->getPathname());
} else {

unlink($item->getPathname());
}

}

return true;
}






public function getVerifyBoundFiles()
{
return $this->verifyBoundFiles;
}







public function setVerifyBoundFiles($verifyBoundFiles)
{
$this->verifyBoundFiles = $verifyBoundFiles;
return $this;
}









protected function composePath($category, $name, $asArray = false)
{
$hash = md5($name);
if ($asArray) {
return array(
$this->path
. DIRECTORY_SEPARATOR . $category
. DIRECTORY_SEPARATOR . substr($hash, 0, 3)
. DIRECTORY_SEPARATOR . substr($hash, 3, 3),
substr($hash, 6),
);
} else {
return $this->path
. DIRECTORY_SEPARATOR . $category
. DIRECTORY_SEPARATOR . substr($hash, 0, 3)
. DIRECTORY_SEPARATOR . substr($hash, 3, 3)
. DIRECTORY_SEPARATOR . substr($hash, 6)
;
}
}







protected function compileBoundFiles(array $boundFiles)
{
$compiledBoundFiles = array();
foreach ($boundFiles as $boundFile) {
if (!is_file($boundFile)) {
throw new RuntimeException(sprintf('Invalid bound file "%s"', $boundFile));
}
$compiledBoundFiles[] = array($boundFile, filemtime($boundFile));
}

return $compiledBoundFiles;
}







protected function validateMeta(array $metaData)
{

if (null !== $metaData['expires'] && $metaData['expires'] < time()) {
return false;
}


if ($this->verifyBoundFiles && null !== $metaData['bound_files']) {
foreach ($metaData['bound_files'] as $boundFile) {
if (!is_file($boundFile[0]) || filemtime($boundFile[0]) !== $boundFile[1]) {
return false;
}
}
}

return true;
}








protected function serialize($data, $maxArrayLevel = 512)
{

$out = '<?php if (!defined(\'_core\')) die; return ';







$queue = array(array(0, $data, null, 0));
$queueStack = array();
$data = null;


do {

while ($item = current($queue)) {

$isEndOfQueue = (false === next($queue));

if ($item[3] >= $maxArrayLevel) {
throw new OverflowException('Array nesting level exceeded - recursive data?');
}


if (0 !== $item[0]) {

$out .= var_export($item[2], true) . '=>';
}


if (is_array($item[1])) {


$out .= 'array(';


if (!empty($item[1])) {


if (!$isEndOfQueue) {
$queueStack[] = $queue;
}


$queue = array();
$arrSize = sizeof($item[1]);
$arrCounter = 0;
foreach ($item[1] as $arrKey => $arrVal) {
++$arrCounter;
if ($arrCounter === $arrSize) {
if(1 === $item[0] || 3 === $item[0]) $arrItemMode = 3;
else $arrItemMode = 2;
$arrItemModeLevel = $item[3] + 1;
} else {
$arrItemMode = 1;
$arrItemModeLevel = 0;
}
$queue[] = array($arrItemMode, $arrVal, $arrKey, $arrItemModeLevel);
}
continue;

} else {


$out .= ')';

}

} elseif (is_object($item[1])) {


$out .= 'unserialize(' . var_export(serialize($item[1]), true) . ')';

} else {


$out .= var_export($item[1], true);

}


switch ($item[0]) {


case 1:
$out .= ',';
break;


case 2:
case 3:
$out .= str_repeat(')', $item[3]);
if(3 === $item[0]) $out .= ',';
break;

}

}

} while ($queue = array_pop($queueStack));


$out .= ';';


return $out;
}

}
