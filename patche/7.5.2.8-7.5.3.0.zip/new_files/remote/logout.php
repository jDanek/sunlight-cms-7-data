<?php

if (!defined('_core')) {
require '../require/load.php';
SL::init('../');
}


if (_xsrfCheck(true)) _userLogout();
_returnHeader();
