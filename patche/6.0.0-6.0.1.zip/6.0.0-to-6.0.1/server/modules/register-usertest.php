<?php

$rootpath=array("path"=>"../");
$moduletitle="register_testname_title";
include("../_connect.php");
include("moduleheader.php");

/*nacteni id*/
$id=$_GET['id'];
$id=anchor($id, false);
if($id==""){$continue=false;}
else{$continue=true;}

?>

<body style="margin: 0px;">

<div class="board" style="width:275px;">
<div class="board-padding">
<center>

<h2><?php echo lang('register_testname_title'); ?></h2>
<?php if($continue==true){echo "<h2><q> ".$id." </q></h2>";} ?>
<p>
<center>
<?php
if($continue==true){

  $userdata=@mysql_query("SELECT id,name,rights,email,note FROM `".tabprefix."-users` WHERE name='$id'");
  $userdata=@mysql_fetch_array($userdata);

  if($userdata['name']!=""){
  echo "<font style='color:red;font-weight:bold;'>".lang('register_testname_true')."</font>";
  }
  else{
  echo "<font style='color:green;font-weight:bold;'>".lang('register_testname_false')."</font>";
  }

}
else{
lang('global_invalidinput', 1);
}
?>
</center>
</p>

</center>
</div>
</div>

</body>
</html>
