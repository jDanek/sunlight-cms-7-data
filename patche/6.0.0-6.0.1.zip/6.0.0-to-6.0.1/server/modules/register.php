<?php

$continue=false;
$done=0;

/*kontrola udaju*/
if(isset($_POST['mod_codecheckr'])){

  /*nacteni promennych*/
  $codecheck=$_POST['mod_codecheck'];
  $codecheckrr=$_POST['mod_codecheckr'];
  $codecheckr=code_decode($codecheckrr);
  $password=$_POST['mod_password'];
  $password2=$_POST['mod_password2'];
  $email=$_POST['mod_email'];
  $email=strtr($email, $trans);
  $email=trim($email);
  $name=$_POST['mod_name'];
  $name=anchor($name, false);
  $name=substr($name, 0, 20);

  if($name!="" and validate_email($email) and ($codecheck==$codecheckr or $st_codecheck==0) and $password==$password2 and $password!=""){
  
  $namecheck=@mysql_query("SELECT name FROM `".tabprefix."-users` WHERE name='$name'");
  $namecheck=mysql_fetch_array($namecheck);
  $namecheck=$namecheck['name'];

  if($namecheck==""){
  
    $emailcheck=@mysql_query("SELECT name FROM `".tabprefix."-users` WHERE email='$email'");
    $emailcheck=mysql_fetch_array($emailcheck);
    $emailcheck=$emailcheck['name'];
    
    if($emailcheck==""){

    if(isset($_POST['mod_step1done'])){
  
    /*vypocet noveho id*/
    $id=@mysql_query("SELECT id FROM `".tabprefix."-users` ORDER BY id DESC LIMIT 1");
    $id=@mysql_fetch_array($id);
    $id=$id['id'];
    $id++;

    /*zasifrovani hesla*/
    $password=md5($password);

    /*vlozeni do db*/
    @mysql_query("INSERT INTO `".tabprefix."-users` (id,name,realname,rights,password,email,sex,year,month,note,lastlogin,lastact,massmail) VALUES ($id,'$name','',0,'$password','$email',-1,-1,-1,'',".time().",".time().",1)");

    /*zprava+parametry*/
    $done=1;
    $continue=false;

    }
    else{
    $continue=true;
    }

    }
    else{
    $msg=lang('global_msg_mailexists');
    }

  }
  else{
  $msg=lang('global_msg_userexists');
  }

  }
  else{
  $msg=lang('global_msg_someempty');
  $continue=false;
  }

}

include("msg.php");
if($continue==true and $done!=1){
echo "<a href='".modrewrite("register")."'>&lt; ".lang('global_goback')."</a><br /><br />";

}
?>

<?php if(template_auto_write_headings=="true"){echo "<h1>".lang('register_title')."</h1>";} ?>

<?php
if($done!=1){

if($continue==true){
echo "
<p>".lang('register_p2')."</p>

<form action='".modrewrite("register")."' method='post'>
<input type='hidden' name='mod_step1done' value='1' />
<input type='hidden' name='mod_codecheck' value='".$codecheck."' />
<input type='hidden' name='mod_codecheckr' value='".$codecheckrr."' />
<input type='hidden' name='mod_password' value='".$password."' />
<input type='hidden' name='mod_password2' value='".$password2."' />
<input type='hidden' name='mod_email' value='".$email."' />
<input type='hidden' name='mod_name' value='".$name."' />

<table>

<tr>
<td><b>".lang('global_username')."</b></td>
<td>$name</td>
</tr>

<tr>
<td><b>".lang('global_pass')."</b></td>
<td><a href=\"javascript:alert('$password');\">".lang('global_show')."</a></td>
</tr>

<tr>
<td><b>".lang('global_email')."</b></td>
<td>$email</td>
</tr>

<tr><td></td><td>&nbsp;</td></tr>

<tr>
<td></td>
<td><input type='submit' value='".lang('global_create')." &gt;' /></td>
</tr>

</table>
</form>
";
}
else{

if($st_codecheck==1){
$codecheck=code_generate();
$codecontent="
<tr>
<td><b>".lang('global_codecheck')."</b></td>
<td><input type='text' name='mod_codecheck' size='20' maxlength='8' />&nbsp;<img src='modules/kod.php?n=".$codecheck."' alt='".lang('global_codecheckhelp')."' title='".lang('global_codecheckhelp')."' class='codecheck' /></td>
</tr>
";
$jscodecontent=" || document.regform.mod_codecheck.value==''";
}else{$codecheck=-1; $codecontent=""; $jscodecontent="";}

echo "
<p>".lang('register_p1')."</p>

<form action='".modrewrite("register")."' method='post' name='regform' onsubmit=\"//<![CDATA[
if(document.regform.mod_name.value=='' || document.regform.mod_password.value=='' || document.regform.mod_password2.value=='' || document.regform.mod_email.value=='' || document.regform.mod_email.value.length<3$jscodecontent){alert('".lang('global_somethingwrong')."'); return false;}
//]]>\">
<input type='hidden' name='mod_codecheckr' value='".$codecheck."' />
<table>

<tr>
<td><b>".lang('global_username')."</b></td>
<td><input type='text' name='mod_name' size='20' maxlength='20' />&nbsp;&gt;&nbsp;<a href='#' onclick=\"if(document.regform.mod_name.value!=''){window.open('modules/register-usertest.php?id='+document.regform.mod_name.value, '_blank', 'toolbar=0,location=0,directories=0,menubar=0,width=350,height=180',scrollbars=1);} return false;\" title='".lang('register_testnamehelp')."'>".lang('global_testit')."</a></td>
</tr>

$codecontent

<tr>
<td><b>".lang('global_pass')."</b></td>
<td><input type='password' name='mod_password' size='20' maxlength='255' /></td>
</tr>

<tr>
<td><b>".lang('global_pass')." ".lang('global_check')."</b></td>
<td><input type='password' name='mod_password2' size='20' maxlength='255' /></td>
</tr>

<tr>
<td><b>".lang('global_email')."</b></td>
<td><input type='text' name='mod_email' size='20' maxlength='128' /></td>
</tr>

<tr>
<td></td>
<td><input type='submit' value='".lang('global_continue')." &gt;' /></td>
</tr>

</table>
</form>
";

}

}
else{
echo "<p>".lang('register_p3')."</p>";
}

?>
