<?php

if(login_indicator!=1){

if($refer!=0){$getrefer="refer=$refer";}else{$getrefer="";}
$mtmp.="<form action=\"".modrewrite("login", false, true)."$getrefer\" method=\"post\" name=\"hcmloginform\" onsubmit=\"document.hcmloginform.cryptedpass.value=hex_md5(document.hcmloginform.password.value);document.hcmloginform.password.value='';\">";
if($loginmodulerefer==true and $_SERVER['HTTP_REFERER']!='' and $refer!=-1){$mtmp.="<input type='hidden' name='loginmodulereferer' value='".ampersands($_SERVER['HTTP_REFERER'])."' />";}

$mtmp.="
<script type='text/javascript' src='".root."modules/md5.js'>
</script>

<script type='text/javascript'>
//<![CDATA[
document.write(\"<input type='hidden' name='crypted' value='1' />\");
document.write(\"<input type='hidden' name='cryptedpass' value='' />\");
//]]>
</script>
<noscript>
<input type='hidden' name='crypted' value='0' />
</noscript>

<table>

<tr>
<td>".lang('global_user')."&nbsp;</td>
<td><input type='text' size='6' name='name' /></td>
</tr>

<tr>
<td>".lang('global_pass')."</td>
<td><input type='password' size='6' name='password' maxlength='255' /></td>
</tr>

<tr>
<td></td>
<td><input type='submit' value='".lang('global_go')." &gt;' /></td>
</tr>

</table>
</form>
";
}
else{
$mtmp.="<a href='modules/logout.php'>".lang('usermenu_logout')."</a>";
}

?>
