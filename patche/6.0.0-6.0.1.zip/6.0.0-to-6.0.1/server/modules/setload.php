<?php

$settings=@mysql_query("SELECT * FROM `".tabprefix."-settings`");

while($item=@mysql_fetch_array($settings)){
$variable=$item['variable'];
$value=$item['value'];
eval('$st_'."$variable='$value';");
}

/*zpracovani hodnot*/

  /*artorder*/
  switch($st_artorder){
  case 1: $st_artorder="date DESC"; break;
  case 2: $st_artorder="id DESC"; break;
  case 3: $st_artorder="title"; break;
  }
  
  /*futureart*/
  if($st_futureart==0){
  $st_futureart=" AND date<=".time();
  $st_futureart2=" WHERE date<=".time();
  }
  else{
  $st_futureart="";
  $st_futureart2="";
  }
  
  /*invismain*/
  if($st_invismain==0){$st_invismain=" AND visible=1";}
  else{$st_invismain="";}

/*definovani konstant*/
if(!defined("stconstantsdefined")){



  //detekovani adresy serveru
  if($st_serverurl=="[DETECT]"){
  function myrealpath($path) {if (strpos($path,"/") === 0) {$path = $_SERVER['DOCUMENT_ROOT'].$path;}else {$currentDir = preg_split("/\//",dirname($_SERVER['PATH_TRANSLATED']));$newDir = preg_split('/\//',$path);foreach ($newDir as $dir) {if ($dir == "..")array_pop($currentDir);elseif ($dir != ".")array_push($currentDir,$dir);}$path = implode($currentDir,"/");}return $path;}
  $st_serverurl=str_replace("\\","/", $_SERVER['PHP_SELF']);
  $st_serverurl=substr($st_serverurl, 1);
  $st_serverurl=substr($st_serverurl, 0, strrpos($st_serverurl, "/")+1);
  $st_serverurl=myrealpath($st_serverurl.root);
  $st_serverurl="http://".getenv('SERVER_NAME').$st_serverurl;
  if(substr($st_serverurl, -1)=="/"){$st_serverurl=substr($st_serverurl, 0, strlen($st_serverurl)-1);}
  @mysql_query("UPDATE `".tabprefix."-settings` SET value='$st_serverurl' WHERE variable='serverurl'");
  }

define('stconstantsdefined', 1);
define('langfile', $st_langfile);
define('artorder', $st_artorder);
define('artread', $st_artread);
define('artrealname', $st_artrealname);
define('futureart', $st_futureart);
define('futureart2', $st_futureart2);
define('comment', $st_comment);
define('postwait', $st_postwait);
define('registration', $st_registration);
define('postadmintimeout', $st_postadmintimeout);
define('redadmreaders', $st_redadmreaders);
define('tpart', $st_tpart);
define('smileys', $st_smileys);
define('updiracpref', $st_updiracpref);
define('userlist', $st_userlist);
define('codecheck', $st_codecheck);
define('serverurl', $st_serverurl);
define('lostpass', $st_lostpass);
define('copytext', $st_copytext);
define('title', $st_title);
define('description', $st_description);
}

?>
