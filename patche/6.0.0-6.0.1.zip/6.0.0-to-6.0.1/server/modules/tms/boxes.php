<?php

$mtmp="";
if(!isset($box_column)){$box_column=0;}
else{$box_column=intval($box_column);}

/*zacatek boxu ->*/   if(template_boxes_ancestor_tag!=""){$mtmp.="<".template_boxes_ancestor_tag." class='box-ancestor'>";}

/*nastaveni obsahu title*/  if(template_boxes_title_content_tag!=""){$title_contenttag1="<".template_boxes_title_content_tag.">"; $title_contenttag2="</".template_boxes_title_content_tag.">";}

$boxes=@mysql_query("SELECT title,showtitle,content FROM `".tabprefix."-boxes` WHERE visible=1 and panel=$box_column ORDER BY ord");
while($box=@mysql_fetch_array($boxes)){
$title="<".template_boxes_title_tag." class='box-title'>$title_contenttag1".$box['title']."$title_contenttag2</".template_boxes_title_tag.">";

/*titulek venku ->*/  if($box['showtitle']==1 and template_boxes_title_tag!="" and template_boxes_title_position=="outside"){$mtmp.=$title;}
/*zacatek pad. ->*/   if(template_boxes_child_tag!=""){$mtmp.="<".template_boxes_child_tag." class='box-child'>";}
/*titulek unvitr ->*/ if($box['showtitle']==1 and template_boxes_title_tag!="" and template_boxes_title_position=="inside"){$mtmp.=$title;}
/*obal obsahu*/       if(template_boxes_child_content_tag!=""){$mtmp.="<".template_boxes_child_content_tag." class='box-content'>";}
/*obsah boxu ->*/     $mtmp.=parsehcm($box['content']);
/*obal obsahu*/       if(template_boxes_child_content_tag!=""){$mtmp.="</".template_boxes_child_content_tag.">";}
/*spodek vevnitr ->*/ if(template_boxes_bottom_tag!="" and template_boxes_bottom_position=="inside"){$mtmp.="<".template_boxes_bottom_tag." class='box-bottom'></".template_boxes_bottom_tag.">";}
/*konec pad. ->*/     if(template_boxes_child_tag!=""){$mtmp.="</".template_boxes_child_tag.">";}
/*spodek venku ->*/   if(template_boxes_bottom_tag!="" and template_boxes_bottom_position=="outside"){$mtmp.="<".template_boxes_bottom_tag." class='box-bottom'></".template_boxes_bottom_tag.">";}

}

/*konec boxu ->*/     if(template_boxes_ancestor_tag!=""){$mtmp.="</".template_boxes_ancestor_tag.">";}

?>
