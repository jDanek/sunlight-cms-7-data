<?php

$donotinit=true;
$rootpath=array("path"=>"../../");
$indicators['administration']=1;
include ("../../_connect.php");
include("../check.php");
include("../functions.php");

  /*pristupova prava*/
  switch($id){
  
    //pouze pro adminy
    case "forum_topics":
    case "vote_ips":
    case "gpost_items":
    if($login_rights!=2){exit;}
    break;
    
    //pouze pro hlavniho admina
    case "sdb_backup": case "sdb_restore": if($login_id!=0){exit;} break;
    
    //ostatni
    case "massemail_getmails": if(!(($login_id==0) or ($login_rights==2 and $st_adminmassmail==1))){exit;} break;
    
  }

  /*vlozeni dat hlavicky*/
  if(!isset($nohead)){include("header_content.php");}

?>
