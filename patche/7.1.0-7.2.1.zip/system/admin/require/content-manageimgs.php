<?php

/*--- core test ---*/
if(!defined('_core')){exit;}

/*--- init variables ---*/
$message="";
$continue=false;
if(isset($_GET['g'])){
$g=intval($_GET['g']);
$galdata=mysql_query("SELECT title,var2,var3 FROM `"._mysql_prefix."-root` WHERE id=".$g." AND type=5");
  if(mysql_num_rows($galdata)!=0){
  $galdata=mysql_fetch_array($galdata);
  $continue=true;
  }
}

/*--- post actions ---*/
if(isset($_POST['action'])){

  switch($_POST['action']){

  /*- insert image -*/
  case 1:

    //load basic vars
    $title=_safeStr(_htmlStr($_POST['title']));
      if(!_checkboxLoad("autoprev")){$prev=_safeStr(_htmlStr($_POST['prev']));}
      else{$prev="*auto*";}
    $full=_safeStr(_htmlStr($_POST['full']));
    
    //move ords or load
    if(_checkboxLoad("moveords")){
    $smallerord=mysql_query("SELECT ord FROM `"._mysql_prefix."-images` WHERE home=".$g." ORDER BY ord LIMIT 1");
      if(mysql_num_rows($smallerord)!=0){$smallerord=mysql_fetch_array($smallerord); $ord=$smallerord['ord'];}
      else{$ord=1;}
    mysql_query("UPDATE `"._mysql_prefix."-images` SET ord=ord+1 WHERE home=".$g);
    }
    else{
    $ord=floatval($_POST['ord']);
    }
    
    //insert
    $newid=_getNewID("images");
    mysql_query("INSERT INTO `"._mysql_prefix."-images` (id,home,ord,title,prev,full) VALUES(".$newid.",".$g.",".$ord.",'".$title."','".$prev."','".$full."')");
    $message=_formMessage(1, $_lang['global.inserted']);

  break;
  
  /*- move ords -*/
  case 2:
  
    //load vars
    $action=intval($_POST['moveaction']);
    $zonedir=intval($_POST['zonedir']);
    $zone=floatval($_POST['zone']);
    $offset=floatval($_POST['offset']);

    //query
    if($action==1){$sign="+";}else{$sign="-";}
    if($zonedir==1){$zonedir=">";}else{$zonedir="<";}
    mysql_query("UPDATE `"._mysql_prefix."-images` SET ord=ord".$sign.$offset." WHERE ord".$zonedir."=".$zone." AND home=".$g);
    $message=_formMessage(1, $_lang['global.done']);

  break;
  
  /*- order cleanup -*/
  case 3:
  $items=mysql_query("SELECT id FROM `"._mysql_prefix."-images` WHERE home=".$g." ORDER BY ord");
  $counter=1;
  while($item=mysql_fetch_array($items)){
  mysql_query("UPDATE `"._mysql_prefix."-images` SET ord=".$counter." WHERE id=".$item['id']." AND home=".$g);
  $counter++;
  }
  break;
  
  /*- update images -*/
  case 4:
  foreach($_POST as $var=>$val){
  if($var=="action"){continue;}
  $var=@explode("-", $var);
    if(count($var)==2){
      $id=intval($var[0]); $var=_safeStr($var[1]);
      $quotes="'";
      $skip=false;
        switch($var){
        case "title": case "full": $val=_safeStr(_htmlStr($val)); break;
        case "prev": if(!_checkboxLoad($id."-autoprev")){$val=_safeStr(_htmlStr($val));}else{$val="*auto*";} break;
        case "ord": $val=floatval($val); $quotes=''; break;
        default: $skip=true; break;
        }
      if(!$skip){mysql_query("UPDATE `"._mysql_prefix."-images` SET ".$var."=".$quotes.$val.$quotes." WHERE id=".$id." AND home=".$g);}
    }
  }
  $message=_formMessage(1, $_lang['global.saved']);
  break;

  }

}

/*--- delete image ---*/
if(isset($_GET['del'])){
$del=intval($_GET['del']);
  if(mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-images` WHERE id=".$del." AND home=".$g), 0)!=0){
  mysql_query("DELETE FROM `"._mysql_prefix."-images` WHERE id=".$del." AND home=".$g);
  $message=_formMessage(1, $_lang['global.done']);
  }
}

/*--- output ---*/
if($continue){
$output.="
<a href='index.php?p=content-editgallery&amp;id=".$g."' class='backlink'>&lt; návrat zpět</a>
<h1>".$_lang['admin.content.manageimgs.title']."</h1>
<p class='bborder'>".str_replace("*galtitle*", $galdata['title'], $_lang['admin.content.manageimgs.p'])."</p>

".$message."

<fieldset>
<legend>".$_lang['admin.content.manageimgs.insert']."</legend>
<form class='cform' action='index.php?p=content-manageimgs&amp;g=".$g."' method='post'>
<input type='hidden' name='action' value='1' />

<table>

<tr>
<td class='rpad'><strong>".$_lang['admin.content.form.title']."</strong></td>
<td><input type='text' name='title' class='inputbig' /></td>
</tr>

<tr>
<td class='rpad'><strong>".$_lang['admin.content.form.ord']."</strong></td>
<td><input type='text' name='ord' class='inputmedium' />&nbsp;&nbsp;<label><input type='checkbox' name='moveords' value='1' /> ".$_lang['admin.content.manageimgs.moveords']."</label></td>
</tr>

<tr>
<td class='rpad'><strong>".$_lang['admin.content.manageimgs.prev']."</strong></td>
<td><input type='text' name='prev' class='inputmedium' />&nbsp;&nbsp;<label><input type='checkbox' name='autoprev' value='1' /> ".$_lang['admin.content.manageimgs.autoprev']."</label></td>
</tr>

<tr>
<td class='rpad'><strong>".$_lang['admin.content.manageimgs.full']."</strong></td>
<td><input type='text' name='full' class='inputmedium' /></td>
</tr>

<tr>
<td></td>
<td><input type='submit' value='".$_lang['global.insert']."' /></td>
</tr>

</table>

</form>
</fieldset>



<fieldset>
<legend>".$_lang['admin.content.manageimgs.moveallords']."</legend>


<form class='cform' action='index.php?p=content-manageimgs&amp;g=".$g."' method='post'>
<input type='hidden' name='action' value='2' />
<select name='moveaction'><option value='1'>".$_lang['admin.content.move.choice1']."</option><option value='2'>".$_lang['admin.content.move.choice2']."</option></select>&nbsp;
".$_lang['admin.content.move.text1']."&nbsp;
<select name='zonedir'><option value='1'>".$_lang['admin.content.move.choice3']."</option><option value='2'>".$_lang['admin.content.move.choice4']."</option></select>&nbsp;
".$_lang['admin.content.move.text2']."&nbsp;
<input type='text' name='zone' value='1' class='inputmini' maxlength='5' />&nbsp;,
".$_lang['admin.content.move.text3']."&nbsp;
<input type='text' name='offset' value='1' class='inputmini' maxlength='5' />.&nbsp;
<input type='submit' value='".$_lang['global.do']."' onclick='return _sysconfirm();' />
</form>

<div class='hr'><hr /></div>

<form class='cform' action='index.php?p=content-manageimgs&amp;g=".$g."' method='post'>
<input type='hidden' name='action' value='3' />
".$_lang['admin.content.manageimgs.moveallords.cleanup']." <input type='submit' value='".$_lang['global.do']."' onclick='return _sysconfirm();' />
</form>

</fieldset>";

  //init imgs paging
  $paging=_resultPaging("index.php?p=content-manageimgs&amp;g=".$g, $galdata['var2'], "images", "home=".$g);
  $s=$paging[2];

$output.="
<fieldset>
<legend>".$_lang['admin.content.manageimgs.current']."</legend>
<form class='cform' action='index.php?p=content-manageimgs&amp;g=".$g."&amp;s=".$s."' method='post'>
<input type='hidden' name='action' value='4' />

<input type='submit' value='".$_lang['admin.content.manageimgs.savechanges']."' />
<div class='hr'><hr /></div>
";

  //imgs
  $output.=$paging[0]."<div class='hr'><hr /></div>";
  $images=mysql_query("SELECT * FROM `"._mysql_prefix."-images` WHERE home=".$g." ORDER BY ord ".$paging[1]);
  if(mysql_num_rows($images)!=0){
    while($image=mysql_fetch_array($images)){
    
      //preview code
      $preview="<a href='"._condReturn(!_isAbsolutePath($image['prev']), _indexroot).$image['full']."' target='_blank'>";
        if($image['prev']!="*auto*"){
        $preview.="<img src='"._condReturn(!_isAbsolutePath($image['prev']), _indexroot).$image['prev']."' alt='preview' />";
        }
        else{
        $preview.="<img src='"._indexroot."remote/imgprev.php?id=".$image['id']."' alt='prev' />";
        }
      $preview.="</a>";
    
    $output.="
    <br />
    <table>

    <tr>
    <td class='rpad'><strong>".$_lang['admin.content.form.title']."</strong></td>
    <td><input type='text' name='".$image['id']."-title' class='inputbig' value='".$image['title']."' /></td>
    </tr>

    <tr>
    <td class='rpad'><strong>".$_lang['admin.content.form.ord']."</strong></td>
    <td><input type='text' name='".$image['id']."-ord' class='inputmedium' value='".$image['ord']."' /></td>
    </tr>

    <tr>
    <td class='rpad'><strong>".$_lang['admin.content.manageimgs.prev']."</strong></td>
    <td><input type='text' name='".$image['id']."-prev' class='inputmedium' value='".$image['prev']."' />&nbsp;&nbsp;<label><input type='checkbox' name='".$image['id']."-autoprev' value='1'"._checkboxActivate($image['prev']=="*auto*")." /> ".$_lang['admin.content.manageimgs.autoprev']."</label></td>
    </tr>

    <tr>
    <td class='rpad'><strong>".$_lang['admin.content.manageimgs.full']."</strong></td>
    <td><input type='text' name='".$image['id']."-full' class='inputmedium' value='".$image['full']."' /></td>
    </tr>
    
    <tr valign='top'>
    <td class='rpad'><strong>".$_lang['global.preview']."</strong></td>
    <td>".$preview."<br /><br /><a href='index.php?p=content-manageimgs&amp;g=".$g."&amp;s=".$s."&amp;del=".$image['id']."' onclick='return _sysconfirm();'><img src='images/icons/delete.gif' alt='del' class='icon' />".$_lang['admin.content.manageimgs.delete']."</a></td>
    </tr>
    
    </table>
    <br /><div class='hr'><hr /></div>
    ";
    }
  $output.=$paging[0];
  }
  else{
  $output.=$_lang['global.nokit'];
  }

$output.="</form></fieldset>";
}
else{
$output.=_formMessage(3, $_lang['global.badinput']);
}

?>