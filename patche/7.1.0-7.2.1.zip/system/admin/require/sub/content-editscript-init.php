<?php

/*--- core test ---*/
if(!defined('_core')){exit;}

/*--- load variables ---*/
$continue=false;
if(isset($_GET['id'])){
$id=intval($_GET['id']);
$query=mysql_query("SELECT * FROM `"._mysql_prefix."-root` WHERE id=".$id." AND type=".$type);
  if(mysql_num_rows($query)!=0){
  $query=mysql_fetch_array($query);
  $custom_settings="";
  $custom_array=array();
  $continue=true;
  }
}

?>