<?php

/*---- initialize core ----*/

define('_indexroot', '../');
define('_administration', '1');
require(_indexroot."core/_core.php");


/*---- system body ----*/

//admin content
_adminOutput();

?>