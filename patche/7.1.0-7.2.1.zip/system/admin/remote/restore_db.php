<?php

/*--- init core ---*/
define('_indexroot', '../../');
require(_indexroot."core/_core.php");

/*--- output ---*/
if(!_loginright_adminbackup){exit;}

function _tmp_restoreMessage($string, $success=false){
global $_lang;

if($success){$link=_indexroot;}
else{$link=_indexroot."admin/index.php?p=other-backup";}

echo '
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<style type="text/css">
body {font-family: Arial, Helvetica, sans-serif; font-size: 13px;}
</style>
<title>'.$_lang['admin.other.backup.restore'].'</title>
</head>

<body>
<h1>'.$_lang['admin.other.backup.restore'].'</h1>
<p>'.$string.'</p>
<p><a href="'.$link.'">&lt; '.$_lang['global.return'].'</a></p>
</body>
</html>
';

exit;

}

  //load uploaded file
  if(is_uploaded_file($_FILES['backup']['tmp_name'])){
    $info=pathinfo($_FILES['backup']['name']);
    if(!isset($info['extension'])){$info['extension']="";}
      if($info['extension']=="sld"){
        $data=@gzinflate(@base64_decode(@file_get_contents($_FILES['backup']['tmp_name'])));
          if($data!=null){
            $data=@explode("\n", $data);
              if(_checkVersion("database_backup", _slcDecode($data[0]))){
              array_shift($data);
              
                //trunacate tables
                $tables=array(
                'articles',
                'boxes',
                'groups',
                'images',
                'iplog',
                'messages',
                'polls',
                'posts',
                'root',
                'settings',
                'users'
                );

                foreach($tables as $table){
                mysql_query("TRUNCATE TABLE `"._mysql_prefix."-".$table."`");
                }

                //insert data
                foreach($data as $line){
                if($line==""){continue;}
                @mysql_query("INSERT INTO `"._mysql_prefix."-".$line);
                if(mysql_error()!=null){_tmp_restoreMessage($_lang['admin.other.backup.restore.queryerror']);}
                }

                //logout, success message
                $logout_noreturn=true; require(_indexroot."remote/logout.php");
                _tmp_restoreMessage($_lang['admin.other.backup.restore.success'], true);
                
              }
              else{
              _tmp_restoreMessage($_lang['admin.other.backup.restore.badversion']);
              }
          }
          else{
          _tmp_restoreMessage($_lang['admin.other.backup.restore.fileerror']);
          }
      }
      else{
      _tmp_restoreMessage($_lang['admin.other.backup.restore.badextension']);
      }
  }
  else{
    _tmp_restoreMessage($_lang['admin.other.backup.restore.notuploaded']);
  }

?>