<?php

/*--- core test ---*/
if(!defined('_core')){exit;}

/*--- variables ---*/
$form=false;
$message="";
$id=null;

  if(isset($_GET['id'])){
  $id=_safeStr(_anchorStr($_GET['id'], false));
  $query=mysql_query("SELECT id,`group`,username,registertime,activitytime,email,avatar,icq,note,blocked FROM `"._mysql_prefix."-users` WHERE username='".$id."'");
    if(mysql_num_rows($query)!=0){
    $query=mysql_fetch_array($query);
    $groupdata=mysql_fetch_array(mysql_query("SELECT title,icon,blocked FROM `"._mysql_prefix."-groups` WHERE id=".$query['group']));
    $form=true;
    
      //variables
      if($query['avatar']==""){$query['avatar']=_indexroot."templates/"._template."/images/system/no-avatar.gif";}
      if($query['note']==""){$note="";}else{$note="<tr valign='top'><td><strong>".$_lang['global.note']."</strong></td><td><div class='note'>"._parsePost($query['note'])."</div></div></td></tr>";}

      $arts=mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-articles` WHERE author=".$query['id']." AND confirmed=1 AND visible=1"), 0);
      if($arts!=0){$arts="<tr><td><strong>".$_lang['global.articlesnum']."</strong></td><td>".$arts."</td></tr>";}
      else{$arts=null;}
    
    }
    else{
    $message=_formMessage(2, $_lang['global.baduser']);
    }
  }

/*--- module ---*/

  //title
  if(_template_autoheadings==1){$module="<h1>".$_lang['mod.profile']."</h1><br />";}else{$module="";}

  //user search from
  $module.="
  <form action='index.php' method='get'>
  <input type='hidden' name='m' value='profile' />
  <input type='text' name='id'"._condReturn($id!=null, " value='".$id."'")." class='inputmedium' /> <input type='submit' value='".$_lang['global.open']."' />
  </form><br />
  ".$message;
  
  //profile table
  if($form==true){
  $module.="
  <table>
  <tr valign='top'>
  
  <td class='avatartd'>
  <div class='avatar'>
  <img src='".$query['avatar']."' alt='avatar' />
  </div>
  </td>
  
  <td>
    <table class='profiletable'>

    "._condReturn($query['blocked']==1 or $groupdata['blocked']==1, "<tr><td colspan='2'><strong class='important'>".$_lang['mod.profile.blockednote']."</strong></td></tr>")."

    <tr>
    <td><strong>".$_lang['login.username']."</strong></td>
    <td>".$query['username']."</td>
    </tr>
    
    <tr>
    <td><strong>".$_lang['global.group']."</strong></td>
    <td>"._condReturn($groupdata['icon']!="", "<img src='"._indexroot."usericons/".$groupdata['icon']."' alt='icon' class='icon' /> ").$groupdata['title']."</td>
    </tr>
    
    "._condReturn(_profileemail, "<tr><td><strong>".$_lang['global.email']."</strong></td><td>"._mailto($query['email'])."</td></tr>")."
    "._condReturn($query['icq']!=0, "<tr><td><strong>".$_lang['global.icq']."</strong></td><td>".$query['icq']." <img src='http://status.icq.com/online.gif?icq=".$query['icq']."&amp;img=5' alt='icq status' class='icon' /></td></tr>")."

    <tr>
    <td><strong>".$_lang['mod.profile.regtime']."</strong></td>
    <td>"._formatTime($query['registertime'])."</td>
    </tr>

    <tr>
    <td><strong>".$_lang['mod.profile.lastact']."</strong></td>
    <td>"._formatTime($query['activitytime'])."</td>
    </tr>

    <tr>
    <td><strong>".$_lang['global.postsnum']."</strong></td>
    <td>".mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-posts` WHERE author=".$query['id']), 0)."</td>
    </tr>
    
    ".$arts."
    ".$note."

    </table>
  </td>
  
  </tr>
  </table>
  ";
  
    //message link
    if(_loginindicator and _messages and $query['id']!=_loginid){
    $module.="<p><a href='index.php?m=messages&a=3&receiver=".$query['username']."'>".$_lang['mod.messages.new']." &gt;</a></p>";
    }
  
  }

?>