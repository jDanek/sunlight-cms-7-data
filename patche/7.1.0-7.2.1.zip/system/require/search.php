<?php

/*--- core test ---*/
if(!defined('_core')){exit;}

/*--- init ---*/
function _tmp_checkboxLoadGet($input){if(isset($_GET[$input])){return 1;}else{return 0;}}

if(isset($_GET['q'])){
$q=trim(stripslashes($_GET['q']));
$root=_tmp_checkboxLoadGet("root");
$art=_tmp_checkboxLoadGet("art");
$post=_tmp_checkboxLoadGet("post");
}
else{
$q=""; $root=1; $art=1; $post=0;
}

/*--- module ---*/
if(_template_autoheadings==1){$module="<h1>".$_lang['mod.search']."</h1>";}else{$module="";}

$module.="
<p class='bborder'>".$_lang['mod.search.p']."</p>

<form action='index.php' method='get'>
<input type='hidden' name='m' value='search' />
<input type='text' name='q' class='inputmedium' value='"._htmlStr($q)."' /> <input type='submit' value='".$_lang['mod.search.submit']."' /><br />
".$_lang['mod.search.where'].":&nbsp;
<label><input type='checkbox' name='root' value='1'"._checkboxActivate($root)." /> ".$_lang['mod.search.where.root']."</label>&nbsp;
<label><input type='checkbox' name='art' value='1'"._checkboxActivate($art)." /> ".$_lang['mod.search.where.articles']."</label>&nbsp;
<label><input type='checkbox' name='post' value='1'"._checkboxActivate($post)." /> ".$_lang['mod.search.where.posts']."</label>
</form>

";

  /*- search -*/
  if($q!=""){
  if(mb_strlen($q)>=3){
  
  $q=_safeStr("%".$q."%");
  $results=array();
  
    if($root){
    $query=mysql_query("SELECT id,title,content,intersectionperex FROM `"._mysql_prefix."-root` WHERE visible=1"._condReturn(!_loginindicator, " AND public=1")." AND (title LIKE '".$q."' OR content LIKE '".$q."' OR intersectionperex LIKE '".$q."')");
      while($item=mysql_fetch_array($query)){
      $results[]=array(_linkRoot($item['id']), $item['title'], strip_tags($item['intersectionperex']));
      }
    }
    
    if($art){
    if(!_loginindicator){$public=" AND public=1 AND ((SELECT public FROM `"._mysql_prefix."-root` WHERE id=`"._mysql_prefix."-articles`.home1)=1 OR (SELECT public FROM `"._mysql_prefix."-root` WHERE id=`"._mysql_prefix."-articles`.home2)=1 OR (SELECT public FROM `"._mysql_prefix."-root` WHERE id=`"._mysql_prefix."-articles`.home3)=1)";}else{$public="";}
    $query=mysql_query("SELECT id,title,perex FROM `"._mysql_prefix."-articles` WHERE visible=1 AND confirmed=1 AND time<=".time()." AND (title LIKE '".$q."' OR content LIKE '".$q."' OR infobox LIKE '".$q."') AND ((SELECT visible FROM `"._mysql_prefix."-root` WHERE id=`"._mysql_prefix."-articles`.home1)=1 OR (SELECT visible FROM `"._mysql_prefix."-root` WHERE id=`"._mysql_prefix."-articles`.home2)=1 OR (SELECT visible FROM `"._mysql_prefix."-root` WHERE id=`"._mysql_prefix."-articles`.home3)=1)".$public);
      while($item=mysql_fetch_array($query)){
      $results[]=array(_linkArticle($item['id']), $item['title'], _cutStr(strip_tags($item['perex']), 255, false));
      }
    }
    
    if($post){
    $query=mysql_query("SELECT id,type,home,text,subject FROM `"._mysql_prefix."-posts` WHERE subject LIKE '".$q."' OR text LIKE '".$q."'");
      while($item=mysql_fetch_array($query)){
      
        //skip if not allowed to access
        switch($item['type']){
        case 1: case 3: $homedata=mysql_fetch_array(mysql_query("SELECT title,public,visible FROM `"._mysql_prefix."-root` WHERE id=".$item['home'])); break;
        case 2: $homedata=mysql_fetch_array(mysql_query("SELECT title,public,visible FROM `"._mysql_prefix."-articles` WHERE id=".$item['home'])); break;
        }
        
        if(!_publicAccess($homedata['public']) or $homedata['visible']!=1){continue;}
        
        //home link
        switch($item['type']){
        case 1: $homelink=_addGetToLink(_linkRoot($item['home']), "s="._resultPagingGetItemPage(_commentsperpage, "posts", "id>".$item['id']." AND type=1 AND xhome=-1 AND home=".$item['home']))."#posts"; break;
        case 2: $homelink=_addGetToLink(_linkArticle($item['home']), "s="._resultPagingGetItemPage(_commentsperpage, "posts", "id>".$item['id']." AND type=2 AND xhome=-1 AND home=".$item['home']))."#posts"; break;
        case 3: $postsperpage=mysql_fetch_array(mysql_query("SELECT var2 FROM `"._mysql_prefix."-root` WHERE id=".$item['home'])); $homelink=_addGetToLink(_linkRoot($item['home']), "s="._resultPagingGetItemPage($postsperpage['var2'], "posts", "id>".$item['id']." AND type=3 AND xhome=-1 AND home=".$item['home']))."#posts"; break;
        }
        
        //fill empty subject
        if($item['subject']==""){$item['subject']=$_lang['mod.messages.nosubject'];}
      
      $results[]=array($homelink, $item['subject']." (".$homedata['title'].")", _cutStr(strip_tags(_parsePost($item['text'])), 255));
      }
    }
    
    if(count($results)!=0){
      foreach($results as $item){
      $module.="
      <h2 class='list-title'><a href='".$item[0]."'>".$item[1]."</a></h2>
      <p class='list-perex'>".$item[2]."</p>
      ";
      }
    }
    else{
      $module.=_formMessage(1, $_lang['mod.search.noresult']);
    }

  }
  else{
  $module.=_formMessage(2, $_lang['mod.search.minlength']);
  }
  }



?>