<?php


/*---- return intersection output ----*/

function _intersectionOutput($id){
global $_lang;


$query=mysql_fetch_array(mysql_query("SELECT * FROM `"._mysql_prefix."-root` WHERE id=".$id));


/*-- title, text --*/
$content="";
if(_template_autoheadings){
$content.="<h1>".$query['title']."</h1>"._parseHCM($query['content'])."<div class='hr'><hr /></div>";
}
else{
  if($query['content']!=""){
  $content.=_parseHCM($query['content'])."<div class='hr'><hr /></div>";
  }
}

/*-- item list --*/
$items=mysql_query("SELECT id,title,type,intersectionperex,var1 FROM `"._mysql_prefix."-root` WHERE intersection=".$id." AND visible=1 ORDER BY ord");
  if(mysql_num_rows($items)!=0){

    while($item=mysql_fetch_array($items)){

      //title
      $content.="<h2 class='list-title'><a href='"._linkRoot($item['id'])."'>".$item['title']."</a></h2>";

      //perex
      if($item['intersectionperex']!=""){
      $content.="<p class='list-perex'>".$item['intersectionperex']."</p>";
      }


      //info
      if($query['var1']==1){
        $iteminfo="";

          switch($item['type']){

          //section
          case 1:
          if($item['var1']==1){$iteminfo.="<span>".$_lang['article.comments'].":</span> ".mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-posts` WHERE type=1 AND home=".$item['id']), 0);}
          break;

          //category
          case 2:
          $iteminfo.="<span>".$_lang['global.articlesnum'].":</span> ".mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-articles` WHERE (home1=".$item['id']." OR home2=".$item['id']." OR home3=".$item['id'].") AND confirmed=1 AND visible=1 AND time<=".time()), 0);
          break;

          //book
          case 3:

            //load lastpost
            $lastpost=mysql_query("SELECT author,guest FROM `"._mysql_prefix."-posts` WHERE home=".$item['id']." ORDER BY id DESC LIMIT 1");
            if(mysql_num_rows($lastpost)!=0){
              $lastpost=mysql_fetch_array($lastpost);
                if($lastpost['author']!=-1){$lastpost=_linkUser($lastpost['author'], null, true, true);}
                else{$lastpost=$lastpost['guest'];}
            }
            else{
              $lastpost="-";
            }

          $iteminfo.="<span>".$_lang['global.postsnum'].":</span> ".mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-posts` WHERE type=3 AND home=".$item['id']), 0)._template_listinfoseparator."<span>".$_lang['global.lastpost'].":</span> ".$lastpost;
          break;
          
          //gallery
          case 5:
          $iteminfo.="<span>".$_lang['global.imgsnum'].":</span> ".mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-images` WHERE home=".$item['id']), 0);
          break;

          }

        if($iteminfo!=""){$content.="<div class='list-info'>".$iteminfo."</div>\n";}
      }

    }

  }
  else{
  $content.=$_lang['global.nokit'];
  }

$title=$query['title'];


return array($content, $title);
}

?>