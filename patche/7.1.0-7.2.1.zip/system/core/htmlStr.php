<?php

/*---- replace disallowed symbols ----*/

function _htmlStr($input){
return str_replace(array("&", "<", ">", "\"", "'"), array("&amp;", "&lt;", "&gt;", "&quot;", "&#39;"), $input);
}

?>