<?php

/*---- check version of stuff ----*/

function _checkVersion($type, $version){

  switch($type){
  case "database_backup": $compatible_versions=array("7.2.0", "7.2.1"); break;
  case "language_file": $compatible_versions=array("7.2.0", "7.2.1"); break;
  case "template": $compatible_versions=array("7.2.0", "7.2.1"); break;
  }

return in_array($version, $compatible_versions);

}

?>