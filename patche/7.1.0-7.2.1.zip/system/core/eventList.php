<?php

/*---- return formatted event list ----*/

function _eventList($events, $intro=null){

  //load intro
  if($intro!=null){
    if($intro!="errors"){$output=$intro;}
    else{global $_lang; $output=$_lang['errorlog.intro'];}
  }
  else{
  $output="";
  }

$output.="<ul>";

  foreach($events as $item){
  $output.="<li>".$item."</li>";
  }

$output.="</ul>";
return $output;
}

?>