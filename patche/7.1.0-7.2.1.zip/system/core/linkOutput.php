<?php

/*---- return link output ----*/

function _linkOutput($id){
global $_lang;


$query=mysql_fetch_array(mysql_query("SELECT * FROM `"._mysql_prefix."-root` WHERE id=".$id));
$title=$query['title'];
$content="<a href='".$query['content']."'>".$title."</a>";
define('_tmp_redirect', $query['content']);


return array($content, $title);
}

?>