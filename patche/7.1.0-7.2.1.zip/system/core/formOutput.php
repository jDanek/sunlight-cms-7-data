<?php

/*---- create and return form table ----*/

function _formOutput($name, $action, $cells, $check=null, $submittext=null, $codenexttosubmit=null){
global $_lang;

/*--- javascript check code, submit text ---*/
if($check!=null){$checkcode=_jsCheckForm($name, $check);}
else{$checkcode="";}

if($submittext!=null){$submit=$submittext;}
else{$submit=$_lang['global.send'];}

/*--- output ---*/
$output="
<form action='".$action."' method='post' name='".$name."'".$checkcode.">
<table>";

  //cells
  foreach($cells as $cell){
  if($cell[0]!=""){
    $output.="
    <tr"._condReturn(isset($cell[2]), " valign='top'").">
    <td class='rpad'><strong>".$cell[0]."</strong></td>
    <td>".$cell[1]."</td>
    </tr>";
  }
  }

//submit buttons, end of table
$output.="
  <tr>
  <td></td>
  <td><input type='submit' value='".$submit."' />".$codenexttosubmit."</td>
  </tr>

</table>
</form>";

return $output;
}

?>