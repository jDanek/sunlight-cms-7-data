<?php

/*---- main initialization ----*/

  //init
  
    //timezone
    if(!ini_get("safe_mode") and function_exists("putenv")){@putenv('TZ=Europe/Prague');}
    setlocale(LC_TIME, "czech");
  
    //header
    if(!defined('_tmp_customheader')){$header="Content-Type: text/html; charset=utf-8";}
    else{$header=_tmp_customheader;}
    header($header);
  
  define('_coreroot', _indexroot.'core/');
  if(!defined('_administration')){define('_administration', 0);}
  mb_internal_encoding("UTF-8");
  //error_reporting(E_ALL);

  //mysql server access data
  require(_indexroot."access.php");
  define('_mysql_prefix', $prefix);
  define('_mysql_db', $database);
  
  //constants and vars
  define('_systemversion', '7.2.1');
  define('_sessionprefix', md5($server.$database.$user.$prefix)."-");
  define('_linksuffix', '.html');
  define('_userip', $_SERVER['REMOTE_ADDR']);
  define('_core', '1');
  $_shid_total=0;


/*---- require core functions ----*/

$require_array=array(
"mysqlConnect",
"initSession",
"systemFailure",
"checkVersion",

"indexOutput",
"adminOutput",
"sectionOutput",
"categoryOutput",
"bookOutput",
"linkOutput",
"galleryOutput",
"intersectionOutput",
"articleOutput",
"articleOutputPreview",
"formOutput",
"commentsOutput",

"linkRoot",
"linkArticle",
"linkUser",
"linkRSS",

"parseHCM",
"parsePost",
"evalBox",
"requireBox",

"templateHead",
"templateContent",
"templateMenu",
"templateLinks",
"templateUserMenu",
"templateTitle",
"templateBoxes",

"uniForm",
"formMessage",
"jsCheckForm",
"jsLimitLength",
"resultPaging",
"resultPagingGetItemPage",
"getNewID",
"restoreValue",
"restoreValueByGet",
"addRestoreGetList",
"mailto",
"slcEncode",
"slcDecode",
"captchaCheck",
"captchaInit",
"getPostformControls",
"savePostdata",

"formatTime",
"wsTrim",
"addGetToLink",
"eventList",
"arrayRemoveKey",
"arrayRemoveValue",
"arrayDefineKeys",
"arraySplitFromKey",
"parsePath",
"boolean",
"removeSlashesFromEnd",

"deleteUser",

"currentScript",
"returnHeader",

"inputDisable",
"checkboxActivate",
"checkboxLoad",
"condReturn",
"isAbsolutePath",

"anchorStr",
"safeStr",
"htmlStr",
"htmlStrUndo",
"cutStr",
"booleanStr",

"levelCheck",
"publicAccess",
"postAccess",
"removePHP",

"validateEmail",
"validateURL",

"iplogCheck",
"iplogUpdate",

"sqlArticleWhereCategories"
);

  //cycle
  foreach($require_array as $require_item){
  require(_coreroot.$require_item.".php");
  }


/*---- connect to mysql server ----*/
$_connection=_mysqlConnect($server, $user, $password, $database);


/*---- define settings constants ----*/
$query=mysql_query("SELECT * FROM `"._mysql_prefix."-settings`");
if(mysql_error()!=null){_systemFailure("Připojení k databázi proběhlo úspěšně, ale dotaz na databázi selhal. Zkontrolujte, zda je databáze správně nainstalovaná.");}
while($item=mysql_fetch_array($query)){

  switch($item['var']){
  case "template": if(!@file_exists(_indexroot."templates/".$item['val']."/index.php") or !@file_exists(_indexroot."templates/".$item['val']."/config.php")){$item['val']="default";} break;
  case "modrewrite": if(!@file_exists(_indexroot.".htaccess")){$item['val']=0;} break;
  case "wysiwyg": if(!@file_exists(_indexroot."admin/modules/tinymce.slam")){$item['val']=0;} break;
  }

define('_'.$item['var'], $item['val']);
}

  //init session
  _initSession();

  //language
  
    //apply custom language settings
    if(_loginindicator and _language_allowcustom and _loginlanguage!=""){$language=_loginlanguage;}
    else{$language=_language;}
  
  $_lang=array();
  $langfile=_coreroot."../languages/".$language.".php";
  $langfile_default=_coreroot."../languages/default.php";
  
    if(@file_exists($langfile)){
      require($langfile);
    }
    else{
      if(@file_exists($langfile_default)){require($langfile_default);}
      else{_systemFailure("Zvolený ani přednastavený jazykový soubor nebyl nalezen.");}
    }
    
      //check language file version
      if(!_checkVersion("language_file", $_lang['main.version'])){
      @mysql_query("UPDATE `"._mysql_prefix."-settings` SET val='default' WHERE var='language'");
      _systemFailure("Zvolený jazykový soubor není kompatibilní s verzí systému.");
      }

  //template
  $template=_coreroot."../templates/"._template."/config.php";
  $template_config=_coreroot."../templates/"._template."/index.php";

    if(!@file_exists($template) or !@file_exists($template_config)){
    _systemFailure("Nastavený ani přednastavený motiv <em>default</em> nebyl nalezen.");
    }

  require(_coreroot."../templates/"._template."/config.php");

    //check template version
    if(!_checkVersion("template", _template_version) and !_administration){
    _systemFailure("Zvolený motiv není kompatibilní s verzí systému.");
    }


/*---- check install directory and patch.php ----*/
if(@file_exists(_indexroot."install") and @is_dir(_indexroot."install")){
_systemFailure("Na serveru se stále nachází adresář <em>install</em>, který obsahuje skripty k instalaci databáze. Smažte jej, pokud je databáze již nainstalovaná.");
}

if(@file_exists(_indexroot."patch.php")){
_systemFailure("Na serveru se stále nachází soubor <em>patch.php</em>. Smažte jej, pokud je databáze již aktualizovaná.");
}


/*---- check banned ----*/
if(!_administration){
  if(_banned!=""){
  $banned=explode("\n", _banned);
    foreach($banned as $item){
    if(mb_substr(_userip, 0, mb_strlen($item))==$item){exit;}
    }
  }
}


/*---- access data and iplog cleanup ----*/
unset($server, $user, $password, $database, $prefix);
mysql_query("DELETE FROM `"._mysql_prefix."-iplog` WHERE (type=1 AND ".time()."-time>"._maxloginexpire.") OR (type=2 AND ".time()."-time>"._artreadexpire.") OR (type=3 AND ".time()."-time>"._artrateexpire.") OR (type=4 AND ".time()."-time>"._pollvoteexpire.") OR (type=5 AND ".time()."-time>"._postsendexpire.")");


?>