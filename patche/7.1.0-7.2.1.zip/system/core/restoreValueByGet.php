<?php

/*---- restore value of input from get array ----*/

function _restoreValueByGet($name, $else=null){
if(isset($_GET['_formData'][$name])){return " value='"._htmlStr($_GET['_formData'][$name])."'";}
else{if($else!=null){return " value='"._htmlStr($else)."'";}}
}

?>