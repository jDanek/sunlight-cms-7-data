<?php

/*---- remove unnecessary whitespace from string ----*/

function _wsTrim($string){
return preg_replace("|  +|", " ", preg_replace("|(\r\n){3,}|", "\r\n\r\n", trim($string)));
}

?>