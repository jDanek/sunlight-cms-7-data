<?php

/*---- paging ----*/

function _resultPaging($url, $limit, $table, $conditions="1", $linksuffix="", $param="s"){
global $_lang;

//init params
$count=mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-".$table."` WHERE ".$conditions), 0);
if($count==0){$count=1;}
if(isset($_GET[$param])){$s=abs(intval($_GET[$param])-1);}else{$s=0;}
$pages=ceil($count/$limit);
if($s+1>$pages){$s=0;}
$start=$s*$limit;
$beginpage=$s+1-_showpages; if($beginpage<1){$endbonus=abs($beginpage)+1; $beginpage=1;}else{$endbonus=0;}
$endpage=$s+1+_showpages+$endbonus; if($endpage>$pages){$beginpage-=$endpage-$pages; if($beginpage<1){$beginpage=1;} $endpage=$pages;}

//list of pages

  //separate symbol in url
  if(mb_substr_count($url, "?")==0){$url.="?";}
  else{$url.="&amp;";}

$paging="<span>";
for($x=$beginpage; $x<=$endpage; $x++){
if($x==$s+1){$class=" class='act'";}else{$class="";}
$paging.="<a href='".$url.$param."=".$x.$linksuffix."'".$class.">".$x."</a>";
if($x!=$endpage){$paging.=" ";}
}
$paging.="</span>";

  //controls

    //minus
    if($s+1!=1){$paging="<a href='".$url.$param."=".($s).$linksuffix."'>&laquo; ".$_lang['global.previous']."</a>&nbsp;&nbsp;".$paging;}
    if($beginpage>1){$paging="<a href='".$url.$param."=1".$linksuffix."' title='".$_lang['global.first']."'>1</a> ... ".$paging;}

    //plus
    if($s+1!=$pages){$paging.="&nbsp;&nbsp;<a href='".$url.$param."=".($s+2).$linksuffix."'>".$_lang['global.next']." &raquo;</a>";}
    if($endpage<$pages){$paging.=" ... <a href='".$url.$param."=".$pages.$linksuffix."' title='".$_lang['global.last']."'>".$pages."</a>";}

$paging="<div class='paging'>".$_lang['global.paging'].":&nbsp;&nbsp;".$paging."</div>";

//return
return array($paging, "LIMIT ".$start.", ".$limit, $s+1, $pages);

}

?>