<?php

/*---- require php file inside function ----*/

function _requireBox($_file, $_params=array()){
$output=null;
require($_file);
return $output;
}


?>