<?php

/*---- create and return xhtml page structure ----*/

function _indexOutput(){
global $_lang;

/*-- module --*/
if(isset($_GET['m'])){


  switch($_GET['m']){
  
  //login
  case "login":
  define('_indexOutput_url', "index.php?m=login");
  $module=_uniForm("login", array('return'=>'mod', 'returnpath'=>null));
  define('_indexOutput_content', $module[0]);
  define('_indexOutput_title', $module[1]);
  break;
  
  //ulist
  case "ulist":
  if(_ulist and (!_notpublicsite or _loginindicator)){
    define('_indexOutput_url', "index.php?m=ulist");
    require(_indexroot."require/ulist.php");
    define('_indexOutput_content', $module);
    define('_indexOutput_title', $_lang['admin.users.list']);
  }
  break;
  
  //reg
  case "reg":
  if(_registration and !_loginindicator){
    define('_indexOutput_url', "index.php?m=reg");
    require(_indexroot."require/reg.php");
    define('_indexOutput_content', $module);
    define('_indexOutput_title', $_lang['mod.reg']);
  }
  break;
  
  //lostpass
  case "lostpass":
  if(_lostpass and !_loginindicator){
    define('_indexOutput_url', "index.php?m=lostpass");
    require(_indexroot."require/lostpass.php");
    define('_indexOutput_content', $module);
    define('_indexOutput_title', $_lang['mod.lostpass']);
  }
  break;

  //profile
  case "profile":
  if(!_notpublicsite or _loginindicator){
    define('_indexOutput_url', "index.php?m=profile");
    require(_indexroot."require/profile.php");
    define('_indexOutput_content', $module);
    define('_indexOutput_title', $_lang['mod.profile']);
  }
  break;
  
  //settings
  case "settings":
  if(_loginindicator){
    define('_indexOutput_url', "index.php?m=settings");
    require(_indexroot."require/settings.php");
    define('_indexOutput_content', $module);
    define('_indexOutput_title', $_lang['mod.settings']);
  }
  break;
  
  //editpost
  case "editpost":
  if(_loginindicator){
    define('_indexOutput_url', "index.php?m=editpost");
    require(_indexroot."require/editpost.php");
    define('_indexOutput_content', $module);
    define('_indexOutput_title', $_lang['mod.editpost']);
  }
  break;
  
  //messages
  case "messages":
  if(_loginindicator and _messages){
    define('_indexOutput_url', "index.php?m=messages");
    require(_indexroot."require/messages.php");
    define('_indexOutput_content', $module);
    define('_indexOutput_title', $_lang['mod.messages']);
  }
  break;
  
  //search
  case "search":
  if(_search){
    define('_indexOutput_url', "index.php?m=search");
    require(_indexroot."require/search.php");
    define('_indexOutput_content', $module);
    define('_indexOutput_title', $_lang['mod.search']);
  }
  break;
  
  }


}
else{


  /*-- content --*/
  if(isset($_GET['a'])){
  $a=intval($_GET['a']);

  

    //article
    if(mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-articles` WHERE id=".$a." AND (confirmed=1 OR "._loginright_adminconfirm."=1 OR "._loginright_adminallart."=1) AND (time<=".time()." OR author="._loginid." OR "._loginright_adminconfirm."=1 OR "._loginright_adminallart."=1)"), 0)!=0){
    define('_indexOutput_url', _linkArticle($a));

      if(!_notpublicsite or _loginindicator){
      $article=_articleOutput($a);
      define('_indexOutput_content', $article[0]);
      define('_indexOutput_title', $article[1]);
      }
      else{
      $form=_uniForm("notpublic", array("notpublicsite"=>true));
      define('_indexOutput_content', $form[0]);
      define('_indexOutput_title', $form[1]);
      }
      
    }
    
  }
  else{


    //load get variable or main page
    $continue=true;
    if(isset($_GET['p'])){
    $pid=intval($_GET['p']);
    }
    else{
    $query=mysql_query("SELECT id FROM `"._mysql_prefix."-root` WHERE intersection=-1 AND type!=4 ORDER BY ord LIMIT 1");
      if(mysql_num_rows($query)!=0){
      $query=mysql_fetch_array($query);
      $pid=$query['id'];
      }
      else{
      $continue=false;
      }
    }

    //load page
    if($continue){

      $query=mysql_query("SELECT type,public,visible,intersection FROM `"._mysql_prefix."-root` WHERE id=".$pid);
      if(mysql_num_rows($query)!=0){
      
        $query=mysql_fetch_array($query);
        define('_indexOutput_url', _linkRoot($pid));

          //intersection return link
          $backlink="";
          if($query['intersection']!=-1 and $query['visible']==1){
            $backlink="<a href='"._linkRoot($query['intersection'])."' class='backlink'>&lt; ".$_lang['global.return']."</a>";
          }
          
          //inherited public param (from intersection)
          if($query['intersection']!=-1){
            $intersection_public=mysql_fetch_array(mysql_query("SELECT public FROM `"._mysql_prefix."-root` WHERE id=".$query['intersection']));
            $intersection_public=$intersection_public['public'];
          }
          else{
            $intersection_public=1;
          }
          

          //content
          if(_publicAccess($query['public']) and _publicAccess($intersection_public) and _publicAccess(!_notpublicsite)){
            switch($query['type']){
            case 1: $content=_sectionOutput($pid); break;
            case 2: $content=_categoryOutput($pid); break;
            case 3: $content=_bookOutput($pid); break;
            case 5: $content=_galleryOutput($pid); break;
            case 6: $content=_linkOutput($pid); break;
            case 7: $content=_intersectionOutput($pid); break;
            }
          }
          else{
            $form=_uniForm("notpublic", array("notpublicsite"=>_notpublicsite));
            $content=array($form[0], $form[1]);
          }

        define('_indexOutput_content', $backlink.$content[0]);
        define('_indexOutput_title', $content[1]);
      
      }

    }
    else{
    define('_indexOutput_content', _condReturn(_template_autoheadings, "<h1>".$_lang['global.error404.title']."</h1>")._formMessage(2, $_lang['global.nokit']));
    define('_indexOutput_title', $_lang['global.error404.title']);
    }


  }


}

/*-- error 404 --*/
if(!defined('_indexOutput_content')){
define('_indexOutput_content', _condReturn(_template_autoheadings, "<h1>".$_lang['global.error404.title']."</h1>")._formMessage(2, $_lang['global.error404']));
define('_indexOutput_title', $_lang['global.error404.title']);
}

/*-- define pid, url and insert template --*/
if(!defined('_tmp_redirect')){
  if(!isset($pid)){$pid=-1;}
  define('_indexOutput_pid', $pid);
  if(!defined('_indexOutput_url')){define('_indexOutput_url', '');}
  require(_coreroot."../templates/"._template."/index.php");
}
else{
header("location: "._tmp_redirect); exit;
}

}

?>