<?php

/*---- iplog check ----*/

function _iplogCheck($type, $var=null){
$return=true;
$querybasic="SELECT * FROM `"._mysql_prefix."-iplog` WHERE ip='"._userip."' AND type=".$type;

  switch($type){
  
    //login
    case 1:
    $query=mysql_query($querybasic);
    if(mysql_num_rows($query)!=0){
      $query=mysql_fetch_array($query);
      if($query['var']>=_maxloginattempts){$return=false;}
    }
    break;
    
    //artread, artrate, pollvote
    case 2: case 3: case 4:
    $query=mysql_query($querybasic." AND var=".$var);
    if(mysql_num_rows($query)!=0){$return=false;}
    break;
    
    //postsend
    case 5:
    $query=mysql_query($querybasic);
    if(mysql_num_rows($query)!=0){$return=false;}
    break;


  }

return $return;
}

?>