<?php

/*---- define unset keys in array ----*/

function _arrayDefineKeys($array, $keys){
if(is_array($array)){
  foreach($keys as $key=>$value){
    if(!isset($array[$key])){$array[$key]=$value;}
  }
return $array;
}
else{return array();}
}

?>