<?php

/*---- preview article ----*/

function _articleOutputPreview($art, $info=true, $perex=true){
global $_lang;

  //title
  $output="<h2 class='list-title'><a href='"._linkArticle($art['id'])."'>".$art['title']."</a></h2>";

  //perex
  if($perex==true){
  $output.="<p class='list-perex'>".$art['perex']."</p>";
  }
  
  //info
  if($info==true){
  
      //comments
      if($art['comments']==1 and _comments){
      $info_comments=_template_listinfoseparator."<span>".$_lang['article.comments'].":</span> ".mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-posts` WHERE home=".$art['id']." AND type=2"), 0);
      }
      else{
      $info_comments="";
      }
  
  $output.="
  <div class='list-info'>
  <span>".$_lang['article.author'].":</span> "._linkUser($art['author'], null, true)._template_listinfoseparator.
  "<span>".$_lang['article.posted'].":</span> "._formatTime($art['time'])._template_listinfoseparator.
  "<span>".$_lang['article.readed'].":</span> ".$art['readed']."x".
  $info_comments.
  "</div>\n";
  }

return $output;
}

?>