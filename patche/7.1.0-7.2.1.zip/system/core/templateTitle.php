<?php

/*---- print title of current page ----*/

function _templateTitle(){
echo _indexOutput_title;
}

?>