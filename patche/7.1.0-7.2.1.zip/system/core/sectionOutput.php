<?php

/*---- return section output ----*/

function _sectionOutput($id){
global $_lang;


$query=mysql_fetch_array(mysql_query("SELECT * FROM `"._mysql_prefix."-root` WHERE id=".$id));
$content=_parseHCM($query['content']);
$title=$query['title'];
if($query['var1']==1 and _comments){$content.=_commentsOutput(1, $id);}


return array($content, $title);
}

?>