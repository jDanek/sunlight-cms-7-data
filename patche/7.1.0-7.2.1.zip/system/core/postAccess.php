<?php

/*---- return if current user is allowed to edit or remove post ----*/

function _postAccess($post){

  //load data
  if($post['author']!=-1){
  $author=mysql_fetch_array(mysql_query("SELECT id,`group` FROM `"._mysql_prefix."-users` WHERE id=".$post['author']));
  $level=mysql_fetch_array(mysql_query("SELECT level FROM `"._mysql_prefix."-groups` WHERE id=".$author['group']));
  $level=$level['level'];
  }
  else{
  $level=0;
  }
  
  //return
  if(_loginindicator and (_loginright_level>$level or _loginid==$author['id']) and ($post['time']+_postadmintime>time() or _loginright_unlimitedpostaccess)){return true;}
  else{return false;}


}

?>