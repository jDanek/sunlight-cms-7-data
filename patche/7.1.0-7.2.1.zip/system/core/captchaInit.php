<?php

/*---- init captcha ----*/

function _captchaInit(){

if(_captcha and !_loginindicator){
  global $_lang;
  $key="";
    for($i=0; $i<=4; $i++){
    if(mt_rand(0,1)>0.5){$key.=mt_rand(0,9);}
    else{$key.=chr(mt_rand(65,90));}
    }
  $key=str_replace("O", "0", $key);
  $key=_slcEncode($key);
  return array("<input type='hidden' name='_cpk' value='".$key."' />", array($_lang['captcha.input'], "<input type='text' name='_cp' class='inputc' />&nbsp;<img src='"._indexroot."remote/cimage.php?cpk=".$key."' alt='img' title='".$_lang['captcha.help']."' class='cimage' />"));
}
else{
  return array("", array("", ""));
}

}

?>