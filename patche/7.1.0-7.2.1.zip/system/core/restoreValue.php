<?php

/*---- restore post value of input ----*/

function _restoreValue($name, $else=null, $noautoparam=false){

if(!$noautoparam){$autoparam_start=" value='"; $autoparam_end="'";}
else{$autoparam_start=""; $autoparam_end="";}

if(isset($_POST[$name])){return $autoparam_start._htmlStr($_POST[$name]).$autoparam_end;}
else{if($else!=null){return $autoparam_start._htmlStr($else).$autoparam_end;}}

}

?>