<?php

/*---- restore replaced disallowed symbols ----*/

function _htmlStrUndo($input, $double=false){
$output=str_replace(array("&lt;", "&gt;", "&quot;", "&#39;", "&amp;"), array("<", ">", "\"", "'", "&"), $input);
if($double){$output=_htmlStrUndo($output);}
return $output;
}

?>