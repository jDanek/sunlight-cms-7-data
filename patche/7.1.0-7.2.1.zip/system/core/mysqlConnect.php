<?php

/*---- establish connection with mysql server ----*/

function _mysqlConnect($server, $user, $password, $database){

  //try to connect
  $con=@mysql_connect($server, $user, $password);
  $db=@mysql_select_db($database);
  
  //check and return
  if(!$con or !$db){
  _systemFailure("Připojení k databázi se nezdařilo. Důvodem je pravděpodobně výpadek serveru nebo chybné přístupové údaje.<hr />\n<pre>".mysql_error()."</pre>");
  }
  else{
  mysql_query("SET NAMES `utf8`");
  return $con;
  }

}

?>