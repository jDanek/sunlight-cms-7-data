<?php

/*---- url to user profile ----*/

function _linkUser($id, $class=null, $noicon=false, $onlyname=false, $namelengthlimit=false){

if($class!=null){$class=" class='".$class."'";}

  //load data
  $userdata=mysql_fetch_array(mysql_query("SELECT username,`group` FROM `"._mysql_prefix."-users` WHERE id=".$id));
  
  if($onlyname==false){
    $groupdata=mysql_fetch_array(mysql_query("SELECT icon FROM `"._mysql_prefix."-groups` WHERE id=".$userdata['group']));

    //icon code
    if($noicon==false){
    $icon=_condReturn($groupdata['icon']!="", "<img src='"._indexroot."usericons/".$groupdata['icon']."' alt='icon' class='icon' /> ");
    }
    else{
    $icon="";
    }

    //link code
    if($namelengthlimit!=false){$username_anchor=_cutStr($userdata['username'], $namelengthlimit, false);}
    else{$username_anchor=$userdata['username'];}
    $link="<a href='"._indexroot."index.php?m=profile&amp;id=".$userdata['username']."'".$class.">".$username_anchor."</a>";
  }
  else{
  $icon=""; $link=$userdata['username'];
  }

return $icon.$link;
}

?>