<?php

/*---- add get variable to link ----*/

function _addGetToLink($link, $params){

  //separate symbol in url
  if(mb_substr_count($link, "?")==0){$link.="?";}
  else{$link.="&amp;";}

return $link.$params;
}

?>