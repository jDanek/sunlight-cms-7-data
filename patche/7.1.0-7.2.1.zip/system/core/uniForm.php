<?php


/*---- return module output ----*/

function _uniForm($id, $vars=array(), $notitle=false){

//init
global $_lang;
$content="";
$title="";

//list
switch($id){


  /*--- login (return{admin,mod,-1},returnpath) ---*/
  case "login":
  
    //title
    $title=$_lang['login.title'];
  
    //message
    if(isset($_GET['r'])){
      switch($_GET['r']){
      case 0: $content.=_formMessage(2, $_lang['login.failure']); break;
      case 1: if(_loginindicator and !_administration){$content.=_formMessage(1, $_lang['login.success']);} break;
      case 2: if(!_loginindicator){$content.=_formMessage(2, $_lang['login.blocked.message']);} break;
      case 3: if(!_loginindicator){$content.=_formMessage(3, $_lang['login.securitylogout']);} break;
      case 4: if(!_loginindicator){$content.=_formMessage(1, $_lang['login.selfremove']);} break;
      case 5: if(!_loginindicator){$content.=_formMessage(2, str_replace(array("*1*", "*2*"), array(_maxloginattempts, _maxloginexpire/60), $_lang['login.attemptlimit']));} break;
      }
    }

    //content
    if(!_loginindicator){
    
      //fields and checks
      $redirparam="<input type='hidden' name='redir' value='".$vars['return']."' />";

      //make form code
      $content.=_formOutput(
      "login_form",
      _indexroot."remote/login.php"._condReturn($vars['return']!="admin" and $vars['return']!="mod", "?_return=".urlencode($vars['returnpath'])),
      array(
        array($_lang['login.username'], "<input type='text' name='username' class='inputsmall'"._restoreValueByGet("username")." maxlength='24' />".$redirparam),
        array($_lang['login.password'], "<input type='password' name='password' class='inputsmall' />")
      ),
      array("username", "password"),
      $_lang['global.login']
      );
      
        //links
        if(!_administration and (_registration or _lostpass)){
        $content.="<p>".
        _condReturn(_registration, "<a href='index.php?m=reg'>".$_lang['mod.reg']." &gt;</a>").
        _condReturn(_lostpass, _condReturn(_registration, "<br />")."<a href='index.php?m=lostpass'>".$_lang['mod.lostpass']." &gt;</a>").
        "</p>";
        }

    }
    else{
    $content.="<p>".$_lang['login.ininfo']." "._loginname." - <a href='"._indexroot."remote/logout.php'>".$_lang['usermenu.logout']."</a>.</p>";
    }
  
  break;
  
  
  /*--- notpublic message ---*/
  case "notpublic":
  $form=_uniForm("login", array('return'=>-1, 'returnpath'=>urlencode(_indexOutput_url)), true);
  if(!isset($vars['notpublicsite'])){$vars['notpublicsite']=false;}
  $content="<p>"._condReturn($vars['notpublicsite']!=true, $_lang['notpublic.p'], $_lang['notpublic.p2'])."</p>".$form[0];
  $title=$_lang['notpublic.title'];
  break;
  
  
  /*--- post form (posttype,posttarget,xhome) ---*/
  case "postform":
  $title="";
  $notitle=true;

  //inputs
  $inputs=array();
  $captcha=_captchaInit();
  $content=_jsLimitLength(3072, "postform", "text");
    if(_loginindicator==0){$inputs[]=array($_lang['posts.guestname'], "<input type='text' name='guest' class='inputsmall' />");}
    if($vars['xhome']==-1){$inputs[]=array($_lang['posts.subject'], "<input type='text' name='subject' class='inputsmall' maxlength='22' />");}
    $inputs[]=$captcha[1];
    $inputs[]=array($_lang['posts.text'], "<textarea name='text' class='areamedium' rows='5' cols='33'></textarea><input type='hidden' name='_posttype' value='".$vars['posttype']."' /><input type='hidden' name='_posttarget' value='".$vars['posttarget']."' /><input type='hidden' name='_xhome' value='".$vars['xhome']."' />".$captcha[0], true);

  //formoutput
  $content.=_formOutput('postform', _addGetToLink(_indexroot."remote/post.php", "_return=".urlencode(_indexOutput_url)."#posts"), $inputs, array("text"), null, _getPostformControls("postform", "text"));

  break;


}
  
//return
if((_template_autoheadings==1 or _administration==1) and $notitle==false){$content="<h1>$title</h1>".$content;}
return array($content, $title);

}

?>