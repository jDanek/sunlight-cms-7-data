<?php

/*---- return formatted timestamp ----*/

function _formatTime($timestamp){
$output=getdate($timestamp);
if(strlen($output['hours'])==1){$output['hours']="0".$output['hours'];}
if(strlen($output['minutes'])==1){$output['minutes']="0".$output['minutes'];}
$output=$output['mday'].".".$output['mon'].". ".$output['year']." ".$output['hours'].":".$output['minutes'];
return $output;
}

?>