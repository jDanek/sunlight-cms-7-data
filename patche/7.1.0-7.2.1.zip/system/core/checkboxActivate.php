<?php

/*---- checked param for checkboxes ----*/

function _checkboxActivate($input){
if($input==1){return " checked='checked'";}
}

?>