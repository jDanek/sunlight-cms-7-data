<?php

/*---- return with regard to given condition ----*/

function _condReturn($cond, $input, $elseinput=null){
if($cond==true){return $input;}
else{if($elseinput!=null){return $elseinput;}}
}

?>