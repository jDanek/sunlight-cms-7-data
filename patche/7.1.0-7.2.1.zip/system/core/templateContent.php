<?php

/*---- print content ----*/

function _templateContent(){
echo _indexOutput_content;
}

?>