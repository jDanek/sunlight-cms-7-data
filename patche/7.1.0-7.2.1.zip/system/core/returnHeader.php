<?php

/*---- return to previous page ----*/

function _returnHeader(){

  //send header
  if(isset($_GET['_return']) and $_GET['_return']!=""){
  $_GET['_return']=urldecode($_GET['_return']);
  if(preg_match("|^index.php\?m=(.*)|", $_GET['_return'])){$_GET['_return']="";}
  header("location: "._indexroot.$_GET['_return']); exit;
  }
  else{
  if(isset($_SERVER['HTTP_REFERER']) and $_SERVER['HTTP_REFERER']!=""){header("location: ".$_SERVER['HTTP_REFERER']); exit;}
  else{header("location: "._indexroot); exit;}
  }

}

?>