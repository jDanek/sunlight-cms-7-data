<?php


/*---- return gallery output ----*/

function _galleryOutput($id){
global $_lang;


$query=mysql_fetch_array(mysql_query("SELECT * FROM `"._mysql_prefix."-root` WHERE id=".$id));

//title, text
$content="";
if(_template_autoheadings){
$content.="<h1>".$query['title']."</h1>"._parseHCM($query['content'])."<div class='hr'><hr /></div>";
}
else{
  if($query['content']!=""){
  $content.=_parseHCM($query['content'])."<div class='hr'><hr /></div>";
  }
}

//images
$paging=_resultPaging(_indexOutput_url, $query['var2'], "images", "home=".$id);
$images=mysql_query("SELECT * FROM `"._mysql_prefix."-images` WHERE home=".$id." ORDER BY ord ".$paging[1]);

  if(mysql_num_rows($images)!=0){

    $usetable=$query['var1']!=-1;
    if($paging[3]>1){$content.=$paging[0];}
    if($usetable){$content.="<table class='gallery'>";}else{$content.="<div class='gallery'>";}

    //cycle trough images
    $counter=0;
    while($img=mysql_fetch_array($images)){
      if($counter==0 and $usetable){$content.="<tr>";}

        //cell
        if($usetable){$content.="<td>";}
        $content.="<a href='"._condReturn(!_isAbsolutePath($img['prev']), _indexroot).$img['full']."' target='_blank' rel='lightbox[".$id."]'"._condReturn($img['title']!="", " title='".$img['title']."'").">";
          if($img['prev']!="*auto*"){
          $content.="<img src='"._condReturn(!_isAbsolutePath($img['prev']), _indexroot).$img['prev']."' alt='preview' />";
          }
          else{
          $content.="<img src='"._indexroot."remote/imgprev.php?id=".$img['id']."' alt='prev' />";
          }
        $content.="</a>";
        if($usetable){$content.="</td>";}

      $counter++;
      if($counter==$query['var1'] and $usetable){$counter=0; $content.="</tr>\n";}
    }

    if($usetable){$content.="</table>";}else{$content.="</div>";}
    if(_pagingmode==2 and $paging[3]>1){$content.=$paging[0];}

  }
  else{
  $content.=$_lang['gallery.noimages'];
  }

$title=$query['title'];
  

return array($content, $title);
}

?>