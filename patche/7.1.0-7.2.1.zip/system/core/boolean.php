<?php

/*---- return boolean value of given number ----*/

function _boolean($input){
if($input==1){return true;}else{return false;}
}

?>