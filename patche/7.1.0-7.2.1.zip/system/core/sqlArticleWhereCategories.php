<?php

/*---- return sql code for finding articles in particular categories (input=list of categories' IDs separated by "-") ----*/

function _sqlArticleWhereCategories($ids){
  if($ids!=null){
    $ids=_arrayRemoveValue(@explode("-", $ids), null);
    $sql_code="(";
    $sql_count=count($ids);
    $counter=1;
      foreach($ids as $rcat){
      $sql_code.="(home1=".$rcat." OR home2=".$rcat." OR home3=".$rcat.")";
      if($counter!=$sql_count){$sql_code.=" OR ";}
      $counter++;
      }
    $sql_code.=")";
    return $sql_code;
  }
  else{
    return null;
  }
}

?>