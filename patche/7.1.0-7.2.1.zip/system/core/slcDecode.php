<?php

/*---- decode string ----*/

function _slcDecode($string){
$output="";

//decompress-level
$string=@gzinflate(@base64_decode(@strrev($string)));

//denum-level
$nums=explode(".", $string);
$x=0;
foreach($nums as $char){
$output.=chr($char-$x);
$x++;
}

//return
return $output;
}

?>