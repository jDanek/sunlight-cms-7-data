<?php

/*---- get page of item ----*/

function _resultPagingGetItemPage($limit, $table, $conditions="1"){
$count=mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-".$table."` WHERE ".$conditions), 0);
return intval($count/$limit)+1;
}

?>