<?php

/*---- get smileys and bbcode buttons ----*/

function _getPostformControls($form, $area){
$output="";

  //bbcode
  if(_bbcode and _template_bbcode_buttons){
  $bbcode_array=array("b", "i", "img", "code");
    foreach($bbcode_array as $item){
    $output.="<a href=\"#\" onclick=\"return _sysaddbbcode('".$form."','".$area."','".$item."');\"><img src=\""._indexroot."/templates/"._template."/images/bbcode/".$item.".gif\" alt=\"".$item."\" /></a> ";
    }
  }

  //smileys
  if(_smileys){
  if(_bbcode){$output.="&nbsp;&nbsp;";}
    for($x=1; $x<=10; $x++){
    $output.="<a href=\"#\" onclick=\"return _sysaddsmiley('".$form."','".$area."',".$x.");\"><img src=\""._indexroot."/templates/"._template."/images/smileys/".$x.".gif\" alt=\"".$x."\" /></a> ";
    }
  }
  
return "<span class='posts-form-buttons'>".trim($output)."</span>";
}

?>