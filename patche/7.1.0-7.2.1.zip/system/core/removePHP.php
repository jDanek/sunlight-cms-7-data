<?php

/*---- remove HCM PHP module from string if not allowed ----*/

function _removePHP($content){
if(!_loginright_adminhcmphp){return preg_replace("|(.*)\[hcm\]php(.*)|ix", '$1$2', $content);}
else{return $content;}
}

?>