<?php

/*---- link for sending email ----*/

function _mailto($email){
$email=str_replace("@", _atreplace, $email);
return "<a href='#' onclick='return _sysmai_lto(this);'>".$email."</a>";
}

?>