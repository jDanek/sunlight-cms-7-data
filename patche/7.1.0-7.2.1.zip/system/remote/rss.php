<?php

/*--- core ---*/
define('_indexroot', '../');
define('_tmp_customheader', 'Content-Type: application/xml; charset=UTF-8');
require(_indexroot."core/_core.php");
if(!_rss){exit;}

/*--- init vars ---*/
$continue=false;
if(isset($_GET['tp']) and isset($_GET['id'])){
$type=intval($_GET['tp']);
$id=intval($_GET['id']);

  //public clause
  if(!_loginindicator){if(!_notpublicsite){$public=" AND public=1";}else{exit;}}
  else{$public="";}

  //check source
  $donottestsource=false;
  $homelimit=" home=".$id;
  switch($type){

    //section comments and book posts
    case 1: case 3:
    $query=mysql_query("SELECT title FROM `"._mysql_prefix."-root` WHERE type=".$type._condReturn($type==1, " AND var1=1").$public." AND id=".$id);
    $feedtitle=_condReturn($type==1, $_lang['rss.recentcomments'], $_lang['rss.recentposts']);
    $typelimit=" AND type=".$type;
    break;
    
    //article comments
    case 2:
    $query=mysql_query("SELECT title FROM `"._mysql_prefix."-articles` WHERE id=".$id." AND comments=1".$public);
    $feedtitle=$_lang['rss.recentcomments'];
    $typelimit=" AND type=2";
    break;
    
    //recent articles
    case 4:
    
      if($id!=-1){
      $query=mysql_query("SELECT title FROM `"._mysql_prefix."-root` WHERE type=2".$public." AND id=".$id);
      $catlimit="(home1=".$id." OR home2=".$id." OR home3=".$id.") AND ";
      }
      else{
      $donottestsource=true;
      $query=array("title"=>null);
      $catlimit="";
      }
    
    $feedtitle=$_lang['rss.recentarticles'];
    break;
    
    //recent posts
    case 5:
    $donottestsource=true;
    $query=array("title"=>null);
    $feedtitle=$_lang['rss.recentposts'];
    $typelimit="";
    $homelimit="1";
    break;

  }
  
  //load items, continue state
  if($donottestsource or mysql_num_rows($query)!=0){
  $feeditems=array();
  if(!$donottestsource){$query=mysql_fetch_array($query);}
  $pagetitle=$query['title'];
  
    switch($type){

      //comments (in sections, articles, etc...)
      case 1: case 2: case 3: case 5:
      $items=mysql_query("SELECT subject,time,author,guest,text,type,home FROM `"._mysql_prefix."-posts` WHERE ".$homelimit.$typelimit." ORDER BY id DESC LIMIT ".(_commentsperpage*2));
      $titlebonus="";
        while($item=mysql_fetch_array($items)){
        
            //load author's name
            if($item['author']!=-1){
            $author=_linkUser($item['author'], null, true, true);
            }
            else{
            $author=$item['guest'];
            }

            //load home link
            switch($item['type']){
            case 1: case 3: $homelink=_linkRoot($item['home']); break;
            case 2: $homelink=_linkArticle($item['home']); break;
            }
          
            //load home title (when showing posts from all sources)
            if($typelimit==""){
            switch($item['type']){
            case 1: case 3: $titlebonus=mysql_fetch_array(mysql_query("SELECT title FROM `"._mysql_prefix."-root` WHERE id=".$item['home'])); break;
            case 2: $titlebonus=mysql_fetch_array(mysql_query("SELECT title FROM `"._mysql_prefix."-articles` WHERE id=".$item['home'])); break;
            }
            $titlebonus=" (".$titlebonus['title'].")";
            }
          
          $feeditems[]=array($author.": ".$item['subject'].$titlebonus, $homelink."#posts", _cutStr(strip_tags(_parsePost(_htmlStrUndo($item['text'], true))), 255));
        }
      break;
      
      //recent articles
      case 4:
      $items=mysql_query("SELECT id,title,perex FROM `"._mysql_prefix."-articles` WHERE ".$catlimit."confirmed=1".$public." AND visible=1 AND time<=".time()." ORDER BY time DESC LIMIT 30");
      while($item=mysql_fetch_array($items)){$feeditems[]=array($item['title'], _linkArticle($item['id']), strip_tags(_htmlStrUndo($item['perex'], true)));}
      break;

    }
  
  $continue=true;
  }
  else{
  echo " ";
  }

}

/*--- feed output ---*/


if($continue){
$maintitle=_title.' '._titleseparator._condReturn($pagetitle!=null, ' '.$pagetitle.' '._titleseparator).' '.$feedtitle;
echo '<?xml version="1.0" encoding="utf-8"?'.'>
<rss version="0.91">
  <channel>
    <title>'.$maintitle.'</title>
    <link>'._url.'/</link>
    <description>'._description.'</description>
    <language>'.$_lang['main.languagespecification'].'</language>
    <image>
      <title>'.$maintitle.'</title>
      <url>'._url.'/templates/'._template.'/images/system/rss-logo.gif</url>
      <link>'._url.'/</link>
      <width>60</width>
      <height>60</height>
    </image>
';

  //items
  foreach($feeditems as $feeditem){
  echo '
    <item>
       <title>'.$feeditem[0].'</title>
       <link>'._url.'/'.$feeditem[1].'</link>
       <description>'.$feeditem[2].'</description>
    </item>
  ';
  }

echo '
  </channel>
</rss>
';
}


?>