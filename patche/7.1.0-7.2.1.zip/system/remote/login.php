<?php

/*--- core ---*/
define('_indexroot', '../');
require(_indexroot."core/_core.php");

/*--- login ---*/
$result=0;
$username="";
if(!_loginindicator){

  if(_iplogCheck(1)){

    //post variables
    $username=_safeStr(_anchorStr($_POST['username'], false));
    $password=md5($_POST['password']);

    //find user
    $query=mysql_query("SELECT * FROM `"._mysql_prefix."-users` WHERE username='".$username."'");

      if(mysql_num_rows($query)!=0){

        $query=mysql_fetch_array($query);
        $groupblock=mysql_fetch_array(mysql_query("SELECT blocked FROM `"._mysql_prefix."-groups` WHERE id=".$query['group']));
        if($query['blocked']==0 and $groupblock['blocked']==0){
          if($password==$query['password']){
          $_SESSION[_sessionprefix."user"]=$query['id'];
          $_SESSION[_sessionprefix."password"]=$password;
          $result=1;
          }
          else{
          _iplogUpdate(1);
          }
        }
        else{
        $result=2;
        }

      }

  }
  else{
  $result=5;
  }

}

/*--- header ---*/
if($result!=1 and $_POST['redir']==-1){$_POST['redir']="mod";}
switch($_POST['redir']){

case "admin":
$url=_indexroot."admin/index.php?r=".$result; if($result!=1){$url=_addRestoreGetList($url, array("username"=>$username));} header("location: ".$url); break;

case "mod":
if($result!=1){$url=_indexroot."index.php?m=login&r=".$result;}
else{$url=_indexroot;}
if($result!=1){$url=_addRestoreGetList($url, array("username"=>$username));}
header("location: ".$url);
break;

default:
_returnHeader();
break;

}

?>