<?php

/*--- initialize core ---*/
define('_indexroot', '../');
define('_tmp_customheader', 'Content-type: application/javascript; charset=utf-8');
require(_indexroot."core/_core.php");

?>


//system alert message
function _sysalert(id){

  switch(id){
  case 1: text="<?php echo $_lang['javascript.alert.someempty']; ?>"; break;
  case 2: text="<?php echo $_lang['javascript.alert.toolong']; ?>"; break;
  }

alert(text);
}

//confirm dialog
function _sysconfirm(){
return confirm("<?php echo $_lang['javascript.confirm']; ?>");
}

//replace at symbol
function _sysmai_lto(f) {
	var re = "<?php echo _atreplace; ?>";
	var addr = f.innerHTML.replace(re,'@');
	f.href = 'mai'+'lt'+'o:'+addr;
	return true;
}

//add smiley
function _sysaddsmiley(fid, aid, text){
eval("txtarea=document."+fid+"."+aid+";");
text=" *"+text+"* ";
if (document.all) {
    if (txtarea.createTextRange && txtarea.caretPos) {
      var caretPos = txtarea.caretPos;
      caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ? text+caretPos.text + ' ' : text+caretPos.text;
    }
    else {txtarea.value = txtarea.value + text; }
}
else if (document.getElementById) {
    var selLength = txtarea.textLength;
    var selStart = txtarea.selectionStart;
    var selEnd = txtarea.selectionEnd;
    if (selEnd==1 || selEnd==2) selEnd=selLength;
    var s1 = (txtarea.value).substring(0,selStart);
    var s2 = (txtarea.value).substring(selStart, selEnd)
    var s3 = (txtarea.value).substring(selEnd, selLength);
    txtarea.value = s1 + text + s2 + s3;
    txtarea.selectionStart=selStart+text.length;
    txtarea.selectionEnd=selStart+text.length;
    }

txtarea.focus();
return false;
}

//add bbcode tags
function _sysaddbbcode(fid, aid, text){
eval("txtarea=document."+fid+"."+aid+";");
if (document.all) {
  text="[" + text + "]" + "[/" + text + "]";
    if (txtarea.createTextRange && txtarea.caretPos) {
      var caretPos = txtarea.caretPos;
      caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ? text+caretPos.text + ' ' : text+caretPos.text;
    }
    else {txtarea.value = txtarea.value + text; }
}
else if (document.getElementById) {
    var selLength = txtarea.textLength;
    var selStart = txtarea.selectionStart;
    var selEnd = txtarea.selectionEnd;
    if (selEnd==1 || selEnd==2) selEnd=selLength;
    var s1 = (txtarea.value).substring(0,selStart);
    var s2 = (txtarea.value).substring(selStart, selEnd)
    var s3 = (txtarea.value).substring(selEnd, selLength);
    txtarea.value = s1 + "[" + text + "]" + s2 + "[/" + text + "]" + s3;
    txtarea.selectionStart=selStart+text.length*2+5+s2.length;
    txtarea.selectionEnd=selStart+text.length*2+5+s2.length;
    }

txtarea.focus();
return false;
}

//hideshow
function _syshse(id, trigger) {
var el=document.getElementById(id);
if(el.style.display=='none' || el.style.display==''){el.style.display='block'; trigger.className="hs_opened";}
else{el.style.display='none'; trigger.className="hs_closed";}
return false;
}