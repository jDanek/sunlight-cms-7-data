<?php

/*--- connect ---*/
require("access.php");
$connection=@mysql_connect($server, $user, $password);
define('_mysql_prefix', $prefix);
@mysql_query("set names `utf8`");
$db=@mysql_select_db($database);

  //check
  if(!$connection or !$db){
  echo "Pripojeni k databazi se nezdarilo.<hr /><pre>".mysql_error()."</pre>";
  exit;
  }
  
/*--- init ---*/
$errors=array();
function _logError(){
global $errors;
if(mysql_error()!=null){$errors[]=mysql_error();}
}

function _eventList($events){
$output="<ul>";

  foreach($events as $item){
  $output.="<li>".$item."</li>";
  }

$output.="</ul>";
return $output;
}

/*--- patch ---*/
@mysql_query("INSERT INTO `"._mysql_prefix."-settings` (`var` ,`val`)VALUES ('titletype', '1'), ('adminlinkprivate', '0');"); _logError();
@mysql_query("ALTER TABLE `"._mysql_prefix."-articles` ADD `showinfo` BOOL NOT NULL AFTER `confirmed`;"); _logError();
@mysql_query("UPDATE `"._mysql_prefix."-articles` SET `showinfo`=1;"); _logError();
@mysql_query("ALTER TABLE `"._mysql_prefix."-users` ADD `language` TINYTEXT NOT NULL AFTER `wysiwyg` ;"); _logError();
@mysql_query("UPDATE `"._mysql_prefix."-users` SET `language`='';"); _logError();
@mysql_query("INSERT INTO `"._mysql_prefix."-settings` (`var` ,`val`)VALUES ('language_allowcustom', '0');"); _logError();
@mysql_query("INSERT INTO `"._mysql_prefix."-settings` (`var` ,`val`)VALUES ('lostpass', '1');"); _logError();
@mysql_query("ALTER TABLE `"._mysql_prefix."-groups` ADD `reglist` BOOL NOT NULL AFTER `blocked`;"); _logError();
@mysql_query("INSERT INTO `"._mysql_prefix."-settings` (`var` ,`val`)VALUES ('registration_grouplist', '0');"); _logError();
@mysql_query("UPDATE `"._mysql_prefix."-groups` SET reglist=1 WHERE id=3;"); _logError();
@mysql_query("UPDATE `"._mysql_prefix."-root` SET var3=1 WHERE type=2;"); _logError();

  //result
  if(count($errors)==0){echo "Databaze byla aktualizovana.";}else{echo "Nastaly chyby!<hr />"._eventList($errors); exit;}
  if(!@unlink("patch.php")){echo " Smazte soubor <em>patch.php</em> ze serveru!";}

?>