<?php

/*---- initialize core ----*/

define('_indexroot', './');
require(_indexroot."core/_core.php");


/*---- output ----*/

_indexOutput();

?>