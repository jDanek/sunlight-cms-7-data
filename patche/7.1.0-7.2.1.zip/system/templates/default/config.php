<?php

/*---- template configuration ----*/

//main
define('_template_version', '7.2.1');
define('_template_autoheadings', 1);
define('_template_bbcode_buttons', 1);

//menu
define('_template_menu_parent', 'ul');
define('_template_menu_child', 'li');

//usermenu
define('_template_usermenu_parent', 'ul');
define('_template_usermenu_item_start', '<li>');
define('_template_usermenu_item_end', '</li>');
define('_template_usermenu_trim', 0);
define('_template_usermenu_showusername', 0);

//boxes
define('_template_boxes_parent', 'ul');
define('_template_boxes_item', 'li');
define('_template_boxes_title', 'h2');
define('_template_boxes_title_inside', 1);
define('_template_boxes_bottom', 0);

//other
define('_template_listinfoseparator', ' &nbsp;&bull;&nbsp; ');
define('_template_votebarwidthreduction', 25);

?>