<?php if(!defined('_core')){exit;}?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php _templateHead(); ?>
</head>

<body>

<div id="body">

<!-- header -->
<div id="header">
	<div id="logo">
		<h1><?php echo _title; ?></h1>
		<p><?php echo _description; ?></p>
	</div>
	<div id="search">
  <?php echo _parseHCM("[hcm]search[/hcm]"); ?>
	</div>
</div>

<!-- page -->
<div id="page">

  <!--  content -->
	<div id="content">
  <?php _templateContent(); ?>
	</div>

	<!-- sidebar -->
	<div id="sidebar">
  <?php _templateBoxes(); ?>
	</div>

</div>

<!-- footer -->
<div id="footer">
	<p><a href="http://www.freecsstemplates.org/">Free CSS Templates</a> &nbsp;&bull;&nbsp; <?php _templateLinks(); ?></p>
</div>

</div>

</body>
</html>