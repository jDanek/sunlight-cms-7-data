<?php






abstract class AdminBread
{






const ACTION_DENIED = 1;

const ACTION_ERR = 2;

const ACTION_NOT_FOUND = 3;

const ACTION_DONE = 4;

const ACTION_REDIR = 5;







public $module;




public $table;




public $tableAlias = 't';




public $primary = 'id';




public $uid;







protected $path;




protected $useRedirectionConstant = true;







protected $defaultAction = array('list');




protected $actionParam = 'action';




protected $prevActionParam = 'prev';



















protected $actions = array(

'list' => array(
'title' => '%s - listing',
'callback' => array(__class__, 'listAction'),
'query' => 'SELECT %columns% FROM %table% %table_alias% WHERE (%cond%)',
'columns' => array('t.id'),
'paginator' => true,
'paginator_size' => 10,
'query_cond' => '1',
'query_cond_params' => array(),
'query_orderby' => null,
'template' => 'list',
),

'edit' => array(
'title' => '%s - editing',
'min_params' => 2,
'callback' => array(__class__, 'editAction'),
'create' => false,
'handler' => null,
'template' => 'edit',
),

'create' => array(
'title' => '%s - creating',
'callback' => array(__class__, 'editAction'),
'create' => true,
'handler' => null,
'template' => 'edit',
'continue_to' => 'edit',
'initial_data' => array(),
),

'del' => array(
'title' => '%s - deleting',
'min_params' => 2,
'callback' => array(__class__, 'deleteAction'),
'handler' => null,
'template' => 'del',
'extra_columns' => array(),
),

);







protected $transCache;




private $formatSqlParams;







public function __construct()
{


$this->setup();


if(null === $this->uid) {
$this->uid = sprintf('_bread_%x', crc32("{$this->table}\${$this->tableAlias}\${$this->primary}\$".get_class($this)));
}

}




abstract protected function setup();











public function run($actionString = null, $actionUrl = null, $actionPrev = null)
{

global $_lang;


$ok = false;
do {


if(null !== $actionString) {
$params = explode('/', $actionString);
} elseif(isset($_GET[$this->actionParam])) {
$params = explode('/', $actionString = strval($_GET['action']));
} else {
$params = $this->defaultAction;
$actionString = implode('/', $params);
}


if(!isset($this->actions[$params[0]])) {
break;
}
$action = $this->actions[$params[0]];


if(isset($action['min_params']) && sizeof($params) < $action['min_params']) {
break;
}


if(null === $actionPrev) {
$actionPrev = (isset($_GET[$this->prevActionParam]) ? $_GET[$this->prevActionParam] : null);
}


if(null === $actionUrl) {
$params['url'] = $this->url(
$params[0],
array_slice($params, 1),
$actionPrev
);
} else {
$params['url'] = $actionUrl;
}


$params['action'] = $actionString;
$params['action_prev'] = $actionPrev;


$response = null;
if(isset($action['on_before'])) $response = call_user_func_array($action['on_before'], array(&$params, &$action, $this));
if(null === $response) $response = call_user_func_array($action['callback'], array($params, $action, $this));


if(is_array($response)) {

list($responseParams, $responseContent) = $response;


if(is_int($responseContent)) {
switch($responseContent) {

case self::ACTION_DENIED: $responseContent = _formMessage(2, $_lang['global.accessdenied']); break;
case self::ACTION_ERR: $responseContent = _formMessage(2, isset($responseParams['msg']) ? $responseParams['msg'] : $_lang['global.error']); break;
case self::ACTION_NOT_FOUND: $responseContent = _formMessage(2, "{$_lang['global.error']} - {$_lang['global.nokit']}"); break;
case self::ACTION_DONE: $responseContent = _formMessage(1, $_lang['global.done']); break;

case self::ACTION_REDIR:
if($this->useRedirectionConstant) define('_redirect_to', $responseParams['url']);
return
(isset($responseParams['msg'])
? _formMessage(
isset($responseParams['msg_type']) ? $responseParams['msg_type'] : 1,
$this->trans($responseParams['msg'], isset($responseParams['msg_params']) ? $responseParams['msg_params'] : null)
)
: ''
)
.'<p><img class="icon" src="images/icons/edit.png" alt="continue" /><strong><a href="'._htmlStr($responseParams['url']).'">'.$_lang['global.continue'].' &gt;</a></strong></p>'
;

}
}


if(null !== $responseParams) {
$params = array_merge($params, $responseParams);
}

} else {


break;

}


$ok = true;

} while(false);


if(!$ok) {
return _formMessage(3, $_lang['global.badinput']);
}


return $this->wrap($responseContent, $params);

}
























protected function wrap($content, array $params)
{

$out = '';
global $_lang;


if(isset($params['title'])) {
$title = $this->trans(
$params['title'],
isset($params['title_params']) ? $params['title_params'] : null
);
} else {
$title = $this->trans(
$this->actions[$params[0]]['title'],
array($this->trans(isset($params['item_name']) ? $params['item_name'] : 'item'))
);
}


if(isset($params['backlink'])) {


$backlink = $params['backlink'];

} elseif(isset($params['backlink_action'])) {


$backlink = $this->url(
$params['backlink_action'],
isset($params['backlink_action_params']) ? $params['backlink_action_params'] : null,
isset($params['backlink_action_prev']) ? $params['backlink_action_prev'] : null
);
} elseif(!empty($_GET[$this->prevActionParam])) {


$backlink = $this->rawUrl(
$_GET[$this->prevActionParam],
null
);

} else {


$backlink = null;

}


if(null !== $backlink) {
$out .= "<a class='backlink' href='"._htmlStr($backlink)."'>&lt; {$_lang['global.return']}</a>\n";
}


$out .= "<h1>"._htmlStr($title)."</h1>\n";


if(isset($params['info'])) {
$out .= "<p".((!isset($params['info_border']) || true === $params['info_border']) ? " class='bborder'" : '').">{$params['info']}</p>\n";
}


if(!empty($params['messages'])) {
foreach($params['messages'] as $message) {
$out .= _formMessage(
$message[0],
_htmlStr($this->trans($message[1], isset($message[2]) ? $message[2] : null))
);
}
}


$out .= "\n{$content}\n";


return $out;

}










public function trans($str, array $params = null)
{


if(null === $this->transCache) {
$transFile = $this->resource('trans', _active_language, 'php');
if(file_exists($transFile)) $this->transCache = include $transFile;
elseif(file_exists($transFile = $this->resource('trans', 'default', 'php'))) $this->transCache = include $transFile;
else $this->transCache = false;
}


if(false !== $this->transCache && isset($this->transCache[$str])) {
$str = $this->transCache[$str];
}


if(null !== $params) return vsprintf($str, $params);
return $str;

}







public function transRender($str, array $params = null)
{
echo _htmlStr($this->trans($str, $params));
}










public function render($_template, array $_params = null)
{


$_templatePath = $this->resource('tpl', $_template, 'php');
if(file_exists($_templatePath)) {


ob_start();
extract($_params, EXTR_SKIP);
global $_lang;


include $_templatePath;


return ob_get_clean();

}


return '{'._htmlStr($_templatePath).'}';

}



















public function renderLink($icon, $caption, $action, array $params = null, $prev = null, array $extra = null)
{


if(isset($extra['is_url']) && $extra['is_url']) $href = $action;
else $href = $this->url($action, $params, $prev);


echo "<a href='"._htmlStr($href)."'"
.((isset($extra, $extra['new_window']) && $extra['new_window']) ? " target='_blank'" : '')
.((isset($extra, $extra['class'])) ? " class='"._htmlStr($extra['class'])."'" : '')
.">"
.((null !== $icon) ? "<img class='icon' src='".((isset($extra, $extra['icon_full']) && $extra['icon_full']) ? _htmlStr($icon) : "./images/icons/{$icon}.png")."' />" : '')
.$caption
."</a>"
;
}






public function renderStr($str)
{
echo _htmlStr($str);
}











public function resource($dirname, $file, $ext = null)
{
return $this->path
.DIRECTORY_SEPARATOR.$dirname
.DIRECTORY_SEPARATOR.$file
.((null === $ext) ? '' : ".{$ext}")
;
}












public function url($action, array $params = null, $prev = null, array $query = null)
{
return 'index.php?p='.$this->module
.'&'.$this->actionParam.'='.$action
.((empty($params)) ? '' : '/'.urlencode(implode('/', $params)))
.((null === $prev) ? '' : '&'.$this->prevActionParam.'='.urlencode($prev))
.(empty($query) ? '' : '&'.http_build_query($query, '', '&'))
;
}








public function rawUrl($actionString, $prevActionString = null, array $query = null)
{
return 'index.php?p='.$this->module
.'&'.$this->actionParam.'='.urlencode($actionString)
.((null === $prevActionString) ? '' : '&'.$this->prevActionParam.'='.urlencode($prevActionString))
.(empty($query) ? '' : '&'.http_build_query($query, '', '&'))
;
}










public function formatSql($sql, array $params)
{
$this->formatSqlParams = $params;
$sql = preg_replace_callback('/%(?P<lit>[a-zA-Z0_9\\-.]+)%|@(?P<val>[a-zA-Z0_9\\-.]+)@/m', array($this, 'formatSqlParam'), $sql);
$this->formatSqlParams = null;
return $sql;
}






public function formatSqlParam(array $match)
{
if(isset($match['lit']) && '' !== $match['lit']) {
if(isset($this->formatSqlParams[$match['lit']])) {
$param = $this->formatSqlParams[$match['lit']];
if(is_array($param)) return implode(',', $param);
return $param;
} else {
throw new RuntimeException("Parameter '{$match['lit']}' is undefined");
}
} else {
if(isset($this->formatSqlParams[$match['val']]) || array_key_exists($match['val'], $this->formatSqlParams)) {
return DB::val($this->formatSqlParams[$match['val']], true);
} else {
throw new RuntimeException("Parameter '{$match['val']}' is undefined");
}
}
}











static public function listAction(array $params, array $action, AdminBread $bread)
{




if('1' !== $action['query_cond']) {
$cond = $bread->formatSql($action['query_cond'], $action['query_cond_params']);
} else {
$cond = $action['query_cond'];
}


$sql = $bread->formatSql($action['query'], array(
'columns' => $action['columns'],
'table' => '`'._mysql_prefix."-{$bread->table}`",
'table_alias' => $bread->tableAlias,
'cond' => $cond,
));


if(!empty($action['query_orderby'])) {
$sql .= " ORDER BY {$action['query_orderby']}";
}




if($action['paginator']) {
$paging = _resultPaging(_htmlStr($params['url']), $action['paginator_size'], "{$bread->table}:{$bread->tableAlias}", $cond);
$sql .= " {$paging[1]}";
} else {
$paging = null;
}




$result = DB::query($sql);
if(false === $result) {
return array(null, self::ACTION_ERR);
}




$out = $bread->render($action['template'], array(
'result' => $result,
'count' => DB::size($result),
'paging' => $paging,
'self' => $params['action'],
));

DB::free($result);


return array(null, $out);

}








static public function editAction(array $params, array $action, AdminBread $bread)
{

$messages = array();
$create = (isset($action['create']) && true === $action['create']);
$trigger = "_edit_{$bread->uid}";

$createMsgKey = "{$bread->uid}_edit_created";
if(!$create) {
$updateMsgKey = "{$bread->uid}_edit_updated";
}



if(!$create) {


if(!isset($params[1])) {
return array(
array('msg' => 'Missing parameter 1 for '.__METHOD__),
self::ACTION_ERR,
);
}


$id = (int)$params[1];


$data = DB::query_row("SELECT {$bread->tableAlias}.* FROM `"._mysql_prefix."-{$bread->table}` {$bread->tableAlias} WHERE {$bread->tableAlias}.{$bread->primary}={$id}");
if(false === $data) {
return array(null, self::ACTION_NOT_FOUND);
}

} else {


$data = $action['initial_data'];

}




if(isset($_POST[$trigger])) {


if(null === $action['handler']) {
return array(
array('msg' => 'Missing handler for '.__METHOD__),
self::ACTION_ERR,
);
}


$success = false;
$insertId = false;
$handlerResult = call_user_func($action['handler'], array(
'success' => &$success,
'create' => $create,
'data' => $data,
'params' => $params,
'action' => $action,
'bread' => $bread,
'messages' => &$messages,
'insert_id' => &$insertId,
));


if($success) {


if($create) {


if(is_array($handlerResult)) {
$insertId = DB::insert(_mysql_prefix.'-'.$bread->table, $handlerResult, true);
}

if(false !== $insertId) {
return array(
array(
'url' => _url.'/admin/'.$bread->url($action['continue_to'], array($insertId), $params['action_prev'], array($createMsgKey => time())),
'msg' => 'Item created',
),
self::ACTION_REDIR,
);
} else {
return array(null, self::ACTION_ERR);
}

} else {


if(is_array($handlerResult)) {


$update = DB::update(_mysql_prefix.'-'.$bread->table, "{$bread->primary}={$id}", $handlerResult);
if(false !== $update) {
$data = $handlerResult + $data;
if(empty($messages)) $messages[] = array(1, 'Item updated');
$_POST = array();
} else {
return array(null, self::ACTION_ERR);
}

} else {


return array(
array(
'url' => _url.'/admin/'.$bread->url($params[0], array($id), $params['action_prev'], array($updateMsgKey => time())),
'msg' => 'Item updated',
),
self::ACTION_REDIR,
);

}

}


} else {


if(is_array($handlerResult)) {
$messages = $handlerResult;
} else {
$messages[] = array(2, 'An error occured while '.($create ? 'creating' : 'updating'));
}

}

}





if(!$create && empty($messages) && isset($_GET[$updateMsgKey]) && time() - intval($_GET[$updateMsgKey]) < 15) {

$messages[] = array(1, 'Item updated');
} elseif(!$create && empty($messages) && isset($_GET[$createMsgKey]) && time() - intval($_GET[$createMsgKey]) < 15) {

$messages[] = array(1, 'Item created');
}


return array(
array('messages' => $messages),
$bread->render($action['template'], array(
'create' => $create,
'data' => $data,
'self' => $params['action'],
'submit_text' => $GLOBALS['_lang'][$create ? 'global.create' : 'global.save'],
'submit_trigger' => $trigger,
)),
);



}








static public function deleteAction(array $params, array $action, AdminBread $bread)
{

$messages = array();
$trigger = "_del_{$bread->uid}";




if(!isset($params[1])) {
return array(
array('msg' => 'Missing parameter 1 for '.__METHOD__),
self::ACTION_ERR,
);
}


$id = (int)$params[1];


$sql = $bread->formatSql("SELECT %columns% FROM `"._mysql_prefix."-{$bread->table}` {$bread->tableAlias} WHERE {$bread->tableAlias}.{$bread->primary}=@id@", array(
'columns' => array_merge(array($bread->primary), $action['extra_columns']),
'id' => $id,
));
$data = DB::query_row($sql);
if(false === $data) {
return array(null, self::ACTION_NOT_FOUND);
}




if(isset($_POST[$trigger])) {


if(null !== $action['handler']) {


$success = call_user_func($action['handler'], array(
'data' => $data,
'params' => $params,
'action' => $action,
'bread' => $bread,
'messages' => &$messages,
));

} else {


$success = DB::query($bread->formatSql("DELETE FROM `"._mysql_prefix."-{$bread->table}` WHERE {$bread->primary}=@id@ LIMIT 1", array('id' => $id)));

}


if($success) {

return array(
array('messages' => $messages),
self::ACTION_DONE,
);

} else {

$messages[] = array(2, $GLOBALS['_lang']['global.error']);

}

}




return array(
array('messages' => $messages),
$bread->render($action['template'], array(
'data' => $data,
'self' => $params['action'],
'submit_text' => $GLOBALS['_lang']['admin.content.redir.act.wipe.submit'],
'submit_trigger' => $trigger,
)),
);

}


}