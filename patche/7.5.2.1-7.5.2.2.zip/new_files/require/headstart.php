<?php if(!defined('_core')) {exit;} ?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="generator" content="SunLight CMS <?php echo _systemversion.' '.$__sys_state[_systemstate]._systemstate_revision; ?>" />
