<?php

/*-- init functions and constants --*/

mb_internal_encoding("UTF-8");
error_reporting(E_ALL);
header("Content-Type: text/html; charset=utf-8");

function win2utf($s)
{
    static $tbl = array("\x80"=>"\xe2\x82\xac","\x81"=>"","\x82"=>"\xe2\x80\x9a","\x83"=>"","\x84"=>"\xe2\x80\x9e","\x85"=>"\xe2\x80\xa6","\x86"=>"\xe2\x80\xa0","\x87"=>"\xe2\x80\xa1","\x88"=>"","\x89"=>"\xe2\x80\xb0","\x8a"=>"\xc5\xa0","\x8b"=>"\xe2\x80\xb9","\x8c"=>"\xc5\x9a","\x8d"=>"\xc5\xa4","\x8e"=>"\xc5\xbd","\x8f"=>"\xc5\xb9","\x90"=>"","\x91"=>"\xe2\x80\x98","\x92"=>"\xe2\x80\x99","\x93"=>"\xe2\x80\x9c","\x94"=>"\xe2\x80\x9d","\x95"=>"\xe2\x80\xa2","\x96"=>"\xe2\x80\x93","\x97"=>"\xe2\x80\x94","\x98"=>"","\x99"=>"\xe2\x84\xa2","\x9a"=>"\xc5\xa1","\x9b"=>"\xe2\x80\xba","\x9c"=>"\xc5\x9b","\x9d"=>"\xc5\xa5","\x9e"=>"\xc5\xbe","\x9f"=>"\xc5\xba","\xa0"=>"\xc2\xa0","\xa1"=>"\xcb\x87","\xa2"=>"\xcb\x98","\xa3"=>"\xc5\x81","\xa4"=>"\xc2\xa4","\xa5"=>"\xc4\x84","\xa6"=>"\xc2\xa6","\xa7"=>"\xc2\xa7","\xa8"=>"\xc2\xa8","\xa9"=>"\xc2\xa9","\xaa"=>"\xc5\x9e","\xab"=>"\xc2\xab","\xac"=>"\xc2\xac","\xad"=>"\xc2\xad","\xae"=>"\xc2\xae","\xaf"=>"\xc5\xbb","\xb0"=>"\xc2\xb0","\xb1"=>"\xc2\xb1","\xb2"=>"\xcb\x9b","\xb3"=>"\xc5\x82","\xb4"=>"\xc2\xb4","\xb5"=>"\xc2\xb5","\xb6"=>"\xc2\xb6","\xb7"=>"\xc2\xb7","\xb8"=>"\xc2\xb8","\xb9"=>"\xc4\x85","\xba"=>"\xc5\x9f","\xbb"=>"\xc2\xbb","\xbc"=>"\xc4\xbd","\xbd"=>"\xcb\x9d","\xbe"=>"\xc4\xbe","\xbf"=>"\xc5\xbc","\xc0"=>"\xc5\x94","\xc1"=>"\xc3\x81","\xc2"=>"\xc3\x82","\xc3"=>"\xc4\x82","\xc4"=>"\xc3\x84","\xc5"=>"\xc4\xb9","\xc6"=>"\xc4\x86","\xc7"=>"\xc3\x87","\xc8"=>"\xc4\x8c","\xc9"=>"\xc3\x89","\xca"=>"\xc4\x98","\xcb"=>"\xc3\x8b","\xcc"=>"\xc4\x9a","\xcd"=>"\xc3\x8d","\xce"=>"\xc3\x8e","\xcf"=>"\xc4\x8e","\xd0"=>"\xc4\x90","\xd1"=>"\xc5\x83","\xd2"=>"\xc5\x87","\xd3"=>"\xc3\x93","\xd4"=>"\xc3\x94","\xd5"=>"\xc5\x90","\xd6"=>"\xc3\x96","\xd7"=>"\xc3\x97","\xd8"=>"\xc5\x98","\xd9"=>"\xc5\xae","\xda"=>"\xc3\x9a","\xdb"=>"\xc5\xb0","\xdc"=>"\xc3\x9c","\xdd"=>"\xc3\x9d","\xde"=>"\xc5\xa2","\xdf"=>"\xc3\x9f","\xe0"=>"\xc5\x95","\xe1"=>"\xc3\xa1","\xe2"=>"\xc3\xa2","\xe3"=>"\xc4\x83","\xe4"=>"\xc3\xa4","\xe5"=>"\xc4\xba","\xe6"=>"\xc4\x87","\xe7"=>"\xc3\xa7","\xe8"=>"\xc4\x8d","\xe9"=>"\xc3\xa9","\xea"=>"\xc4\x99","\xeb"=>"\xc3\xab","\xec"=>"\xc4\x9b","\xed"=>"\xc3\xad","\xee"=>"\xc3\xae","\xef"=>"\xc4\x8f","\xf0"=>"\xc4\x91","\xf1"=>"\xc5\x84","\xf2"=>"\xc5\x88","\xf3"=>"\xc3\xb3","\xf4"=>"\xc3\xb4","\xf5"=>"\xc5\x91","\xf6"=>"\xc3\xb6","\xf7"=>"\xc3\xb7","\xf8"=>"\xc5\x99","\xf9"=>"\xc5\xaf","\xfa"=>"\xc3\xba","\xfb"=>"\xc5\xb1","\xfc"=>"\xc3\xbc","\xfd"=>"\xc3\xbd","\xfe"=>"\xc5\xa3","\xff"=>"\xcb\x99");
    return strtr($s, $tbl);
}

function esc($input){
foreach($input as $key=>$value){
$input[$key]=mysql_escape_string(win2utf($value));
}
return $input;
}

function convert_smilies($input){
return str_replace(array("*01*", "*02*", "*03*", "*04*", "*05*", "*06*", "*07*", "*08*"), array("*1*", "*2*", "*10*", "*1*", "*1*", "*6*", "*8*", "*7*"), $input);
}

/*-- connect to mysql server --*/

require("_access.php");
$connection=@mysql_connect($c_server, $c_user, $c_password);
define('_mysql_prefix', $c_tabprefix);
@mysql_query("set names 'cp1250'");
$db=@mysql_select_db($c_database);

  //check
  if(!$connection or !$db){
  echo "Pripojeni k databazi se nezdarilo.<hr /><pre>".mysql_error()."</pre>";
  exit;
  }
  
/*-- conversion --*/

$output="";

  //menu
  $query=mysql_query("SELECT * FROM `"._mysql_prefix."-menu` WHERE type!=6 AND type!=7");
  while($item=mysql_fetch_array($query)){
  $item=esc($item);

    //regonly -> public
    if($item['regonly']==1){$public=0;}
    else{$public=1;}
    
    //type, var1, var2, var3
    switch($item['type']){
    case 1: $type=1; $var1=$item['comment']; $var2=0; $var3=0; break;
    case 2: $type=2; $var1=1; $var2=15; $var3=0; break;
    case 3: $type=3; $var1=1; $var2=15; $var3=0; break;
    case 4: $type=6; $var1=$item['comment']; $var2=0; $var3=0; break;
    case 5: $type=4; $var1=0; $var2=0; $var3=0; break;
    case 8: $type=7; $var1=1; $var2=0; $var3=0; break;
    }
    
    //level-based invisibility
    if($item['level']==0){$item['visible']=0; $item['ord']=$item['ord']+100;}
    
    //intersection
    $intersection=mysql_query("SELECT home,perex FROM `"._mysql_prefix."-gpitems` WHERE target=".$item['id']." AND type=".$item['type']);
    if(mysql_num_rows($intersection)!=0){
      $intersection=mysql_fetch_array($intersection);
      $intersection=$intersection['home'];
      $intersectionperex=mysql_escape_string(win2utf($intersection['perex']));
    }
    else{
    $intersection="-1";
    $intersectionperex="";
    }
  
  $output.="root` (id,title,type,intersection,intersectionperex,ord,content,visible,public,var1,var2,var3) VALUES (".$item['id'].",'".$item['anchor']."',".$type.",".$intersection.",'".$intersectionperex."',".$item['ord'].",'".$item['code']."',".$item['visible'].",".$public.",".$var1.",".$var2.",".$var3.")\n";
  }
  
  //articles
  $query=mysql_query("SELECT * FROM `"._mysql_prefix."-articles`");
  while($item=mysql_fetch_array($query)){
  $item=esc($item);
  $output.="articles` (id,title,perex,content,infobox,author,home1,home2,home3,time,visible,public,comments,confirmed,readed,rateon,ratenum,ratesum) VALUES (".$item['id'].",'".$item['title']."','".$item['perex']."','".$item['code']."','',".$item['author'].",".$item['home'].",-1,-1,".$item['date'].",".$item['visible'].",1,".$item['comment'].",1,".$item['opened'].",".$item['rate_allow'].",".$item['rate_counter'].",".$item['rate_total'].")\n";
  }
  
  //comments
  $new_id=1;
  $query=mysql_query("SELECT * FROM `"._mysql_prefix."-comments`");
  while($item=mysql_fetch_array($query)){
  $item=esc($item);
  $output.="posts` (id,type,home,xhome,subject,text,author,guest,time,ip) VALUES (".$new_id.",".$item['tp'].",".$item['home'].",-1,'".$item['subject']."','".convert_smilies($item['text'])."',".$item['author'].",'',".$item['date'].",'".$item['ip']."')\n";
  $new_id++;
  }
  
  //posts
  $query=mysql_query("SELECT * FROM `"._mysql_prefix."-posts` WHERE topic=-1");
  while($item=mysql_fetch_array($query)){
  $item=esc($item);
  if($item['name']!=""){$item['author']=-1;}
  $output.="posts` (id,type,home,xhome,subject,text,author,guest,time,ip) VALUES (".$new_id.",3,".$item['home'].",-1,'".$item['subject']."','".convert_smilies($item['text'])."',".$item['author'].",'".$item['name']."',".$item['date'].",'".$item['ip']."')\n";
  $new_id++;
  }
  
  //users
  $query=mysql_query("SELECT * FROM `"._mysql_prefix."-users`");
  while($item=mysql_fetch_array($query)){
  $item=esc($item);
  
    //group
    switch($item['rights']){
    case 0: $group=3; break;
    case 1: $group=5; break;
    case 2: if($item['id']!=0){$group=4;}else{$group=1;} break;
    }
  
  $output.="users` (id,`group`,username,password,registertime,activitytime,blocked,massemail,wysiwyg,ip,email,avatar,icq,note) VALUES (".$item['id'].",".$group.",'".$item['name']."','".$item['password']."',".$item['lastlogin'].",".$item['lastact'].",0,".$item['massmail'].",0,'0.0.0.0','".$item['email']."','',0,'".$item['note']."')\n";
  }
  
  //boxes
  $query=mysql_query("SELECT * FROM `"._mysql_prefix."-boxes`");
  while($item=mysql_fetch_array($query)){
  $item=esc($item);
  $output.="boxes` (id,ord,title,content,visible,public,`column`) VALUES (".$item['id'].",".$item['ord'].",'".$item['title']."','".$item['content']."',".$item['visible'].",1,".($item['panel']+1).")\n";
  }
  
//static
$query=mysql_query("SELECT * FROM `"._mysql_prefix."-settings`");
while($item=mysql_fetch_array($query)){$settings[$item['variable']]=$item['value'];}
$output.="groups` (`id`,`title`,`level`,`icon`,`administration`,`adminsettings`,`adminusers`,`admingroups`,`admincontent`,`adminsection`,`admincategory`,`adminbook`,`adminseparator`,`admingallery`,`adminlink`,`adminintersection`,`adminart`,`adminallart`,`adminchangeartauthor`,`adminconfirm`,`adminneedconfirm`,`adminpoll`,`adminpollall`,`adminbox`,`adminfman`,`adminfmanlimit`,`adminfmanplus`,`adminhcmphp`,`adminbackup`,`adminmassemail`,`adminbans`,`changeusername`,`postcomments`,`unlimitedpostaccess`,`artrate`,`pollvote`) VALUES (1,'Hlavni administrátoři',10000,'boss.gif',1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1)
groups` (`id`,`title`,`level`,`icon`,`administration`,`adminsettings`,`adminusers`,`admingroups`,`admincontent`,`adminsection`,`admincategory`,`adminbook`,`adminseparator`,`admingallery`,`adminlink`,`adminintersection`,`adminart`,`adminallart`,`adminchangeartauthor`,`adminconfirm`,`adminneedconfirm`,`adminpoll`,`adminpollall`,`adminbox`,`adminfman`,`adminfmanlimit`,`adminfmanplus`,`adminhcmphp`,`adminbackup`,`adminmassemail`,`adminbans`,`changeusername`,`postcomments`,`unlimitedpostaccess`,`artrate`,`pollvote`) VALUES (2,'Neregistrovaní­',0,'',1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0)
groups` (`id`,`title`,`level`,`icon`,`administration`,`adminsettings`,`adminusers`,`admingroups`,`admincontent`,`adminsection`,`admincategory`,`adminbook`,`adminseparator`,`admingallery`,`adminlink`,`adminintersection`,`adminart`,`adminallart`,`adminchangeartauthor`,`adminconfirm`,`adminneedconfirm`,`adminpoll`,`adminpollall`,`adminbox`,`adminfman`,`adminfmanlimit`,`adminfmanplus`,`adminhcmphp`,`adminbackup`,`adminmassemail`,`adminbans`,`changeusername`,`postcomments`,`unlimitedpostaccess`,`artrate`,`pollvote`) VALUES (3,'Čtenáři',1,'',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,1)
groups` (`id`,`title`,`level`,`icon`,`administration`,`adminsettings`,`adminusers`,`admingroups`,`admincontent`,`adminsection`,`admincategory`,`adminbook`,`adminseparator`,`admingallery`,`adminlink`,`adminintersection`,`adminart`,`adminallart`,`adminchangeartauthor`,`adminconfirm`,`adminneedconfirm`,`adminpoll`,`adminpollall`,`adminbox`,`adminfman`,`adminfmanlimit`,`adminfmanplus`,`adminhcmphp`,`adminbackup`,`adminmassemail`,`adminbans`,`changeusername`,`postcomments`,`unlimitedpostaccess`,`artrate`,`pollvote`) VALUES (5,'Redaktoři',250,'editor.gif',1,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,1,0,1,1)
groups` (`id`,`title`,`level`,`icon`,`administration`,`adminsettings`,`adminusers`,`admingroups`,`admincontent`,`adminsection`,`admincategory`,`adminbook`,`adminseparator`,`admingallery`,`adminlink`,`adminintersection`,`adminart`,`adminallart`,`adminchangeartauthor`,`adminconfirm`,`adminneedconfirm`,`adminpoll`,`adminpollall`,`adminbox`,`adminfman`,`adminfmanlimit`,`adminfmanplus`,`adminhcmphp`,`adminbackup`,`adminmassemail`,`adminbans`,`changeusername`,`postcomments`,`unlimitedpostaccess`,`artrate`,`pollvote`) VALUES (4,'Administrátoři',5000,'admin.gif',1,0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,0,0,0,1,1,1,1,0,1,1)
settings` (`var`,`val`) VALUES ('url','".$settings['serverurl']."')
settings` (`var`,`val`) VALUES ('template','default')
settings` (`var`,`val`) VALUES ('title','".$settings['title']."')
settings` (`var`,`val`) VALUES ('description','".$settings['description']."')
settings` (`var`,`val`) VALUES ('keywords','".$settings['keywords']."')
settings` (`var`,`val`) VALUES ('mailerusefrom','0')
settings` (`var`,`val`) VALUES ('titleseparator','".$settings['separator']."')
settings` (`var`,`val`) VALUES ('language','default')
settings` (`var`,`val`) VALUES ('modrewrite','0')
settings` (`var`,`val`) VALUES ('defaultgroup','3')
settings` (`var`,`val`) VALUES ('showpages','4')
settings` (`var`,`val`) VALUES ('ulist','".$settings['userlist']."')
settings` (`var`,`val`) VALUES ('registration','".$settings['registration']."')
settings` (`var`,`val`) VALUES ('adminintro','')
settings` (`var`,`val`) VALUES ('atreplace',' zavináč ')
settings` (`var`,`val`) VALUES ('profileemail','".$settings['showmail']."')
settings` (`var`,`val`) VALUES ('captcha','".$settings['codecheck']."')
settings` (`var`,`val`) VALUES ('commentsperpage','".$settings['postlimit']."')
settings` (`var`,`val`) VALUES ('postadmintime','43200')
settings` (`var`,`val`) VALUES ('smileys','".$settings['smileys']."')
settings` (`var`,`val`) VALUES ('bbcode','".$settings['bbcode']."')
settings` (`var`,`val`) VALUES ('wysiwyg','0')
settings` (`var`,`val`) VALUES ('pagingmode','2')
settings` (`var`,`val`) VALUES ('maxloginattempts','20')
settings` (`var`,`val`) VALUES ('maxloginexpire','1800')
settings` (`var`,`val`) VALUES ('artreadexpire','18000')
settings` (`var`,`val`) VALUES ('pollvoteexpire','604800')
settings` (`var`,`val`) VALUES ('postsendexpire','30')
settings` (`var`,`val`) VALUES ('artrateexpire','604800')
settings` (`var`,`val`) VALUES ('comments','".$settings['comment']."')
settings` (`var`,`val`) VALUES ('notpublicsite','".$settings['regonly']."')
settings` (`var`,`val`) VALUES ('lightbox','1')
settings` (`var`,`val`) VALUES ('rss','".$settings['rss']."')
settings` (`var`,`val`) VALUES ('messages','1')
settings` (`var`,`val`) VALUES ('messagesperpage','50')
settings` (`var`,`val`) VALUES ('search','1')
settings` (`var`,`val`) VALUES ('banned','')
settings` (`var`,`val`) VALUES ('author','admin')";

//download
header('Content-Description: File Transfer');
header('Content-Type: application/force-download');
header('Content-Disposition: attachment; filename="'._mysql_prefix.'_'.date("j_n_Y").'.sld'.'"');
echo chunk_split(base64_encode(gzdeflate("==AAGUzMUH7MQXzMXHzMVXzM\n".$output)));

?>