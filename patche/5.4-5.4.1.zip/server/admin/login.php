<?php
if(isset($_POST['password'])){

/*nacteni post promennych*/

  /*heslo*/
  if($_POST['crypted']==0 or $_POST['cryptedpass']==""){
  $password=$_POST['password'];
  $password=md5($password);
  }
  else{
  $password=$_POST['cryptedpass'];
  }

$name=$_POST['name'];
$name=addslashes($name);

/*kontrola spravnosti*/
$rootpath=array("path"=>"../");
$indicators['administration']=1;
include("../_connect.php");
$userdata=@mysql_query("SELECT id,name,rights,password FROM `".tabprefix."-users` WHERE name='$name'");
$userdata=@mysql_fetch_array($userdata);

if($userdata['name']!=""){

  /*kontrola prav*/
  if($userdata['rights']==0){
  header("location: index.php?wrong");
  exit;
  }

  /*kontrola hesla*/
  if($userdata['password']!=$password){
  header("location: index.php?wrong");
  exit;
  }

}
else{
header("location: index.php?wrong");
exit;
}

/*zaznamenani casu prihlaseni*/
@mysql_query("UPDATE `".tabprefix."-users` SET lastlogin=".time()." WHERE id=".$userdata['id']);

/*nastaveni sessions a presmerovani*/
session_start();
$_SESSION[systemuid.'login_aindicator']=1;
$_SESSION[systemuid.'login_aid']=$userdata['id'];

header("location: admin.php");
exit;

}
?>
