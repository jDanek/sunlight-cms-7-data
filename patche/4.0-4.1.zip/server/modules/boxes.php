<?php

if(!isset($box_column)){$box_column=0;}
else{$box_column=intval($box_column);}

$boxes=@mysql_query("SELECT title,showtitle,content FROM `".tabprefix."-boxcontent` WHERE visible=1 and panel=$box_column ORDER BY ord");
while($box=@mysql_fetch_array($boxes)){

if(strpos("##".$box['content'], "<!--noboxpadding-->")){$padding=true;}else{$padding=false;}

$boxecho="<div class='box'>\n";
if($padding==false){$boxecho.="<div class='box-padding'>\n";}
if($box['showtitle']==1){$boxecho.="<div class='box-title'>".$box['title']."</div>\n";}
$boxecho.=parsehcm($box['content'])."\n</div>\n\n";
if($padding==false){$boxecho.="</div>\n";}
echo $boxecho;
}

?>
