<?php


/*pristupova data*/
$c_server="server";       //MySQL server
$c_user="uzivatel";       //MySQL uzivatel
$c_password="heslo";      //MySQL heslo
$c_database="databaze";   //MySQL databaze
$c_tabprefix="webman";    //Prefix jmen tabulek








/*
###########################################
UPRAVA CEHOKOLIV NIZE NA VLASTNI NEBEZPECI!
###########################################
*/

/*definovani globalni promenne prefixu*/
if($c_tabprefix!=""){
define('tabprefix', $c_tabprefix);
}
else{
$error="Musite zadat prefix (promenna c_tabprafix)!.";
include($root."modules/error.php");
exit;
}

/*nastaveni predpon mod_rewrite pluginu - kdyz zmenite
toto, musite zmenit take soubor .htaccess!*/
$st_secprefix="sekce";
$st_catprefix="kategorie";
$st_artprefix="clanek";
$st_gbprefix="kniha";

  /*definovani globalnich*/
  define('secprefix', $st_secprefix);
  define('catprefix', $st_catprefix);
  define('artprefix', $st_artprefix);
  define('gbprefix', $st_gbprefix);

/*pripojeni*/
$connection=@mysql_connect($c_server, $c_user, $c_password);
@mysql_query("set names 'cp1250'");
$db=@mysql_select_db($c_database);

  /*kontrola*/
  if(!$connection or !$db){
  $error="Pripojeni k databazi se nezdarilo. Odpoved MySQL serveru muzete videt nize.";
  include($root."modules/error.php");
  echo "<pre>".mysql_error()."</pre>";
  exit;
  }

if($stopconnecting!=true){


/*definovani root*/
if(isset($root)){define('root', $root);}else{define('root', "./");}

/*kontrola existence tabulek*/
$controldatabase=@mysql_query("SHOW TABLES FROM $c_database");
$controldatabase_matches=0;
while($controldatabase_item=mysql_fetch_array($controldatabase)){
switch($controldatabase_item[0]){
case tabprefix."-articlecontent": $controldatabase_matches++; break;
case tabprefix."-blockedip": $controldatabase_matches++; break;
case tabprefix."-bookcontent": $controldatabase_matches++; break;
case tabprefix."-boxcontent": $controldatabase_matches++; break;
case tabprefix."-codecontent": $controldatabase_matches++; break;
case tabprefix."-comments": $controldatabase_matches++; break;
case tabprefix."-menu": $controldatabase_matches++; break;
case tabprefix."-settings": $controldatabase_matches++; break;
case tabprefix."-users": $controldatabase_matches++; break;
case tabprefix."-votecontent": $controldatabase_matches++; break;
}
}

  /*vypis pripadne hlasky*/
  if($controldatabase_matches!=10){
  $error="Zvolena databaze $c_database neobsahuje vsechny tabulky systemu (nalezeno $controldatabase_matches z 10)! Prosim zkontrolujte, zda je databaze korektne nainsalovana a/nebo zda jste nastavili spravny prefix (promenna c_tabprefix v _connect.php).";
  include($root."modules/error.php");
  exit;
  }

/*kontrola, zda neexistuje slozka install*/
if(file_exists(root."install/")){
$error="Prosim zkontrolujte, zda se adresar <i>install</i> nenachazi na serveru a pripadne jej smazte";
include($root."modules/error.php");
exit;
}

/*vymazani nepotrebnych pristupovych udaju*/
unset($c_server);
unset($c_user);
unset($c_password);
unset($c_database);

/*nacteni nastaveni*/
include(root."modules/setload.php");

/*nacteni funkci*/
include(root."modules/funcload.php");

/*nastaveni vseobecnych promennych*/
$systemversion="4.1";
$systempackage="patched";
$attrans=array("<" => "&lt;", ">" => "&gt;", "&" => "&amp;", "@" => $st_atmask);
$trans=array("<" => "&lt;", ">" => "&gt;", "&" => "&amp;");
$antislash=array("/" => "-");
$at=array("@" => $st_atmask);
$atback=array($st_atmask => "@");
$st_postwait=30;

/*kontrola blokovani ip*/
if($administration_indicator!=true)
$addr=$_SERVER['REMOTE_ADDR'];
$blockedips=@mysql_query("SELECT adress FROM `".tabprefix."-blockedip`");
while($blockedip=@mysql_fetch_array($blockedips)){
  $blockedip_match=strpos("##".$addr, $blockedip['adress']);
  if($blockedip_match==2){exit;}
}


}
?>
