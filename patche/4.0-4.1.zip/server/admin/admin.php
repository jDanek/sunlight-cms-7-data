<?php
include("check.php");
include("header.php");

/*-----admin funkce-----*/

  /*kontrola existence dat*/
  function data_exists($input){
  if($input==""){
  echo "
  <script type='text/javascript' language='javascript'>
  document.location='admin.php?pg=404';
  </script>
  <noscript>
  ".lang('admin_404_p', 'r')."
  </noscript>
  </body>
  </html>
  ";
  exit;
  }
  }
  
  /*vypis hlasky o zadnem obsahu*/
  function content_exists($input){
  if($input==0){lang('admin_global_nokit', 'e');}
  }


?>

<script type="text/javascript" language="javascript">
function ask(){
if(!confirm('<?php lang('global_msg_doask', 'e'); ?>')){return false;}
}
</script>

<div id="container">
<a href="../" target="_blank" title="<?php lang('admin_icons_showmain', 'e'); ?>" alt="<?php lang('admin_icons_showmain', 'e'); ?>"><img src="pics/icon_showmain.gif" class="micon"></a>
<a href="admin.php" target="_blank" title="<?php lang('admin_icons_newwin', 'e'); ?>" alt="<?php lang('admin_icons_newwin', 'e'); ?>"><img src="pics/icon_newwin.gif" class="micon"></a>
<a href="admin.php?pg=help" title="<?php lang('admin_icons_help', 'e'); ?>" alt="<?php lang('admin_icons_help', 'e'); ?>"><img src="pics/icon_help.gif" class="micon"></a>
<div id="container-padding">

<!--logo-->
<div id="logo"><span><a><?php echo $login_name; ?></a> | <a href="logout.php"><?php lang('admin_logout', 'e'); ?></a></span></div>

<!--menu-->
<div id="menu">
&nbsp;

<?php
/*spolecne polozky home a sprava obsahu*/
echo "
<a href='admin.php?pg=home'>".lang('admin_mainmenu_home', 'r')." |</a>
<a href='admin.php?pg=content'>".lang('admin_mainmenu_content', 'r')." |</a>
";

/*sprava uzivatelu pro adminy*/
if($login_rights==2){echo "\n<a href='admin.php?pg=users'>".lang('admin_mainmenu_users', 'r')." |</a>";}

/*nastaveni systemu a blokovani pro hlavniho admina*/
if($login_id==0){
echo "
<a href='admin.php?pg=settings'>".lang('admin_mainmenu_settings', 'r')." |</a>
<a href='admin.php?pg=blocking'>".lang('admin_mainmenu_blocking', 'r')." |</a>
";
}

/*upload*/
if($login_rights==2 or $st_redcanup==1){echo "\n<a href='admin.php?pg=upload'>".lang('admin_mainmenu_upload', 'r')." |</a>";}

echo "\n<a href='admin.php?pg=help'>".lang('admin_mainmenu_help', 'r')." |</a>";
?>

</div>


<!--content-->
<div id="content">

<?php
/*vlozeni dle pg*/
if(isset($_GET['pg'])){

/*nacteni parametru pg*/
$pg=$_GET['pg'];
$pg=anchor($pg, false);

$accessgranted=true;
/*pristupova prava redaktoru*/
if($login_rights==1){
  switch($pg){
  case "upload": if($st_redcanup!=1){$accessgranted=false;} break;
  case "blocking": $accessgranted=false; break;
  case "settings": $accessgranted=false; break;
  case "users": $accessgranted=false; break;
  case "users-list": $accessgranted=false; break;
  case "content-newsection": $accessgranted=false; break;
  case "content-deletesection": $accessgranted=false; break;
  case "content-editsection": $accessgranted=false; break;
  case "content-editsection_a": $accessgranted=false; break;
  case "content-newcategory": $accessgranted=false; break;
  case "content-deletecategory": $accessgranted=false; break;
  case "content-editcategory": $accessgranted=false; break;
  case "content-editcategory_a": $accessgranted=false; break;
  case "content-menuanchor": $accessgranted=false; break;
  case "content-menuorder": $accessgranted=false; break;
  case "content-menuorder_manual": $accessgranted=false; break;
  case "content-editbook": $accessgranted=false; break;
  case "content-editbook_a": $accessgranted=false; break;
  case "content-deletebook": $accessgranted=false; break;
  case "content-newbox": $accessgranted=false; break;
  case "content-editbox": $accessgranted=false; break;
  case "content-editbox_a": $accessgranted=false; break;
  case "content-deletebox": $accessgranted=false; break;
  case "content-orderbox": $accessgranted=false; break;
  }
}

/*pristupova prava adminu*/
if($login_id!=0){
  switch($pg){
  case "blocking": $accessgranted=false; break;
  case "settings": $accessgranted=false; break;
  case "users-massemail": $accessgranted=false; break;
  case "content-newbox": $accessgranted=false; break;
  case "content-editbox": $accessgranted=false; break;
  case "content-editbox_a": $accessgranted=false; break;
  case "content-deletebox": $accessgranted=false; break;
  case "content-orderbox": $accessgranted=false; break;
  }
}

/*pristupova prava k souborum _inc*/
if(substr($pg, 0, 4)=="_inc"){
$accessgranted=false;
}
else{
if($accessgranted!=false){$accessgranted=true;}
}

/*pridani cesty k parametru pg a vlozeni*/
$pg="modules/$pg.inc";

  if(file_exists($pg)){

    if($accessgranted==true){
    include($pg);
    }
    else{
    echo "<b>".lang('global_denied', 'r')."</b>";
    }

  }
  else{
  include("modules/home.inc");
  }

}
else{
include("modules/home.inc");
}

?>

</div>


</div>
</div>

<!--copyright-->
<div id="copyright"><?php lang('admin_global_copyright', 'e'); ?></div>

</body>
</html>

<?php @mysql_close($connection) ?>
