<?php

@mysql_query("INSERT INTO `".tabprefix."-boxcontent` VALUES (999, -99, 1, 0, 'Menu', 0, '<!--noboxpadding-->\n<!--hcm:menu:start--><!--hcm:menu:end-->');");
@mysql_query("INSERT INTO `".tabprefix."-settings` VALUES ('showmail', '1');");

?>
