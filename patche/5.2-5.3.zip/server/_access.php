<?php


/*----pristupove udaje k mysql----*/
$c_server="server"; //server
$c_user="uzivatel"; //uzivatel
$c_password="heslo"; //heslo
$c_database="databaze"; //databaze
$c_tabprefix="sunlight"; //prefix v nazvu tabulek


/*----nastaveni----*/
$checktables=true; //kontrolovat existenci tabulek
$checkreferer=true; //kontolovat referer pro formulare
$gzip=false; //zapnout gzip kompresi


?>
