<?php

$rootpath=array("path"=>"../../");
include("../../_connect.php");

session_start();
if(!isset($_SESSION[systemuid.'login_aindicator'])){exit;}

$moduletitle="admin_forms_preview";
include("../../modules/moduleheader.php");

$vid=$_GET['vid'];
$vid=intval($vid);

?>

<body>

<div class="board">
<div class="board-padding">

<h1><?php lang('admin_forms_preview', 'e'); ?></h1>

<?php
echo parsehcm("[hcm:vote]$vid,150,none[/hcm:vote]");
?>

</div>
</div>

</body>
</html>
