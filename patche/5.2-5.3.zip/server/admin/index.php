<?php

$rootpath=array("path"=>"../");
$indicators['administration']=1;
include ("../_connect.php");
include("header.php");

/*chybne heslo*/
if(isset($_GET['wrong'])){$msg=lang('global_msg_wrongpass'); include("../modules/msg.php");}

?>

<br />
<div id="loginboard">
<div id="loginboard-padding">

<h1><?php lang('admin_title', 'e'); ?></h1>
<h3><?php lang('global_enterlogin', 'e'); ?></h3><br />

<?php if(isset($_GET['out'])){echo "<div class='msg'>".lang('global_msg_logoutdone')."</div><br />";} ?>

<form action="login.php" method="post" name="form" onsubmit="document.form.cryptedpass.value=hex_md5(document.form.password.value);document.form.password.value='';">

<script type="text/javascript" src="../modules/md5.js">
</script>

<script type="text/javascript">
//<![CDATA[
document.write("<input type='hidden' name='crypted' value='1' />");
document.write("<input type='hidden' name='cryptedpass' value='' />");
//]]>
</script>
<noscript>
<input type="hidden" name="md5crypted" value="0" />
</noscript>

<table>

<tr>
<td><?php lang('global_user', 'e'); ?>&nbsp;&nbsp;</td>
<td><input type="text" size="20" name="name" /></td>
</tr>

<tr>
<td><?php lang('global_pass', 'e'); ?></td>
<td><input type="password" size="20" name="password" /></td>
</tr>

<tr>
<td></td>
<td><input type="submit" value="<?php lang('global_continue', 'e'); ?> &gt;" /></td>
</tr>

</table>
</form>

<a href="../">&lt; <?php lang('global_backtomain', 'e'); ?></a>

</div>
</div>

<div id="loginboard-copyright"><?php lang('admin_global_copyright', 'e'); ?></div>

</body>
</html>
