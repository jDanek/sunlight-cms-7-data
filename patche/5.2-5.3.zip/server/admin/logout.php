<?php

if(!isset($indicators['securitylogout'])){
$rootpath=array("path"=>"../");
include("../_connect.php");
}

session_start();
unset($_SESSION[systemuid.'login_aindicator']);
unset($_SESSION[systemuid.'login_aid']);

if(!isset($indicators['securitylogout'])){
header("location: index.php?out");
exit;
}

?>
