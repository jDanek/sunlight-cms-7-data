<?php
echo "&lt; <a href='".referer(true)."'>".lang('global_goback')."</a><br /><br />";
lang('bbcode_help_page', 'e');
?>
