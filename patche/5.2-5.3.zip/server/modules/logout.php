<?php

if(!isset($indicators['securitylogout'])){
$rootpath=array("path"=>"../");
include("../_connect.php");
}

session_start();
unset($_SESSION[systemuid.'login_indicator']);
unset($_SESSION[systemuid.'login_id']);
unset($_SESSION[systemuid.'login_name']);
unset($_SESSION[systemuid.'login_rights']);

if(!isset($indicators['securitylogout'])){
  $referer=$_SERVER['HTTP_REFERER'];
  if($referer!="" and !ismodule($referer)){header("location: $referer");}
  else{header("location: ../");}
  exit;
}

?>
