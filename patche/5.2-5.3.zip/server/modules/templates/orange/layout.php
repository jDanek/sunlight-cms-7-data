<?php echo "<"; ?>?xml version="1.0" encoding="windows-1250"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="cs">
<head>
<?php include("modules/head.php"); ?>
</head>

<body>

<div id="border-top"></div>
<div id="border-middle">
<div id="border-middle-padding">

<!--logo-->
<div id="usermenu"><?php include("modules/usermenu.php"); ?></div>
<div id="logo-border"><div id="logo"><a href="./" title="<?php echo $st_title; ?>"></a></div></div>
<div id="logo-line">&nbsp;</div>


  <!--column-first-->
  <div id="column-first">
  <div id="column-first-padding">
  <?php include("modules/boxes.php"); ?>
  </div>
  </div>

  <!--column-main-->
  <div id="column-main">
  <div id="column-main-padding">
  <?php include("modules/content.php"); ?>
  </div>
  </div>

<div class="cleaner"></div>



</div>
</div>
<div id="border-bottom"></div>

<!--copyright-->
<div id="copyright">
<div id="copyright-padding">
<?php lang('global_copyright', 'e'); ?>
</div>
</div>

</body>
</html>
