<?php

/*nastaveni*/
$rootpath=array("path"=>"../../");
include("../../_connect.php");
if($st_artprint!=1){exit;}

/*nacteni clanku*/
if(isset($_GET['art'])){
$art=intval($_GET['art']);
$adata=@mysql_query("SELECT * FROM `".tabprefix."-articles` WHERE id=$art");
$adata=@mysql_fetch_array($adata);

  if($adata['comment']=="" or ($a_content['date']>time() and !isset($_SESSION[systemuid.'login_aindicator']))){
  lang('global_wrongrequest', 'e');
  exit;
  }

/*-----nacteni autora-----*/
$a_author=@mysql_query("SELECT name,realname FROM `".tabprefix."-users` WHERE id=".$adata['author']);
$a_author=@mysql_fetch_array($a_author);
if($st_artrealname==1 and $a_author['realname']!=""){$authoranchor=$a_author['realname'];}
else{$authoranchor=$a_author['name'];}

/*-----vyhodnoceni obsahu-----*/
if($st_arthcm==1){$a_code=content_editor_process(parsehcm($adata['code']));}
else{$adata['code']=content_editor_process($adata['code']);}

}
else{
lang('global_wrongrequest', 'e');
exit;
}

/*vlozeni hlavicky*/
$printmode=true;
$moduletitle_custom=true;
$moduletitle=$adata['title'];
$moduleheader_code="<base href=\"$st_serverurl/\" />\n";
include("../moduleheader.php");

?>


<body>

<?php
echo "<b>".lang('article_author')."</b>: $authoranchor | <b>".lang('article_posted')."</b>: ".formatdate($adata['date'])." | <b>".lang('global_adress')."</b>: $st_serverurl/".artrewrite($art, $adata['title'], false)."<hr /><h1>".$adata['title']."</h1><p id='perex'>".$adata['perex']."</p>".$adata['code'];
?>

</body>
</html>
