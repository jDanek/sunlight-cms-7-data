<?php

/*nacteni cid*/
if(isset($_GET['cid'])){
$cid=$_GET['cid'];
$cid=intval($cid);
}
else{
$cid=-1;
}
$done=0;


/*kontrola loginu*/

  /*nacteni autora*/
  $c_data=@mysql_query("SELECT author,date FROM `".tabprefix."-comments` WHERE id=$cid");
  $c_data=@mysql_fetch_array($c_data);
  
  $c_author=$c_data['author'];
  if($c_author!=-2){
  $c_author_rights=@mysql_query("SELECT rights FROM `".tabprefix."-users` WHERE id=$c_author");
  $c_author_rights=@mysql_fetch_array($c_author_rights);
  $c_author_rights=$c_author_rights['rights'];
  }
  else{
  $c_author_rights=0;
  }

  /*smazani z db*/
  if(postaccess_allow($c_author, $c_author_rights, $c_data['date'])){
  @mysql_query("DELETE FROM `".tabprefix."-comments` WHERE id=$cid");
  $done=1;
  }


include("msg.php");

?>


<h1><?php lang('comment_delete', 'e'); ?></h1>
<div class="hr"><hr /></div>

<?php
if($done!=1){
echo "<b>".lang('global_denied')."</b>";
}
else{
echo "<p>".lang('global_actiondone')."<br />&lt; <a href='".referer(true)."'>".lang('global_goback')."</a></p>";
}
?>
