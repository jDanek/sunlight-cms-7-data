<?php

/*nacteni parametru*/
if(isset($_GET['a'])){
$a=$_GET['a'];
$a=intval($_GET['a']);
}
else{
$a=-1;
}

$vid=$_GET['vid'];
$vid=intval($vid);
$vdata=@mysql_query("SELECT question,answers,votes,ipcache,locked FROM `".tabprefix."-votes` WHERE id=$vid");
$vdata=@mysql_fetch_array($vdata);
if($vdata['ipcache']!=""){$ipcache=explode("|", $vdata['ipcache']);}else{$ipcache=array();}
$ip=$_SERVER['REMOTE_ADDR'];

  $continue=false;
  if($vdata['question']!="" and $vdata['locked']==0){
  $answers=explode("#", $vdata['answers']);
    if($a>=0 and $a<=count($answers)-1){
    $votes=explode("#", $vdata['votes']);
    $votes[$a]++;
    $votes=implode("#", $votes);
    $continue=true;
    }
  }

?>


<h1><?php echo lang('vote_title'); ?></h1>
<div class="hr"><hr /></div>
<p>

<?php
if($continue==true){

$v_log=$ipcache;
$v_lognum=0;
$v_logfound=false;
while($v_lognum<=count($v_log)){
$v_logitem=$v_log[$v_lognum];
if($v_logitem==$ip){$v_logfound=true; break;}
$v_lognum++;
}

  /*vlozeni do logu a pripocteni pocitadla*/
  if($v_logfound==false){

  $n_ipcache="";
  for($step=-1; $step<=497 and $step<=count($ipcache); $step++){

    if($step!=-1){
    if($ipcache[$step]!=""){$n_ipcache_item=$ipcache[$step];}else{continue;}
    }
    else{
    $n_ipcache_item=$ip;
    }
  
  $n_ipcache.=$n_ipcache_item."|";
  }

  @mysql_query("UPDATE `".tabprefix."-votes` SET ipcache='$n_ipcache'");
  @mysql_query("UPDATE `".tabprefix."-votes` SET votes='$votes' WHERE id=$vid");
  lang('global_rate_accepted', 'e');
  }
  else{
  lang('global_rate_denied', 'e');
  }


}
else{
lang('global_invalidinput', 'e');
}

echo "<br />&lt; <a href='".referer(true)."'>".lang('global_goback')."</a>";
?>

</p>
