<?php

/*zpracovani postdat*/
if(isset($_POST['mod_mode']) and $st_lostpass==1){

$postmode=intval($_POST['mod_mode']);

  switch($postmode){
  
  case 1:
  $postemail=$_POST['mod_email'];
  $postemail=strtr($postemail, $trans);
  $codecheck=$_POST['mod_codecheck'];
  $codecheckr=code_decode($_POST['mod_codecheckr']);
  if(validate_email($postemail) and $codecheck==$codecheckr){
  $userdata=@mysql_query("SELECT name,password FROM `".tabprefix."-users` WHERE email='$postemail'");
  $userdata=@mysql_fetch_array($userdata);
    if($userdata['name']!=""){
    
    $mailtext_trans=array("*user*"=>$userdata['name'], "*url*"=>$st_serverurl, "*time*"=>date("j.n. Y H:i"), "*ip*"=>$_SERVER['REMOTE_ADDR']);
    $mailtext=lang('lostpassword_email_text1');
    $mailtext=strtr($mailtext, $mailtext_trans);
    $maillink=$st_serverurl."/".antiampersands(modrewrite("lostpassword", false, true, false))."mode=2&ph=".strrev($userdata['password'])."&ts=".strrev(time())."&em=".$postemail;
    $mailbody=$mailtext."\n\n".$maillink;
    @mail($postemail, lang('lostpassword_email_subject1'), $mailbody, "Content-Type:text/plain;charset=win-1250\n");
    $msg=lang('lostpassword_msg_emailsent1');

    }
    else{
    $msg=lang('lostpassword_msg_bademail');
    }
  }
  else{
  $msg=lang('global_msg_someempty');
  }
  break;

  case 2:
  $forcemode1=true;
  $postpasshash=strtr($_POST['mod_ph'], $trans);
  $posttimestamp=$_POST['mod_ts'];
  $postemail=strtr($_POST['mod_em'], $trans);
  
  if(validate_email($postemail)){
  $userdata=@mysql_query("SELECT name,email,password FROM `".tabprefix."-users` WHERE email='$postemail'");
  $userdata=@mysql_fetch_array($userdata);

  $valid=true;
  if(strrev($postpasshash)!=$userdata['password']){$valid=false;}
  if($postemail!=$userdata['email']){$valid=false;}
  if(time()-strrev($posttimestamp)>86400){$valid=false;}

    if($valid==true){
    $newpass=password_generate(8);
    @mysql_query("UPDATE `".tabprefix."-users` SET password='".md5($newpass)."' WHERE email='$postemail'");
    $mailtext_trans=array("*user*"=>$userdata['name'], "*url*"=>$st_serverurl);
    $mailtext=lang('lostpassword_email_text2');
    $mailtext=strtr($mailtext, $mailtext_trans);
    $mailbody=$mailtext."\n\n".lang('lostpassword_email_newpass').":\n".$newpass;
    @mail($postemail, lang('lostpassword_email_subject2'), $mailbody, "Content-Type:text/plain;charset=win-1250\n");
    $msg=lang('lostpassword_msg_emailsent2');
    }
    else{
    $msg=lang('lostpassword_invalidlink');
    }

  }
  else{
  $msg=lang('global_wrongrequest');
  }
  break;

  }

}


/*nacteni mode*/
$mode=$_GET['mode'];
$mode=intval($mode);
if(!($mode==1 or $mode==2)){$mode=1;}
if($forcemode1==true){$mode=1;}

include("msg.php");
?>


<h1><?php lang('lostpassword_title', 'e'); ?></h1>
<p><?php lang("lostpassword_p_$mode", 'e'); ?></p>

<?php

switch($mode){

  case 1:
  $codecheck=code_generate(4);
  echo "
  <form action='".modrewrite("lostpassword", false, true)."mode=1' method='post'>
  <input type='hidden' name='mod_mode' value='1' />
  <input type='hidden' name='mod_codecheckr' value='$codecheck' />
  <table>
  
  <tr>
  <td><b>".lang('global_youremail')."</b></td>
  <td><input type='text' name='mod_email' size='24' maxlength='128' /></td>
  </tr>

  <tr'>
  <td><b>".lang('global_codecheck')."</b></td>
  <td><input type='text' name='mod_codecheck' size='12' maxlength='8' />&nbsp;<img src='modules/kod.php?n=".$codecheck."' alt='".lang('global_codecheckhelp')."' title='".lang('global_codecheckhelp')."' class='codecheck' /></td>
  </tr>
  
  <tr><td></td>
  <td><input type='submit' value='".lang('global_continue')."' /></td>
  </tr>
  
  </table>
  </form>
  ";
  break;

  case 2:
  $getpasshash=strtr($_GET['ph'], $trans);
  $gettimestamp=$_GET['ts'];
  $getemail=strtr($_GET['em'], $trans);
  
  if(validate_email($getemail)){
  $userdata=@mysql_query("SELECT name,email,password FROM `".tabprefix."-users` WHERE email='$getemail'");
  $userdata=@mysql_fetch_array($userdata);
  
  $valid=true;
  if(strrev($getpasshash)!=$userdata['password']){$valid=false;}
  if($getemail!=$userdata['email']){$valid=false;}
  if(time()-strrev($gettimestamp)>86400){$valid=false;}

    if($valid==true){
    echo "
    <form action='".modrewrite("lostpassword", false, true)."mode=2' method='post'>
    <input type='hidden' name='mod_ph' value='$getpasshash' />
    <input type='hidden' name='mod_ts' value='$gettimestamp' />
    <input type='hidden' name='mod_em' value='$getemail' />
    <input type='hidden' name='mod_mode' value='2' />
    <table>

    <tr>
    <td><b>".lang('global_user')."</b></td>
    <td>".$userdata['name']."</td>
    </tr>

    <tr'>
    <td><b>".lang('global_email')."</b>&nbsp;</td>
    <td>".$userdata['email']."</td>
    </tr>

    <tr><td rowspan='2'><input type='submit' value='".lang('global_do')."' /></td></tr>

    </table>
    </form>
    ";
    }
    else{
    echo "<b>".lang('lostpassword_invalidlink')."</b>";
    }
  
  }
  else{
  echo "<b>".lang('global_wrongrequest')."</b>";
  }
  break;

}

?>
