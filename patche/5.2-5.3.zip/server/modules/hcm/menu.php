<?php

if($limit==true){$limit=" WHERE ord>=$lstart AND ord<=$lend ";}
else{$limit="";}

$menu=@mysql_query("SELECT * FROM `".tabprefix."-menu`".$limit."ORDER BY ord");
$mtmp="<ul class='menu'>";

while($item=@mysql_fetch_array($menu)){

  /*preskoceni neviditelnych*/
  $m_visible=$item['visible'];
  if($m_visible!=1){
  continue;
  }

  /*nacteni promennych k polozce*/
  $m_id=$item['id'];
  $m_anchor=$item['anchor'];
  $m_type=$item['type'];
  $m_sublink=$item['sublink'];
  
  /*sublink trida*/
  if($m_sublink==1){$class=" class='sublink'";}else{$class="";}
  
  /*odkaz*/
  switch($m_type){
  case 1: $linkhref=secrewrite($m_id, $m_anchor); break;
  case 2: $linkhref=catrewrite($m_id, $m_anchor, 1); break;
  case 3: $linkhref=bookrewrite($m_id, $m_anchor, 1); break;
  }

  $mtmp.="<li><a href='".root."$linkhref'$class>$m_anchor</a></li>\n";

}

$mtmp.="</ul>";

?>
