<?php
if($refer!=0){$getrefer="refer=$refer";}else{$getrefer="";}
echo "<form action=\"".modrewrite("login", false, true)."$getrefer\" method=\"post\" name=\"hcmloginform\" onsubmit=\"document.hcmloginform.cryptedpass.value=hex_md5(document.hcmloginform.password.value);document.hcmloginform.password.value='';\">";
if($loginmodulerefer==true and $_SERVER['HTTP_REFERER']!='' and $refer!=-1){echo "<input type='hidden' name='loginmodulereferer' value='".ampersands($_SERVER['HTTP_REFERER'])."' />";}
?>

<script type="text/javascript" src="<?php echo $root; ?>modules/md5.js">
</script>

<script type="text/javascript">
//<![CDATA[
document.write("<input type='hidden' name='crypted' value='1' />");
document.write("<input type='hidden' name='cryptedpass' value='' />");
//]]>
</script>
<noscript>
<input type="hidden" name="crypted" value="0" />
</noscript>

<table>

<tr>
<td><?php lang('global_user', 'e'); ?>&nbsp;</td>
<td><input type="text" size="6" name="name" /></td>
</tr>

<tr>
<td><?php lang('global_pass', 'e'); ?></td>
<td><input type="password" size="6" name="password" maxlength="255" /></td>
</tr>

<tr>
<td></td>
<td><input type="submit" value="<?php lang('global_go', 'e'); ?> &gt;" /></td>
</tr>

</table>
</form>
<br />
