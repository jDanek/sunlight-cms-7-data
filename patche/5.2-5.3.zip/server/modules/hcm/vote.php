<?php

$vdata=@mysql_query("SELECT * FROM `".tabprefix."-votes` WHERE id=$vid");
$vdata=@mysql_fetch_array($vdata);

if($vdata['question']!=""){

$answers=explode("#", $vdata['answers']);
$votes=explode("#", $vdata['votes']);

  if($vdata['locked']==0){$questtext="";}
  else{$questtext="\n<div class='vote-lockedtext'>".lang('vote_lockedtext')."</div>";}
  
  if($float!="none"){$votestyle_float="float:$float;";}else{$votestyle_float="";}
  
  $mtmp.="
  <div class='vote' style='width:".$boxwidth."px;$votestyle_float'>
  <div class='vote-border'>

  <div class='vote-question'>
  ".$vdata['question'].$questtext."
  </div>
  ";

  /*vypis odpovedi*/
  $x=0;
  $highlight=false;

    while($x<=count($answers)-1){
      if(array_sum($votes)!=0 and $votes[$x]!=0){
      $width=round(($votes[$x]/array_sum($votes))*($boxwidth-60));
      $percent=round(($votes[$x]/array_sum($votes))*100);
      }
      else{
      $width=1;
      $percent=0;
      }
    if($highlight==true){$class="2";}else{$class="1";}


    if($vdata['locked']==0){$votelink=" href='".modrewrite("vote", false, true)."vid=$vid&amp;a=$x' title='".lang('vote_vote')."'";}
    else{$votelink="";}

    $mtmp.="
    <div class='vote-answer'>
    <div class='vote-answer-padding$class'>
    <a$votelink>".$answers[$x]."</a>
    <img src='".root."modules/templates/".template."/pics/votebar.gif' class='vote-bar' width='$width' alt='$percent%' />$percent%
    </div>
    </div>
    ";

    $highlight=!$highlight;
    $x++;
    }

  $mtmp.="
  <div class='vote-total'>".lang('vote_total').": ".array_sum($votes)."</div>
  </div>
  </div>
  ";

}

?>
