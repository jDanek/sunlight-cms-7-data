<?php

/*pripojeni*/
$rootpath=array("path"=>"../");
$indicators['installmode']=1;
$indicators['ignorereferer']=1;
include("../_connect.php");

/*instalace db*/
if(isset($_POST['akce'])){

      /*provedeni sql dotazu a zprava*/
      include("db.php");
      @mysql_close($connection);
      $msg="Aktualizace MySQL datab�ze byla provedena.";

}
?>

<?php echo "<"; ?>?xml version="1.0" encoding="windows-1250"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="cs">
<head>
  <meta http-equiv="content-type" content="text/html; charset=windows-1250" />
  <title>Upgrade datab�ze verze 5.2 na 5.3</title>
</head>

<body>
<?php include("../modules/msg.php"); ?>

<h1>Upgrade datab�ze verze 5.2 na 5.3</h1>
<p>Tento skript provede p�evod tabulek verze 5.2 na verzi 5.3. Pozor!
 Aktualizovat pouze datab�zi nesta��! Je nutn� aktualizovat i syst�mov� soubory.
 V�ce informac� naleznete v souboru <i>ctimne.html</i>. Po proveden� aktualizace sma�te
 slo�ku <i>patch</i> ze serveru!!</p>
 

<h2>Upozorn�n�</h2>
<p>Tento patch byl testov�n a shled�n pln� funk�n�m, ale p�esto doporu�uji p�ed
 jeho aplikac� prov�st z�lohu datab�ze.</p>


<form action="patch.php" method="post">
<input type="hidden" name="akce" value="1" />
<input type="submit" value="Prove� &gt;" />
</form>

</body>
</html>
