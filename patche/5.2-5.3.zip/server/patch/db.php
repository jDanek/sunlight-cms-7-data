<?php

/*provedeni sql skriptu*/
@mysql_query("INSERT INTO `".tabprefix."-settings` ( `variable` , `value` ) VALUES ('smileys', '1');");
@mysql_query("INSERT INTO `".tabprefix."-settings` ( `variable` , `value` ) VALUES ('showauthorrate', '1');");
@mysql_query("INSERT INTO `".tabprefix."-settings` ( `variable` , `value` ) VALUES ('redadir', '0');");
@mysql_query("INSERT INTO `".tabprefix."-settings` ( `variable` , `value` ) VALUES ('updiracpref', '0');");
@mysql_query("INSERT INTO `".tabprefix."-settings` ( `variable` , `value` ) VALUES ('artprint', '0');");
@mysql_query("ALTER TABLE `".tabprefix."-users` ADD `massmail` TINYINT NOT NULL ;");
@mysql_query("UPDATE `".tabprefix."-users` SET massmail=1;");

?>
