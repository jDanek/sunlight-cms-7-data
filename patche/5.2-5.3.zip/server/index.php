<?php

/*priprava*/
$rootpath=array("path"=>"./");
include("_connect.php");
include("modules/sessions.php");
include("modules/content_preload.php");

/*vlozeni layoutu*/
include($templatefile);

/*odpojeni*/
@mysql_close($connection);

?>
