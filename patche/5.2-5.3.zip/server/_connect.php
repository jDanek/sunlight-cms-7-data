<?php


/*-----zakazane parametry-----*/
$denied_params=array("rootpath", "indicators", "ignorereferer", "content_preload", "securitylogout", "dontchecktables", "installmode");
foreach($denied_params as $param){if(isset($_GET[$param]) or isset($_POST[$param])){exit;}}


/*-----definovani root-----*/
if(isset($rootpath['path'])){define('root', $rootpath['path']); $root=$rootpath['path'];}
else{define('root', "./"); $root="./";}


/*-----aktivace gzip-----*/
if($gzip==true){if(!ini_get('zlib.output_compression')){ob_start("ob_gzhandler");}}


/*-----vlozeni pristupovych dat-----*/
include($root."_access.php");


/*-----definovani globalni promenne prefixu-----*/
if($c_tabprefix!=""){
define('tabprefix', $c_tabprefix);
}
else{
$error="Musite zadat prefix (promenna c_tabprafix)!.";
include($root."modules/error.php");
exit;
}


/*-----pripojeni k mysql-----*/
$connection=@mysql_connect($c_server, $c_user, $c_password);
@mysql_query("set names 'cp1250'");
$db=@mysql_select_db($c_database);

  /*kontrola*/
  if(!$connection or !$db){
  $error="Pripojeni k databazi se nezdarilo, zkontrolujte pristupove udaje. Odpoved MySQL serveru muzete videt nize.";
  include($root."modules/error.php");
  echo "<pre>".mysql_error()."</pre>";
  exit;
  }


/*-----kontrola existence tabulek-----*/
if($checktables==true and !isset($indicators['installmode'])){
$controldatabase=@mysql_query("SHOW TABLES FROM $c_database");
$controldatabase_matches=0;
while($controldatabase_item=mysql_fetch_array($controldatabase)){
switch($controldatabase_item[0]){
case tabprefix."-articles":
case tabprefix."-bans":
case tabprefix."-books":
case tabprefix."-boxes":
case tabprefix."-sections":
case tabprefix."-comments":
case tabprefix."-menu":
case tabprefix."-sboxes":
case tabprefix."-sboxes-posts":
case tabprefix."-settings":
case tabprefix."-users":
case tabprefix."-votes":
$controldatabase_matches++; break;
}
}
}
else{
$controldatabase_matches=12;
}

  /*vypis pripadne hlasky*/
  if($controldatabase_matches!=12){
  $error="Zvolena databaze $c_database neobsahuje vsechny tabulky systemu (nalezeno $controldatabase_matches z 12)! Prosim zkontrolujte, zda je databaze korektne nainsalovana a/nebo zda jste nastavili spravny prefix.";
  include($root."modules/error.php");
  exit;
  }

if(!isset($indicators['installmode'])){

  /*-----kontrola, zda neexistuje slozka install-----*/
  if(file_exists(root."install/")){
  $error="Prosim zkontrolujte, zda se adresar <i>install</i> nenachazi na serveru a pripadne jej smazte";
  include($root."modules/error.php");
  exit;
  }


  /*-----kontrola, zda neexistuje slozka patch-----*/
  if(file_exists(root."patch/")){
  $error="Prosim zkontrolujte, zda se adresar <i>patch</i> nenachazi na serveru a pripadne jej smazte";
  include($root."modules/error.php");
  exit;
  }

}


/*-----nacteni nastaveni a systemovych promennych, kontrola nastaveni -----*/
include($root."modules/setload.php");

  /*-----kontrola refereru-----*/
  if($checkreferer==true and !isset($indicators['ignorereferer'])){
    if(count($_POST)!=0){
    if(!strpos("#".$_SERVER['HTTP_REFERER'], $st_serverurl)){unset($_POST);}
    }
  }

  /*-----systemove promenne-----*/
  $systemversion="5.3";
  $systembuild="3";
  $attrans=array("<" => "&lt;", ">" => "&gt;", "&" => "&amp;", "\"" => "&quot;", "@" => $st_atmask);
  $trans=array("<" => "&lt;", ">" => "&gt;", "&" => "&amp;", "\"" => "&quot;");
  $antislash=array("/" => "-", "\\"=>"-");
  $at=array("@" => $st_atmask);
  $atback=array($st_atmask => "@");

    /*globalni*/
    define("rewritesuffix", ".html");
    define("secprefix", "sekce");
    define("catprefix", "kategorie");
    define("artprefix", "clanek");
    define("bookprefix", "kniha");
    define("modprefix", "modul");
    define("systemuid", md5($c_tabprefix)."_");

    /*-----kontrola rewrite pluginu-----*/
    if(!file_exists(root.".htaccess") and $st_rewrite==1){$st_rewrite=0;}
    define('rewrite', $st_rewrite);

    /*-----kontrola editoru-----*/
    switch($st_editor){
    case 1: if(!file_exists(root."admin/tinymce.smf")){$st_editor=0;} break;
    case 2: if(!file_exists(root."admin/texy.smf")){$st_editor=0;} break;
    }
    define('editor', $st_editor);

    /*nacteni funkci*/
    include($root."modules/funcload.php");

    /*zruseni pristupovych udaju*/
    if(!isset($indicators['installmode'])){
    unset($c_server);
    unset($c_user);
    unset($c_password);
    unset($c_database);
    }

    /*kontrola verze jazykoveho souboru*/
    if(lang('_slfver')!=$systemversion){$error="Zvoleny jazykovy soubor '$st_langfile' neni kompatibilni s touto verzi systemu!"; include($root."modules/error.php"); exit;}


/*-----motiv-----*/
$set_template=root."modules/templates/$st_template/layout.php";
if(file_exists($set_template)){$templatefile=$set_template;}
else{
$seektemplate=opendir(root."modules/templates/");
$seektemplate_index=0;
$seektemplate_array=array();
  while($seektemplate_item=readdir($seektemplate)){
  if($seektemplate_item!="." and $seektemplate_item!=".." and is_dir(root."modules/templates/$seektemplate_item") and file_exists(root."modules/templates/$seektemplate_item/layout.php")){
  $seektemplate_array[$seektemplate_index]=$seektemplate_item;
  $seektemplate_index++;
  }
  }
  if(count($seektemplate_array)!=0){$templatefile=root."modules/templates/".$seektemplate_array[0]."/layout.php"; $st_template=$seektemplate_array[0];}
  else{$templatefile=""; $st_template="";}
}
define('template', $st_template);

  /*nacteni nastaveni motivu*/
  if($st_template!=""){
  $template_config=substr($templatefile, 0, strpos($templatefile, "layout.php"));
  $template_config.="config.cfg";
  $template_config=@file_get_contents($template_config);
  $template_config=explode(",", $template_config);

    /*nacteni hodnot*/
    if(count($template_config)!=0){
    $st_boxbottom=trim($template_config[0]);
    $st_boxsecond=trim($template_config[1]);
    $st_sysver=trim($template_config[2]);
    }

    /*zpracovani hodnot*/
    if($st_sysver!=$systemversion and $st_sysver!="5.2" and !isset($indicators['administration'])){$error="Zvoleny motiv '$st_template' neni kompatibilni s touto verzi systemu!"; include($root."modules/error.php"); exit;}
    if($st_boxbottom!=1){$st_boxbottom=false;}else{$st_boxbottom=true;}
    if($st_boxsecond!=1){$st_boxsecond=false;}else{$st_boxsecond=true;}

  }
  $smajlici=getsmileys();

  /*error*/
  if($st_template=="" and !isset($indicators['administration'])){
  $error="Nebyl nalezen zadny motiv vzhledu (slozka modules/templates/)!";
  include($root."modules/error.php");
  exit;
  }


/*-----kontrola ip, blokovani-----*/
if(!isset($indicators['administration']))
$addr=$_SERVER['REMOTE_ADDR'];
$blockedips=@mysql_query("SELECT adress FROM `".tabprefix."-bans`");
while($blockedip=@mysql_fetch_array($blockedips)){
  $blockedip_match=strpos("##".$addr, $blockedip['adress']);
  if($blockedip_match==2){exit;}
}

?>
