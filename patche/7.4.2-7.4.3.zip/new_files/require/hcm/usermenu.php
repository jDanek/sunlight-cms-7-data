<?php
/*--- kontrola jadra ---*/
if(!defined('_core')) {
    exit;
}

/*--- definice funkce modulu ---*/
function _HCM_usermenu()
{
    return _templateUserMenu(true);
}

?>