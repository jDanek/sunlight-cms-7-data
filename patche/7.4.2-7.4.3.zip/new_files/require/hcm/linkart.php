<?php
/*--- kontrola jadra ---*/
if(!defined('_core')) {
    exit;
}

/*--- definice funkce modulu ---*/
function _HCM_linkart($id = null, $text = null, $nove_okno = false)
{
    $id = intval($id);
    $query = mysql_query("SELECT title FROM `"._mysql_prefix."-articles` WHERE id=".$id);
    if(isset($nove_okno) and _boolean($nove_okno)) {
        $target = " target='_blank'";
    } else {
        $target = "";
    }
    if(mysql_num_rows($query) != 0) {
        $query = mysql_fetch_assoc($query);
        if(isset($text) and $text != "") {
            $query['title'] = $text;
        }
        return "<a href='"._linkArticle($id)."'".$target.">".$query['title']."</a>";
    }
}

?>