<?php

// pripojeni k db
require 'access.php';
$con = @mysql_connect($server, $user, $password);
if(!is_resource($con)) die('Nepodarilo se pripojit k databazi!<br>'.mysql_error());
if(!@mysql_select_db($database)) die('Nepodarilo se zvolit aktualni databazi!');

// zjisteni verze db
$q = mysql_query('SELECT val FROM `'.$prefix.'-settings` WHERE var=\'dbversion\'');
if(!is_resource($q) || mysql_num_rows($q) !== 1) die('Nepodarilo se zjistit verzi databaze!');
$q = mysql_fetch_assoc($q);
$q = $q['val'];

// kontrola verze db
if($q !== '7.4.0') {
    if($q === '7.4.3') die('Patch byl jiz aplikovan, smazte soubor patch.php!');
    die('Nespravna verze databaze!');
}

// priprava sql dotazu
$sql = array();
$sql[] = 'ALTER TABLE `'.$prefix.'-posts` ADD `locked` BOOL NOT NULL DEFAULT \'0\'';
$sql[] = 'ALTER TABLE `'.$prefix.'-posts` ADD `bumptime` INT NOT NULL DEFAULT \'0\', ADD INDEX ( bumptime )';
//$sql[] = 'UPDATE `'.$prefix.'-posts` SET bumptime=time WHERE type=5 AND xhome=-1';
$sql[] = 'ALTER TABLE `'.$prefix.'-groups` ADD `locktopics` BOOL NOT NULL AFTER `unlimitedpostaccess`';
$sql[] = 'UPDATE `'.$prefix.'-groups` SET `locktopics` = \'1\' WHERE `id` =1';
$sql[] = 'UPDATE `'.$prefix.'-settings` SET `val` = \'7.4.3\' WHERE `var` = \'dbversion\'';
$sql[] = 'ALTER TABLE `'.$prefix.'-articles` CHANGE `id` `id` INT( 11 ) NOT NULL AUTO_INCREMENT ';
$sql[] = 'ALTER TABLE `'.$prefix.'-boxes` CHANGE `id` `id` INT( 11 ) NOT NULL AUTO_INCREMENT ';
$sql[] = 'ALTER TABLE `'.$prefix.'-groups` CHANGE `id` `id` INT( 11 ) NOT NULL AUTO_INCREMENT ';
$sql[] = 'ALTER TABLE `'.$prefix.'-images` CHANGE `id` `id` INT( 11 ) NOT NULL AUTO_INCREMENT ';
$sql[] = 'ALTER TABLE `'.$prefix.'-iplog` CHANGE `id` `id` INT( 11 ) NOT NULL AUTO_INCREMENT ';
$sql[] = 'ALTER TABLE `'.$prefix.'-messages` CHANGE `id` `id` INT( 11 ) NOT NULL AUTO_INCREMENT ';
$sql[] = 'ALTER TABLE `'.$prefix.'-polls` CHANGE `id` `id` INT( 11 ) NOT NULL AUTO_INCREMENT ';
$sql[] = 'ALTER TABLE `'.$prefix.'-posts` CHANGE `id` `id` INT( 11 ) NOT NULL AUTO_INCREMENT ';
$sql[] = 'ALTER TABLE `'.$prefix.'-root` CHANGE `id` `id` INT( 11 ) NOT NULL AUTO_INCREMENT ';
$sql[] = 'ALTER TABLE `'.$prefix.'-sboxes` CHANGE `id` `id` INT( 11 ) NOT NULL AUTO_INCREMENT';
$sql[] = 'UPDATE `'.$prefix.'-users` SET `id`=2147483646 WHERE `id`=0';
$sql[] = 'ALTER TABLE `'.$prefix.'-users` CHANGE `id` `id` INT( 11 ) NOT NULL AUTO_INCREMENT';
$sql[] = 'UPDATE `'.$prefix.'-users` SET `id`=0 WHERE `id`=2147483646';
$sql[] = 'ALTER TABLE `'.$prefix.'-users` AUTO_INCREMENT=0';
$sql[] = 'INSERT INTO `'.$prefix.'-settings` (`var` ,`val`)VALUES (\'modrewrite_type\', \'0\')';
$sql[] = 'ALTER TABLE `'.$prefix.'-images` ADD INDEX(`full`(8))';
$sql[] = 'INSERT INTO `'.$prefix.'-settings` (`var` ,`val`)VALUES (\'galuploadresize_w\', \'750\'), (\'galuploadresize_h\', \'565\')';
$sql[] = 'ALTER TABLE `'.$prefix.'-images` ADD `in_storage` BOOL NOT NULL DEFAULT \'0\', ADD INDEX ( in_storage )';
$sql[] = 'ALTER TABLE `'.$prefix.'-images` CHANGE `ord` `ord` INT NOT NULL ';
$sql[] = 'ALTER TABLE `'.$prefix.'-settings` CHANGE `var` `var` VARCHAR( 24 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL';
$sql[] = 'ALTER TABLE `'.$prefix.'-settings` ADD PRIMARY KEY ( `var` )';
$sql[] = 'INSERT INTO `'.$prefix.'-settings` (`var` ,`val`)VALUES (\'codemirror\', \'1\')';

// provedeni
for($i = 0; isset($sql[$i]); ++$i) {
    mysql_query($sql[$i]);
    $error = mysql_error();
    if(!empty($error)) die('Chyba pri aktualizaci databaze!<br><br>Chyba:'.$error.'<br><br>SQL dotaz:<br>'.$sql[$i]);
}

// doplneni bumptime u temat ve foru
$q = mysql_query("SELECT id,time,(SELECT time FROM `".$prefix."-posts` WHERE xhome=`_topic`.`id` ORDER BY id DESC LIMIT 1) AS `new_bumptime` FROM `".$prefix."-posts` AS `_topic` WHERE type=5 AND xhome=-1 AND bumptime=0");
while($t = mysql_fetch_assoc($q)) mysql_query("UPDATE `".$prefix."-posts` SET bumptime=".(isset($t["new_bumptime"]) ? $t["new_bumptime"] : $t["time"])." WHERE id=".$t["id"]);

// ok
echo 'OK! Databaze byla aktualizovana na verzi 7.4.3.';
if(!@unlink(__FILE__)) echo '<br>Smazte soubor patch.php!';

?>