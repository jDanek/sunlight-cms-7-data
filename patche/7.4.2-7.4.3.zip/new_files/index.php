<?php
/*---- inicializace jadra ----*/

define('_indexroot', './');
require (_indexroot."core.php");
require (_indexroot."/require/functions-template.php");


/*---- vystup ----*/

$notpublic_form = false;
$notpublic_form_wholesite = false;

/*-- aplikovani nastaveni neverejnych stranek --*/
if(_publicAccess(!_notpublicsite) or (isset($_GET['m']) and in_array($_GET['m'], array("login", "reg", "lostpass")))) {


    /*-- modul --*/
    if(isset($_GET['m'])) {
        if(_loginindicator or !in_array($_GET['m'], array("settings", "editpost", "messages"))) {

            define('_indexOutput_ptype', 'module');
            switch($_GET['m']) {

                    //prihlaseni
                case "login":
                    define('_indexOutput_url', "index.php?m=login");
                    require (_indexroot."require/mod/login.php");
                    define('_indexOutput_content', $module);
                    define('_indexOutput_title', $_lang['login.title']);
                    break;

                    //seznam uzivatelu
                case "ulist":
                    if(_ulist) {
                        define('_indexOutput_url', "index.php?m=ulist");
                        require (_indexroot."require/mod/ulist.php");
                        define('_indexOutput_content', $module);
                        define('_indexOutput_title', $_lang['admin.users.list']);
                    }
                    break;

                    //registrace
                case "reg":
                    if(_registration and !_loginindicator) {
                        define('_indexOutput_url', "index.php?m=reg");
                        require (_indexroot."require/mod/reg.php");
                        define('_indexOutput_content', $module);
                        define('_indexOutput_title', $_lang['mod.reg']);
                    }
                    break;

                    //ztracene heslo
                case "lostpass":
                    if(_lostpass and !_loginindicator) {
                        define('_indexOutput_url', "index.php?m=lostpass");
                        require (_indexroot."require/mod/lostpass.php");
                        define('_indexOutput_content', $module);
                        define('_indexOutput_title', $_lang['mod.lostpass']);
                    }
                    break;

                    //profil
                case "profile":
                    define('_indexOutput_url', "index.php?m=profile");
                    require (_indexroot."require/mod/profile.php");
                    define('_indexOutput_content', $module);
                    define('_indexOutput_title', $_lang['mod.profile']);
                    break;

                    //clanky autora
                case "profile-arts":
                    define('_indexOutput_url', "index.php?m=profile-arts");
                    require (_indexroot."require/mod/profile-arts.php");
                    define('_indexOutput_content', $module);
                    define('_indexOutput_title', $_lang['mod.profile.arts']);
                    break;

                    //prispevky uzivatele
                case "profile-posts":
                    define('_indexOutput_url', "index.php?m=profile-posts");
                    require (_indexroot."require/mod/profile-posts.php");
                    define('_indexOutput_content', $module);
                    define('_indexOutput_title', $_lang['mod.profile.posts']);
                    break;

                    //nastaveni
                case "settings":
                    define('_indexOutput_url', "index.php?m=settings");
                    require (_indexroot."require/mod/settings.php");
                    define('_indexOutput_content', $module);
                    define('_indexOutput_title', $_lang['mod.settings']);
                    break;

                    //uprava prispevku
                case "editpost":
                    define('_indexOutput_url', "index.php?m=editpost");
                    require (_indexroot."require/mod/editpost.php");
                    define('_indexOutput_content', $module);
                    define('_indexOutput_title', $_lang['mod.editpost']);
                    break;

                    // uzamknuti prispevku (forum topic)
                case "locktopic":
                    define('_indexOutput_url', "index.php?m=locktopic");
                    require (_indexroot."require/mod/locktopic.php");
                    define('_indexOutput_content', $module);
                    define('_indexOutput_title', $_lang['mod.locktopic']);
                    break;

                    //vzkazy
                case "messages":
                    if(_messages) {
                        define('_indexOutput_url', "index.php?m=messages");
                        require (_indexroot."require/mod/messages.php");
                        define('_indexOutput_content', $module);
                        define('_indexOutput_title', $_lang['mod.messages']);
                    }
                    break;

                    //vyhledavani
                case "search":
                    if(_search) {
                        define('_indexOutput_url', "index.php?m=search");
                        require (_indexroot."require/mod/search.php");
                        define('_indexOutput_content', $module);
                        define('_indexOutput_title', $_lang['mod.search']);
                    }
                    break;

                    //tema
                case "topic":
                    //_indexOutput_url je definovano uvnitr:
                    require (_indexroot."require/mod/topic.php");
                    define('_indexOutput_content', $module);
                    if($forumtitle != "" and $topictitle != "") {
                        define('_indexOutput_title', $forumtitle." "._titleseparator." ".$topictitle);
                    } else {
                        define('_indexOutput_title', $_lang['mod.topic']);
                    }
                    break;

            }

            if(defined('_indexOutput_content')) define('_indexOutput_pid', $_GET['m']);

        } else {
            $notpublic_form = true;
        }
    }

    ///*-- clanek --*/

    elseif(isset($_GET['a'])) {

        $id = intval($_GET['a']);

        //clanek
        $query = mysql_query("SELECT * FROM `"._mysql_prefix."-articles` WHERE id=".$id);
        if(mysql_num_rows($query) != 0) {

            //rozebrani dat, test pristupu
            $query = mysql_fetch_assoc($query);
            $access = _articleAccess($query);
            define('_indexOutput_url', _linkArticle($id));
            define('_indexOutput_ptype', 'article');

            //vlozeni modulu
            if($access == 1) {

                // kontrola rewrite adresy
                if(_modrewrite && isset($_GET['rwsid']) && _anchorStr($query['title']) !== $_GET['rwsid']) {
                    header('HTTP/1.1 301 Moved Permanently');
                    header('Location: '._url.'/'._linkArticle($query['id']));
                    die;
                } else {
                    // skript
                    require (_indexroot."require/page/article.php");
                    define('_indexOutput_content', $content);
                    define('_indexOutput_title', $title);
                }

            } elseif($access == 2) {
                $notpublic_form = true;
            }

        }

    }

    /*-- stranka nebo hlavni strana --*/  else {

        //nacteni ID stranky nebo hlavni strany
        $continue = true;
        if(isset($_GET['p'])) {
            $id = intval($_GET['p']);
        } else {
            $query = mysql_query("SELECT id FROM `"._mysql_prefix."-root` WHERE intersection=-1 AND type!=4 ORDER BY ord LIMIT 1");
            if(mysql_num_rows($query) != 0) {
                $query = mysql_fetch_assoc($query);
                $id = $query['id'];
            } else {
                $continue = false;
            }
        }

        //vypis stranky
        if($continue) {

            $query = mysql_query("SELECT * FROM `"._mysql_prefix."-root` WHERE id=".$id);
            if(mysql_num_rows($query) != 0) {

                //rozebrani dat, test pristupu
                $query = mysql_fetch_assoc($query);
                define('_indexOutput_url', _linkRoot($id));
                define('_indexOutput_pid', $id);

                //priprava pro vystup
                if(_publicAccess($query['public'])) {

                    //dedicnost nastaveni verejnosti po rozcestniku
                    if($query['intersection'] != -1) {
                        $intersection_data = mysql_fetch_assoc(mysql_query("SELECT public,var2 FROM `"._mysql_prefix."-root` WHERE id=".$query['intersection']));
                        $intersection_public = $intersection_data['public'];
                    } else {
                        $intersection_public = 1;
                    }

                    //zpetny odkaz na rozcestnik
                    $backlink = "";
                    if($query['intersection'] != -1 and $query['visible'] == 1 and _template_intersec_backlink and $intersection_data['var2'] != 1) {
                        $backlink = "<a href='"._linkRoot($query['intersection'])."' class='backlink'>&lt; ".$_lang['global.return']."</a>";
                    }

                    //vlozeni modulu
                    if(_publicAccess($intersection_public)) {

                        // kontrola rewrite adresy
                        if(_modrewrite && isset($_GET['rwsid']) && _anchorStr($query['title']) !== $_GET['rwsid']) {
                            header('HTTP/1.1 301 Moved Permanently');
                            header('Location: '._url.'/'._linkRoot($query['id']));
                            die;
                        } else {

                            // skript
                            switch($query['type']) {
                                case 1:
                                    require (_indexroot."require/page/section.php");
                                    define('_indexOutput_ptype', 'section');
                                    break;
                                case 2:
                                    require (_indexroot."require/page/category.php");
                                    define('_indexOutput_ptype', 'category');
                                    break;
                                case 3:
                                    require (_indexroot."require/page/book.php");
                                    define('_indexOutput_type', 'book');
                                    break;
                                case 5:
                                    require (_indexroot."require/page/gallery.php");
                                    define('_indexOutput_ptype', 'gallery');
                                    break;
                                case 6:
                                    require (_indexroot."require/page/link.php");
                                    define('_indexOutput_ptype', 'link');
                                    break;
                                case 7:
                                    require (_indexroot."require/page/intersection.php");
                                    define('_indexOutput_ptype', 'intersection');
                                    break;
                                case 8:
                                    require (_indexroot."require/page/forum.php");
                                    define('_indexOutput_ptype', 'forum');
                                    break;
                            }

                            define('_indexOutput_content', $backlink.$content);
                            define('_indexOutput_title', $title);

                        }

                    } else {
                        $notpublic_form = true;
                    }

                } else {
                    $notpublic_form = true;
                }

            }

        } else {
            //neni co zobrazit
            define('_indexOutput_content', (_template_autoheadings ? "<h1>".$_lang['global.error404.title']."</h1>" : '')._formMessage(2, $_lang['global.nokit']));
            define('_indexOutput_title', $_lang['global.error404.title']);
        }

    }


} else {
    $notpublic_form = true;
    $notpublic_form_wholesite = true;
}


/*-- definovani nedefinovanych konstant --*/
if(!defined('_indexOutput_pid')) define('_indexOutput_pid', -1);
if(!defined('_indexOutput_ptype')) define('_indexOutput_ptype', '');
if(!defined('_indexOutput_url')) define('_indexOutput_url', _indexroot);


/*-- nenalezeno nebo pozadovani prihlaseni pro neverejny obsah --*/
if(!defined('_indexOutput_content')) {
    if(!$notpublic_form) {
        define('_indexOutput_content', (_template_autoheadings ? "<h1>".$_lang['global.error404.title']."</h1>" : '')._formMessage(2, $_lang['global.error404']));
        define('_indexOutput_title', $_lang['global.error404.title']);
    } else {
        $form = _uniForm("notpublic", array($notpublic_form_wholesite));
        define('_indexOutput_content', $form[0]);
        define('_indexOutput_title', $form[1]);
    }
}


/*-- vlozeni sablony motivu nebo presmerovani --*/
if(!defined('_tmp_redirect')) {
    require (_indexroot."templates/"._template."/template.php");
} else {
    header("HTTP/1.1 301 Moved Permanently");
    header("Location: "._tmp_redirect);
    exit;
}

?>