<?php

/*prepocet data, priprava dotazu*/
$date_recount=array();
$date_recount_id=0;
$tabulka="articlecontent";
$replace=array(" " => "-", ":" => "-", "." => "-");
$x=1;

while($x<=3){

  $data=@mysql_query("SELECT date,id FROM `".tabprefix."-$tabulka`");
  while($datum=@mysql_fetch_array($data)){

  $old=$datum['date'];
  $old=strtr($old, $replace);
  
    $letterpos=0;
    $double="--";
    while($letterpos<=strlen($old)){
    $letter=substr($old, $letterpos, 2);
      if($letter==$double){
      $old_start=substr($old, 0, $letterpos+1);
      $old_end=substr($old, $letterpos+2);
      $old=$old_start.$old_end;
      $letterpos-=1;
      }
    $letterpos++;
    }
  
  $old=explode("-", $old);
  $new=mktime($old[3], $old[4], 0, $old[1], $old[0], $old[2]);
  $date_recount[$date_recount_id]="UPDATE `".tabprefix."-$tabulka` SET date=$new WHERE id=".$datum['id'];
  $date_recount_id++;

  }

$x++;
switch($x){
case 2: $tabulka="bookcontent"; break;
case 3: $tabulka="comments"; break;
}

}


/*aktualizace tabulek*/
@mysql_query("ALTER TABLE `".tabprefix."-comments` CHANGE `date` `date` BIGINT NOT NULL ;");
@mysql_query("ALTER TABLE `".tabprefix."-articlecontent` CHANGE `date` `date` BIGINT NOT NULL ;");
@mysql_query("ALTER TABLE `".tabprefix."-bookcontent` CHANGE `date` `date` BIGINT NOT NULL ;");
@mysql_query("INSERT INTO `".tabprefix."-settings` ( `variable` , `value` ) VALUES ('postadmintimeout', '172800');");
@mysql_query("INSERT INTO `".tabprefix."-settings` ( `variable` , `value` ) VALUES ('wmcode', '1');");
@mysql_query("INSERT INTO `".tabprefix."-settings` ( `variable` , `value` ) VALUES ('gbguests', '1');");
@mysql_query("INSERT INTO `".tabprefix."-settings` ( `variable` , `value` ) VALUES ('artorder', '1');");


/*aplikace prepoctu*/
$x=0;
while($x<=count($date_recount)-1){
@mysql_query($date_recount[$x]);
$x++;
}

?>
