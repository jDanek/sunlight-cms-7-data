<?php

$vid=$_GET['vid'];
$vid=intval($vid);

$root="../";
$moduletitle="admin_forms_preview";
include("../_connect.php");
include("../modules/moduleheader.php");

?>

<body>

<div class="board">
<div class="board-padding">

<h1><?php lang('admin_forms_preview', 'e'); ?></h1>

<?php
echo parsehcm("<!--hcm:vote:start-->$vid,150,none<!--hcm:vote:end-->");
?>

</div>
</div>

</body>
</html>
