<?php
$root="../";
include("../_connect.php");
session_start();
unset($_SESSION[systemuid.'login_aindicator']);
unset($_SESSION[systemuid.'login_aid']);
header("location: index.php?m=2");
exit;
?>
