<?php
$root="../";
$moduletitle="userlist_title";
include("../_connect.php");
include("moduleheader.php");
?>

<body>

<div class="board">
<div class="board-padding">

<a href="../">&lt; <?php lang('global_backtomain', 'e'); ?></a><br><br>
<h1><?php lang('userlist_title', 'e'); ?></h1>
<p><?php lang('userlist_p', 'e'); ?></p>

<?php
/*nacteni promennych pro filtrovani*/

  /*limit*/
  $filter_limit=$_GET['limit'];
  $filter_limit=intval($filter_limit);
  
  if($filter_limit==0 or $filter_limit=="" or $filter_limit>999){
  $filter_limit=100;
  }

  /*prava*/
  $filter_rightss=$_GET['rights'];
  $filter_rightss=addslashes($filter_rightss);
  switch($filter_rightss){
  case "all": $filter_rights=""; $f_all="selected"; $f_readers=""; $f_redaction=""; break;
  case "readers": $filter_rights="WHERE rights=0"; $f_all=""; $f_readers="selected"; $f_redaction=""; break;
  case "redaction": $filter_rights="WHERE rights=1 OR rights=2"; $f_all=""; $f_readers=""; $f_redaction="selected"; break;
  default: $filter_rights=""; $f_all="selected"; $f_readers=""; $f_redaction=""; break;
  }

/*filtr-formular*/
echo "
<form action='".$_SERVER['PHP_SELF']."' method='get'>

<b>".lang('global_filter', 'r')."</b>&nbsp;

<select name='rights'>
<option value='all' $f_all>".lang('global_all', 'r')."</option>
<option value='readers' $f_readers>".lang('global_readers', 'r')."</option>
<option value='redaction' $f_redaction>".lang('global_adminsandredactors', 'r')."</option>
</select>&nbsp;

-&nbsp;<input type='text' size='2' maxlength='3' name='limit' value='$filter_limit'>&nbsp;
".lang('global_perpage', 'r').".&nbsp;
<input type='submit' value='".lang('global_justfilter', 'r')."'>

</form>
";

/*strankovani*/
if(isset($_GET['s'])){
$startpage=$_GET['s'];
$startpage=intval($startpage);
}
else{
$startpage=0;
}

/*seznam stran*/
$strany=@mysql_query("SELECT id FROM `".tabprefix."-users` $filter_rights");
$pocetstran=0;

  /*spocitani stran*/
  while($strana=@mysql_fetch_array($strany)){$pocetstran++;}
  if($pocetstran==0){$pocetstran=1;}
  $pocetstran=$pocetstran/$filter_limit;
  $pocetstran=ceil($pocetstran);

/*vypis stran*/
if($startpage>9){$strana=$startpage-5;}
else{$strana=0;}
$odkazu=0;
$back=$startpage-10;
$forward=$startpage+10;
echo "<hr size='1' color='$st_linecolor'><div class='strany'>".lang('global_page', 'r').": ";
if($startpage>=10){echo "<a href='userlist.php?&rights=$filter_rightss&limit=$filter_limit&s=$back'>&lt;</a> ";}

while($strana<$pocetstran and $odkazu<=$st_maxpages){
$odkazu++;
$stranaanchor=$strana+1;
if($strana==$startpage){echo "<a href='userlist.php?&rights=$filter_rightss&limit=$filter_limit&s=$strana' class='active'>$stranaanchor</a> ";}
else{echo "<a href='userlist.php?&rights=$filter_rightss&limit=$filter_limit&s=$strana'>$stranaanchor</a> ";}
$strana++;
}

if($startpage<=$pocetstran-10){echo "<a href='userlist.php?&rights=$filter_rightss&limit=$filter_limit&s=$forward'>&gt;</a> ";}
echo "</div><hr size='1' color='$st_linecolor'>\n";

/*vypis uzivatelu*/
echo "<table id='userlist' cellspacing='0' cellpadding='3'>\n<tr><td class='main'>".lang('global_user', 'r')."</td><td class='main'>".lang('global_rights', 'r')."</td></tr>\n";
$start=$startpage*$filter_limit;
$idlist=@mysql_query("SELECT id,name,rights FROM `".tabprefix."-users` $filter_rights ORDER BY rights DESC LIMIT $start,$filter_limit");

while($iditem=@mysql_fetch_array($idlist)){
$iditem['email']=strtr($iditem['email'], $at);

switch($iditem['rights']){
case 0: $idprava=lang('global_reader', 'r'); break;
case 1: $idprava=lang('global_redactor', 'r'); break;
case 2: if($iditem['id']!=0){$idprava=lang('global_administrator', 'r');}else{$idprava=lang('global_mainadministrator', 'r');} break;
}

$idcode="<tr><td><a href='viewprofile.php?id=".$iditem['name']."'>".$iditem['name']."</a></td><td>".$idprava."</td></tr>\n";
echo $idcode;
}
?>

</table>

</div>
</div>

</body>
</html>
