<?php
$root="../";
$moduletitle="wmcode_help_title";
include("../_connect.php");
include("moduleheader.php");
?>

<body>

<div class="board">
<div class="board-padding">

<?php lang('wmcode_help_page', 'e'); ?>

</div>
</div>

</body>
</html>
