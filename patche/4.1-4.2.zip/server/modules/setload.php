<?php
$settings=@mysql_query("SELECT * FROM `".tabprefix."-settings`");

while($item=@mysql_fetch_array($settings)){
$variable=$item['variable'];
$value=$item['value'];
eval('$st_'."$variable='$value';");
}

/*zpracovani hodnot*/
if($st_artorder==1){$st_artorder="date";}
else{$st_artorder="id";}

/*definovani globalnich*/
define('langfile', $st_langfile);
define('linecolor', $st_linecolor);
define('rewrite', $st_rewrite);
define('artorder', $st_artorder);
?>
