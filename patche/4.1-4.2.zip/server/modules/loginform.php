<?php
if($refer!=0){$getrefer="?refer=$refer";}else{$getrefer="";}
echo "<form action=\"".root."modules/login.php$getrefer\" method=\"post\" name=\"loginform\" onsubmit=\"document.loginform.cryptedpass.value=hex_md5(document.loginform.password.value);document.loginform.password.value='';\">";
if(isset($_POST['loginmodulereferer'])){echo "<input type='hidden' name='loginmodulereferer' value='".$_POST['loginmodulereferer']."'>";}
else{if($loginmodulerefer==true and $_SERVER['HTTP_REFERER']!='' and $refer!=-1){echo "<input type='hidden' name='loginmodulereferer' value='".$_SERVER['HTTP_REFERER']."'>";}}
?>

<script type="text/javascript" language="javascript" src="<?php echo $root; ?>modules/md5.js">
</script>

<script type="text/javascript" language="javascript">
document.write("<input type='hidden' name='crypted' value='1'>");
document.write("<input type='hidden' name='cryptedpass' value=''>");
</script>
<noscript>
<input type="hidden" name="crypted" value="0">
</noscript>

<h3><?php lang('global_enterlogin', 'e'); ?></h3>
<p><?php lang('global_enterlogin_p', 'e'); ?> <a href="<?php echo root."modules/register.php"; ?>"><?php lang('global_enterlogin_p_link', 'e'); ?></a></p>

<table>

<tr>
<td><?php lang('global_user', 'e'); ?>&nbsp;&nbsp;</td>
<td><input type="text" size="20" name="name"></td>
</tr>

<tr>
<td><?php lang('global_pass', 'e'); ?></td>
<td><input type="password" size="20" name="password" maxlength="255"></td>
</tr>

<tr>
<td></td>
<td><input type="submit" value="<?php lang('global_continue', 'e'); ?> &gt;"></td>
</tr>

</table>
</form>
<br>
