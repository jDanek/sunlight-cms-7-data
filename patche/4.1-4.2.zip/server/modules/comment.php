<?php
/*vlozeni komentare*/
if(isset($_POST['subject']) and $login_indicator==1){

if($_SESSION[systemuid.'log_posttime']<time()-$st_postwait){
$_SESSION[systemuid.'log_posttime']=time();

  /*nacteni promennych*/
  $ic_text=$_POST['text'];
  
    /*home a tp*/
    if(isset($_GET['articleread'])){
    $ic_home=$a_articleread;
    $ic_tp=2;
    }
    else{
    $ic_home=$c_str;
    $ic_tp=1;
    }

  $ic_subject=$_POST['subject'];
  $ic_date=time();
  $ic_ip=$_SERVER['REMOTE_ADDR'];


  /*kontrola a uprava promennych*/
  
    /*aplikace maximalni delky*/
    $ic_text=substr($ic_text, 0, 2048);
    $ic_subject=substr($ic_subject, 0, 32);
    
    /*odstraneni mezer*/
    $ic_text=trim($ic_text);
    $ic_subject=trim($ic_subject);
    
    /*kontrola zadani*/
    if($ic_text!="" and $ic_subject!=""){
    $continue=true;
    }
    else{
    $continue=false;
    }

  
  /*vypocet id a vlozeni*/
  if($continue==true){
  $vypocetid=@mysql_query("SELECT id FROM `".tabprefix."-comments` ORDER BY id DESC LIMIT 1");
  $vypocetid=@mysql_fetch_array($vypocetid);
  $newid=$vypocetid['id'];
  $newid++;
  @mysql_query("INSERT INTO `".tabprefix."-comments` (id,author,text,home,subject,date,tp,ip) VALUES ($newid,$login_id,'$ic_text','$ic_home','$ic_subject',$ic_date,'$ic_tp','$ic_ip')");
  }
  else{
  $msg=lang('global_msg_badinput', 'r');
  }
  
}
else{
$msg=lang('global_msg_timelimit', 'r');
}

}

/*sestaveni akce formulare*/
if(isset($_GET['articleread'])){

$home=$a_articleread;
$tp=2;
/*rewrite*/
if($st_rewrite==1){$formaction="$st_artprefix-$a_title4url-$a_articleread.html";}
else{$formaction="index.php?articleread=$a_articleread";}
}

else {

$home=$c_str;
$tp=1;
/*rewrite*/
if($st_rewrite==1){$formaction="$st_secprefix-$code_anchor-$c_str.html";}
else{$formaction="index.php?str=$c_str&tp=1";}

}

include("modules/msg.php");

if($login_indicator==1){

if($st_wmcode==1){$wmcode_help="&nbsp;<a href='modules/wmcode-help.php' target='_blank' class='wmcodehelp'>[?]</a>";}else{$wmcode_help="";}

$itext_maxlength=2048;
$itext_form="commentform";
include("modules/itext.inc");

echo "<br><hr size='1' color='$st_linecolor'>
<h2>".lang('comment_title', 'r')."</h2>

<form action='$formaction' method='post' name='commentform' onsubmit=\"if(document.commentform.subject.value=='' ||  document.commentform.text.value==''){alert('".lang('global_somethingwrong', 'r')."'); return false;}\">

<table>

<tr>
<td>".lang('global_subject', 'r').":</td>
<td><input type='text' maxlength='32' name='subject' class='ifield'></td>
</tr>

<tr valign='top'>
<td>".lang('global_text', 'r').":</td>
<td><textarea name='text' class='itext' id='itext'></textarea></td>
</tr>

<tr>
<td></td>
<td>
<input type='submit' value='".lang('global_send', 'r')." &gt;'>
<input type='reset' value='".lang('global_empty', 'r')."'>$wmcode_help
</td>
</tr>

</table>

</form>
";

}
else{
echo $lognise;
$refer=1;
include("modules/loginform.php");
}

/*nadpis2*/
echo "
<h2>".lang('comment_title2', 'r')."</h2>
<hr size='1' color='$st_linecolor'>
<div id='comments'>
";

/*vypis komentaru*/
$comments=@mysql_query("SELECT * FROM `".tabprefix."-comments` WHERE home=$home AND tp=$tp ORDER BY id DESC");
  $commentcount=0;
  while($c_item=@mysql_fetch_array($comments)){
  
  if($c_item['author']!=-2){
  $userdata=@mysql_query("SELECT name,rights FROM `".tabprefix."-users` WHERE id=".$c_item['author']);
  $userdata=@mysql_fetch_array($userdata);
  }
  else{
  $userdata['name']=lang('global_fableduser', 'r');
  $userdata['rights']=0;
  }
  
    if($login_indicator==1){if(($c_item['author']==$login_id and time()-$c_item['date']<=$st_postadmintimeout) or $login_id==0 or ($userdata['rights']==0 and $login_rights==1) or ($userdata['rights']==1 and $login_rights==2)){$commentadmin=" | <a href='modules/commentdel.php?cid=".$c_item['id']."' target='_blank' onclick='return ask();' title='".lang('global_delete', 'r')."'>x</a> | <a href='modules/commentedit.php?cid=".$c_item['id']."' target='_blank' title='".lang('global_edit', 'r')."'>e</a>";}else{$commentadmin="";}}
    $itemdate=formatdate($c_item['date']);
    if($st_wmcode==1){$c_item['text']=parsewmcode($c_item['text']);}
    $c_item['text']=nl2br($c_item['text']);
    echo "<a href='modules/viewprofile.php?id=".$userdata['name']."' title='".lang('comment_viewprofile', 'r')."'>".$userdata['name']."</a>, <b>".$c_item['subject']."</b> <span class='postadmin'>(<span title='".$c_item['ip']."'>".$itemdate."</span>$commentadmin)</span><p>".$c_item['text']."</p><hr size='1' color='$st_linecolor'>\n";
    $commentcount++;
    }
  
  /*hlaska o zadnych komentarich*/
  if($commentcount==0){
  echo "<p>".lang('comment_nokit', 'r')."</p>";
  }

echo "</div>";
?>
