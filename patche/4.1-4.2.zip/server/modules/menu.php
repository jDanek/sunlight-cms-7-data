<?php
$menu=@mysql_query("SELECT * FROM `".tabprefix."-menu` ORDER BY 'ord'");
while($item=@mysql_fetch_array($menu)){

  /*preskoceni neviditelnych*/
  $m_visible=$item['visible'];
  if($m_visible!=1){
  continue;
  }

  /*nacteni promennych k polozce*/
  $m_id=$item['id'];
  $m_anchor=$item['anchor'];
  $m_type=$item['type'];
  
  /*anchor pro url*/
  $anchor=anchor($m_anchor);
  
  /*sestaveni a vypis odkazu*/
  switch($m_type){
  
  case 1:
  /*rewrite*/
  if($st_rewrite==1){$linkhref="$st_secprefix-$anchor-$m_id.html";}
  else{$linkhref="index.php?str=$m_id&tp=1";}
  break;
  
  case 2:
  /*rewrite*/
  if($st_rewrite==1){$linkhref="$st_catprefix-$anchor-$m_id-1.html";}
  else{$linkhref="index.php?str=$m_id&tp=2";}
  break;
  
  case 3:
  /*rewrite*/
  if($st_rewrite==1){$linkhref="$st_gbprefix-$anchor-$m_id-1.html";}
  else{$linkhref="index.php?str=$m_id&tp=3";}
  break;
  
  }
  
  echo "<li><a href='$linkhref'>$m_anchor</a></li>\n";
}
?>
