<?php

/*--- kontrola jadra ---*/
if(!defined('_core')){exit;}

/*-- akce --*/
session_start();
$result=0;

  //pole konstant opravneni
  $rights_array=_getRightsArray();

  //kontrola existence session
  if(isset($_SESSION[_sessionprefix."user"]) and isset($_SESSION[_sessionprefix."password"]) and isset($_SESSION[_sessionprefix."ip"])){

    //kontroly
    $id=intval($_SESSION[_sessionprefix."user"]);
    $pass=$_SESSION[_sessionprefix."password"];
    $ip=$_SESSION[_sessionprefix."ip"];
    $uquery=mysql_query("SELECT * FROM `"._mysql_prefix."-users` WHERE id=".$id);

      $continue=false;
      if(mysql_num_rows($uquery)!=0){
      $uquery=mysql_fetch_array($uquery);
      $gquery=mysql_fetch_array(mysql_query("SELECT * FROM `"._mysql_prefix."-groups` WHERE id=".$uquery['group']));
        if($uquery['password']==$pass and $uquery['blocked']==0 and $gquery['blocked']==0 and $ip==_userip){
        $continue=true;
        }
      }

      //zabiti neplatne session
      if($continue!=true){
      $_SESSION=array();
      session_destroy();
      if(_administration!=1){header("location: "._indexroot."index.php?m=login&_mlr=3");}
      else{header("location: "._indexroot."admin/index.php?_mlr=3");}
      }

    //definovani konstant
    if($continue){
    
    $result=1;
    define('_loginid', $uquery['id']);
    define('_loginname', $uquery['username']);
      if($uquery['publicname']!=""){define('_loginpublicname', $uquery['publicname']);}
      else{define('_loginpublicname', $uquery['username']);}
    define('_loginemail', $uquery['email']);
    define('_loginwysiwyg', $uquery['wysiwyg']);
    define('_loginlanguage', $uquery['language']);
    define('_logincounter', $uquery['logincounter']);

      //konstanty skupiny
      define('_loginright_group', $gquery['id']);
      define('_loginright_groupname', $gquery['title']);

            //zvyseni levelu pro superuzivatele
            if($uquery['levelshift']==1){$gquery['level']+=1;}

        foreach($rights_array as $item){
        define('_loginright_'.$item, $gquery[$item]);
        }

      //zaznamenani casu aktivity
      mysql_query("UPDATE `"._mysql_prefix."-users` SET activitytime='".time()."', ip='".$_SERVER['REMOTE_ADDR']."' WHERE id="._loginid);

    }

  }
  else{

  //konstanty hosta
  define('_loginid', -1);
  define('_loginname', '');
  define('_loginpublicname', '');
  define('_loginemail', '');
  define('_loginwysiwyg', 0);
  define('_loginlanguage', '');
  define('_logincounter', 0);

    //konstanty skupiny
    $gquery=mysql_fetch_array(mysql_query("SELECT * FROM `"._mysql_prefix."-groups` WHERE id=2"));
    define('_loginright_group', $gquery['id']);
    define('_loginright_groupname', $gquery['title']);

      foreach($rights_array as $item){
      define('_loginright_'.$item, $gquery[$item]);
      }
  }

  //konstanta pro indikaci prihlaseni
  define('_loginindicator', $result);

?>