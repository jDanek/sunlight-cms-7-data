<?php

/*--- kontrola jadra ---*/
if(!defined('_core')){exit;}

/*-- skript --*/
switch(mb_strtolower($paramarray[0])){



//menu
case "menu":
if(isset($paramarray[1]) and isset($paramarray[2])){$start=intval($paramarray[1]); $length=intval($paramarray[2]);}
else{$start=null; $length=null;}
$mresult=_templateMenu($start, $length);
break;



//usermenu
case "usermenu":
$mresult=_templateUserMenu(true);
break;



//player
case "player":
if(count($paramarray)>=2){

  //prednastavene hodnoty
  $extension=pathinfo($paramarray[1]);
  if(isset($extension['extension'])){$extension=$extension['extension'];}
  if($extension=="mp3"){$defheight="20";}else{$defheight="240";}
  $defwidth="320";

    //nacteni parametru
    $file=_htmlStr($paramarray[1]);
    if(!_isAbsolutePath($file)){$file=_url."/".$file;}
    if(!isset($paramarray[2])){$width=$defwidth;}else{$width=intval($paramarray[2]);}
    if(!isset($paramarray[3])){$height=$defheight;}else{$height=intval($paramarray[3]);}
    if(!isset($paramarray[4])){$autostart="false";}else{$autostart=_booleanStr(_boolean($paramarray[4]));}

    //sestaveni kodu
    $mresult="
    <!--[if !IE]> -->
    <object type='application/x-shockwave-flash' data='"._indexroot."remote/hcm/player.swf' width='".$width."' height='".$height."'>
    <!-- <![endif]-->

    <!--[if IE]>
    <object classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000' codebase='http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0' width='$width' height='$height'>
    <param name='movie' value='"._indexroot."remote/hcm/player.swf' />
    <!--><!---->
    <param name='loop' value='true' />
    <param name='menu' value='false' />
    <param name='flashvars' value='file=".$file."&amp;height=".$height."&amp;width=".$width."&amp;autostart=".$autostart."' />

    ".$_lang['hcm.player.alt']."
    </object>
    <!-- <![endif]-->
    ";

}
break;



//notpublic
case "notpublic":
if(count($paramarray)>=2){
  if(_loginindicator){$mresult=$paramarray[1];}
  else{if(isset($paramarray[2])){$mresult=$paramarray[2];}}
}
break;



//levelcontent
case "levelcontent":
if(count($paramarray)>=3){
  if(_loginright_level>=intval($paramarray[1])){$mresult=$paramarray[2];}
  else{if(isset($paramarray[3])){$mresult=$paramarray[3];}}
}
break;



//levelcontent2
case "levelcontent2":
if(count($paramarray)>=4){
  if(_loginright_level>=intval($paramarray[1]) and _loginright_level<=intval($paramarray[2])){$mresult=$paramarray[3];}
  else{if(isset($paramarray[4])){$mresult=$paramarray[4];}}
}
break;



//levelaccess
case "levelaccess":
if(count($paramarray)==3){
  if(_loginright_level<intval($paramarray[1])){
    if(!defined('_tmp_redirect')){define('_tmp_redirect', $paramarray[2]);}
  }
}
break;



//levelaccess2
case "levelaccess2":
if(count($paramarray)==4){
  if(_loginright_level<intval($paramarray[1]) or _loginright_level>intval($paramarray[2])){
    if(!defined('_tmp_redirect')){define('_tmp_redirect', $paramarray[3]);}
  }
}
break;



//filelist
case "filelist":
if(isset($paramarray[1])){

$rdir=_indexroot.$paramarray[1];
if(isset($paramarray[2]) and _boolean($paramarray[2])){$rshowfilesize=true;}else{$rshowfilesize=false;}
if(mb_substr($rdir, -1, 1)!="/"){$rdir.="/";}

  if(@file_exists($rdir) and @is_dir($rdir)){
  $handle=@opendir($rdir);
    while($item=@readdir($handle)){
      if(@is_dir($rdir.$item) or $item=="." or $item==".."){continue;}
      $items[]=$item;
    }
    natsort($items);
    $mresult="<ul>\n";
      foreach($items as $item){
        $mresult.="<li>";
        $mresult.="<a href='".$rdir.urlencode($item)."' target='_blank'>".$item."</a>";
        if($rshowfilesize){$mresult.=" (".round(@filesize($rdir.$item)/1024)."kB)";}
        $mresult.="</li>\n";
      }
    $mresult.="</ul>\n";
  @closedir($handle);
  }

}
break;



//countusers
case "countusers":
if(isset($paramarray[1])){$cond=" WHERE "._sqlWhereColumn("`group`", $paramarray[1]);}else{$cond="";}
$mresult=mysql_result(mysql_query("SELECT COUNT(id) FROM `"._mysql_prefix."-users`".$cond), 0);
break;



//users
case "users":
if(count($paramarray)>=2){

  $rtype=$paramarray[1];
  if(isset($paramarray[2])){$rlimit=abs(intval($paramarray[2]));}else{$rlimit=5;}
  if(isset($paramarray[3])){$rnamecut=intval($paramarray[3]);}else{$rnamecut=false;}

  $rcond="";
  switch($rtype){
  case 2: $rorder="activitytime DESC"; $rcond=" WHERE ".time()."-activitytime<1800"; break;
  case 3: $rorder="(SELECT COUNT(id) FROM `"._mysql_prefix."-posts` WHERE author=`sunlight-users`.id) DESC"; break;
  case 4: $rcond=" WHERE (SELECT COUNT(id) FROM `"._mysql_prefix."-articles` WHERE author=`"._mysql_prefix."-users`.id AND rateon=1 AND ratenum!=0)!=0"; $rorder="(SELECT ROUND(SUM(ratesum)/SUM(ratenum)) FROM `"._mysql_prefix."-articles` WHERE rateon=1 AND ratenum!=0 AND author=`"._mysql_prefix."-users`.id) DESC"; break;
  default: $rorder="id DESC"; break;
  }

  if($rtype!=4){$mresult="<ul>\n";}else{$mresult="<ol>\n";}
  $query=mysql_query("SELECT id FROM `"._mysql_prefix."-users`".$rcond." ORDER BY ".$rorder." LIMIT ".$rlimit);
  while($item=mysql_fetch_array($query)){

    //pridani doplnujicich informaci
    switch($rtype){
    
      //pocet prispevku
      case 3:
        $rvar=mysql_result(mysql_query("SELECT COUNT(id) FROM `"._mysql_prefix."-posts` WHERE author=".$item['id']), 0);
        if($rvar==0){continue;}else{$rext=" (".$rvar.")";}
      break;
      
      //hodnoceni autora
      case 4:
        $rvar=mysql_fetch_array(mysql_query("SELECT ROUND(SUM(ratesum)/SUM(ratenum)),COUNT(id) FROM `"._mysql_prefix."-articles` WHERE rateon=1 AND ratenum!=0 AND author=".$item['id']));
        $rext=" - ".$rvar[0]."%, ".$_lang['global.articlesnum'].": ".$rvar[1];
      break;

      //nic
      default:
      $rext="";
      break;
    
    }

  $mresult.="<li>"._linkUser($item['id'], null, false, false, $rnamecut).$rext."</li>\n";
  }
  if($rtype!=4){$mresult.="</ul>\n";}else{$mresult.="</ol>\n";}

}
break;



//countart
case "countart":
if(isset($paramarray[1]) and $paramarray[1]!=""){$cond=" AND "._sqlArticleWhereCategories($paramarray[1]);}else{$cond="";}
$mresult=mysql_result(mysql_query("SELECT COUNT(id) FROM `"._mysql_prefix."-articles` WHERE "._sqlArticleFilter().$cond), 0);
break;



//randomfile
case "randomfile":
if(count($paramarray)>=3){

  $rdir=_indexroot.$paramarray[1];
  $rdir_noroot=$paramarray[1];
  if(mb_substr($rdir, -1, 1)!="/"){$rdir.="/";}
  if(mb_substr($rdir_noroot, -1, 1)!="/"){$rdir_noroot.="/";}
  $rtype=$paramarray[2];
  if(isset($paramarray[3])){$rnumber=intval($paramarray[3]);}else{$rnumber=1;}


    if(@file_exists($rdir) and @is_dir($rdir)){
    $handle=@opendir($rdir);

      switch($rtype){
      case 2: $allowed_extensions=$__image_ext; if(isset($paramarray[4])){$rheight=intval($paramarray[4]);}else{$rheight=96;} break;
      default: $allowed_extensions=array("txt", "htm", "html"); break;
      }

      $items=array();
      while($item=@readdir($handle)){
      $ext=pathinfo($item);
      if(isset($ext['extension'])){$ext=mb_strtolower($ext['extension']);}else{$ext="";}
        if(@is_dir($item) or $item=="." or $item==".." or !in_array($ext, $allowed_extensions)){continue;}
        $items[]=$item;
      }

      if(count($items)!=0){
        if($rnumber>count($items)){$rnumber=count($items);}
        $randitems=array_rand($items, $rnumber);
        if(!is_array($randitems)){$randitems=array($randitems);}

        foreach($randitems as $item){
        $item=$items[$item];
          switch($rtype){
          case 2: $mresult.="<a href='".$rdir.urlencode($item)."' target='_blank' rel='lightbox[hcm".$__hcm_uid."]'><img src='"._indexroot."remote/imgprev.php?id=".urlencode(base64_encode($rdir_noroot.$item))."&amp;c&amp;h=".$rheight."' alt='".$item."' /></a>\n"; break;
          default: $mresult.=@file_get_contents(_indexroot.$rdir.$item); break;
          }
        }
      }

    @closedir($handle);
    }

}
break;



//gallery
case "gallery":
if(count($paramarray)>=2){

  //priprava
  $rdir=_indexroot.$paramarray[1];
  $rdir_noroot=$paramarray[1];
  if(mb_substr($rdir, -1, 1)!="/"){$rdir.="/";}
  if(mb_substr($rdir_noroot, -1, 1)!="/"){$rdir_noroot.="/";}
  if(isset($paramarray[2])){$rheight=intval($paramarray[2]);}else{$rheight=96;}
  if(isset($paramarray[3]) and $paramarray[3]>0){$paged=true; $imgsperpage=intval($paramarray[3]);}else{$paged=false;}

  if(@file_exists($rdir) and @is_dir($rdir)){
  $handle=@opendir($rdir);

    //nacteni polozek
    $items=array();
    while($item=@readdir($handle)){
      $ext=pathinfo($item);
      if(isset($ext['extension'])){$ext=mb_strtolower($ext['extension']);}else{$ext="";}
        if(@is_dir($item) or $item=="." or $item==".." or !in_array($ext, $__image_ext)){continue;}
        $items[]=$item;
    }
    @closedir($handle);
    natsort($items);
    
    //priprava strankovani
    if($paged){
    $count=count($items);
    $paging=_resultPaging(_indexOutput_url, $imgsperpage, $count, "", "#hcm_gal".$__hcm_uid, "hcm_gal".$__hcm_uid."p");
    }

    //vypis
    $mresult="<div class='anchor'><a name='hcm_gal".$__hcm_uid."'></a></div>\n<div class='gallery'>\n";
      $counter=0;
      foreach($items as $item){
        if($paged and $counter>$paging[6]){break;}
        if(!$paged or ($paged and _resultPagingIsItemInRange($paging, $counter))){$mresult.="<a href='".$rdir.urlencode($item)."' target='_blank' rel='lightbox[hcm".$__hcm_uid."]'><img src='"._indexroot."remote/imgprev.php?id=".urlencode(base64_encode($rdir_noroot.$item))."&amp;c&amp;h=".$rheight."' alt='".$item."' /></a>\n";}
        $counter++;
      }
    $mresult.="</div>\n";
    if($paged){$mresult.=$paging[0];}

  }

}
break;



//gallery2
case "gallery2":
if(count($paramarray)>=2){

  //priprava
  $rdir=_indexroot.$paramarray[1];
  $rdir_noroot=$paramarray[1];
  if(mb_substr($rdir, -1, 1)!="/"){$rdir.="/";}
  if(isset($paramarray[2]) and $paramarray[2]>0){$paged=true; $imgsperpage=intval($paramarray[2]); if($imgsperpage<=0){$imgsperpage=1;}}else{$paged=false;}

  if(@file_exists($rdir) and @is_dir($rdir) and @file_exists($rdir."prev/") and @is_dir($rdir."prev/") and @file_exists($rdir."full/") and @is_dir($rdir."full/")){
  $handle=@opendir($rdir."prev/");

    //nacteni polozek
    $items=array();
    while($item=@readdir($handle)){
      $ext=pathinfo($item);
      if(isset($ext['extension'])){$ext=mb_strtolower($ext['extension']);}else{$ext="";}
        if(@is_dir($item) or $item=="." or $item==".." or !in_array($ext, $__image_ext) or !@file_exists($rdir."full/".$item)){continue;}
        $items[]=$item;
    }
    @closedir($handle);
    natsort($items);

    //priprava strankovani
    if($paged){
    $count=count($items);
    $paging=_resultPaging(_indexOutput_url, $imgsperpage, $count, "", "#hcm_gal".$__hcm_uid, "hcm_gal".$__hcm_uid."p");
    }

    //vypis
    $mresult="<div class='anchor'><a name='hcm_gal".$__hcm_uid."'></a></div>\n<div class='gallery'>\n";
      $counter=0;
      foreach($items as $item){
        if($paged and $counter>$paging[6]){break;}
        if(!$paged or ($paged and _resultPagingIsItemInRange($paging, $counter))){$mresult.="<a href='".$rdir."full/".urlencode($item)."' target='_blank' rel='lightbox[hcm".$__hcm_uid."]'><img src='".$rdir."prev/".urlencode($item)."' alt='".$item."' /></a>\n";}
        $counter++;
      }
    $mresult.="</div>\n";
    if($paged){$mresult.=$paging[0];}

  }

}
break;



//img
case "img":
if(isset($paramarray[1])){
$rurl=_htmlStr($paramarray[1]);
if(isset($paramarray[2]) and $paramarray[2]>0){$rheight=intval($paramarray[2]);}else{$rheight=96;}
if(isset($paramarray[3]) and $paramarray[3]!=""){$rtitle=_htmlStr($paramarray[3]);}else{$rtitle="img";}
if(isset($paramarray[4])){$rlbox=mb_substr(md5($paramarray[4]), 0, 8);}else{$rlbox=$__hcm_uid;}
  $mresult="<a href='".$rurl."' target='_blank' rel='lightbox[hcm".$rlbox."]' title='".$rtitle."'><img src='"._indexroot."remote/imgprev.php?id=".urlencode(base64_encode($rurl))."&amp;c&amp;h=".$rheight."' alt='".$rtitle."' /></a>\n";
}
break;



//ximg
case "ximg":
if(isset($paramarray[1])){

    //alternativni text
    $ralt=basename($paramarray[1]);
    if(mb_substr_count($ralt, ".")!=0){$ralt=mb_substr($ralt, 0, mb_strrpos($ralt, "."));}

  if(isset($paramarray[2])){$rpluscode=" ".$paramarray[2];}else{$rpluscode="";}
  $mresult="<img src='"._htmlStr($paramarray[1])."' alt='".$ralt."'".$rpluscode." />";

}
break;



//galimg
case "galimg":
if(count($paramarray)>=3){

  //nacteni parametru
  $rids=_sqlWhereColumn("home", $paramarray[1]);
  $rtype=$paramarray[2];
  if(isset($paramarray[3]) and $paramarray[3]>0 and $paramarray[3]<1024){$rheight=intval($paramarray[3]);}else{$rheight=128;}
  if(isset($paramarray[4])){$rlimit=abs(intval($paramarray[4]));}else{$rlimit=1;}
  
  //urceni razeni
  switch($rtype){
  case 2: $rorder="RAND()"; break;
  default: $rorder="id DESC";
  }
  
  //vypis obrazku
  $rimgs=mysql_query("SELECT id,title,prev,full FROM `"._mysql_prefix."-images` WHERE ".$rids." ORDER BY ".$rorder." LIMIT ".$rlimit);
  while($rimg=mysql_fetch_array($rimgs)){
  $mresult.=_galleryImage($rimg, "hcm".$__hcm_uid, $rheight);
  }

}
break;



//articles
case "articles":
if(count($paramarray)>=3){

$paramarray=_arrayDefineKeys($paramarray, array(3=>1, 4=>1, 5=>null));
$rtype=intval($paramarray[1]); if($rtype<1 or $rtype>9){$rtype=1;}
$rlimit=intval($paramarray[2]); if($rlimit<1){$rlimit=1;}
$rperex=_boolean($paramarray[3]);
$rinfo=_boolean($paramarray[4]);

  //limitovani na kategorie
  $rcats=_sqlArticleWhereCategories($paramarray[5]);

  //priprava casti sql dotazu
  switch($rtype){
  case 1: $rorder="time DESC"; $rcond=""; break;
  case 2: $rorder="readed DESC"; $rcond="readed!=0"; break;
  case 3: $rorder="ratesum/ratenum DESC"; $rcond="ratenum!=0"; break;
  case 4: $rorder="ratenum DESC"; $rcond="ratenum!=0"; break;
  case 5: $rorder="RAND()"; $rcond=""; break;
  case 6: $rorder="(SELECT time FROM `"._mysql_prefix."-iplog` WHERE type=2 AND var=`"._mysql_prefix."-articles`.id AND `"._mysql_prefix."-articles`.visible=1 AND `"._mysql_prefix."-articles`.time<=".time()." AND `"._mysql_prefix."-articles`.confirmed=1 ORDER BY id DESC LIMIT 1) DESC"; $rcond="readed!=0"; break;
  case 7: $rorder="(SELECT time FROM `"._mysql_prefix."-iplog` WHERE type=3 AND var=`"._mysql_prefix."-articles`.id AND `"._mysql_prefix."-articles`.visible=1 AND `"._mysql_prefix."-articles`.time<=".time()." AND `"._mysql_prefix."-articles`.confirmed=1 ORDER BY id DESC LIMIT 1) DESC"; $rcond="ratenum!=0"; break;
  case 8: $rorder="(SELECT time FROM `"._mysql_prefix."-posts` WHERE home=`"._mysql_prefix."-articles`.id AND type=2 ORDER BY time DESC LIMIT 1) DESC"; $rcond="(SELECT COUNT(id) FROM `"._mysql_prefix."-posts` WHERE home=`"._mysql_prefix."-articles`.id AND type=2)!=0"; break;
  case 9: $rorder="(SELECT COUNT(id) FROM `"._mysql_prefix."-posts` WHERE home=`"._mysql_prefix."-articles`.id AND type=2) DESC"; $rcond="(SELECT COUNT(id) FROM `"._mysql_prefix."-posts` WHERE home=`"._mysql_prefix."-articles`.id AND type=2)!=0"; break;
  }

    //pripojeni casti
    if($rcond!=""){$rcond=" AND ".$rcond;}
    $rcond=" WHERE "._sqlArticleFilter(true).$rcond;
    if($rcats!=""){$rcond.=" AND ".$rcats;}

//vypis
$query=mysql_query("SELECT id,title,perex,author,time,readed,comments FROM `"._mysql_prefix."-articles`".$rcond." ORDER BY ".$rorder." LIMIT ".$rlimit);
  while($item=mysql_fetch_array($query)){
  $mresult.=_articlePreview($item, $rinfo, $rperex);
  }


}
break;



//mailform
case "mailform":
if(isset($paramarray[1])){

$paramarray=_arrayDefineKeys($paramarray, array(2=>0, 3=>''));
$remail=base64_encode(@implode(",",_arrayRemoveValue(@explode(";",trim($paramarray[1])), "")));
if(_boolean($paramarray[2])){$rfile=array($_lang['hcm.mailform.att'], "<input type='file' name='att' />"); $att=true;}else{$rfile=array(''); $att=false;}
if($paramarray[3]!=""){$rsubject=" value='"._htmlStr($paramarray[3])."'";}else{$rsubject="";}
$rcaptcha=_captchaInit();

    //zprava
    if(isset($_GET['hcm_mr'])){
      switch($_GET['hcm_mr']){
      case 1: $mresult=_formMessage(1, $_lang['hcm.mailform.msg.done']); break;
      case 2: $mresult=_formMessage(2, $_lang['hcm.mailform.msg.failure']); break;
      case 3: $mresult=_formMessage(3, $_lang['hcm.mailform.msg.failure2']); break;
      }
    }

    //predvyplneni odesilatele
    if(_loginindicator){$sender=_loginemail;}
    else{$sender="&#64;";}

  $mresult.="<div class='anchor'><a name='hcm_mform_".$__hcm_uid."'></a></div>\n"._formOutput(
  "mform".$__hcm_uid,
  _indexroot."remote/hcm/mform.php?_return=".urlencode(_indexOutput_url)._condReturn($att, "' enctype='multipart/form-data"),
  array(
    array($_lang['hcm.mailform.sender'], "<input type='text' class='inputsmall' name='sender' value='".$sender."' /><input type='hidden' name='fid' value='".$__hcm_uid."' /><input type='hidden' name='rec' value='".$remail."' />".$rcaptcha[0]),
    array($_lang['posts.subject'], "<input type='text' class='inputsmall' name='subject'".$rsubject." />"),
    $rcaptcha[1],
    array($_lang['hcm.mailform.text'], "<textarea class='areasmall' name='text' rows='9' cols='33'></textarea>", true),
    $rfile
  ),
  array("text", "sender"),
  $_lang['hcm.mailform.send']
  );

}
break;



//php
case "php":
if(isset($paramarray[1])){
$mresult=_evalBox($paramarray[1]);
}
break;



//recentposts
case "recentposts":
if(isset($paramarray[1]) and intval($paramarray[1])>=1){$rlimit=intval($paramarray[1]);}else{$rlimit=10;}

  //filtr cisel sekci, knih nebo clanku
  if(isset($paramarray[2]) and isset($paramarray[3])){
    $rtype=intval($paramarray[3]);
    if($rtype<1 or $rtype>3){$rtype=1;}
    $rroots="("._sqlWhereColumn("home", $paramarray[2]).") AND type=".$rtype;
  }
  else{
    $rroots="type!=4";
  }

$query=mysql_query("SELECT id,type,home,xhome,subject,author,guest,time,text FROM `"._mysql_prefix."-posts` WHERE ".$rroots." ORDER BY id DESC LIMIT ".$rlimit);
  while($item=mysql_fetch_array($query)){

    //nacteni titulku a odkazu na stranku
    switch($item['type']){
    case 1: case 3: $homelink=_linkRoot($item['home']); $hometitle=mysql_fetch_array(mysql_query("SELECT title FROM `"._mysql_prefix."-root` WHERE id=".$item['home'])); break;
    case 2: $homelink=_linkArticle($item['home']); $hometitle=mysql_fetch_array(mysql_query("SELECT title FROM `"._mysql_prefix."-articles` WHERE id=".$item['home'])); break;

      case 5:
      if($item['xhome']==-1){
        $tid=$item['id'];
        $hometitle=array("title"=>$item['subject']);
      }
      else{
        $tid=$item['xhome'];
        $hometitle=mysql_fetch_array(mysql_query("SELECT subject FROM `"._mysql_prefix."-posts` WHERE id=".$item['xhome']));
        $hometitle=array("title"=>$hometitle['subject']);
      }
        
      $homelink="index.php?m=topic&amp;id=".$tid;
      break;
      
    }

    //nacteni jmena autora
    if($item['author']!=-1){$authorname=_linkUser($item['author'], null, true, true);}
    else{$authorname=$item['guest'];}

    $hometitle=$hometitle['title'];

  $mresult.="
  <h2 class='list-title'><a href='".$homelink."'>".$hometitle."</a></h2>
  <p class='list-perex'>"._cutStr(strip_tags(_parsePost($item['text'])), 256)."</p>
  <div class='list-info'>
  <span>".$_lang['global.postauthor'].":</span> ".$authorname._template_listinfoseparator."
  <span>".$_lang['global.posttime'].":</span> "._formatTime($item['time'])."
  </div>\n
  ";

  }
break;



//poll
case "poll":
if(isset($paramarray[1])){

  //nacteni promennych
  $rid=intval($paramarray[1]);
  if(isset($paramarray[2])){$rwidth=intval($paramarray[2]);}else{$rwidth=150;}
  if($rwidth<100){$rwidth=100;}

  //nacteni dat ankety
  $vpolldata=mysql_query("SELECT * FROM `"._mysql_prefix."-polls` WHERE id=".$rid);
  if(mysql_num_rows($vpolldata)!=0){$vpolldata=mysql_fetch_array($vpolldata); $rcontinue=true;}
  else{$rcontinue=false;}

  //sestaveni kodu
  if($rcontinue){

      //odpovedi
      $ranswers=explode("#", $vpolldata['answers']);
      $rvotes=explode("-", $vpolldata['votes']);
      $rvotes_sum=array_sum($rvotes);
      if(_loginright_pollvote==1 and $vpolldata['locked']!=1 and _iplogCheck(4, $rid)){$rallowvote=true;}else{$rallowvote=false;}

      if($rallowvote){$ranswers_code="<form action='"._indexroot."remote/hcm/pvote.php?_return=".urlencode(_indexOutput_url."#hcm_poll_".$__hcm_uid)."' method='post'>\n<input type='hidden' name='pid' value='".$vpolldata['id']."' />";}
      else{$ranswers_code="";}

                $ranswer_id=0;
                foreach($ranswers as $item){
                  if($rvotes_sum!=0 and $rvotes[$ranswer_id]!=0){$rpercent=$rvotes[$ranswer_id]/$rvotes_sum; $rbarwidth=round($rpercent*($rwidth-_template_votebarwidthreduction));}else{$rpercent=0; $rbarwidth=1;}
                  if($rallowvote){$item="<label><input type='radio' name='option' value='".$ranswer_id."' /> ".$item." [".$rvotes[$ranswer_id]."/".round($rpercent*100)."%]</label>";}else{$item.=" [".$rvotes[$ranswer_id]."/".round($rpercent*100)."%]";}
                  $ranswers_code.="<div class='poll-answer'>".$item."<div style='width:".$rbarwidth."px;'></div></div>\n";
                  $ranswer_id++;
                }

              $ranswers_code.="<div class='poll-answer'>";
              if($rallowvote){$ranswers_code.="<input type='submit' value='".$_lang['hcm.poll.vote']."' class='votebutton' />";}
              $ranswers_code.=$_lang['hcm.poll.votes'].":&nbsp;".$rvotes_sum."</div>";
              if($rallowvote){$ranswers_code.="</form>\n";}

$mresult="
<div class='anchor'><a name='hcm_poll_".$__hcm_uid."'></a></div>
<div class='poll' style='width:".$rwidth."px;'>
<div class='poll-content'>

<div class='poll-question'>
".$vpolldata['question']."
"._condReturn($vpolldata['locked']==1, "<div>(".$_lang['hcm.poll.locked'].")</div>")."
</div>

".$ranswers_code."

</div>
</div>\n
";

  }

}
break;



//sbox
case "sbox":
if(isset($paramarray[1])){

  //nacteni id
  $rid=intval($paramarray[1]);
  if(isset($paramarray[2]) and $paramarray[2]==1){$rnormalmode=0;}else{$rnormalmode=1;}
  if(isset($paramarray[3]) and intval($paramarray[3])>0){$rchatreload=intval($paramarray[3]);}else{$rchatreload=20;}

  //nacteni dat shoutboxu
  $sboxdata=mysql_query("SELECT * FROM `"._mysql_prefix."-sboxes` WHERE id=".$rid);
  if(mysql_num_rows($sboxdata)!=0){$sboxdata=mysql_fetch_array($sboxdata); $rcontinue=true;}
  else{$rcontinue=false;}

  //sestaveni kodu
  if($rcontinue){

$mresult="
<div class='anchor'><a name='hcm_sbox_".$__hcm_uid."'></a></div>
<div class='sbox'>
<div class='sbox-content'>
"._condReturn($sboxdata['title']!="", "<div class='sbox-title'>".$sboxdata['title']."</div>").
"<div class='sbox-item'"._condReturn($sboxdata['title']=="", " style='border-top:none;'").">";

  //formular na pridani
  if($sboxdata['locked']!=1 and _publicAccess($sboxdata['public']) and _publicAccess($rnormalmode)){

    //priprava bunek
    $captcha=_captchaInit();
    if(!_loginindicator){$inputs[]=array($_lang['posts.guestname'], "<input type='text' name='guest' class='sbox-input' maxlength='22' />");}
    $inputs[]=array($_lang['posts.text'], "<input type='text' name='text' class='sbox-input' maxlength='255' /><input type='hidden' name='_posttype' value='4' /><input type='hidden' name='_posttarget' value='".$rid."' />".$captcha[0]);
    if(!_loginindicator){$captcha[1][2]=true; $inputs[]=$captcha[1];}
    
    //kontrolni prvky pro chat
    if($rnormalmode==0){
      $rcontrols=
      _getPostformControls("hcm_sboxform_".$__hcm_uid, "text", true)." <span id='hcm_timer_".$__hcm_uid."' class='lpad'></span>
      <script type='text/javascript'>
      //<![CDATA[
      _sysSboxChatInit(".$__hcm_uid.", ".$rchatreload.");
      //]]>
      </script>
      <noscript><a href='"._indexOutput_url."'>".$_lang['global.reload']."</a></noscript>";
    }
    else{
      $rcontrols=null;
    }
  
  $mresult.=_formOutput(
  "hcm_sboxform_".$__hcm_uid,
  _indexroot."remote/post.php?_return=".urlencode(_indexOutput_url."#hcm_sbox_".$__hcm_uid),
  $inputs,
  null,
  null,
  $rcontrols
  );
  
  }
  else{
    if($sboxdata['locked']!=1){$mresult.=$_lang['posts.loginrequired'];}
    else{$mresult.="<img src='"._templateImage("icons/bubble.gif")."' alt='locked' class='icon' /> ".$_lang['posts.locked2'];}
  }
  
  $mresult.="\n</div>\n<div class='sbox-posts'>";
  //vypis prispevku
  $sposts=mysql_query("SELECT id,text,author,guest,time,ip FROM `"._mysql_prefix."-posts` WHERE home=".$rid." AND type=4 ORDER BY id DESC");
  if(mysql_num_rows($sposts)!=0){
    while($spost=mysql_fetch_array($sposts)){
    
      //nacteni autora
      if($spost['author']!=-1){$author=_linkUser($spost['author'], "post-author' title='"._formatTime($spost['time']), false, false, 16, ":");}
      else{$author="<span class='post-author-guest' title='"._formatTime($spost['time']).", ip=".$spost['ip']."'>".$spost['guest'].":</span>";}
      
      //odkaz na spravu
      if(_postAccess($spost)){$alink=" <a href='index.php?m=editpost&amp;id=".$spost['id']."'><img src='"._templateImage("icons/edit.gif")."' alt='edit' class='icon' /></a>";}
      else{$alink="";}
    
      //kod polozky
      $mresult.="<div class='sbox-item'>".$author.$alink." "._parsePost($spost['text'], true, false, false)."</div>\n";
      
    }
  }
  else{
    $mresult.="\n<div class='sbox-item'>".$_lang['posts.noposts']."</div>\n";
  }

$mresult.="
</div>
</div>
</div>
";

  }

}
break;



//search
case "search":
if(_search){
$mresult="<form action='index.php' method='get' class='searchform'>
<input type='hidden' name='m' value='search' />
<input type='hidden' name='root' value='1' />
<input type='hidden' name='art' value='1' />
<input type='text' name='q' class='q' /> <input type='submit' value='".$_lang['mod.search.submit']."' />
</form>
";
}
break;



//linkroot
case "linkroot":
if(isset($paramarray[1])){
$id=intval($paramarray[1]);
$query=mysql_query("SELECT title FROM `"._mysql_prefix."-root` WHERE id=".$id);
if(isset($paramarray[3]) and _boolean($paramarray[3])){$target=" target='_blank'";}else{$target="";}
  if(mysql_num_rows($query)!=0){
  $query=mysql_fetch_array($query);
  if(isset($paramarray[2]) and $paramarray[2]!=""){$query['title']=$paramarray[2];}
  $mresult="<a href='"._linkRoot($id)."'".$target.">".$query['title']."</a>";
  }
}
break;



//linkart
case "linkart":
if(isset($paramarray[1])){
$id=intval($paramarray[1]);
$query=mysql_query("SELECT title FROM `"._mysql_prefix."-articles` WHERE id=".$id);
if(isset($paramarray[3]) and _boolean($paramarray[3])){$target=" target='_blank'";}else{$target="";}
  if(mysql_num_rows($query)!=0){
  $query=mysql_fetch_array($query);
  if(isset($paramarray[2]) and $paramarray[2]!=""){$query['title']=$paramarray[2];}
  $mresult="<a href='"._linkArticle($id)."'".$target.">".$query['title']."</a>";
  }
}
break;



//linkuser
case "linkuser":
if(isset($paramarray[1])){
$name=_safeStr(_anchorStr($paramarray[1], false));
$query=mysql_query("SELECT id FROM `"._mysql_prefix."-users` WHERE username='".$name."'");
  if(mysql_num_rows($query)!=0){
  $query=mysql_fetch_array($query);
  $mresult=_linkUser($query['id']);
  }
}
break;



//flash
case "flash":
if(isset($paramarray[1])){

  //prednastavene rozmery
  $defwidth="320"; $defheight="240";

  //nacteni parametru
  $file=_htmlStr($paramarray[1]);
  if(!_isAbsolutePath($file)){$file=_url."/".$file;}
  if(!isset($paramarray[2])){$width=$defwidth;}else{$width=intval($paramarray[2]); if(!isset($paramarray[3])){$height=round(0.75*$width);}}
  if(!isset($paramarray[3])){if(!isset($paramarray[2])){$height=$defheight;}}else{$height=intval($paramarray[3]);}

  //sestaveni kodu
  $mresult="
  <!--[if !IE]> -->
  <object type='application/x-shockwave-flash' data='".$file."' width='".$width."' height='".$height."'>
  <!-- <![endif]-->

  <!--[if IE]>
  <object classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000' codebase='http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0' width='$width' height='$height'>
  <param name='movie' value='".$file."' />
  <!--><!---->
  <param name='loop' value='true' />
  <param name='menu' value='false' />

  ".$_lang['hcm.player.alt']."
  </object>
  <!-- <![endif]-->
  ";

}
break;



//source
case "source":
if(isset($paramarray[1])){
$mresult="<div class='pre'>".nl2br(_htmlStr(trim($paramarray[1])))."</div>";
}
break;



//phpsource
case "phpsource":
if(isset($paramarray[1])){
$mresult="<div class='pre'>".highlight_string($paramarray[1], true)."</div>";
}
break;



//smileys
case "smileys":
if(isset($paramarray[1])){
  $mresult=_parsePost($paramarray[1], true, false, false);
}
break;



//custom
case "custom":
if(isset($paramarray[1])){
$filename=_anchorStr($paramarray[1], false);
$customfile=_indexroot."require/custom_hcm/".$filename.".php";
array_shift($paramarray); $params=$paramarray;
if(file_exists($customfile)){$mresult=_requireBox($customfile, $params, $__hcm_uid);}
else{$mresult=str_replace("*name*", $filename, $_lang['hcm.notfound']);}
}
break;



//default - modul nenalezen
default:
$mresult=str_replace("*name*", $paramarray[0], $_lang['hcm.notfound']);
break;



}

?>