<?php

/*--- inicializace jadra ---*/
define('_indexroot', '../');
define('_tmp_customheader', 'Content-type: application/javascript; charset=utf-8');
require(_indexroot."core.php");

?>
//otevreni okna
function _sysOpenWindow(url, width, height){
return !window.open(url, "_blank", "width="+width+",height="+height+",toolbar=0,location=0,status=0,menubar=0,resizable=1,scrollbars=1");
}

//script loader
function _sysScriptLoader(url){

    //smazani predchoziho loaderu
    var head=document.getElementsByTagName('head')[0];
    var dataLoader=document.getElementById('scriptLoader');
    if(dataLoader){head.removeChild(dataLoader);}

    //vytvoreni noveho elementu script
    script=document.createElement('script');
    script.id='scriptLoader';
    script.src =url+'&amp;r='+Math.random();

    //vlozeni skriptu
    head.appendChild(script);

}

//vypnuti prvku formulare
function _sysDisableField(checked, form, field){
 if(checked){eval("document."+form+"."+field+".disabled=true;");}
 else{eval("document."+form+"."+field+".disabled=false;");}
}

//systemova zprava
function _sysAlert(id){

  switch(id){
  case 1: text="<?php echo $_lang['javascript.alert.someempty']; ?>"; break;
  case 2: text="<?php echo $_lang['javascript.alert.toolong']; ?>"; break;
  }

alert(text);
}

//potvrzeni
function _sysConfirm(){
return confirm("<?php echo $_lang['javascript.confirm']; ?>");
}

//nahrazeni znaku zavinace
function _sysMai_lto(f) {
	var re = "<?php echo _atreplace; ?>";
	var addr = f.innerHTML.replace(re,'@');
	f.href = 'mai'+'lt'+'o:'+addr;
	return true;
}

//pridani smajlu
function _sysAddSmiley(fid, aid, text){
eval("txtarea=document."+fid+"."+aid+";");
text=" *"+text+"* ";
if (document.all) {
    if (txtarea.createTextRange && txtarea.caretPos) {
      var caretPos = txtarea.caretPos;
      caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ? text+caretPos.text + ' ' : text+caretPos.text;
    }
    else {txtarea.value = txtarea.value + text; }
}
else if (document.getElementById) {
    var selLength = txtarea.textLength;
    var selStart = txtarea.selectionStart;
    var selEnd = txtarea.selectionEnd;
    if (selEnd==1 || selEnd==2) selEnd=selLength;
    var s1 = (txtarea.value).substring(0,selStart);
    var s2 = (txtarea.value).substring(selStart, selEnd)
    var s3 = (txtarea.value).substring(selEnd, selLength);
    txtarea.value = s1 + text + s2 + s3;
    txtarea.selectionStart=selStart+text.length;
    txtarea.selectionEnd=selStart+text.length;
    }

txtarea.focus();
return false;
}

//vlozeni bbcode zagu
function _sysAddBBCode(fid, aid, text){
eval("txtarea=document."+fid+"."+aid+";");
if (document.all) {
  text="[" + text + "]" + "[/" + text + "]";
    if (txtarea.createTextRange && txtarea.caretPos) {
      var caretPos = txtarea.caretPos;
      caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ? text+caretPos.text + ' ' : text+caretPos.text;
    }
    else {txtarea.value = txtarea.value + text; }
}
else if (document.getElementById) {
    var selLength = txtarea.textLength;
    var selStart = txtarea.selectionStart;
    var selEnd = txtarea.selectionEnd;
    if (selEnd==1 || selEnd==2) selEnd=selLength;
    var s1 = (txtarea.value).substring(0,selStart);
    var s2 = (txtarea.value).substring(selStart, selEnd)
    var s3 = (txtarea.value).substring(selEnd, selLength);
    txtarea.value = s1 + "[" + text + "]" + s2 + "[/" + text + "]" + s3;
    txtarea.selectionStart=selStart+text.length*2+5+s2.length;
    txtarea.selectionEnd=selStart+text.length*2+5+s2.length;
    }

txtarea.focus();
return false;
}

//rozbalovaci menu
function _sysHideShow(id, trigger) {
var el=document.getElementById(id);
if(el.style.display=='none' || el.style.display==''){el.style.display='block'; trigger.className="hs_opened";}
else{el.style.display='none'; trigger.className="hs_closed";}
return false;
}

//inicializace sbox-chatu
_sboxtimers=new Array();

function _sysSboxChatInit(hid, rtime){
  _sboxtimers[hid]=rtime+1;
  setTimeout("_sysSboxChatStep("+hid+");", 1);
}

//krok odpoctu sbox-chatu
function _sysSboxChatStep(hid){
if(_sboxtimers[hid]!=-1){
  
  eval("text=document.hcm_sboxform_"+hid+".text.value;");
  if(text==""){
    if(_sboxtimers[hid]>0){
      //odpocet
      _sboxtimers[hid]=_sboxtimers[hid]-1;
      document.getElementById("hcm_timer_"+hid).innerHTML="<?php echo $_lang['hcm.sbox.timer']; ?> "+_sboxtimers[hid];
      setTimeout("_sysSboxChatStep("+hid+");", 1000);
    }
    else{
      //obnoveni
      location.reload(true);
    }
  }
  else{
    document.getElementById("hcm_timer_"+hid).innerHTML="<?php echo $_lang['hcm.sbox.timerbroken']; ?>";
  }

}
}