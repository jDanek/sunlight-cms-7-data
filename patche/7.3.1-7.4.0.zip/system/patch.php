<?php

//priprava
error_reporting(E_ALL);
@mb_internal_encoding("UTF-8");
$new_dbversion="7.4.0";

//pripojeni
require("access.php");
$connection=@mysql_connect($server, $user, $password);
define('_mysql_prefix', $prefix);
@mysql_query("set names `utf8`");
$db=@mysql_select_db($database);

  //kontrola
  if(!$connection or !$db){
  echo "<p>Pripojeni k databazi se nezdarilo.</p>\n<hr /><pre>".mysql_error()."</pre>";
  exit;
  }
  
//kontrola verze databaze
$query=mysql_query("SELECT val FROM `"._mysql_prefix."-settings` WHERE var='dbversion'");
if(mysql_num_rows($query)!=0){
  $query=mysql_fetch_array($query);
  if($query['val']==$new_dbversion){echo "Patch byl jiz pouzit. Odstrante soubor <em>patch.php</em> ze serveru!"; exit;}
}

//patch

$sql="
ALTER TABLE `".$prefix."-users` ADD `jabber` TINYTEXT NOT NULL AFTER `icq`
ALTER TABLE `".$prefix."-users` ADD `levelshift` BOOL NOT NULL AFTER `group`
UPDATE `".$prefix."-users` SET levelshift=1 WHERE id=0
ALTER TABLE `".$prefix."-groups` ADD `selfdestruction` BOOL NOT NULL
UPDATE `".$prefix."-groups` SET selfdestruction=1
ALTER TABLE `".$prefix."-users` ADD `logincounter` INT NOT NULL AFTER `salt`
UPDATE `".$prefix."-users` SET logincounter=1
INSERT INTO `".$prefix."-settings` (`var` ,`val`) VALUES ('uploadavatar', '0')
UPDATE `".$prefix."-settings` SET val='7.4.0' WHERE var='dbversion'
";
$sql_error=false;
$sql=explode("\n", trim($sql));
foreach($sql as $line){
  @mysql_query($line);
  if(mysql_error()!=false){$sql_error=mysql_error(); break;}
}

//zaverecna zprava
if($sql_error==false){
  echo "Patch byl aplikovan.";
  if(!@unlink("patch.php")){echo " Smazte soubor <em>patch.php</em> ze serveru!";}
}
else{
  echo "<p>Behem patchovani nastala chyba!</p>\n<pre>".$sql_error."</pre>";
}


?>