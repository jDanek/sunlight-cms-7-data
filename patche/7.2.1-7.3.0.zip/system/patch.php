<?php

//priprava
error_reporting(E_ALL);
@mb_internal_encoding("UTF-8");
$new_dbversion="7.3.1";

//pripojeni
require("access.php");
$connection=@mysql_connect($server, $user, $password);
define('_mysql_prefix', $prefix);
@mysql_query("set names `utf8`");
$db=@mysql_select_db($database);

  //kontrola
  if(!$connection or !$db){
  echo "<p>Pripojeni k databazi se nezdarilo.</p>\n<hr /><pre>".mysql_error()."</pre>";
  exit;
  }
  
//kontrola verze databaze
$query=mysql_query("SELECT val FROM `"._mysql_prefix."-settings` WHERE var='dbversion'");
if(mysql_num_rows($query)!=0){
  $query=mysql_fetch_array($query);
  if($query['val']==$new_dbversion){echo "Patch byl jiz pouzit. Odstrante soubor <em>patch.php</em> ze serveru!"; exit;}
}

//patch

$sql="
INSERT INTO `"._mysql_prefix."-settings` (`var` ,`val`) VALUES ('adminscheme', '0'), ('dbversion', '7.3.0'), ('favicon', '0'), ('rules', ''), ('printart', '1'), ('extratopicslimit', '15'), ('rsslimit', '30'), ('sboxmemory', '30'), ('ratemode', '2'), ('time_format', 'j.n.Y G:i')
ALTER TABLE `"._mysql_prefix."-users` ADD `publicname` TINYTEXT NOT NULL AFTER `username`
UPDATE `"._mysql_prefix."-images` SET prev='' WHERE prev='*auto*'
DELETE FROM `"._mysql_prefix."-settings` WHERE var='adminintro'
ALTER TABLE `"._mysql_prefix."-articles` ADD `commentslocked` BOOL NOT NULL AFTER `comments`  
ALTER TABLE `"._mysql_prefix."-articles` ADD `showinfo` tinyint(1) NOT NULL 
ALTER TABLE `"._mysql_prefix."-users` ADD `web` TINYTEXT NOT NULL AFTER `avatar` , ADD `skype` TINYTEXT NOT NULL AFTER `web` , ADD `msn` TINYTEXT NOT NULL AFTER `skype`
CREATE TABLE `"._mysql_prefix."-sboxes` (`id` BIGINT NOT NULL ,`title` TINYTEXT NOT NULL ,`locked` BOOL NOT NULL ,`public` BOOL NOT NULL) ENGINE = MYISAM
ALTER TABLE `"._mysql_prefix."-sboxes` CHANGE `title` `title` TINYTEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
ALTER TABLE `"._mysql_prefix."-groups` ADD `adminsbox` BOOL NOT NULL AFTER `adminpollall` 
UPDATE `"._mysql_prefix."-groups` SET adminsbox=1 WHERE id=1
ALTER TABLE `"._mysql_prefix."-groups` ADD `blocked` tinyint(1) NOT NULL 
ALTER TABLE `"._mysql_prefix."-groups` ADD `adminposts` BOOL NOT NULL AFTER `adminbans` ;
UPDATE `"._mysql_prefix."-groups` SET adminposts=1 WHERE id=1
UPDATE `"._mysql_prefix."-groups` SET icon='root.gif' WHERE icon='boss.gif'
ALTER TABLE `"._mysql_prefix."-groups` ADD `adminforum` BOOL NOT NULL AFTER `adminintersection`
UPDATE `"._mysql_prefix."-groups` SET adminforum=1 WHERE id=1
ALTER TABLE `"._mysql_prefix."-articles` ADD PRIMARY KEY ( `id` )
ALTER TABLE `"._mysql_prefix."-articles` ADD INDEX ( `author` , `home1` , `home2` , `home3` , `time` , `visible` , `public` , `confirmed` )
ALTER TABLE `"._mysql_prefix."-boxes` ADD PRIMARY KEY ( `id` )
ALTER TABLE `"._mysql_prefix."-boxes` ADD INDEX ( `visible` , `public` , `column` )
ALTER TABLE `"._mysql_prefix."-groups` ADD PRIMARY KEY ( `id` )
ALTER TABLE `"._mysql_prefix."-images` ADD PRIMARY KEY ( `id` )
ALTER TABLE `"._mysql_prefix."-images` ADD INDEX ( `home` )
ALTER TABLE `"._mysql_prefix."-iplog` ADD PRIMARY KEY ( `id` )
ALTER TABLE `"._mysql_prefix."-iplog` ADD INDEX ( `ip` ( 15 ) , `type` , `time` , `var` )
ALTER TABLE `"._mysql_prefix."-messages` ADD PRIMARY KEY ( `id` )
ALTER TABLE `"._mysql_prefix."-messages` ADD INDEX ( `sender` , `receiver` , `readed` , `time` )
ALTER TABLE `"._mysql_prefix."-polls` ADD PRIMARY KEY ( `id` )
ALTER TABLE `"._mysql_prefix."-polls` ADD INDEX ( `author` )
ALTER TABLE `"._mysql_prefix."-posts` ADD PRIMARY KEY ( `id` )
ALTER TABLE `"._mysql_prefix."-posts` ADD INDEX ( `type` , `home` , `xhome` , `author` , `time` )
ALTER TABLE `"._mysql_prefix."-root` ADD PRIMARY KEY ( `id` )
ALTER TABLE `"._mysql_prefix."-root` ADD INDEX ( `type` , `intersection` , `visible` , `public` )
ALTER TABLE `"._mysql_prefix."-users` ADD PRIMARY KEY ( `id` )
ALTER TABLE `"._mysql_prefix."-users` ADD INDEX ( `group` , `username` ( 4 ) , `registertime` , `activitytime` )
ALTER TABLE `"._mysql_prefix."-users` ADD `salt` TINYTEXT NOT NULL AFTER `password`
ALTER TABLE `"._mysql_prefix."-articles` CHANGE `id` `id` INT NOT NULL , CHANGE `home1` `home1` INT NOT NULL , CHANGE `home2` `home2` INT NOT NULL , CHANGE `home3` `home3` INT NOT NULL , CHANGE `time` `time` INT NOT NULL , CHANGE `readed` `readed` INT NOT NULL , CHANGE `ratesum` `ratesum` INT NOT NULL
ALTER TABLE `"._mysql_prefix."-boxes` CHANGE `id` `id` INT NOT NULL
ALTER TABLE `"._mysql_prefix."-groups` CHANGE `id` `id` INT NOT NULL
ALTER TABLE `"._mysql_prefix."-images` CHANGE `id` `id` INT( 20 ) NOT NULL , CHANGE `home` `home` INT( 20 ) NOT NULL
ALTER TABLE `"._mysql_prefix."-iplog` CHANGE `id` `id` INT NOT NULL , CHANGE `time` `time` INT NOT NULL , CHANGE `var` `var` INT NOT NULL
ALTER TABLE `"._mysql_prefix."-messages` CHANGE `id` `id` INT NOT NULL , CHANGE `sender` `sender` INT NOT NULL , CHANGE `receiver` `receiver` INT NOT NULL , CHANGE `time` `time` INT NOT NULL
ALTER TABLE `"._mysql_prefix."-polls` CHANGE `id` `id` INT NOT NULL , CHANGE `author` `author` INT NOT NULL
ALTER TABLE `"._mysql_prefix."-posts` CHANGE `id` `id` INT NOT NULL , CHANGE `home` `home` INT NOT NULL , CHANGE `xhome` `xhome` INT NOT NULL , CHANGE `author` `author` INT NOT NULL , CHANGE `time` `time` INT NOT NULL
ALTER TABLE `"._mysql_prefix."-root` CHANGE `id` `id` INT NOT NULL
ALTER TABLE `"._mysql_prefix."-sboxes` CHANGE `id` `id` INT NOT NULL
ALTER TABLE `"._mysql_prefix."-users` CHANGE `id` `id` INT NOT NULL , CHANGE `group` `group` INT NOT NULL , CHANGE `registertime` `registertime` INT NOT NULL , CHANGE `activitytime` `activitytime` INT NOT NULL , CHANGE `icq` `icq` INT NOT NULL
ALTER TABLE `"._mysql_prefix."-articles` CHANGE `ratenum` `ratenum` INT NOT NULL
";
$sql_error=false;
$sql=explode("\n", trim($sql));
foreach($sql as $line){
  if($line==""){continue;}
  @mysql_query($line);
  if(mysql_error()!=false){$sql_error=mysql_error();}
}

//zaverecna zprava
if($sql_error==false){
  echo "Patch byl aplikovan.";
  if(!@unlink("patch.php")){echo " Smazte soubor <em>patch.php</em> ze serveru!";}
}
else{
  echo "<p>Behem patchovani nastala chyba!</p>\n<pre>".$sql_error."</pre>";
}


?>