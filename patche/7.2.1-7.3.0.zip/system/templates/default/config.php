<?php

/*---- konfigurace motivu ----*/

//hlavni nastaveni
define('_template_version', '2.0');
define('_template_autoheadings', 1);
define('_template_smileys', 10);
define('_template_smileys_list', 0);
define('_template_bbcode_buttons', 1);
define('_template_intersec_backlink', 1);
define('_template_listinfoseparator', ' &nbsp;&bull;&nbsp; ');
define('_template_votebarwidthreduction', 12);

//menu
define('_template_menu_parent', 'ul');
define('_template_menu_child', 'li');

//uzivatelske menu
define('_template_usermenu_parent', 'ul');
define('_template_usermenu_item_start', '<li>');
define('_template_usermenu_item_end', '</li>');
define('_template_usermenu_trim', 0);
define('_template_usermenu_showusername', 0);

//boxy
define('_template_boxes_parent', '');
define('_template_boxes_item', '');
define('_template_boxes_title', 'h3');
define('_template_boxes_title_inside', 0);
define('_template_boxes_bottom', 0);

?>