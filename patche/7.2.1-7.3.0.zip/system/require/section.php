<?php

//kontrola jadra
if(!defined('_core')){exit;}

//titulek, obsah
$title=$query['title'];
$content="";
if($query['var2']==1){$content.="<h1>".$title."</h1>";}
$content.=_parseHCM($query['content']);
if($query['var1']==1 and _comments){$content.=_postsOutput(1, $id, $query['var3']);}

?>