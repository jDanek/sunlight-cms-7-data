<?php

/*--- kontrola jadra ---*/
if(!defined('_core')){exit;}

/*-- script --*/
@session_start();
$result=0;

  //pole prav
  $rights_array=array(
  "level",
  "administration",
  "adminsettings",
  "adminusers",
  "admingroups",
  "admincontent",
  "adminsection",
  "admincategory",
  "adminbook",
  "adminseparator",
  "admingallery",
  "adminlink",
  "adminintersection",
  "adminforum",
  "adminart",
  "adminallart",
  "adminchangeartauthor",
  "adminpoll",
  "adminpollall",
  "adminsbox",
  "adminbox",
  "adminconfirm",
  "adminneedconfirm",
  "adminfman",
  "adminfmanlimit",
  "adminfmanplus",
  "adminhcmphp",
  "adminbackup",
  "adminmassemail",
  "adminbans",
  "adminposts",
  "changeusername",
  "unlimitedpostaccess",
  "postcomments",
  "artrate",
  "pollvote"
  );

  //kontrola existence session
  if(isset($_SESSION[_sessionprefix."user"]) and isset($_SESSION[_sessionprefix."password"]) and isset($_SESSION[_sessionprefix."ip"])){

    //kontroly
    $id=intval($_SESSION[_sessionprefix."user"]);
    $pass=$_SESSION[_sessionprefix."password"];
    $ip=$_SESSION[_sessionprefix."ip"];
    $query=mysql_query("SELECT * FROM `"._mysql_prefix."-users` WHERE id=".$id);

      $continue=false;
      if(mysql_num_rows($query)!=0){
      $query=mysql_fetch_array($query);
      $groupblock=mysql_fetch_array(mysql_query("SELECT blocked FROM `"._mysql_prefix."-groups` WHERE id=".$query['group']));
        if($query['password']==$pass and $query['blocked']==0 and $groupblock['blocked']==0 and $ip==_userip){
        $continue=true;
        }
      }

      //zabiti neplatne session
      if($continue!=true){
      $_SESSION=array();
      session_destroy();
      if(_administration!=1){header("location: "._indexroot."index.php?m=login&_mlr=3");}
      else{header("location: "._indexroot."admin/index.php?_mlr=3");}
      }

    //definovani konstant
    if($continue){
    $result=1;
    define('_loginid', $query['id']);
    define('_loginname', $query['username']);
      if($query['publicname']!=""){define('_loginpublicname', $query['publicname']);}
      else{define('_loginpublicname', $query['username']);}
    define('_loginemail', $query['email']);
    define('_loginwysiwyg', $query['wysiwyg']);
    define('_loginlanguage', $query['language']);

      //konstanty skupiny
      $query=mysql_fetch_array(mysql_query("SELECT * FROM `"._mysql_prefix."-groups` WHERE id=".$query['group']));
      define('_loginright_group', $query['id']);
      define('_loginright_groupname', $query['title']);

            //ultra-level hlavniho administratora
            if(_loginid==0){$query['level']=10001;}

        foreach($rights_array as $item){
        define('_loginright_'.$item, $query[$item]);
        }

      //zaznamenani casu aktivity
      mysql_query("UPDATE `"._mysql_prefix."-users` SET activitytime='".time()."', ip='".$_SERVER['REMOTE_ADDR']."' WHERE id="._loginid);

    }

  }
  else{

  //konstanty hosta
  define('_loginid', -1);
  define('_loginname', '');
  define('_loginpublicname', '');
  define('_loginemail', '');
  define('_loginwysiwyg', 0);
  define('_loginlanguage', '*');

    //konstanty skupiny
    $query=mysql_fetch_array(mysql_query("SELECT * FROM `"._mysql_prefix."-groups` WHERE id=2"));
    define('_loginright_group', $query['id']);
    define('_loginright_groupname', $query['title']);

      foreach($rights_array as $item){
      define('_loginright_'.$item, $query[$item]);
      }
  }

  //konstanta pro indikaci prihlaseni
  define('_loginindicator', $result);

?>