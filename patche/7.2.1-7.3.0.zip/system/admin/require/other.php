<?php

/*--- kontrola jadra ---*/
if(!defined('_core')){exit;}

/*--- vystup ---*/
$output.="
<p class='bborder'>".$_lang['admin.other.p']."</p>
<ul id='other-list'>\n"
._condReturn(_loginright_adminmassemail, "<li><a href='index.php?p=other-massemail'>".$_lang['admin.other.massemail.title']."</a></li>\n")
._condReturn(_loginright_adminbans, "<li><a href='index.php?p=other-bans'>".$_lang['admin.other.bans.title']."</a></li>\n")
._condReturn(_loginright_adminbackup, "<li><a href='index.php?p=other-backup'>".$_lang['admin.other.backup.title']."</a></li>\n")
._condReturn(_loginid==0, "<li><a href='index.php?p=other-cleanup'>".$_lang['admin.other.cleanup.title']."</a></li>\n<li><a href='remote/sqlex.php' target='_blank'>".$_lang['admin.other.sqlex.title']."</a></li>\n")
."</ul>";

?>