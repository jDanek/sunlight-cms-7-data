<?php

/*--- kontrola jadra ---*/
if(!defined('_core')){exit;}

/*--- nacteni promennych ---*/
$message="";
$continue=false;
if(isset($_GET['id']) and isset($_GET['returnid']) and isset($_GET['returnpage'])){
$id=intval($_GET['id']);
$returnid=$_GET['returnid']; if($returnid!="load"){$returnid=intval($returnid);}
$returnpage=intval($_GET['returnpage']);
$query=mysql_query("SELECT * FROM `"._mysql_prefix."-articles` WHERE id=".$id._tmp_artAccess());
  if(mysql_num_rows($query)!=0){
  $query=mysql_fetch_array($query);
  $readed_counter=$query['readed'];
  if($returnid=="load"){$returnid=$query['home1'];} $backlink="index.php?p=content-articles-list&amp;cat=".$returnid."&amp;page=".$returnpage;
  $actionplus="&amp;id=".$id."&amp;returnid=".$returnid."&amp;returnpage=".$returnpage;
  $submittext="global.savechanges";
  $artlink=" <a href='"._indexroot._linkArticle($query['id'])."' target='_blank'><img src='images/icons/loupe.gif' alt='prev' /></a>";
  $new=false;
  $continue=true;
  }
}
else{
$backlink="index.php?p=content-articles";
$actionplus="";
$submittext="global.create";
$artlink="";
$new=true;
$id=-1;
$readed_counter=0;
$query=array(
"id"=>-1,
"title"=>"",
"perex"=>"",
"content"=>"",
"infobox"=>"",
"author"=>_loginid,
"home1"=>-2,
"home2"=>-1,
"home3"=>-1,
"time"=>time(),
"visible"=>1,
"public"=>1,
"comments"=>1,
"commentslocked"=>0,
"showinfo"=>1,
"confirmed"=>!_loginright_adminneedconfirm,
"rateon"=>1,
"readed"=>0
);

$continue=true;
}

/*--- ulozeni ---*/
if(isset($_POST['title'])){

  //nacteni promennych
  $newdata['title']=_safeStr(_htmlStr($_POST['title']));
  $newdata['home1']=intval($_POST['home1']);
  $newdata['home2']=intval($_POST['home2']);
  $newdata['home3']=intval($_POST['home3']);
  if(_loginright_adminchangeartauthor){$newdata['author']=intval($_POST['author']);}else{$newdata['author']=$query['author'];}
  $newdata['perex']=_safeStr(_stripSlashes($_POST['perex']), false);
  $newdata['content']=_safeStr(_filtrateHCM(_stripSlashes($_POST['content'])), false);
  $newdata['infobox']=_safeStr(_filtrateHCM(_stripSlashes($_POST['infobox'])), false);
  $newdata['public']=_checkboxLoad('public');
  $newdata['visible']=_checkboxLoad('visible');
  if(_loginright_adminconfirm){$newdata['confirmed']=_checkboxLoad('confirmed');}else{$newdata['confirmed']=$query['confirmed'];}
  $newdata['comments']=_checkboxLoad('comments');
  $newdata['commentslocked']=_checkboxLoad('commentslocked');
  $newdata['rateon']=_checkboxLoad('rateon');
  $newdata['showinfo']=_checkboxLoad('showinfo');
  $newdata['resetrate']=_checkboxLoad('resetrate');
  $newdata['delcomments']=_checkboxLoad('delcomments');
  $newdata['resetread']=_checkboxLoad('resetread');
  $newdata['time']=_tmp_loadTime($query['time']);
  
  //kontrola promennych
  $error_log=array();

    //titulek
    if($newdata['title']==""){$error_log[]=$_lang['admin.content.articles.edit.error1'];}

    //kategorie
    $homechecks=array("home1", "home2", "home2");
    foreach($homechecks as $homecheck){
      if($newdata[$homecheck]!=-1 or $homecheck=="home1"){
        if(mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-root` WHERE type=2 AND id=".$newdata[$homecheck]), 0)==0){
        $error_log[]=$_lang['admin.content.articles.edit.error2'];
        }
      }
    }
    
      //zruseni duplikatu
      if($newdata['home1']==$newdata['home2']){$newdata['home2']=-1;}
      if($newdata['home2']==$newdata['home3'] or $newdata['home1']==$newdata['home3']){$newdata['home3']=-1;}
    
    //autor
    if(mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-users` WHERE id=".$newdata['author']." AND (id="._loginid." OR (SELECT level FROM `"._mysql_prefix."-groups` WHERE id=`"._mysql_prefix."-users`.`group`)<"._loginright_level.")"), 0)==0){
    $error_log[]=$_lang['admin.content.articles.edit.error3'];
    }
  
  //ulozeni
  if(count($error_log)==0){

    if(!$new){
    
      //data
      mysql_query("UPDATE `"._mysql_prefix."-articles` SET title='".$newdata['title']."',home1=".$newdata['home1'].",home2=".$newdata['home2'].",home3=".$newdata['home3'].",author=".$newdata['author'].",perex='".$newdata['perex']."',content='".$newdata['content']."',infobox='".$newdata['infobox']."',public=".$newdata['public'].",visible=".$newdata['visible'].",confirmed=".$newdata['confirmed'].",comments=".$newdata['comments'].",commentslocked=".$newdata['commentslocked'].",rateon=".$newdata['rateon'].",showinfo=".$newdata['showinfo'].",time=".$newdata['time']." WHERE id=".$id);
    
      //smazani komentaru
      if($newdata['delcomments']==1){mysql_query("DELETE FROM `"._mysql_prefix."-posts` WHERE type=2 AND home=".$id);}
      
      //vynulovani poctu precteni
      if($newdata['resetread']==1){mysql_query("UPDATE `"._mysql_prefix."-articles` SET readed=0 WHERE id=".$id);}
      
      //vynulovani hodnoceni
      if($newdata['resetrate']==1){
      mysql_query("UPDATE `"._mysql_prefix."-articles` SET ratenum=0,ratesum=0 WHERE id=".$id);
      mysql_query("DELETE FROM `"._mysql_prefix."-iplog` WHERE type=3 AND var=".$id);
      }
    
      //presmerovani
      define('_tmp_redirect', 'index.php?p=content-articles-edit&id='.$id.'&saved&returnid='.$returnid.'&returnpage='.$returnpage);

    }
    else{

      //vlozeni
      $newid=_getNewID("articles");
      mysql_query("INSERT INTO `"._mysql_prefix."-articles` (id,title,perex,content,infobox,author,home1,home2,home3,time,visible,public,comments,commentslocked,confirmed,showinfo,readed,rateon,ratenum,ratesum) VALUES (".$newid.",'".$newdata['title']."','".$newdata['perex']."','".$newdata['content']."','".$newdata['infobox']."',".$newdata['author'].",".$newdata['home1'].",".$newdata['home2'].",".$newdata['home3'].",".$newdata['time'].",".$newdata['visible'].",".$newdata['public'].",".$newdata['comments'].",".$newdata['commentslocked'].",".intval(!_loginright_adminneedconfirm).",".$newdata['showinfo'].",0,".$newdata['rateon'].",0,0)");

      //presmerovani
      define('_tmp_redirect', 'index.php?p=content-articles-edit&id='.$newid.'&created&returnid='.$newdata['home1'].'&returnpage=1');

    }

  }
  else{
  $message=_formMessage(2, _eventList($error_log, 'errors'));
  }

}


/*--- vystup ---*/
if($continue){

  //vyber autora
  if(_loginright_adminchangeartauthor){
  $author_select="
  <tr>
  <td class='rpad'><strong>".$_lang['article.author']."</strong></td>
  <td>"._tmp_authorSelect("author", $query['author'], "adminart=1", "selectbig")."</td></tr>
  ";
  }
  else{
  $author_select="";
  }
  
  //zprava
  if(isset($_GET['saved'])){$message=_formMessage(1, $_lang['global.saved']."&nbsp;&nbsp;<small>("._formatTime(time()).")</small>");}
  if(isset($_GET['created'])){$message=_formMessage(1, $_lang['global.created']);}

//wysiwyg editor
$output.=_tmp_wysiwyg();

//vypocet hodnoceni
if(!$new){
  if($query['ratenum']!=0){$rate=mysql_result(mysql_query("SELECT ROUND(ratesum/ratenum) FROM `"._mysql_prefix."-articles` WHERE id=".$query['id']), 0)."%, ".$query['ratenum']."x";}
  else{$rate=$_lang['article.rate.nodata'];}
}
else{
  $rate="";
}

//formular
$output.="
<a href='".$backlink."' class='backlink'>&lt; ".$_lang['global.return']."</a>
<h1>".$_lang['admin.content.articles.edit.title']."</h1>
<p class='bborder'>".$_lang['admin.content.articles.edit.p']."</p>".$message."

"._condReturn($new==true and _loginright_adminneedconfirm, _tmp_smallNote($_lang['admin.content.articles.edit.newconfnote']))."
"._condReturn($new==false and $query['confirmed']!=1, _tmp_smallNote($_lang['admin.content.articles.edit.confnote']))."

<form class='cform' action='index.php?p=content-articles-edit".$actionplus."' method='post' name='artform'"._jsCheckForm("artform", array("title")).">

<table>

<tr>
<td class='rpad'><strong>".$_lang['admin.content.form.title']."</strong></td>
<td><input type='text' name='title' value='".$query['title']."' class='inputbig' /></td>
</tr>

<tr>
<td class='rpad'><strong>".$_lang['article.category']."</strong></td>
<td>"._tmp_rootSelect("home1", 2, $query['home1'], false)." "._tmp_rootSelect("home2", 2, $query['home2'], true)." "._tmp_rootSelect("home3", 2, $query['home3'], true)."</td>
</tr>

".$author_select."

<tr valign='top'>
<td class='rpad'><strong>".$_lang['admin.content.form.perex']."</strong></td>
<td><textarea name='perex' rows='9' cols='94' class='areabigperex'>"._htmlStr($query['perex'])."</textarea></td>
</tr>

<tr valign='top'>
<td class='rpad'><strong>".$_lang['admin.content.form.content']."</strong>".$artlink."</td>
<td>

  <table id='ae-table'>
  <tr valign='top'>
    <td id='content-cell'>
      <textarea name='content' rows='25' cols='68' id='wysiwygtarget'>"._htmlStr($query['content'])."</textarea>
    </td>
    <td id='is-cell'>
      <div>
      <h2>".$_lang['admin.content.form.infobox']."</h2>
      <textarea name='infobox' rows='10' cols='20'>"._htmlStr($query['infobox'])."</textarea><br /><br />
      <h2>".$_lang['admin.content.form.settings']."</h2>
      <p>
      <label><input type='checkbox' name='public' value='1'"._checkboxActivate($query['public'])." /> ".$_lang['admin.content.form.public']."</label>
      <label><input type='checkbox' name='visible' value='1'"._checkboxActivate($query['visible'])." /> ".$_lang['admin.content.form.visible']."</label>
      "._condReturn(_loginright_adminconfirm and !$new, "<label><input type='checkbox' name='confirmed' value='1'"._checkboxActivate($query['confirmed'])." /> ".$_lang['admin.content.form.confirmed']."</label>")."
      <label><input type='checkbox' name='comments' value='1'"._checkboxActivate($query['comments'])." /> ".$_lang['admin.content.form.comments']."</label>
      <label><input type='checkbox' name='commentslocked' value='1'"._checkboxActivate($query['commentslocked'])." /> ".$_lang['admin.content.form.commentslocked']."</label>
      <label><input type='checkbox' name='rateon' value='1'"._checkboxActivate($query['rateon'])." /> ".$_lang['admin.content.form.artrate']."</label>
      <label><input type='checkbox' name='showinfo' value='1'"._checkboxActivate($query['showinfo'])." /> ".$_lang['admin.content.form.showinfo']."</label>
      "._condReturn(!$new, "<label><input type='checkbox' name='resetrate' value='1' /> ".$_lang['admin.content.form.resetartrate']." <small>(".$rate.")</small></label>")."
      "._condReturn(!$new, "<label><input type='checkbox' name='delcomments' value='1' /> ".$_lang['admin.content.form.delcomments']." <small>(".mysql_result(mysql_query("SELECT COUNT(*) FROM `"._mysql_prefix."-posts` WHERE home=".$query['id']." AND type=2"), 0).")</small></label>")."
      "._condReturn(!$new, "<label><input type='checkbox' name='resetread' value='1' /> ".$_lang['admin.content.form.resetartread']." <small>(".$readed_counter.")</small></label>")."
      </p>
      </div>
    </td>
  </tr>
  </table>

</td>
</tr>

<tr id='time-cell'>
<td class='rpad'><strong>".$_lang['article.posted']."</strong></td>
<td>"._tmp_editTime($query['time'], true, $new)."</td>
</tr>

<tr>
<td></td>
<td><br /><input type='submit' value='".$_lang[$submittext]."' />
"._condReturn(!$new, "
&nbsp;&nbsp;
<span class='customsettings'><a href='index.php?p=content-articles-delete&amp;id=".$query['id']."&amp;returnid=".$query['home1']."&amp;returnpage=1'><span><img src='images/icons/delete.gif' alt='del' class='icon' />".$_lang['global.delete']."</span></a></span>&nbsp;&nbsp;
<span class='customsettings'><small>".$_lang['admin.content.form.thisid']." ".$query['id']."</small></span>
")."
</td>
</tr>

</table>

</form>

";

}
else{
$output.="<a href='index.php?p=content-articles' class='backlink'>&lt; ".$_lang['global.return']."</a>\n<h1>".$_lang['admin.content.articles.edit.title']."</h1>\n"._formMessage(3, $_lang['global.badinput']);
}




?>