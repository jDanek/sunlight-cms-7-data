<?php

/*--- kontrola jadra ---*/
if(!defined('_core')){exit;}

/*--- pripava promennych ---*/
$mysqlver=mysql_get_server_info();
if(mb_substr_count($mysqlver, "-")!=0){$mysqlver=mb_substr($mysqlver, 0, strpos($mysqlver, "-"));}
$software=getenv('SERVER_SOFTWARE');
if(mb_strlen($software)>16){$software=substr($software, 0, 13)."...";}

/*--- vystup ---*/

  //nacteni verze mysql
  $mysqlver=@mysql_get_server_info();
  if($mysqlver!=null and mb_substr_count($mysqlver, "-")!=0){$mysqlver=mb_substr($mysqlver, 0, strpos($mysqlver, "-"));}

$output.="
<table id='indextable'>


<tr valign='top'>

<td>
  <h1>".$_lang['admin.menu.index']."</h1>
  <p>".$_lang['admin.index.p']."</p>
  <ul>
  <li><a href='http://sunlight-cms.net/' target='_blank'>".$_lang['admin.link.web']."</a></li>
  <li><a href='http://sunlight-cms.net/feedback/docs.php' target='_blank'>".$_lang['admin.link.docs']."</a></li>
  <li><a href='http://sunlight-cms.net/feedback/forum.php' target='_blank'>".$_lang['admin.link.forum']."</a></li>
  </ul>
</td>

<td width='200'>
  <h2>".$_lang['admin.index.box']."</h2>
  <p>
  <strong>".$_lang['global.version'].":</strong> "._systemversion."."._systembuild."<br />
  <span id='hook'></span>
  <strong>PHP:</strong> ".PHP_VERSION."<br />
  <strong>MySQL:</strong> ".$mysqlver."<br />
  </p>
</td>

</tr>


<tr>
<td colspan='2'>
<div id='news-box'>
<h2>Oficiální novinky a oznámení</h2>
<div id='news'><p><em>".$_lang['global.loading']."</em></p></div>
</div>
</td>
</tr>


</table>


<script type='text/javascript'>_sysScriptLoader(_hook);</script>
";
?>