<?php













if(!defined('_core_no_env_changes')) {


if(!extension_loaded('mbstring')) die("# Na serveru neni nainstalovano nebo aktivovano rozsireni PHP o <em>mbstring</em> (Multibyte String Functions), ktere je potrebne pro praci s retezci v kadovani UTF-8.");
if(!extension_loaded('mysql')) die("#  Na serveru neni nainstalovano nebo aktivovano rozsireni PHP o <em>mysql</em>, ktere je potrebne pro praci s MySQL databazi.");


if(!isset($_SERVER['REQUEST_URI'])) {
if(isset($_SERVER['HTTP_X_REWRITE_URL'])) $_SERVER['REQUEST_URI'] = $_SERVER['HTTP_X_REWRITE_URL'];
elseif(isset($_SERVER['HTTP_REQUEST_URI'])) $_SERVER['REQUEST_URI'] = $_SERVER['HTTP_REQUEST_URI'];
else {
if(isset($_SERVER['SCRIPT_NAME'])) $_SERVER['HTTP_REQUEST_URI'] = $_SERVER['SCRIPT_NAME'];
else $_SERVER['HTTP_REQUEST_URI'] = $_SERVER['PHP_SELF'];
if(!empty($_SERVER['QUERY_STRING'])) $_SERVER['HTTP_REQUEST_URI'] .= '?'.$_SERVER['QUERY_STRING'];
$_SERVER['REQUEST_URI'] = $_SERVER['HTTP_REQUEST_URI'];
}
}


if(ini_get('register_globals') != '') {
$keys = array_keys($_REQUEST);
foreach($keys as $key) unset($GLOBALS[$key]);
}


if(function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc() === 1) {


$in = array(&$_GET, &$_POST, &$_COOKIE);
while(list($key, $val) = each($in)) {
foreach($val as $key2 => $val2) {
if(!is_array($val2)) {
$in[$key][$key2] = stripslashes($val2);
continue;
}
$in[] = &$in[$key][$key2];
}
}


if(function_exists('set_magic_quotes_runtime')) @set_magic_quotes_runtime(0);

}

}




if(!function_exists('memory_get_usage')) {





function memory_get_usage()
{
return 1048576;
}
}








abstract class DB
{







static public function query($sql, $expect_error = false)
{




$q = mysql_query($sql, _mysql_link);
if(_dev && $q === false && $expect_error === false) {

trigger_error(_htmlStr('SQL error: '.mysql_error(_mysql_link).' --- SQL code: '.$sql), E_USER_WARNING);
$e = new Exception;
echo "<pre>"._htmlStr($e->getTraceAsString())."</pre>\n";
}
return $q;
}







static public function query_row($sql, $expect_error = false)
{
$q = self::query($sql, $expect_error);
if(false === $q) return false;
$row = self::row($q);
self::free($q);
return $row;
}







static public function count($table, $where = '1')
{
$q = self::query('SELECT COUNT(*) FROM `'.$table.'` WHERE '.$where);
if(is_resource($q)) {
$count = intval(mysql_result($q, 0));
mysql_free_result($q);
return $count;
}
return 0;
}





static public function error()
{
return mysql_error(_mysql_link);
}






static public function row($query)
{
return mysql_fetch_assoc($query);
}






static public function rown($query)
{
return mysql_fetch_row($query);
}







static public function result($query, $row, $field = 0)
{
return mysql_result($query, $row, $field);
}






static public function free($query)
{
return mysql_free_result($query);
}






static public function size($query)
{
return mysql_num_rows($query);
}





static public function insertID()
{
return mysql_insert_id(_mysql_link);
}





static public function affectedRows()
{
return mysql_affected_rows(_mysql_link);
}







static public function esc($value, $handleArray = false)
{
if(null === $value) return null;
if($handleArray && is_array($value)) {
foreach($value as &$item) $item = self::esc($item);
return $item;
}
if(is_string($value)) return mysql_real_escape_string($value, _mysql_link);
if(is_numeric($value)) return (0 + $value);
return mysql_real_escape_string(@strval($value), _mysql_link);
}







static public function val($value, $handleArray = false)
{
$value = self::esc($value, $handleArray);
if($handleArray && is_array($value)) {
$out = '';
$itemCounter = 0;
foreach($value as $item) {
if(0 !== $itemCounter) $out .= ',';
$out .= self::val($item);
++$itemCounter;
}
return $out;
} elseif(is_string($value)) return '\''.$value.'\'';
elseif(null === $value) return 'NULL';
return $value;
}






static public function arr($arr)
{
$sql = '';
for($i = 0; isset($arr[$i]); ++$i) {
if(0 !== $i) $sql .= ',';
$sql .= self::val($arr[$i]);
}
return $sql;
}








static public function insert($table, $data, $get_insert_id = false)
{
if(empty($data)) return false;
$counter = 0;
$col_list = '';
$val_list = '';
foreach($data as $col => $val) {
if(0 !== $counter) {
$col_list .= ',';
$val_list .= ',';
}
$col_list .= "`{$col}`";
$val_list .= self::val($val);
++$counter;
}
$q = self::query("INSERT INTO `{$table}` ({$col_list}) VALUES({$val_list})");
if(false !== $q && $get_insert_id) return self::insertID();
return $q;
}









static public function update($table, $cond, $data, $limit = 1)
{
if(empty($data)) return false;
$counter = 0;
$set_list = '';
foreach($data as $col => $val) {
if(0 !== $counter) $set_list .= ',';
$set_list .= "`{$col}`=".self::val($val);
++$counter;
}
return self::query("UPDATE `{$table}` SET {$set_list} WHERE {$cond}".((null === $limit) ? '' : " LIMIT {$limit}"));
}






static public function datetime($timestamp)
{
return date('Y-m-d H:i:s', $timestamp);
}






static public function date($timestamp)
{
return date('Y-m-d', $timestamp);
}

}










function _addGetToLink($link, $params, $entity = true)
{


if($params !== '') {
if(mb_substr_count($link, "?") == 0) {
$link .= "?";
} else {
if($entity) {
$link .= "&amp;";
} else {
$link .= "&";
}
}
}

return $link.$params;
}








function _addFdGetToLink($url, $array)
{


if(mb_substr_count($url, "?") == 0) {
$url .= "?";
} else {
$url .= "&";
}


foreach($array as $key => $item) {
$url .= "_formData[".$key."]=".urlencode($item)."&";
}

return mb_substr($url, 0, mb_strlen($url) - 1);
}







function _buildQuery($items)
{

if(function_exists('http_build_query')) return http_build_query($items);
$output = '';
$last = sizeof($items) - 1;
$current = 0;
foreach($items as $key => $val) {
$output .= urlencode($key).'='.urlencode($val);
if($current !== $last) $output .= '&';
++$current;
}
return $output;

}








function _buildURL($parts)
{

$output = '';


if(!empty($parts['host'])) {
if(!empty($parts['scheme'])) $output .= $parts['scheme'].'://';
if(!empty($parts['user'])) $output .= $parts['user'];
if(!empty($parts['pass'])) $output .= ':'.$parts['pass'];
if(!empty($parts['user']) || !empty($parts['pass'])) $output .= '@';
$output .= $parts['host'];
if(!empty($parts['port'])) $output .= ':'.$parts['port'];
}


if(!empty($parts['path'])) $output .= (($parts['path'][0] !== '/') ? '/' : '').$parts['path'];
else $output .= '/';


if(!empty($parts['query']) && is_array($parts['query'])) {
$output .= '?';
$output .= _buildQuery($parts['query']);
}


if(!empty($parts['fragment'])) $output .= '#'.$parts['fragment'];


return $output;

}







function _addSchemeToURL($url)
{
if(mb_substr($url, 0, 7) !== 'http://' && mb_substr($url, 0, 8) !== 'https://' && $url[0] !== '/' && mb_substr($url, 0, 2) !== './') $url = 'http://'.$url;
return $url;
}









function _anchorStr($input, $lower = true, $extra = null)
{


static $trans = array(' ' => '-', 'é' => 'e', 'ě' => 'e', 'É' => 'E', 'Ě' => 'E', 'ř' => 'r', 'Ř' => 'R', 'ť' => 't', 'Ť' => 'T', 'ž' => 'z', 'Ž' => 'Z', 'ú' => 'u', 'Ú' => 'U', 'ů' => 'u', 'Ů' => 'U', 'ü' => 'u', 'Ü' => 'U', 'í' => 'i', 'Í' => 'I', 'ó' => 'o', 'Ó' => 'O', 'á' => 'a', 'Á' => 'A', 'š' => 's', 'Š' => 'S', 'ď' => 'd', 'Ď' => 'D', 'ý' => 'y', 'Ý' => 'Y', 'č' => 'c', 'Č' => 'C', 'ň' => 'n', 'Ň' => 'N', 'ä' => 'a', 'Ä' => 'A', 'ĺ' => 'l', 'Ĺ' => 'L', 'ľ' => 'l', 'Ľ' => 'L', 'ŕ' => 'r', 'Ŕ' => 'R', 'ö' => 'o', 'Ö' => 'O');
$input = strtr($input, $trans);


static $allow = array('A' => 0, 'a' => 1, 'B' => 2, 'b' => 3, 'C' => 4, 'c' => 5, 'D' => 6, 'd' => 7, 'E' => 8, 'e' => 9, 'F' => 10, 'f' => 11, 'G' => 12, 'g' => 13, 'H' => 14, 'h' => 15, 'I' => 16, 'i' => 17, 'J' => 18, 'j' => 19, 'K' => 20, 'k' => 21, 'L' => 22, 'l' => 23, 'M' => 24, 'm' => 25, 'N' => 26, 'n' => 27, 'O' => 28, 'o' => 29, 'P' => 30, 'p' => 31, 'Q' => 32, 'q' => 33, 'R' => 34, 'r' => 35, 'S' => 36, 's' => 37, 'T' => 38, 't' => 39, 'U' => 40, 'u' => 41, 'V' => 42, 'v' => 43, 'W' => 44, 'w' => 45, 'X' => 46, 'x' => 47, 'Y' => 48, 'y' => 49, 'Z' => 50, 'z' => 51, '0' => 52, '1' => 53, '2' => 54, '3' => 55, '4' => 56, '5' => 57, '6' => 58, '7' => 59, '8' => 60, '9' => 61, '.' => 62, '-' => 63, '_' => 64),
$lowermap = array("A" => "a", "B" => "b", "C" => "c", "D" => "d", "E" => "e", "F" => "f", "G" => "g", "H" => "h", "I" => "i", "J" => "j", "K" => "k", "L" => "l", "M" => "m", "N" => "n", "O" => "o", "P" => "p", "Q" => "q", "R" => "r", "S" => "s", "T" => "t", "U" => "u", "V" => "v", "W" => "w", "X" => "x", "Y" => "y", "Z" => "z");
$output = "";
for($i = 0; isset($input[$i]); ++$i) {
$char = $input[$i];
if(isset($allow[$char]) || null !== $extra && isset($extra[$char])) {
if($lower && isset($lowermap[$char])) $output .= $lowermap[$char];
else $output .= $char;
}
}


$from = array('|--+|', '|\.\.+|', '|\.-+|', '|-\.+|');
$to = array('-', '.', '.', '-');
if(null !== $extra) {
foreach($extra as $extra_char => $i) {
$from[] = '|'.preg_quote($extra_char.$extra_char).'+|';
$to[] = $extra_char;
}
}
$output = preg_replace($from, $to, $output);


$trim_chars = "-_.";
if(null !== $extra) $trim_chars .= implode('', array_keys($extra));
$output = trim($output, $trim_chars);


return $output;

}








function _md5Salt($str, $usesalt = null)
{
if($usesalt === null) $salt = _wordGen(8, 3);
else $salt = $usesalt;
$hash = md5($salt.$str.$salt);
if($usesalt === null) return array($hash, $salt, $str);
else return $hash;
}














function _md5HMAC($data, $key)
{
static $b = 64;
if(strlen($key) > $b) $key = pack("H*", md5($key));
$key = str_pad($key, $b, chr(0x00));
$ipad = str_pad('', $b, chr(0x36));
$opad = str_pad('', $b, chr(0x5c));
$k_ipad = $key ^ $ipad;
$k_opad = $key ^ $opad;
return md5($k_opad.pack("H*", md5($k_ipad.$data)));
}








function _arrayDefineKeys($array, $keys)
{
if(is_array($array)) {
foreach($keys as $key => $value) {
if(!isset($array[$key])) {
$array[$key] = $value;
}
}
return $array;
} else {
return array();
}
}








function _arrayRemoveValue($array, $value_remove, $preserve_keys = false)
{
$output = array();
if(is_array($array)) {
foreach($array as $key => $value) {
if($value != $value_remove) {
if(!$preserve_keys) $output[] = $value;
else $output[$key] = $value;
}
}
}
return $output;
}







function _boolean($input)
{
return @($input == 1);
}







function _booleanStr($input)
{
if(@($input == true)) return "true";
return "false";
}






function _checkboxActivate($input)
{
if($input == 1) return " checked='checked'";
return '';
}







function _checkboxLoad($name)
{
if(isset($_POST[$name])) return 1;
return 0;
}









function _cutStr($string, $length, $convert_entities = true)
{
if($length === null) return $string;
if($length > 0) {
if($convert_entities) $string = _htmlStrUndo($string);
if(mb_strlen($string) > $length) $string = mb_substr($string, 0, $length - 3)."...";
if($convert_entities) $string = _htmlStr($string);
return $string;
}
return $string;
}







function _htmlStr($input)
{
return str_replace(array("&", "<", ">", "\"", "'"), array("&amp;", "&lt;", "&gt;", "&quot;", "&#39;"), $input);

}








function _htmlStrUndo($input, $double = false)
{
static $map;
if(!isset($map)) $map = array_flip(get_html_translation_table(HTML_SPECIALCHARS, ENT_QUOTES));
$output = strtr($input, $map);
if($double) $output = _htmlStrUndo($output, false);
return $output;
}







function _inputDisable($cond)
{
if($cond != true) return " disabled='disabled'";
return '';
}







function _isAbsolutePath($path)
{
$path = @parse_url($path);
return isset($path['scheme']);
}








function _wordGen($len = 10, $numlen = 3)
{
if($len > $numlen) {
$wordlen = $len - $numlen;
} else {
$wordlen = $len;
$numlen = 0;
}
$output = "";


static $letters1 = array("a", "e", "i", "o", "u", "y");
static $letters2 = array("b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "q", "r", "s", "t", "v", "w", "x", "z");


$t = true;
for($x = 0; $x < $wordlen; $x++) {
if($t) {
$r = array_rand($letters2);
$output .= $letters2[$r];
} else {
$r = array_rand($letters1);
$output .= $letters1[$r];
}
$t = !$t;
}


if($numlen != 0) $output .= mt_rand(pow(10, $numlen - 1), pow(10, $numlen) - 1);


return $output;
}












function _wordGenMarkov($length)
{

static $matrix = array(0.0001, 0.0218, 0.0528, 0.1184, 0.1189, 0.1277, 0.1450, 0.1458, 0.1914, 0.1915, 0.2028, 0.2792, 0.3131, 0.5293, 0.5304, 0.5448, 0.5448, 0.6397, 0.7581, 0.9047, 0.9185, 0.9502, 0.9600, 0.9601, 0.9982, 1.0000, 0.0893, 0.0950, 0.0950, 0.0950, 0.4471, 0.4471, 0.4471, 0.4471, 0.4784, 0.4821, 0.4821, 0.6075, 0.6078, 0.6078, 0.7300, 0.7300, 0.7300, 0.7979, 0.8220, 0.8296, 0.9342, 0.9348, 0.9351, 0.9351, 1.0000, 1.0000, 0.1313, 0.1317, 0.1433, 0.1433, 0.3264, 0.3264, 0.3264, 0.4887, 0.5454, 0.5454, 0.5946, 0.6255, 0.6255, 0.6255, 0.8022, 0.8022, 0.8035, 0.8720, 0.8753, 0.9545, 0.9928, 0.9928, 0.9928, 0.9928, 1.0000, 1.0000, 0.0542, 0.0587, 0.0590, 0.0840, 0.3725, 0.3837, 0.3879, 0.3887, 0.5203, 0.5208, 0.5211, 0.5390, 0.5435, 0.5550, 0.8183, 0.8191, 0.8191, 0.8759, 0.9376, 0.9400, 0.9629, 0.9648, 0.9664, 0.9664, 1.0000, 1.0000, 0.0860, 0.0877, 0.1111, 0.2533, 0.3017, 0.3125, 0.3183, 0.3211, 0.3350, 0.3355, 0.3378, 0.4042, 0.4381, 0.5655, 0.5727, 0.5842, 0.5852, 0.7817, 0.8718, 0.9191, 0.9201, 0.9530, 0.9652, 0.9792, 0.9998, 1.0000, 0.1033, 0.1037, 0.1050, 0.1057, 0.2916, 0.3321, 0.3324, 0.3324, 0.4337, 0.4337, 0.4337, 0.4912, 0.4912, 0.4912, 0.7237, 0.7274, 0.7274, 0.8545, 0.8569, 0.9150, 0.9986, 0.9986, 0.9990, 0.9990, 1.0000, 1.0000, 0.1014, 0.1017, 0.1024, 0.1028, 0.2725, 0.2729, 0.2855, 0.4981, 0.5770, 0.5770, 0.5770, 0.6184, 0.6191, 0.6384, 0.7783, 0.7797, 0.7797, 0.9249, 0.9663, 0.9688, 0.9923, 0.9923, 0.9937, 0.9937, 1.0000, 1.0000, 0.2577, 0.2579, 0.2580, 0.2581, 0.6967, 0.6970, 0.6970, 0.6970, 0.8648, 0.8648, 0.8650, 0.8661, 0.8667, 0.8670, 0.9397, 0.9397, 0.9397, 0.9509, 0.9533, 0.9855, 0.9926, 0.9926, 0.9929, 0.9929, 1.0000, 1.0000, 0.0324, 0.0478, 0.0870, 0.1267, 0.1585, 0.1908, 0.2182, 0.2183, 0.2193, 0.2193, 0.2309, 0.2859, 0.3426, 0.6110, 0.6501, 0.6579, 0.6583, 0.6923, 0.8211, 0.9764, 0.9781, 0.9948, 0.9949, 0.9965, 0.9965, 1.0000, 0.1276, 0.1276, 0.1276, 0.1276, 0.4286, 0.4286, 0.4286, 0.4286, 0.4337, 0.4337, 0.4337, 0.4337, 0.4337, 0.4337, 0.6684, 0.6684, 0.6684, 0.6684, 0.6684, 0.6684, 1.0000, 1.0000, 1.0000, 1.0000, 1.0000, 1.0000, 0.0033, 0.0059, 0.0100, 0.0109, 0.5401, 0.5443, 0.5477, 0.5485, 0.7149, 0.7149, 0.7149, 0.7316, 0.7333, 0.9247, 0.9264, 0.9273, 0.9273, 0.9289, 0.9791, 0.9816, 0.9824, 0.9824, 0.9833, 0.9833, 1.0000, 1.0000, 0.0850, 0.0865, 0.0874, 0.1753, 0.3439, 0.3725, 0.3744, 0.3746, 0.5083, 0.5083, 0.5192, 0.6784, 0.6840, 0.6848, 0.8088, 0.8128, 0.8128, 0.8147, 0.8326, 0.8511, 0.8743, 0.8817, 0.9054, 0.9054, 1.0000, 1.0000, 0.1562, 0.1760, 0.1774, 0.1776, 0.5513, 0.5517, 0.5517, 0.5520, 0.6352, 0.6352, 0.6352, 0.6369, 0.6486, 0.6499, 0.7717, 0.8230, 0.8230, 0.8337, 0.8697, 0.8703, 0.9376, 0.9376, 0.9378, 0.9378, 1.0000, 1.0000, 0.0255, 0.0265, 0.0682, 0.2986, 0.4139, 0.4204, 0.6002, 0.6009, 0.6351, 0.6360, 0.6507, 0.6672, 0.6679, 0.6786, 0.7718, 0.7723, 0.7732, 0.7873, 0.8364, 0.9715, 0.9753, 0.9797, 0.9803, 0.9804, 0.9997, 1.0000, 0.0050, 0.0089, 0.0183, 0.0379, 0.0410, 0.1451, 0.1494, 0.1514, 0.1654, 0.1656, 0.1866, 0.2171, 0.2821, 0.4272, 0.4761, 0.4926, 0.4927, 0.6434, 0.6722, 0.7195, 0.9126, 0.9332, 0.9913, 0.9925, 0.9999, 1.0000, 0.1596, 0.1688, 0.1688, 0.1688, 0.3799, 0.3799, 0.3799, 0.4011, 0.4827, 0.4827, 0.4833, 0.6081, 0.6087, 0.6090, 0.7353, 0.7953, 0.7953, 0.8804, 0.9181, 0.9584, 0.9952, 0.9952, 0.9952, 0.9952, 1.0000, 1.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 1.0000, 1.0000, 1.0000, 1.0000, 1.0000, 1.0000, 0.0902, 0.0938, 0.1003, 0.1555, 0.4505, 0.4606, 0.4705, 0.4740, 0.5928, 0.5928, 0.6018, 0.6201, 0.6402, 0.6605, 0.7619, 0.7666, 0.7671, 0.8125, 0.8645, 0.9029, 0.9226, 0.9298, 0.9319, 0.9319, 0.9996, 1.0000, 0.0584, 0.0598, 0.0903, 0.0912, 0.2850, 0.2870, 0.2883, 0.3902, 0.5057, 0.5058, 0.5165, 0.5271, 0.5400, 0.5447, 0.6525, 0.6762, 0.6792, 0.6792, 0.7512, 0.9370, 0.9843, 0.9851, 0.9953, 0.9953, 0.9999, 1.0000, 0.0416, 0.0419, 0.0466, 0.0467, 0.1673, 0.1696, 0.1697, 0.6314, 0.7003, 0.7003, 0.7003, 0.7142, 0.7150, 0.7160, 0.8626, 0.8626, 0.8627, 0.9023, 0.9255, 0.9498, 0.9746, 0.9746, 0.9812, 0.9812, 0.9998, 1.0000, 0.0141, 0.0308, 0.0668, 0.0877, 0.1241, 0.1282, 0.1874, 0.1874, 0.2191, 0.2192, 0.2210, 0.3626, 0.3794, 0.4618, 0.4632, 0.5097, 0.5097, 0.6957, 0.8373, 0.9949, 0.9949, 0.9961, 0.9963, 0.9982, 0.9984, 1.0000, 0.0740, 0.0740, 0.0740, 0.0740, 0.8423, 0.8423, 0.8423, 0.8423, 0.9486, 0.9486, 0.9486, 0.9486, 0.9486, 0.9491, 0.9836, 0.9836, 0.9836, 0.9849, 0.9849, 0.9849, 0.9907, 0.9907, 0.9907, 0.9907, 1.0000, 1.0000, 0.2785, 0.2789, 0.2795, 0.2823, 0.4088, 0.4118, 0.4118, 0.6070, 0.7774, 0.7774, 0.7782, 0.7840, 0.7840, 0.8334, 0.9704, 0.9704, 0.9704, 0.9861, 0.9996, 1.0000, 1.0000, 1.0000, 1.0000, 1.0000, 1.0000, 1.0000, 0.0741, 0.0741, 0.1963, 0.1963, 0.2519, 0.2741, 0.2741, 0.3333, 0.4000, 0.4000, 0.4000, 0.4000, 0.4000, 0.4000, 0.4037, 0.6741, 0.7667, 0.7667, 0.7667, 0.9667, 0.9963, 0.9963, 0.9963, 0.9963, 1.0000, 1.0000, 0.0082, 0.0130, 0.0208, 0.0225, 0.1587, 0.1608, 0.1613, 0.1686, 0.2028, 0.2028, 0.2032, 0.2322, 0.2391, 0.2417, 0.8232, 0.8314, 0.8314, 0.8409, 0.9529, 0.9965, 0.9965, 0.9965, 0.9991, 0.9996, 1.0000, 1.0000, 0.0678, 0.0678, 0.0763, 0.0763, 0.7373, 0.7373, 0.7373, 0.7458, 0.8729, 0.8729, 0.8729, 0.8814, 0.8814, 0.8814, 0.9237, 0.9237, 0.9237, 0.9237, 0.9237, 0.9407, 0.9492, 0.9492, 0.9492, 0.9492, 0.9492, 1.0000);
static $chars = 'abcdefghijklmnopqrstuvwxyz';

$output = '';
$char = mt_rand(0, 25);

for($i = 0; $i < $length; ++$i) {


$output .= chr($char + 65 + 32);


$next = mt_rand(0, 10000) / 10000;
for($j = 0; $j < 26; ++$j) {
if($next < $matrix[$char * 26 + $j]) {
$char = $j;
break;
}
}

}

return $output;
}







function _parseStr($input)
{


static $sep = ',', $quote = '"', $quote2 = '\'', $esc = '\\', $ws = array("\n" => 0, "\r" => 1, "\t" => 2, " " => 3);


$output = array();
$input = trim($input);
$last = strlen($input) - 1;
$val = '';
$ws_buffer = '';
$val_quote = null;
$mode = 0;


for($i = 0; isset($input[$i]); ++$i) {

$char = $input[$i];
switch($mode) {


case 0:
if(!isset($ws[$char])) {
if($char === $sep) $output[] = null;
else {
--$i;
$mode = 1;
$val = '';
$val_fc = true;
$escaped = false;
}
}
break;


case 1:


if($val_fc) {
$val_fc = false;
if($char === $quote || $char === $quote2) {
$val_quote = $char;
break;
} else $val_quote = null;
}


if(isset($val_quote)) {


if($char === $esc) {


if($escaped) {

$val .= $char;
$escaped = false;
} else {

$escaped = true;
}

} elseif($char === $val_quote) {


if($escaped) {

$val .= $char;
$escaped = false;
} else {

$output[] = $val;
$mode = 2;
}

} else {

if($escaped) {

$val .= $esc;
$escaped = false;
}
$val .= $char;
}

} else {


if($char === $sep || $i === $last) {

$ws_buffer = '';
if($i === $last) $val .= $char;
$output[] = $val;
$mode = 0;
} elseif(isset($ws[$char])) {

$ws_buffer .= $char;
} else {

if($ws_buffer !== '') {

$val .= $ws_buffer;
$ws_buffer = '';
}
$val .= $char;
}

}

break;


case 2:
if($char === $sep) $mode = 0;
break;

}

}


return $output;

}







function _parsePath($path)
{
$path = _arrayRemoveValue(explode("/", trim($path, "/")), ".");
$loop = true;

while($loop) {

$moverindex = -1;

for($i = count($path) - 1; $i >= 0; --$i) {
if($path[$i] == "..") {
$moverindex = $i;
break;
}
}

if($moverindex != -1) {

$collision = -1;

for($i = $moverindex - 1; $i >= 0; --$i) {
if($path[$i] != "..") {
$collision = $i;
break;
}
}

if($collision != -1) {
unset($path[$moverindex], $path[$collision]);
$path = array_values($path);;
} else {
$loop = false;
}

} else {
$loop = false;
}

}

$output = implode("/", $path)."/";
if($output == "/") {
$output = "./";
}
return $output;
}







function _isSafeUrl($url)
{
if(mb_strtolower(mb_substr($url, 0, 11)) == "javascript:" or mb_strtolower(mb_substr($url, 0, 5)) == "data:") return false;
return true;
}







function _removeSlashesFromEnd($string)
{
while(mb_substr($string, -1) == "/") {
$string = mb_substr($string, 0, mb_strlen($string) - 1);
}
return $string;
}











function _restorePostValue($name, $else = null, $noparam = false, $cond = true, $else_entities = true)
{

if($noparam) {
$param_start = "";
$param_end = "";

} else {
$param_start = " value='";
$param_end = "'";
}

if(isset($_POST[$name]) && $cond) return $param_start._htmlStr($_POST[$name]).$param_end;
elseif(isset($else)) return $param_start.($else_entities ? _htmlStr($else) : $else).$param_end;
return '';

}








function _restoreGetValue($name, $else = null)
{
if(isset($_GET[$name]) and $_GET[$name] != "") {
return " value='"._htmlStr($_GET[$name])."'";
} else {
if($else != null) {
return " value='"._htmlStr($else)."'";
}
}
}










function _get($key, $default = null, $allow_array = false)
{
if(isset($_GET[$key]) && ($allow_array || !is_array($_GET[$key]))) {
return $_GET[$key];
}
return $default;
}










function _post($key, $default = null, $allow_array = false)
{
if(isset($_POST[$key]) && ($allow_array || !is_array($_POST[$key]))) {
return $_POST[$key];
}
return $default;
}










function _getPostdata($array = false, $prefix = null, $skip = null)
{
$output = array();
$counter = 0;
if(isset($filter)) $filter_len = mb_strlen($filter);
if(isset($skip)) $skip = array_flip($skip);
foreach($_POST as $key => $value) {
if(isset($filter) && mb_substr($key, 0, $filter_len) != $filter) continue;
if(isset($skip, $skip[$key])) continue;
if(!$array) $output[] = _getPostdata_processItem($key, $value);
else $output[] = array($key, $value);
++$counter;
}
if(!$array) $output = implode("\n", $output);
return $output;
}





function _getPostdata_processItem($key, $value, $pkeys = array())
{


if(is_array($value)) {
$output = array();
foreach($value as $vkey => $vvalue) $output[] = _getPostdata_processItem($key, $vvalue, array_merge($pkeys, array($vkey)));
return implode("\n", $output);
}


$name = _htmlStr($key);
if(!empty($pkeys)) $name .= _htmlStr('['.implode('][', $pkeys).']');
return "<input type='hidden' name='".$name."' value='"._htmlStr($value)."' />";

}







function _validateEmail($email)
{
$isValid = true;
$atIndex = mb_strrpos($email, "@");
if(is_bool($atIndex) && !$atIndex) {
$isValid = false;
} else {
$domain = mb_substr($email, $atIndex + 1);
$local = mb_substr($email, 0, $atIndex);
$localLen = mb_strlen($local);
$domainLen = mb_strlen($domain);
if($localLen < 1 || $localLen > 64) {

$isValid = false;
} else
if($domainLen < 1 || $domainLen > 255) {

$isValid = false;
} else
if($local[0] == '.' || $local[$localLen - 1] == '.') {

$isValid = false;
} else
if(preg_match('/\\.\\./', $local)) {

$isValid = false;
} else
if(!preg_match('/^[A-Za-z0-9\\-\\.]+$/', $domain)) {

$isValid = false;
} else
if(preg_match('/\\.\\./', $domain)) {

$isValid = false;
} else
if(!preg_match('/^[A-Za-z0-9\\-\\._]+$/', $local)) $isValid = false;







if(function_exists("checkdnsrr")) {
if($isValid && !(checkdnsrr($domain, "MX") || checkdnsrr($domain, "A"))) {

$isValid = false;
}
}
}
return $isValid;
}







function _validateURL($url)
{
return (preg_match('|^https?:\/\/[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,6}((:[0-9]{1,5})?\/.*)?$|i', $url) === 1);
}







function _wsTrim($string)
{
$from = array("|(\r\n){3,}|s", "|  +|s");
$to = array("\r\n\r\n", " ");
return preg_replace($from, $to, trim($string));
}







function _getUploadLimit($get_mb = false)
{
static $result;
if(!isset($result)) {
$limit_lowest = null;
$opts = array('upload_max_filesize', 'post_max_size', 'memory_limit');
for($i = 0; isset($opts[$i]); ++$i) {
$limit = _phpIniLimit($opts[$i]);
if(isset($limit) && (!isset($limit_lowest) || $limit < $limit_lowest)) $limit_lowest = $limit;
}
if(isset($limit_lowest)) $result = ($get_mb ? round($limit_lowest / 1048576, 1) : $limit_lowest);
else $result = null;
}
return $result;
}






function _phpIniLimit($opt)
{


$ini = ini_get($opt);


if($ini === '') {

return null;
}


$last = substr($ini, -1);
$ini += 0;


switch($last) {
case 'M':
case 'm':
$ini *= 1048576;
break;
case 'K':
case 'k':
$ini *= 1024;
break;
case 'G':
case 'g':
$ini *= 1073741824;
break;
}


return $ini;

}








function _isDayTime($time = null, $get_times = false)
{


if(!isset($time)) $time = time();
$sunrise = date_sunrise($time, SUNFUNCS_RET_TIMESTAMP, 50.5, 14.26, 90.583333, date('Z') / 3600);
$sunset = date_sunset($time, SUNFUNCS_RET_TIMESTAMP, 50.5, 14.26, 90.583333, date('Z') / 3600);


if($get_times) return array($time, $sunrise, $sunset);
if($time >= $sunrise && $time < $sunset) return true;
return false;

}








function _tmpFile($mode = 'wb+')
{


static $init = false;
if(!$init) {
$init = true;
@register_shutdown_function('_tmpFile_clean', false);
}


$path = _tmp_dir.uniqid('', false).'.tmp';
$handle = fopen($path, $mode);
_tmpFile_clean(array(realpath($path), $handle));
return array($handle, $path);

}





function _tmpFileCleaned($path)
{
_tmpFile_clean($path, true);
}







function _tmpFile_clean($path, $remove = false)
{
static $list = array();
if($path === false) {

foreach($list as $path => $handle) {
@fclose($handle);
@unlink($path);
}
} elseif($remove) unset($list[$path]);
else $list[$path[0]] = $path[1];
}








function _emptyDir($dir, $check_only = true, $recursing = false)
{


$handle = opendir($dir);
if(!is_resource($handle)) return $dir;
$dirs = array();
while($item = readdir($handle)) {


if($item === '.' || $item === '..') continue;


if(is_file($dir.$item)) {
if($check_only) {
if(!is_writeable($dir.$item)) return $dir.$item;
} elseif(!unlink($dir.$item)) return $dir.$item;
continue;
}


$dirs[] = $dir.$item.'/';

}
closedir($handle);


for($i = 0; isset($dirs[$i]); ++$i)
if(($s_dir = _emptyDir($dirs[$i], $check_only, true)) !== true) return $s_dir;


if($recursing)
if(!$check_only && !rmdir($dir) || $check_only && !is_writeable($dir)) return $dir;


return true;

}







function _getBaseUrl()
{


$path = parse_url($_SERVER['REQUEST_URI']);
if(!isset($path['path'])) return false;
$path = $path['path'];


$lslash = strrpos($path, '/');
if($lslash === false) return false;


if($lslash + 1 !== strlen($path)) {
$path = substr($path, 0, $lslash + 1);
}

return 'http://'.$_SERVER['SERVER_NAME'].(($_SERVER['SERVER_PORT'] != 80) ? $_SERVER['SERVER_PORT'] : '').'/'._parsePath($path._indexroot);

}







function _isSafeFile($fname)
{


static $unsafe_ext = array("php", "php3", "php4", "php5", "phtml", "shtml", "asp", "py", "cgi", "htaccess");
static $unsafe_ext_pattern;
if(!isset($unsafe_ext_pattern)) $unsafe_ext_pattern = implode('|', $unsafe_ext);


return (preg_match('/\.('.$unsafe_ext_pattern.')(\..*){0,1}$/is', trim($fname)) === 0);

}











function _editTime($name, $timestamp = null, $updatebox = false, $updateboxchecked = false)
{
global $_lang;
if(-1 === $timestamp) $timestamp = time();
if(null !== $timestamp) $timestamp = getdate($timestamp);
else $timestamp = array('seconds' => '', 'minutes' => '', 'hours' => '', 'mday' => '', 'mon' => '', 'year' => '');
$return = "<input type='text' size='1' maxlength='2' name='{$name}[tday]' value='".$timestamp['mday']."' />.<input type='text' size='1' maxlength='2' name='{$name}[tmonth]' value='".$timestamp['mon']."' />&nbsp;&nbsp;<input type='text' size='3' maxlength='4' name='{$name}[tyear]' value='".$timestamp['year']."' />&nbsp;&nbsp;<input type='text' size='1' maxlength='2' name='{$name}[thour]' value='".$timestamp['hours']."' />:<input type='text' size='1' maxlength='2' name='{$name}[tminute]' value='".$timestamp['minutes']."' />:<input type='text' size='1' maxlength='2' name='{$name}[tsecond]' value='".$timestamp['seconds']."' />&nbsp;&nbsp;<small>".$_lang['admin.content.form.timehelp']."</small>";
if($updatebox) {
if($updateboxchecked) $updateboxchecked = " checked='checked'";
else $updateboxchecked = "";
$return .= "&nbsp;&nbsp;<label><input type='checkbox' name='{$name}[tupdate]' value='1'".$updateboxchecked." /> ".$_lang['admin.content.form.timeupdate']."</label>";
}
return $return;
}







function _loadTime($name, $default = null)
{
if(!isset($_POST[$name]) || !is_array($_POST[$name])) return $default;
if(!isset($_POST[$name]['tupdate'])) {
$day = intval($_POST[$name]['tday']);
$month = intval($_POST[$name]['tmonth']);
$year = intval($_POST[$name]['tyear']);
$hour = intval($_POST[$name]['thour']);
$minute = intval($_POST[$name]['tminute']);
$second = intval($_POST[$name]['tsecond']);
if(checkdate($month, $day, $year) and $hour >= 0 and $hour < 24 and $minute >= 0 and $minute < 60 and $second >= 0 and $second < 60) {
return mktime($hour, $minute, $second, $month, $day, $year);
} else return $default;
}
return time();
}