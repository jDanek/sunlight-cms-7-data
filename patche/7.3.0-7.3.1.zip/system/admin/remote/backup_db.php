<?php

/*--- inicializace jadra ---*/
define('_indexroot', '../../');
define('_tmp_customheader', '');
require(_indexroot."core.php");

/*--- vystup ---*/
if(!_loginright_adminbackup){exit;}

//struktura databaze
$database=array(

  //articles
  array(
  'articles',
    array(
    'id'=>0,
    'title'=>1,
    'perex'=>1,
    'content'=>1,
    'infobox'=>1,
    'author'=>0,
    'home1'=>0,
    'home2'=>0,
    'home3'=>0,
    'time'=>0,
    'visible'=>0,
    'public'=>0,
    'comments'=>0,
    'commentslocked'=>0,
    'confirmed'=>0,
    'showinfo'=>0,
    'readed'=>0,
    'rateon'=>0,
    'ratenum'=>0,
    'ratesum'=>0
    )
  ),

  //boxes
  array(
  'boxes',
    array(
    'id'=>0,
    'ord'=>0,
    'title'=>1,
    'content'=>1,
    'visible'=>0,
    'public'=>0,
    'column'=>0
    )
  ),

  //groups
  array(
  'groups',
    array(
    'id'=>0,
    'title'=>1,
    'level'=>0,
    'icon'=>1,
    'blocked'=>0,
    'reglist'=>0,
    'administration'=>0,
    'adminsettings'=>0,
    'adminusers'=>0,
    'admingroups'=>0,
    'admincontent'=>0,
    'adminsection'=>0,
    'admincategory'=>0,
    'adminbook'=>0,
    'adminseparator'=>0,
    'admingallery'=>0,
    'adminlink'=>0,
    'adminintersection'=>0,
    'adminforum'=>0,
    'adminart'=>0,
    'adminallart'=>0,
    'adminchangeartauthor'=>0,
    'adminconfirm'=>0,
    'adminneedconfirm'=>0,
    'adminpoll'=>0,
    'adminpollall'=>0,
    'adminsbox'=>0,
    'adminbox'=>0,
    'adminfman'=>0,
    'adminfmanlimit'=>0,
    'adminfmanplus'=>0,
    'adminhcmphp'=>0,
    'adminbackup'=>0,
    'adminmassemail'=>0,
    'adminbans'=>0,
    'adminposts'=>0,
    'changeusername'=>0,
    'postcomments'=>0,
    'unlimitedpostaccess'=>0,
    'artrate'=>0,
    'pollvote'=>0
    )
  ),

  //images
  array(
  'images',
    array(
    'id'=>0,
    'home'=>0,
    'ord'=>0,
    'title'=>1,
    'prev'=>1,
    'full'=>1
    )
  ),

  //iplog
  array(
  'iplog',
    array(
    'id'=>0,
    'ip'=>1,
    'type'=>0,
    'time'=>0,
    'var'=>0
    )
  ),

  //messages
  array(
  'messages',
    array(
    'id'=>0,
    'sender'=>0,
    'receiver'=>0,
    'readed'=>0,
    'subject'=>1,
    'text'=>1,
    'time'=>0
    )
  ),

  //polls
  array(
  'polls',
    array(
    'id'=>0,
    'author'=>0,
    'question'=>1,
    'answers'=>1,
    'locked'=>0,
    'votes'=>1
    )
  ),

  //posts
  array(
  'posts',
    array(
    'id'=>0,
    'type'=>0,
    'home'=>0,
    'xhome'=>0,
    'subject'=>1,
    'text'=>1,
    'author'=>0,
    'guest'=>1,
    'time'=>0,
    'ip'=>1
    )
  ),

  //root
  array(
  'root',
    array(
    'id'=>0,
    'title'=>1,
    'type'=>0,
    'intersection'=>0,
    'intersectionperex'=>1,
    'ord'=>0,
    'content'=>1,
    'visible'=>0,
    'public'=>0,
    'var1'=>0,
    'var2'=>0,
    'var3'=>0
    )
  ),

  //sboxes
  array(
  'sboxes',
    array(
    'id'=>0,
    'title'=>1,
    'locked'=>0,
    'public'=>0
    )
  ),

  //settings
  array(
  'settings',
    array(
    'var'=>1,
    'val'=>1
    )
  ),

  //users
  array(
  'users',
    array(
    'id'=>0,
    'group'=>0,
    'username'=>1,
    'publicname'=>1,
    'password'=>1,
    'salt'=>1,
    'registertime'=>0,
    'activitytime'=>0,
    'blocked'=>0,
    'massemail'=>0,
    'wysiwyg'=>0,
    'language'=>1,
    'ip'=>1,
    'email'=>1,
    'avatar'=>1,
    'web'=>1,
    'skype'=>1,
    'msn'=>1,
    'icq'=>0,
    'note'=>1
    )
  )


);

//data zalohy
$compress=_checkboxLoad("compress");
if($compress==1 and !function_exists("gzdeflate")){$compress=0;}
$backup_version=_checkVersion("database_backup", null, true);
$header=base64_encode($backup_version[0].";".$compress)."\n";
$output="";
foreach($database as $data){

  //seznam sloupcu
  $column_list="";
  foreach($data[1] as $column=>$var){$column_list.="`".$column."`,";}
  $column_list=trim($column_list, ",");
  
  //obsah
  $table_content=mysql_query("SELECT * FROM `"._mysql_prefix."-".$data[0]."`");
  $data_list="";
    while($table_row=mysql_fetch_array($table_content)){
    
      //vypis bunek
      $data_list.="(";
        foreach($data[1] as $column=>$var){
        if($var==1){$quotes="'";}else{$quotes="";}
        $data_list.=$quotes.mysql_escape_string($table_row[$column]).$quotes.",";
        }
      $data_list=trim($data_list, ",")."),";
    
    }
  if($data_list!=""){$output.=$data[0]."` (".$column_list.") VALUES ".trim($data_list, ",")."\n";}
  
}
$output=trim($output);

//stazeni
header('Content-Description: File Transfer');
header('Content-Type: application/force-download');
header('Content-Disposition: attachment; filename="'._mysql_db.'_'.date("j_n_Y").'.sld'.'"');
if($compress==1){$output=gzdeflate($output);}
echo $header.base64_encode($output);

?>