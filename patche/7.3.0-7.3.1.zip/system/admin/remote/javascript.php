<?php

/*--- inicializace jadra ---*/
define('_indexroot', '../../');
define('_tmp_customheader', 'Content-type: application/javascript; charset=utf-8');
require(_indexroot."core.php");

?>
//promenne
var _hook="http://sunlight-cms.net/feedback/hook.php?ver=<?php echo _systemversion; ?>";

//soub. manazer - zaskrtnout vse, odskrtnout vse, invertovat
function _sysFmanSelect(number, action){
var tmp=1;
  while(tmp<=number){
    switch(action){
    case 1: eval("document.filelist.f"+tmp+".checked=true"); break;
    case 2: eval("document.filelist.f"+tmp+".checked=false"); break;
    case 3: eval("document.filelist.f"+tmp+".checked=!document.filelist.f"+tmp+".checked"); break;
    }
  tmp+=1;
  }
return false;
}

//soub. manazer - presunout vybrane
function _sysFmanMoveSelected(){
newdir=prompt("<?php echo $_lang['admin.fman.selected.move.prompt']; ?>:", '');
if(newdir!="" && newdir!=null){
document.filelist.action.value='move';
document.filelist.param.value=newdir;
document.filelist.submit();
}
}

//soub. manazer - smazat vybrane
function _sysFmanDeleteSelected(){
if(confirm("<?php echo $_lang['admin.fman.selected.delete.confirm']; ?>")){
document.filelist.action.value='deleteselected';
document.filelist.submit();
}
}

//soub. manazer - pridat vyber do galerie
function _sysFmanAddSelectedToGallery(){
document.filelist.action.value='addtogallery_showform';
document.filelist.submit();
}

//soub. manazer - upload souboru
var _totalfiles=1;
function _sysFmanAddFile(){
newfile=document.createElement('span');
newfile.id="file"+_totalfiles;
newfile.innerHTML="<br /><input type='file' name='f"+_totalfiles+"' /> <a href=\"#\" onclick=\"return _sysFmanRemoveFile("+_totalfiles+");\"><?php echo $_lang['global.cancel']; ?></a>";
document.getElementById("fmanFiles").appendChild(newfile);
_totalfiles+=1;
}

function _sysFmanRemoveFile(id){
document.getElementById("fmanFiles").removeChild(document.getElementById("file"+id));
}