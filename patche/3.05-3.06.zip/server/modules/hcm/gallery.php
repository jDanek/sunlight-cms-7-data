<?php
$outputwidth=148;
$outputheight=116;

$path=$_GET['path'];
$path="../../".$path;
$suffix=strrpos($path, ".");
$suffix=substr($path, $suffix+1);

if(file_exists($path)){

  list($width, $height)=getimagesize($path);
  $thumb=imagecreatetruecolor($outputwidth,$outputheight);
  
  switch($suffix){
  case "jpg": $source=@imagecreatefromjpeg($path); break;
  case "jpeg": $source=@imagecreatefromjpeg($path); break;
  case "png": $source=@imagecreatefrompng($path); break;
  case "gif": $source=@imagecreatefromgif($path); break;
  default: exit;
  }

  imagecopyresized($thumb, $source, 0, 0, 0, 0, $outputwidth, $outputheight, $width, $height);

  
  /*odeslani a ukonceni*/
  header("Content-type: image/jpeg");
  imagejpeg($thumb);
  imagedestroy($thumb);

}
?>
