<?php
$root="../";
$moduletitle="register_title";
include("../_connect.php");
include("moduleheader.php");

/*kontrola udaju*/
if(isset($_POST['codecheckr'])){

  /*nacteni promennych*/
  $codecheck=$_POST['codecheck'];
  $codecheckrr=$_POST['codecheckr'];
  $codecheckr=code_decode($codecheckrr);
  $password=$_POST['password'];
  $password2=$_POST['password2'];
  $email=$_POST['email'];
  $email=strtr($email, $trans);
  $email=trim($email);
  $name=$_POST['name'];
  $name=anchor($name, false);
  $name=substr($name, 0, 20);

  if($name!="" and strpos($email, "@") and strlen($email)>=3 and $codecheck==$codecheckr and $password==$password2 and $password!=""){
  
  $namecheck=@mysql_query("SELECT name FROM `".tabprefix."-users` WHERE name='$name'");
  $namecheck=mysql_fetch_array($namecheck);
  $namecheck=$namecheck['name'];

  if($namecheck==""){

    if(isset($_POST['step1done'])){
  
    /*vypocet noveho id*/
    $id=@mysql_query("SELECT id FROM `".tabprefix."-users` ORDER BY id DESC LIMIT 1");
    $id=@mysql_fetch_array($id);
    $id=$id['id'];
    $id++;

    /*zasifrovani hesla*/
    $password=md5($password);

    /*vlozeni do db*/
    @mysql_query("INSERT INTO `".tabprefix."-users` (id,name,rights,password,email,note) VALUES ($id, '$name', 0, '$password', '$email', '-')");

    /*zprava+parametry*/
    $done=1;
    $continue=false;

    }
    else{
    $continue=true;
    }

  }
  else{
  $msg=lang('global_msg_userexists', 'r');
  }

  }
  else{
  $msg=lang('global_msg_someempty', 'r');
  $continue=false;
  }

}

/*kontrolni cislo*/
if($continue!=true){
$codecheck=code_generate(4);
}
?>

<body>

<?php include("msg.php"); ?>

<div class="board">
<div class="board-padding">

<?php
if($continue==true and $done!=1){
echo "<a href='register.php' onclick='history.go(-1); return false;'>&lt; ".lang('global_goback', 'r')."</a>";
}
else{echo "<a href='../'>&lt; ".lang('global_backtomain', 'r')."</a>";}
?>
<br><br>

<h1><?php lang('register_title', 'e'); ?></h1>

<?php
if($done!=1){

if($continue==true){
echo "
<p>".lang('register_p2', 'r')."</p>

<form action='".$_SERVER['PHP_SELF']."' method='post'>
<input type='hidden' name='step1done' value='1'>
<input type='hidden' name='codecheck' value='".$codecheck."'>
<input type='hidden' name='codecheckr' value='".$codecheckrr."'>
<input type='hidden' name='password' value='".$password."'>
<input type='hidden' name='password2' value='".$password2."'>
<input type='hidden' name='email' value='".$email."'>
<input type='hidden' name='name' value='".$name."'>

<table>

<tr>
<td><b>".lang('global_username', 'r')."</b>:</td>
<td>$name</td>
</tr>

<tr>
<td><b>".lang('global_pass', 'r')."</b>:</td>
<td><a href=\"javascript:alert('$password');\">".lang('global_show', 'r')."</td>
</tr>

<tr>
<td><b>".lang('global_email', 'r')."</b>:</td>
<td>$email</td>
</tr>

<tr><td></td><td>&nbsp;</td></tr>

<tr>
<td></td>
<td><input type='submit' value='".lang('global_create', 'r')." &gt;'></td>
</tr>

</table>
</form>
";
}
else{
echo "
<p>".lang('register_p1', 'r')."</p>

<form action='".$_SERVER['PHP_SELF']."' method='post' name='form' onsubmit=\"if(document.form.name.value=='' || document.form.password.value=='' || document.form.password2.value=='' || document.form.email.value=='' || document.form.email.value.length<3 || document.form.codecheck.value==''){alert('".lang('global_somethingwrong', 'r')."'); return false;}\">
<input type='hidden' name='codecheckr' value='".$codecheck."'>
<table>

<tr>
<td><b>".lang('global_username', 'r')."</b>:</td>
<td><input type='text' name='name' size='20' maxlength='20'>&nbsp;&gt;&nbsp;<a href='#' onclick=\"if(document.form.name.value!=''){window.open('register-usertest.php?id='+document.form.name.value, 'new', 'toolbar=0,location=0,directories=0,menubar=0,width=300,height=140');} return false;\" title='".lang('register_testnamehelp', 'r')."'>".lang('global_testit', 'r')."</a></td>
</tr>

<tr>
<td><b>".lang('global_pass', 'r')."</b>:</td>
<td><input type='password' name='password' size='20' maxlength='255'></td>
</tr>

<tr>
<td><b>".lang('global_pass', 'r')." ".lang('global_check', 'r')."</b>:</td>
<td><input type='password' name='password2' size='20' maxlength='255'></td>
</tr>

<tr>
<td><b>".lang('global_email', 'r')."</b>:</td>
<td><input type='text' name='email' size='20' maxlength='128'></td>
</tr>

<tr>
<td><b>".lang('global_codecheck', 'r')."</b>:</td>
<td><input type='text' name='codecheck' size='20' maxlength='8'>&nbsp;</td>
</tr>

<tr>
<td></td>
<td><img src='kod.php?n=".$codecheck."' alt='".lang('global_codecheckhelp', 'r')."' title='".lang('global_codecheckhelp', 'r')."'></td>
</tr>

<tr><td></td><td>&nbsp;</td></tr>

<tr>
<td></td>
<td><input type='submit' value='".lang('global_continue', 'r')." &gt;'></td>
</tr>

</table>
</form>
";

}

}
else{
echo "<p>".lang('register_p3', 'r')."</p>";
}
?>

</div>
</div>

</body>
</html>
