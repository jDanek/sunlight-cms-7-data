<?php
$root="../";
include("../_connect.php");

if(isset($_POST['password'])){

/*nacteni post promennych*/

  /*heslo*/
  if($_POST['crypted']==0 or $_POST['cryptedpass']==""){
  $password=$_POST['password'];
  $password=md5($password);
  }
  else{
  $password=$_POST['cryptedpass'];
  }
  
$name=$_POST['name'];
$name=addslashes($name);

/*kontrola spravnosti*/
$userdata=@mysql_query("SELECT id,name,rights,password FROM `".tabprefix."-users` WHERE name='$name'");
$userdata=@mysql_fetch_array($userdata);

$continue=true;

if($userdata['name']!=""){

  /*kontrola hesla*/
  if($userdata['password']!=$password){
  $msg=lang('global_msg_wrongpass', 'r');
  $continue=false;
  }

}
else{
$msg=lang('global_msg_wrongpass', 'r');
$continue=false;
}

if($continue==true){
/*nastaveni sessions a presmerovani*/
session_start();
$_SESSION['login_indicator']=1;
$_SESSION['login_id']=$userdata['id'];

  /*navrat*/
  if(isset($_GET['refer'])){$refer=1;}else{$refer=0;}
  $referer=$_SERVER['HTTP_REFERER'];
  
  if($referer!="" and $refer==1){
  header("location: $referer");
  }
  else{
    if(isset($_POST['loginmodulereferer'])){
    $loginmodulereferer=$_POST['loginmodulereferer'];
    header("location: $loginmodulereferer");
    }
    else{
    header("location: ../");
    }
  }
  exit;

}
}

$moduletitle='global_login';
include("moduleheader.php");
?>

<body>

<?php include("msg.php");?>

<div class="board">
<div class="board-padding">

<a href="../" onclick="history.go(-1); return false;">&lt; <?php lang('global_goback', 'e'); ?></a><br><br>
<?php
$refer=0;
$loginmodulerefer=true;
include("loginform.php");
?>

</div>
</div>

</body>
</html>
