<?php
if(isset($msg)){
echo "<script type='text/javascript' language='javascript'>alert('$msg');</script><noscript><br><span class='msg'>$msg</span><br><br></noscript>";
}
?>
