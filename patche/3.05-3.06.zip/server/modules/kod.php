<?php
$root="../";
define('root', "../");
include("funcload.php");

$img=imagecreate(68,16);
$n=$_GET['n'];
$n=code_decode($n);

/*barvy*/
$bg=imagecolorallocate($img, 255, 255, 255);
$tmaveseda=imagecolorallocate($img, 150, 150, 150);
$seda=imagecolorallocate($img, 200, 200, 200);
$svetleseda=imagecolorallocate($img, 225, 225, 225);

/*vykresleni sedych bodu*/
$pocet=0;
while($pocet<=200){
imagesetpixel($img,mt_rand(0,64),mt_rand(0,16),$seda);
$pocet++;
}

/*vykresleni svetlesedych bodu*/
$pocet=0;
while($pocet<=60){
imagesetpixel($img,mt_rand(0,68),mt_rand(0,16),$svetleseda);
$pocet++;
}

/*vykresleni tmavesedych bodu*/
$pocet=0;
while($pocet<=20){
imagesetpixel($img,mt_rand(0,68),mt_rand(0,16),$tmaveseda);
$pocet++;
}

/*vykresleni sedych car*/
$pocet=0;
while($pocet<=5){
imageline($img,mt_rand(0,68),mt_rand(0,16),mt_rand(0,68),mt_rand(0,16),$seda);
$pocet++;
}

/*ramecek*/
imagerectangle($img,0,0,67,15,$seda);

/*vypis textu*/
imagestring($img,5,16,0,$n,$tmaveseda);

/*odeslani a ukonceni*/
header("Content-type: image/PNG");
imagepng($img);
imagedestroy($img);
?>
