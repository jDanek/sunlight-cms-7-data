<?php
session_start();
unset($_SESSION['login_aindicator']);
unset($_SESSION['login_aid']);
session_destroy();
header("location: index.php?m=2");
exit;
?>
