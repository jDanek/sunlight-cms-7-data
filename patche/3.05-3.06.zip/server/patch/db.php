<?php
@mysql_query("DROP TABLE `".tabprefix."-adminevents`;");
?>
