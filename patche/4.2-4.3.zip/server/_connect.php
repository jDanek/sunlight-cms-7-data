<?php




  /*pristupova data*/
  $c_server="server";       //MySQL server
  $c_user="uzivatel";       //MySQL uzivatel
  $c_password="heslo";      //MySQL heslo
  $c_database="databaze";   //MySQL databaze
  $c_tabprefix="webman";    //Prefix jmen tabulek








/*
###########################################
UPRAVA CEHOKOLIV NIZE NA VLASTNI NEBEZPECI!
###########################################
*/

/*definovani globalni promenne prefixu*/
if($c_tabprefix!=""){
define('tabprefix', $c_tabprefix);
}
else{
$error="Musite zadat prefix (promenna c_tabprafix)!.";
include($root."modules/error.php");
exit;
}

/*nastaveni predpon mod_rewrite pluginu - kdyz zmenite
toto, musite zmenit take soubor .htaccess!*/
$st_secprefix="sekce";
$st_catprefix="kategorie";
$st_artprefix="clanek";
$st_gbprefix="kniha";

  /*definovani globalnich*/
  define('secprefix', $st_secprefix);
  define('catprefix', $st_catprefix);
  define('artprefix', $st_artprefix);
  define('gbprefix', $st_gbprefix);
  define('systemuid', md5($c_tabprefix).'_');

/*pripojeni*/
$connection=@mysql_connect($c_server, $c_user, $c_password);
@mysql_query("set names 'cp1250'");
$db=@mysql_select_db($c_database);

  /*kontrola*/
  if(!$connection or !$db){
  $error="Pripojeni k databazi se nezdarilo. Odpoved MySQL serveru muzete videt nize.";
  include($root."modules/error.php");
  echo "<pre>".mysql_error()."</pre>";
  exit;
  }

if($stopconnecting!=true){


/*definovani root*/
if(isset($root)){define('root', $root);}else{define('root', "./");}

/*kontrola existence tabulek*/
$controldatabase=@mysql_query("SHOW TABLES FROM $c_database");
$controldatabase_matches=0;
while($controldatabase_item=mysql_fetch_array($controldatabase)){
switch($controldatabase_item[0]){
case tabprefix."-articlecontent": 
case tabprefix."-blockedip":
case tabprefix."-bookcontent":
case tabprefix."-boxcontent":
case tabprefix."-codecontent":
case tabprefix."-comments":
case tabprefix."-menu":
case tabprefix."-settings":
case tabprefix."-users":
case tabprefix."-votecontent":
$controldatabase_matches++; break;
}
}

  /*vypis pripadne hlasky*/
  if($controldatabase_matches!=10){
  $error="Zvolena databaze $c_database neobsahuje vsechny tabulky systemu (nalezeno $controldatabase_matches z 10)! Prosim zkontrolujte, zda je databaze korektne nainsalovana a/nebo zda jste nastavili spravny prefix (promenna c_tabprefix v _connect.php).";
  include($root."modules/error.php");
  exit;
  }

/*kontrola, zda neexistuje slozka install*/
if(file_exists(root."install/")){
$error="Prosim zkontrolujte, zda se adresar <i>install</i> nenachazi na serveru a pripadne jej smazte";
include($root."modules/error.php");
exit;
}

/*kontrola, zda neexistuje slozka patch*/
if(file_exists(root."patch/")){
$error="Prosim zkontrolujte, zda se adresar <i>patch</i> nenachazi na serveru a pripadne jej smazte";
include($root."modules/error.php");
exit;
}

/*vymazani nepotrebnych pristupovych udaju*/
unset($c_server);
unset($c_user);
unset($c_password);
unset($c_database);

/*nacteni nastaveni*/
include(root."modules/setload.php");

/*nacteni funkci*/
include(root."modules/funcload.php");

/*nastaveni motivu*/
$set_template="modules/templates/$st_template/layout.php";
$default_template="modules/templates/default/layout.php";
if(file_exists($set_template)){$templatefile=$set_template;}
else{
  if(file_exists($default_template)){$templatefile=$default_template; $st_template="default";}
  else{$templatefile=""; $error="Nebyl nalezen zadny motiv vzhledu (slozka modules/templates/)!";}
}
define('template', $st_template);

/*nastaveni vseobecnych promennych*/
$systemversion="4.3";
$systempackage="patched";
$attrans=array("<" => "&lt;", ">" => "&gt;", "&" => "&amp;", "\"" => "&quot;", "@" => $st_atmask);
$trans=array("<" => "&lt;", ">" => "&gt;", "&" => "&amp;", "\"" => "&quot;");
$antislash=array("/" => "-", "\\"=>"-");
$at=array("@" => $st_atmask);
$atback=array($st_atmask => "@");

  /*prepis smajliku*/
  $smajlici=array(
  "*01*"=>"<img src='".$root."modules/templates/$st_template/pics/smileys/01.gif' alt=':D'>",
  "*02*"=>"<img src='".$root."modules/templates/$st_template/pics/smileys/02.gif' alt=':P'>",
  "*03*"=>"<img src='".$root."modules/templates/$st_template/pics/smileys/03.gif' alt='8)'>",
  "*04*"=>"<img src='".$root."modules/templates/$st_template/pics/smileys/04.gif' alt=';)'>",
  "*05*"=>"<img src='".$root."modules/templates/$st_template/pics/smileys/05.gif' alt=':)'>",
  "*06*"=>"<img src='".$root."modules/templates/$st_template/pics/smileys/06.gif' alt=':S'>",
  "*07*"=>"<img src='".$root."modules/templates/$st_template/pics/smileys/07.gif' alt=':|'>",
  "*08*"=>"<img src='".$root."modules/templates/$st_template/pics/smileys/08.gif' alt=':('>"
  );

/*kontrola blokovani ip*/
if($administration_indicator!=true)
$addr=$_SERVER['REMOTE_ADDR'];
$blockedips=@mysql_query("SELECT adress FROM `".tabprefix."-blockedip`");
while($blockedip=@mysql_fetch_array($blockedips)){
  $blockedip_match=strpos("##".$addr, $blockedip['adress']);
  if($blockedip_match==2){exit;}
}


}
?>
