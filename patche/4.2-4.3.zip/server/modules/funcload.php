<?php

/*filtrovani znaku, anchor funkce*/
function anchor($input, $lower=true){

  /*odstraneni diakritiky*/
  $input=strtr($input, " �����؝����������������������������ž�����", "-eeEErRtTzZuUuUuUiIoOaAsSdDyYcCnNaAlLlLrRoO");

  /*odfiltrovani nepovolenych znaku*/
  $letterpos=0;
  $output="";
  while($letterpos<=strlen($input)){
  $letter=substr($input, $letterpos, 1);
  if($letter=="A" or $letter=="a" or $letter=="B" or $letter=="b" or $letter=="C" or $letter=="c" or $letter=="D" or $letter=="d" or $letter=="E" or $letter=="e" or $letter=="F" or $letter=="f" or $letter=="G" or $letter=="g" or $letter=="H" or $letter=="h" or $letter=="I" or $letter=="i" or $letter=="J" or $letter=="j" or $letter=="K" or $letter=="k" or $letter=="L" or $letter=="l" or $letter=="M" or $letter=="m" or $letter=="N" or $letter=="n" or $letter=="O" or $letter=="o" or $letter=="P" or $letter=="p" or $letter=="Q" or $letter=="q" or $letter=="R" or $letter=="r" or $letter=="S" or $letter=="s" or $letter=="T" or $letter=="t" or $letter=="U" or $letter=="u" or $letter=="V" or $letter=="v" or $letter=="W" or $letter=="w" or $letter=="X" or $letter=="x" or $letter=="Y" or $letter=="y" or $letter=="Z" or $letter=="z" or $letter=="0" or $letter=="1" or $letter=="2" or $letter=="3" or $letter=="4" or $letter=="5" or $letter=="6" or $letter=="7" or $letter=="8" or $letter=="9" or $letter=="_" or $letter=="-" or $letter=="."){$output.=$letter;}
  $letterpos++;
  }
  
  /*odfiltrovani opakovanych pomlcek, podtrzitek a tecek*/
  $count=0;
  $double="--";
  while($count!=3){
  
  $letterpos=0;
  while($letterpos<=strlen($output)){
  $letter=substr($output, $letterpos, 2);
    if($letter==$double){
    $output_start=substr($output, 0, $letterpos+1);
    $output_end=substr($output, $letterpos+2);
    $output=$output_start.$output_end;
    $letterpos-=1;
    }
  $letterpos++;
  }
  
  /*odstraneni pomlcek, podtrzitek a tecek ze zacatku a konce*/
  $letterpos=0;
  while($letterpos<=strlen($output)){
  if(substr($output, 0, 1)=="-"){$output=substr($output, 1); $letterpos=-1;}
  if(substr($output, -1)=="-"){$output=substr($output, 0, -1); $letterpos=-1;}
  if(substr($output, 0, 1)=="_"){$output=substr($output, 1); $letterpos=-1;}
  if(substr($output, -1)=="_"){$output=substr($output, 0, -1); $letterpos=-1;}
  if(substr($output, 0, 1)=="."){$output=substr($output, 1); $letterpos=-1;}
  if(substr($output, -1)=="."){$output=substr($output, 0, -1); $letterpos=-1;}
  $letterpos++;
  }

  $count++;
  if($count==1){$double="__";}
  else{$double="..";}
  
  }

if($lower==true){$output=strtolower($output);}
return $output;

}



/*formatovani data*/
function formatdate($timestamp){
$output=@getdate($timestamp);
if(strlen($output['hours'])==1){$output['hours']="0".$output['hours'];}
if(strlen($output['minutes'])==1){$output['minutes']="0".$output['minutes'];}
$output=$output['mday'].".".$output['mon'].". ".$output['year']." ".$output['hours'].":".$output['minutes'];
return $output;
}




/*validace emailu*/
function validate_email($email) {

  if (!ereg("^[^@]{1,64}@[^@]{1,255}$", $email)) {
    return false;
  }
  $email_array = explode("@", $email);
  $local_array = explode(".", $email_array[0]);
  for ($i = 0; $i < sizeof($local_array); $i++) {
     if (!ereg("^(([A-Za-z0-9!#$%&#038;'*+/=?^_`{|}~-][A-Za-z0-9!#$%&#038;'*+/=?^_`{|}~\.-]{0,63})|(\"[^(\\|\")]{0,62}\"))$", $local_array[$i])) {
      return false;
    }
  }
  if (!ereg("^\[?[0-9\.]+\]?$", $email_array[1])) {
    $domain_array = explode(".", $email_array[1]);
    if (sizeof($domain_array) < 2) {
        return false;
    }
    for ($i = 0; $i < sizeof($domain_array); $i++) {
      if (!ereg("^(([A-Za-z0-9][A-Za-z0-9-]{0,61}[A-Za-z0-9])|([A-Za-z0-9]+))$", $domain_array[$i])) {
        return false;
      }
    }
  }
  return true;
}




/*cteni z jazykoveho souboru*/
$langfile=root."modules/language/".langfile;
define('langfile_load', true);

if(!file_exists($langfile)){
$langfile_default=root."modules/language/default.htm";
  if(!file_exists($langfile_default)){
  define('langfile_load', false);
  }
  else{
  $langfile=$langfile_default;
  }
}

  if(langfile_load==true){define('langfilecontent', file_get_contents($langfile));}
  else{define('langfilecontent', "");}

function lang($input, $param='r', $langfile=langfilecontent, $failed=langfile_load){

  /*vyhledani fraze v souboru*/
  if($failed!=false){
  $langfile=langfilecontent;
  $startpos=strpos($langfile, "<$input>");
  $endpos=strpos($langfile, "</$input>");
  }

  /*nalezeni a vypis*/
  if($startpos!==false and $endpos!==false and $failed!=false){
  $start=$startpos+strlen("<$input>");
  $end=$endpos-$start;
  $langfile=substr($langfile, $start, $end);
     switch($param){
     case 'r': return $langfile; break;
     case 'e': echo $langfile; break;
      }
  }
  else{
     $lerror="LANGFILE_ERROR";
     switch($param){
     case 'r': return $lerror; break;
     case 'e': echo $lerror; break;
     }
  }

}



/*zkracovani textu*/
function textpart($input){
$length=strlen($input);
$input=substr($input, 0, 128);
$input=strip_tags($input);
if($length>128){$input=$input."...";}
return $input;
}



/*zpracovani refereru*/
function referer($return=false){
$referer=$_SERVER['HTTP_REFERER'];
  if($referer!="" and !strpos("##".$referer, $_SERVER['PHP_SELF'])){
  if($return==false){echo $referer;}else{return $referer;}
  }
  else{
  if($return==false){echo root;}else{return root;}
  }
}



/*generovani bezpecnostniho kodu*/

  /*generovani*/
  function code_generate($length) {
  $x=0;
  $code="";
  while($x!=$length){
  $code.=mt_rand(1, 9);
  $x++;
  }
  $code=$code;
  
  $x=0;
  $output="";
  while($x!=$length){
  $output.=strrev(ord(substr($code, $x, 1))+4)."-";
  $x++;
  }
  $output=substr($output, 0, strlen($output)-1);
  $output=strrev($output);
  return $output;
  }

  /*dekodovani*/
  function code_decode($input){
  $input=strrev($input);
  $tokenize=strtok($input, "-");
  while($tokenize){
  $step=chr(strrev($tokenize)-4);
  $output.=$step;
  $tokenize=strtok("-");
  }

  return $output;
  }




/*rozpoznani nebezpecne pripony*/
function isscript($input){
$output=true;
$input=trim($input);
$dotpos=strrpos($input, ".")+1;
$pripona=substr($input, $dotpos);
$pripona=strtolower($pripona);

switch($pripona){
case "php":
case "php3":
case "php4":
case "php5":
case "phtml":
case "py":
case "asp":
case "cgi":
case "shtml":
case "htaccess":
break;
default: $output=false; break;
}

return $output;
}



/*rozpoznani editovatelneho souboru*/
function istextfile($input){
$input=trim($input);
$dotpos=strrpos($input, ".")+1;
$pripona=substr($input, $dotpos);
$pripona=strtolower($pripona);

switch($pripona){
case "php":
case "php3":
case "php4":
case "php5":
case "phtml":
case "py":
case "asp":
case "cgi":
case "shtml":
case "htaccess":
case "txt":
case "html":
case "htm":
case "xhtml":
case "inc":
case "diz":
case "ini":
case "cfg":
case "xml":
case "inf":
case "css":
$output=true; break;
default: $output=false; break;
}
return $output;
}





/*parsovani WM Code*/
function parsewmcode($input){

$output="##".$input;

$wmcode_tags=array(
"b",
"i",
"u",
"q",
"pre",
"red",
"green",
"blue",
"big",
"small",
"url",
"email",
"img"
);

$wmcode_num=0;
while($wmcode_num<=count($wmcode_tags)-1){

$wmcode_tag=$wmcode_tags[$wmcode_num];
$wmcode_starttag="[$wmcode_tag]";
$wmcode_endtag="[/$wmcode_tag]";

  /*lokalizace tagu, spocitani vyskytu*/
  $tcount=substr_count($output, $wmcode_starttag);
  $tparserrepeat=0;

  while($tparserrepeat<$tcount){

  $tpos1=strpos($output, $wmcode_starttag);
  $tpos2=strpos($output, $wmcode_endtag);
  $tparam=substr($output, $tpos1+strlen($wmcode_starttag), $tpos2-($tpos1+strlen($wmcode_starttag)));
  $tparam=trim($tparam);
  $tresult="";

  if($tpos1 and $tpos2 and $tpos2>$tpos1 and $tparam!=""){

  $start=substr($output, 0, $tpos1);
  $end=substr($output, $tpos2+strlen($wmcode_endtag));

  /*parsovani tagu*/

  switch($wmcode_num){

  //b
  case 0:
  $tresult=$start."<b>".$tparam."</b>".$end;
  break;

  //i
  case 1:
  $tresult=$start."<i>".$tparam."</i>".$end;
  break;

  //u
  case 2:
  $tresult=$start."<u>".$tparam."</u>".$end;
  break;

  //q
  case 3:
  $tresult=$start."<q>".$tparam."</q>".$end;
  break;

  //pre
  case 4:
  $tresult=$start."<pre>".$tparam."</pre>".$end;
  break;

  //red
  case 5:
  $tresult=$start."<font style='color:red;'>".$tparam."</font>".$end;
  break;

  //green
  case 6:
  $tresult=$start."<font style='color:green;'>".$tparam."</font>".$end;
  break;

  //blue
  case 7:
  $tresult=$start."<font style='color:blue;'>".$tparam."</font>".$end;
  break;

  //big
  case 8:
  $tresult=$start."<big>".$tparam."</big>".$end;
  break;

  //small
  case 9:
  $tresult=$start."<small>".$tparam."</small>".$end;
  break;

  //url
  case 10:
  $tresult=$start."<a href='".$tparam."' target='_blank' rel='nofollow'>$tparam</a>".$end;
  break;

  //email
  case 11:
  $tresult=$start."<a href='mailto:".$tparam."'>$tparam</a>".$end;
  break;

  //img
  case 12:
  $tresult=$start."<img src='".$tparam."'>".$end;
  break;

  }

  if($tresult!=""){$output=$tresult;}

  }
  else{
    /*odfiltrovani neuzavreneho tagu*/
    if($tpos1){
    $start=substr($output, 0, $tpos1);
    $end=substr($output, $tpos1+strlen($wmcode_starttag));
    $output=$start.$end;
    }
  }

  $tparserrepeat++;
  }

$wmcode_num++;
}


  /*navraceni vystupu parseru*/
  $output=substr($output, 2);
  return $output;
}




/*filtrovani WM Code*/
function stripwmcode($input){

$output="##".$input;

$wmcode_tags=array("b", "i", "u", "q", "pre", "red", "green", "blue", "big", "small", "url", "email", "img");

$wmcode_num=0;
while($wmcode_num<=count($wmcode_tags)-1){

$wmcode_tag=$wmcode_tags[$wmcode_num];
$wmcode_starttag="[$wmcode_tag]";
$wmcode_endtag="[/$wmcode_tag]";

  /*lokalizace tagu, spocitani vyskytu*/
  $tcount=substr_count($output, $wmcode_starttag);
  $tparserrepeat=0;

  while($tparserrepeat<$tcount){

  $tpos1=strpos($output, $wmcode_starttag);
  $tpos2=strpos($output, $wmcode_endtag);
  $tparam=substr($output, $tpos1+strlen($wmcode_starttag), $tpos2-($tpos1+strlen($wmcode_starttag)));
  $tparam=trim($tparam);
  $tresult="";

  if($tpos1 and $tpos2 and $tpos2>$tpos1 and $tparam!=""){

  $start=substr($output, 0, $tpos1);
  $end=substr($output, $tpos2+strlen($wmcode_endtag));

  /*parsovani tagu*/
  $tresult=$start.$tparam.$end;
  $output=$tresult;

  }
  else{
    /*odfiltrovani neuzavreneho tagu*/
    if($tpos1){
    $start=substr($output, 0, $tpos1);
    $end=substr($output, $tpos1+strlen($wmcode_starttag));
    $output=$start.$end;
    }
  }

  $tparserrepeat++;
  }

$wmcode_num++;
}


  /*navraceni vystupu parseru*/
  $output=substr($output, 2);
  return $output;
}




/*parsovani HCM modulu*/
function parsehcm($input, $php=false){

  $output="##".$input;

  $hcm_array=array(
  "latart",
  "latart2",
  "latcom",
  "mailform",
  "php",
  "gallery",
  "gallery2",
  "randimg",
  "randtxt",
  "filelist",
  "mrart",
  "mrart2",
  "randart",
  "randart2",
  "fulltextbox",
  "vote",
  "brart",
  "brart2",
  "menu",
  "loginform",
  "latcom2"
  );

  $hcm_num=0;
  while($hcm_num<=count($hcm_array)-1){
  
  $hcm_item=$hcm_array[$hcm_num];
  $hcm_item_starttag="<!--hcm:$hcm_item:start-->";
  $hcm_item_endtag="<!--hcm:$hcm_item:end-->";

    /*lokalizace tagu, spocitani vyskytu*/
    $mcount=substr_count($output, $hcm_item_starttag);
    $mparserrepeat=0;

    while($mparserrepeat<$mcount){

    $mpos1=strpos($output, $hcm_item_starttag);
    $mpos2=strpos($output, $hcm_item_endtag);
    $mparam=substr($output, $mpos1+strlen($hcm_item_starttag), $mpos2-($mpos1+strlen($hcm_item_starttag)));
    $mparam=trim($mparam);
    $mresult="";

    if($mpos1 and $mpos2 and $mpos2>$mpos1 and ($mparam!="" or $hcm_num==14 or $hcm_num==18 or $hcm_num==19)){

    $start=substr($output, 0, $mpos1);
    $end=substr($output, $mpos2+strlen($hcm_item_endtag));
    
    /*parsovani modulu*/
    
    switch($hcm_num){


      //latart
      case 0:
      $mparam=intval($mparam);
      $mdata=@mysql_query("SELECT title,perex,id,author,date,opened,comment FROM `".tabprefix."-articlecontent` WHERE visible=1".futureart." ORDER BY ".artorder." DESC LIMIT 0, $mparam");
      $mtmp="";

      while($mitem=@mysql_fetch_array($mdata)){
      $anchor4url=anchor($mitem['title']);
        /*rewrite*/
        if(rewrite==1){$linkhref=artprefix."-$anchor4url-".$mitem['id'].".html";}
        else{$linkhref="index.php?articleread=".$mitem['id'];}

        /*spocitani komentaru*/
        $a_commentscount_code="";
        if($mitem['comment']==1){
        $a_commentscount=@mysql_query("SELECT id FROM `".tabprefix."-comments` WHERE home=".$mitem['id']." AND tp=2");
        $a_commentscount_number=0;
        while($commentscount_item=@mysql_fetch_array($a_commentscount)){
        $a_commentscount_number++;
        }
        $a_commentscount_code=" | <b>".lang('article_totalcomments', 'r').":</b> $a_commentscount_number";
        }

        $author=@mysql_fetch_array(@mysql_query("SELECT name FROM `".tabprefix."-users` WHERE id=".$mitem['author']));
        $author=$author['name'];

        $mitem['date']=formatdate($mitem['date']);
        $mtmp.="<a href='$linkhref' class='title'>".$mitem['title']."</a><p class='cperex'>".$mitem['perex']."</p><div class='cinfo'><b>".lang('article_author', 'r').":</b> $author | <b>".lang('article_posted', 'r').":</b> ".$mitem['date']." | <b>".lang('article_read', 'r').":</b> ".$mitem['opened']."x$a_commentscount_code</div>\n";
      }
      $mresult=$start."<div>".$mtmp."</div>".$end;
      break;
      
      
      //latart2
      case 1:
      $mparam=intval($mparam);
      
      $mtmp="";
      $mdata=@mysql_query("SELECT title,id FROM `".tabprefix."-articlecontent` WHERE visible=1".futureart." ORDER BY ".artorder." DESC LIMIT 0, $mparam");
      while($mitem=@mysql_fetch_array($mdata)){
      $anchor4url=anchor($mitem['title']);
        /*rewrite*/
        if(rewrite==1){$linkhref=artprefix."-$anchor4url-".$mitem['id'].".html";}
        else{$linkhref="index.php?articleread=".$mitem['id'];}
      $mtmp.="<a href='$linkhref'><b>".$mitem['title']."</b></a><hr size='1' color='".linecolor."'>\n";
      }
      $mresult=$start."<div>".$mtmp."</div>".$end;
      break;

      
      //latcom
      case 2:
      $mparam=intval($mparam);

          $comments=@mysql_query("SELECT tp,home,author,text,subject FROM `".tabprefix."-comments` ORDER BY id DESC LIMIT $mparam");
          $mtmp="";
          while($comment=@mysql_fetch_array($comments)){

          /*spocitani komentaru*/
          $commentscount=@mysql_query("SELECT id FROM `".tabprefix."-comments` WHERE home=".$comment['home']." AND tp=".$comment['tp']);
          $commentscount_number=0;
          while(@mysql_fetch_array($commentscount)){
          $commentscount_number++;
          }

          /*sestaveni odkazu*/
          $failed=false;

          switch($comment['tp']){

          case 1:
          $title4url=@mysql_query("SELECT anchor,visible FROM `".tabprefix."-menu` WHERE id=".$comment['home']);
          $title4url=@mysql_fetch_array($title4url);
          if($title4url['visible']==1){
            $title4url=$title4url['anchor'];
            $anchor=$title4url;
            $title4url=anchor($title4url);

            $id=$comment['home'];
              if(rewrite==1){$linkhref=root.secprefix."-$title4url-$id.html";}
              else{$linkhref="index.php?str=$id&tp=1";}
          }
          else{
          $failed=true;
          }
          break;

          case 2:
          $title4url=@mysql_query("SELECT title,visible FROM `".tabprefix."-articlecontent` WHERE id=".$comment['home'].futureart);
          $title4url=@mysql_fetch_array($title4url);
          if($title4url['visible']==1){
            $title4url=$title4url['title'];
            $anchor=$title4url;
            $title4url=anchor($title4url);

            $id=$comment['home'];
              if(rewrite==1){$linkhref=root.artprefix."-$title4url-$id.html";}
              else{$linkhref="index.php?articleread=$id";}
          }
          else{
          $failed=true;
          }
          break;

          }

          $c_author=@mysql_query("SELECT name FROM `".tabprefix."-users` WHERE id=".$comment['author']);
          $c_author=@mysql_fetch_array($c_author);
          $c_author=$c_author['name'];

          if($failed==false){$mtmp.="<a href='$linkhref' class='title'>$anchor: ".$comment['subject']."</a><p class='cperex'>".textpart(stripwmcode($comment['text']))."</p><div class='cinfo'><b>".lang('article_totalcomments', 'r').":</b> $commentscount_number | <b>".lang('article_composter', 'r').":</b> $c_author</div>\n";}


      }

      $mresult=$start."<div>".$mtmp."</div>".$end;
      break;
      
      
      //mailform
      case 3:
      $mparam=addslashes($mparam);
      $mparam=strtr($mparam, "@", "#");
      $codecheck=code_generate(4);

      $mtmp="
      <form action='".root."modules/hcm/mailform.php' method='post'>
      <input type='hidden' name='receiver' value='$mparam'>
      <input type='hidden' name='codecheckr' value='$codecheck'>

      <table>

      <tr>
      <td><b>".lang('global_youremail', 'r')."</b></td>
      <td><input type='text' name='sender' class='ifieldsmall' maxlength='128' value='@'></td>
      </tr>

      <tr>
      <td><b>".lang('global_subject', 'r')."</b></td>
      <td><input type='text' name='subject' class='ifieldsmall' maxlength='128'></td>
      </tr>

      <tr valign='top'>
      <td><b>".lang('global_text', 'r')."</b></td>
      <td><textarea name='text' class='itextsmall' id='itext'></textarea></td>
      </tr>

      <tr>
      <td><b>".lang('global_codecheck', 'r')."</b></td>
      <td><input type='text' name='codecheck' maxlength='8' class='ifieldsmall'></td>
      </tr>

      <tr>
      <td></td>
      <td><img src='".root."modules/kod.php?n=".$codecheck."' alt='".lang('global_codecheckhelp', 'r')."' title='".lang('global_codecheckhelp', 'r')."' class='codecheck'></td>
      </tr>

      <tr>
      <td></td>
      <td>
      <input type='submit' value='".lang('global_send', 'r')."'>
      <input type='reset' value='".lang('global_reset', 'r')."'>
      </td>
      </tr>

      </table>
      </form>
      ";
      
      $mresult=$start."<div>".$mtmp."</div>".$end;
      break;
      
      
      //php
      case 4:
      if($php==true){
      eval($mparam);
      $mresult=$start.$end;
      }
      break;
      
      
      //gallery
      case 5:
      $mparam=@explode(",",$mparam);

      $dir=trim($mparam[0]);
      $width=intval(trim($mparam[1]));
      
      if(count($mparam)==2 and $width>0 and $width<=2048){
      
        if(substr($dir, -1)!="/"){$dir.="/";}
        if(file_exists(root.$dir) and is_dir(root.$dir)){

        $gcode="";
        $handle=opendir(root.$dir);
        
        while($item=readdir($handle)){
        $suffix=strrpos($item, ".");
        $suffix=substr($item, $suffix+1);
        $suffix=strtolower($suffix);
        if($item=="." or $item==".." or is_dir(root.$dir.$item) or !($suffix=="jpeg" or $suffix=="jpg" or $suffix=="gif" or $suffix=="png")){continue;}
        $item_size=ceil(filesize(root.$dir.$item)/1024);
        $gcode.="<a href='".root."$dir$item' target='_blank' title='$item | ".$item_size."kB'><img src='".root."modules/hcm/gallery.php?f=$dir$item&w=$width'></a>\n";
        }
        
        closedir($handle);

        }

        $mresult=$start."<div>".$gcode."</div>".$end;
        
      }
      break;
      
      
      //gallery2
      case 6:
      if(substr($mparam, -1)!="/"){$mparam.="/";}
      $dir=$mparam;
      $fulldir=$dir."full/";
      $prevdir=$dir."prev/";

      if(file_exists(root.$dir) and is_dir(root.$dir) and file_exists(root.$fulldir) and is_dir(root.$fulldir) and file_exists(root.$prevdir) and is_dir(root.$prevdir)){

      $gcode="";
      $handle=opendir(root.$fulldir);
      while($item=readdir($handle)){
      $suffix=strrpos($item, ".");
      $suffix=substr($item, $suffix+1);
      $suffix=strtolower($suffix);
      if($item=="." or $item==".." or is_dir(root.$fulldir.$item) or !($suffix=="jpeg" or $suffix=="jpg" or $suffix=="gif" or $suffix=="png") or !file_exists(root.$prevdir.$item)){continue;}
      $item_size=ceil(filesize(root.$fulldir.$item)/1024);
      $gcode.="<a href='".root."$fulldir$item' target='_blank' title='$item | ".$item_size."kB'><img src='".root."$prevdir$item' border='0'></a>\n";
      }
      closedir($handle);

      }

      $mresult=$start."<div>".$gcode."</div>".$end;
      break;
      
      
      //randimg
      case 7:
      if(substr($mparam, -1)!="/"){$mparam.="/";}
      $dir=$mparam;

      if(file_exists(root.$dir) and is_dir(root.$dir)){

      $handle=opendir(root.$dir);
      $items=array();
      $itemnum=0;
      while($item=readdir($handle)){
      $suffix=strrpos($item, ".");
      $suffix=substr($item, $suffix+1);
      $suffix=strtolower($suffix);
      if($item=="." or $item==".." or is_dir(root.$item) or !($suffix=="jpeg" or $suffix=="jpg" or $suffix=="gif" or $suffix=="png")){continue;}
      $items[$itemnum]=$item;
      $itemnum++;
      }

      closedir($handle);

      if($itemnum!=0){
      $ritem=array_rand($items);
      $rname=$items[$ritem];
      $mresult=$start."<img src='".root.$dir.$rname."'>".$end;
      }

      }
      break;
      
      
      //randtxt
      case 8:
      if(substr($mparam, -1)!="/"){$mparam.="/";}
      $dir=$mparam;

      if(file_exists(root.$dir) and is_dir(root.$dir)){

      $handle=opendir(root.$dir);
      $items=array();
      $itemnum=0;
      while($item=readdir($handle)){
      $suffix=strrpos($item, ".");
      $suffix=substr($item, $suffix+1);
      $suffix=strtolower($suffix);
      if($item=="." or $item==".." or is_dir(root.$item) or !($suffix=="txt" or $suffix=="html" or $suffix=="htm")){continue;}
      $items[$itemnum]=$item;
      $itemnum++;
      }

      closedir($handle);

      if($itemnum!=0){
      $ritem=array_rand($items);
      $rname=$items[$ritem];
      $rcontent=file_get_contents(root.$dir.$rname);
      $mresult=$start.$rcontent.$end;
      }

      }
      break;
      
      
      //filelist
      case 9:
      if(substr($mparam, -1)!="/"){$mparam.="/";}
      $dir=$mparam;

      if(file_exists(root.$dir) and is_dir(root.$dir)){
      $mtmp="";
      $handle=opendir($mparam);
        while($item=readdir($handle)){
        if($item=="." or $item==".." or is_dir(root.$dir.$item)){continue;}
        $mtmp.="<a href='".root.$dir.$item."' target='_blank'>$item</a><br>\n";
        }
      closedir($handle);
      }

      $mresult=$start."<div>".$mtmp."</div>".$end;
      break;
      
      
      //mrart
      case 10:
      $mparam=intval($mparam);

      $mdata=@mysql_query("SELECT title,perex,id,author,date,opened,comment FROM `".tabprefix."-articlecontent` WHERE opened!=0 AND visible=1".futureart." ORDER BY opened DESC LIMIT 0, $mparam");
      $mtmp="";
      while($mitem=@mysql_fetch_array($mdata)){
      $anchor4url=anchor($mitem['title']);
        /*rewrite*/
        if(rewrite==1){$linkhref=artprefix."-$anchor4url-".$mitem['id'].".html";}
        else{$linkhref="index.php?articleread=".$mitem['id'];}

        /*spocitani komentaru*/
        $a_commentscount_code="";
        if($mitem['comment']==1){
        $a_commentscount=@mysql_query("SELECT id FROM `".tabprefix."-comments` WHERE home=".$mitem['id']." AND tp=2");
        $a_commentscount_number=0;
        while($commentscount_item=@mysql_fetch_array($a_commentscount)){
        $a_commentscount_number++;
        }
        $a_commentscount_code=" | <b>".lang('article_totalcomments', 'r').":</b> $a_commentscount_number";
        }

        $author=@mysql_fetch_array(@mysql_query("SELECT name FROM `".tabprefix."-users` WHERE id=".$mitem['author']));
        $author=$author['name'];
        
        $mitem['date']=formatdate($mitem['date']);
        $mtmp.="<a href='$linkhref' class='title'>".$mitem['title']."</a><p class='cperex'>".$mitem['perex']."</p><div class='cinfo'><b>".lang('article_author', 'r').":</b> $author | <b>".lang('article_posted', 'r').":</b> ".$mitem['date']." | <b>".lang('article_read', 'r').":</b> ".$mitem['opened']."x$a_commentscount_code</div>\n";
      }
      $mresult=$start."<div>".$mtmp."</div>".$end;
      break;
      
      
      //mrart2
      case 11:
      $mparam=intval($mparam);

      $mtmp="";
      $mdata=@mysql_query("SELECT title,id FROM `".tabprefix."-articlecontent` WHERE opened!=0 AND visible=1".futureart." ORDER BY opened DESC LIMIT 0, $mparam");
      while($mitem=@mysql_fetch_array($mdata)){
      $anchor4url=anchor($mitem['title']);
        /*rewrite*/
        if(rewrite==1){$linkhref=artprefix."-$anchor4url-".$mitem['id'].".html";}
        else{$linkhref="index.php?articleread=".$mitem['id'];}
      $mtmp.="<a href='$linkhref'><b>".$mitem['title']."</b></a><hr size='1' color='".linecolor."'>\n";
      }
      $mresult=$start."<div>".$mtmp."</div>".$end;
      break;
      
      
      //randart
      case 12:
      $mparam=intval($mparam);

      $mdata=@mysql_query("SELECT title,perex,id,author,date,opened,comment FROM `".tabprefix."-articlecontent` WHERE visible=1".futureart." ORDER BY RAND() DESC LIMIT 0, $mparam");
      $mtmp="";
      while($mitem=mysql_fetch_array($mdata)){
      $anchor4url=anchor($mitem['title']);
        /*rewrite*/
        if(rewrite==1){$linkhref=artprefix."-$anchor4url-".$mitem['id'].".html";}
        else{$linkhref="index.php?articleread=".$mitem['id'];}

        /*spocitani komentaru*/
        $a_commentscount_code="";
        if($mitem['comment']==1){
        $a_commentscount=@mysql_query("SELECT id FROM `".tabprefix."-comments` WHERE home=".$mitem['id']." AND tp=2");
        $a_commentscount_number=0;
        while($commentscount_item=@mysql_fetch_array($a_commentscount)){
        $a_commentscount_number++;
        }
        $a_commentscount_code=" | <b>".lang('article_totalcomments', 'r').":</b> $a_commentscount_number";
        }

        $author=@mysql_fetch_array(@mysql_query("SELECT name FROM `".tabprefix."-users` WHERE id=".$mitem['author']));
        $author=$author['name'];
        
        $mitem['date']=formatdate($mitem['date']);
        $mtmp.="<a href='$linkhref' class='title'>".$mitem['title']."</a><p class='cperex'>".$mitem['perex']."</p><div class='cinfo'><b>".lang('article_author', 'r').":</b> $author | <b>".lang('article_posted', 'r').":</b> ".$mitem['date']." | <b>".lang('article_read', 'r').":</b> ".$mitem['opened']."x$a_commentscount_code</div>\n";
      }
      $mresult=$start."<div>".$mtmp."</div>".$end;
      break;
      
      
      //randart2
      case 13:
      $mparam=intval($mparam);

      $mtmp="";
      $mdata=@mysql_query("SELECT title,id FROM `".tabprefix."-articlecontent` WHERE visible=1".futureart." ORDER BY RAND() LIMIT 0, $mparam");
      while($mitem=@mysql_fetch_array($mdata)){
      $anchor4url=anchor($mitem['title']);
        /*rewrite*/
        if(rewrite==1){$linkhref=artprefix."-$anchor4url-".$mitem['id'].".html";}
        else{$linkhref="index.php?articleread=".$mitem['id'];}
      $mtmp.="<a href='$linkhref'><b>".$mitem['title']."</b></a><hr size='1' color='".linecolor."'>\n";
      }
      $mresult=$start."<div>".$mtmp."</div>".$end;
      break;
      
      //fulltextbox
      case 14:
      include(root."modules/hcm/fulltextbox.php");
      $mresult=$start.$mtmp.$end;
      break;
      
      //vote
      case 15:
      $mparam=@explode(",",$mparam);
      
      $vid=intval(trim($mparam[0]));
      $boxwidth=intval(trim($mparam[1]));
      $float=trim($mparam[2]);
      $mtmp="";

      $vdata=@mysql_query("SELECT * FROM `".tabprefix."-votecontent` WHERE id=$vid");
      $vdata=@mysql_fetch_array($vdata);

      if($vdata['question']!="" and count($mparam)==3 and $boxwidth>=100){

      $answers=explode("#", $vdata['answers']);
      $votes=explode("#", $vdata['votes']);

        $mtmp.="
        <div class='vote' style='width:".$boxwidth."px;float:$float;'>
        <div class='vote-border'>

        <div class='vote-question'>
        ".$vdata['question']."
        </div>
        ";

        /*vypis odpovedi*/
        $x=0;
        $highlight=false;

          while($x<=count($answers)-1){
            if(array_sum($votes)!=0 and $votes[$x]!=0){
            $width=round(($votes[$x]/array_sum($votes))*($boxwidth-60));
            $percent=round(($votes[$x]/array_sum($votes))*100);
            }
            else{
            $width=1;
            $percent=0;
            }
          if($highlight==true){$class="2";}else{$class="";}

          $mtmp.="
          <div class='vote-answer'>
          <div class='vote-answer-padding$class'>
          <a href='".root."modules/vote.php?vid=$vid&a=$x' title='".lang('vote_vote', 'r')."' target='_blank'>".$answers[$x]."</a>
          <img src='".root."modules/templates/".template."/pics/votebar.gif' class='vote-bar' width='$width'>".$percent."%
          </div>
          </div>
          ";

          $highlight=!$highlight;
          $x++;
          }

        $mtmp.="
        <div class='vote-total'>".lang('vote_total', 'r').": ".array_sum($votes)."</div>
        </div>
        </div>
        ";

      }

      $mresult=$start.$mtmp.$end;
      break;
      
      
      //brart
      case 16:
      $mparam=intval($mparam);

      $mdata=@mysql_query("SELECT title,perex,id,author,date,opened,comment FROM `".tabprefix."-articlecontent` WHERE visible=1 AND rate_total!=0".futureart." ORDER BY rate_total LIMIT 0, $mparam");
      $mtmp="";
      while($mitem=@mysql_fetch_array($mdata)){
      $anchor4url=anchor($mitem['title']);
        /*rewrite*/
        if(rewrite==1){$linkhref=artprefix."-$anchor4url-".$mitem['id'].".html";}
        else{$linkhref="index.php?articleread=".$mitem['id'];}

        /*spocitani komentaru*/
        $a_commentscount_code="";
        if($mitem['comment']==1){
        $a_commentscount=@mysql_query("SELECT id FROM `".tabprefix."-comments` WHERE home=".$mitem['id']." AND tp=2");
        $a_commentscount_number=0;
        while($commentscount_item=@mysql_fetch_array($a_commentscount)){
        $a_commentscount_number++;
        }
        $a_commentscount_code=" | <b>".lang('article_totalcomments', 'r').":</b> $a_commentscount_number";
        }

        $author=@mysql_fetch_array(@mysql_query("SELECT name FROM `".tabprefix."-users` WHERE id=".$mitem['author']));
        $author=$author['name'];

        $mitem['date']=formatdate($mitem['date']);
        $mtmp.="<a href='$linkhref' class='title'>".$mitem['title']."</a><p class='cperex'>".$mitem['perex']."</p><div class='cinfo'><b>".lang('article_author', 'r').":</b> $author | <b>".lang('article_posted', 'r').":</b> ".$mitem['date']." | <b>".lang('article_read', 'r').":</b> ".$mitem['opened']."x$a_commentscount_code</div>\n";
      }
      $mresult=$start."<div>".$mtmp."</div>".$end;
      break;
      
      
      //brart2
      case 17:
      $mparam=intval($mparam);

      $mtmp="";
      $mdata=@mysql_query("SELECT title,id FROM `".tabprefix."-articlecontent` WHERE visible=1 AND rate_total!=0".futureart." ORDER BY rate_total LIMIT 0, $mparam");
      while($mitem=@mysql_fetch_array($mdata)){
      $anchor4url=anchor($mitem['title']);
        /*rewrite*/
        if(rewrite==1){$linkhref=artprefix."-$anchor4url-".$mitem['id'].".html";}
        else{$linkhref="index.php?articleread=".$mitem['id'];}
      $mtmp.="<a href='$linkhref'><b>".$mitem['title']."</b></a><hr size='1' color='".linecolor."'>\n";
      }
      $mresult=$start."<div>".$mtmp."</div>".$end;
      break;
      

      //menu
      case 18:
      if($mparam!=""){
      $limits=@explode(",", $mparam);
        if(count($limits)==2){
        $limit=true;
        $lstart=intval(trim($limits[0]));
        $lend=intval(trim($limits[1]));
        }
        else{
        $limit=false;
        }
      }
      else{
      $limit=false;
      }

      include(root."modules/hcm/menu.php");
      $mresult=$start.$mtmp.$end;
      break;
      
      
      //loginform
      case 19:
      $refer=1;
      include(root."modules/hcm/loginform.php");
      $mresult=$start.$mtmp.$end;
      break;
      
      
      
      //latcom2
      case 20:
      $mparam=intval($mparam);

          $comments=@mysql_query("SELECT tp,home,author,text,subject FROM `".tabprefix."-comments` ORDER BY id DESC LIMIT $mparam");
          $mtmp="";
          while($comment=@mysql_fetch_array($comments)){

          /*spocitani komentaru*/
          $commentscount=@mysql_query("SELECT id FROM `".tabprefix."-comments` WHERE home=".$comment['home']." AND tp=".$comment['tp']);
          $commentscount_number=0;
          while(@mysql_fetch_array($commentscount)){
          $commentscount_number++;
          }

          /*sestaveni odkazu*/
          $failed=false;

          switch($comment['tp']){

          case 1:
          $title4url=@mysql_query("SELECT anchor,visible FROM `".tabprefix."-menu` WHERE id=".$comment['home']);
          $title4url=@mysql_fetch_array($title4url);
          if($title4url['visible']==1){
            $title4url=$title4url['anchor'];
            $anchor=$title4url;
            $title4url=anchor($title4url);

            $id=$comment['home'];
              if(rewrite==1){$linkhref=root.secprefix."-$title4url-$id.html";}
              else{$linkhref="index.php?str=$id&tp=1";}
          }
          else{
          $failed=true;
          }
          break;

          case 2:
          $title4url=@mysql_query("SELECT title,visible FROM `".tabprefix."-articlecontent` WHERE id=".$comment['home'].futureart);
          $title4url=@mysql_fetch_array($title4url);
          if($title4url['visible']==1){
            $title4url=$title4url['title'];
            $anchor=$title4url;
            $title4url=anchor($title4url);

            $id=$comment['home'];
              if(rewrite==1){$linkhref=root.artprefix."-$title4url-$id.html";}
              else{$linkhref="index.php?articleread=$id";}
          }
          else{
          $failed=true;
          }
          break;

          }

          if($failed==false){$mtmp.="<a href='$linkhref'><b>$anchor</b> ($commentscount_number)</a><br>\n";}


      }

      $mresult=$start."<div>".$mtmp."</div>".$end;
      break;
      


    }
    
    if($mresult!=""){$output=$mresult;}

    }
    else{
      /*odfiltrovani neuzavreneho tagu*/
      if($mpos1){
      $start=substr($output, 0, $mpos1);
      $end=substr($output, $mpos1+strlen($hcm_item_starttag));
      $output=$start.$end;
      }
    }
    
    $mparserrepeat++;
    }

  $hcm_num++;
  }
  
  /*navraceni vystupu parseru*/
  $output=substr($output, 2);
  return $output;

}

?>
