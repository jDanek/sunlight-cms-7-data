<?php

if($securitylogout==false){
$root="../";
include("../_connect.php");
}

session_start();
unset($_SESSION[systemuid.'login_indicator']);
unset($_SESSION[systemuid.'login_id']);
unset($_SESSION[systemuid.'login_name']);
unset($_SESSION[systemuid.'login_rights']);

if($securitylogout==false){
  $referer=$_SERVER['HTTP_REFERER'];
  if($referer!=""){header("location: $referer");}
  else{header("location: ../");}
  exit;
}

?>
