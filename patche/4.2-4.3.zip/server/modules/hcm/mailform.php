<?php
$root="../../";
include("../../_connect.php");

/*odeslani*/
if(isset($_POST['text'])){

  /*nacteni promennych*/
  $receiver=$_POST['receiver'];
  $receiver=strtr($receiver, "#", "@");
  $sender=$_POST['sender'];
  $sender=trim($sender);
  $sender=substr($sender, 0, 128);
  $ip=$_SERVER['REMOTE_ADDR'];
  $subject=$_POST['subject'];
  $subject=trim($subject);
  $text=$_POST['text'];
  $text=substr($text, 0, 102400);
  $text=trim($text);
  $text="FROM: $sender\nIP: $ip\n===============\n\n$text";
  $codecheck=$_POST['codecheck'];
  $codecheckr=$_POST['codecheckr'];
  $codecheckr=code_decode($codecheckr);

  if($text!="" and strpos($sender, "@") and strlen($sender)>=3 and $subject!="" and $codecheck==$codecheckr){
  @mail($receiver, $subject, $text, "Content-Type:text/plain;charset=win-1250\n");
  $msg=lang('hcm_mailform_sent', 'r');
  }
  else{
  $msg=lang('global_msg_someempty', 'r');
  }

}
else{
exit;
}

$moduletitle='hcm_mailform_title';
include("../moduleheader.php");
?>

<body>

<?php include("../msg.php");?>

<div class="board">
<div class="board-padding">

<a href="<?php referer(); ?>">&lt; <?php lang('global_goback', 'e'); ?></a>

</div>
</div>

</body>
</html>
