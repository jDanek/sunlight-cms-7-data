<?php

if($limit==true){$limit=" WHERE ord>=$lstart AND ord<=$lend ";}
else{$limit="";}

$menu=@mysql_query("SELECT * FROM `".tabprefix."-menu`".$limit."ORDER BY ord");
$mtmp="<menu>";

while($item=@mysql_fetch_array($menu)){

  /*preskoceni neviditelnych*/
  $m_visible=$item['visible'];
  if($m_visible!=1){
  continue;
  }

  /*nacteni promennych k polozce*/
  $m_id=$item['id'];
  $m_anchor=$item['anchor'];
  $m_type=$item['type'];
  
  /*anchor pro url*/
  $anchor=anchor($m_anchor);
  
  /*sestaveni a vypis odkazu*/
  switch($m_type){
  
  case 1:
  /*rewrite*/
  if(rewrite==1){$linkhref=secprefix."-$anchor-$m_id.html";}
  else{$linkhref="index.php?str=$m_id&tp=1";}
  break;
  
  case 2:
  /*rewrite*/
  if(rewrite==1){$linkhref=catprefix."-$anchor-$m_id-1.html";}
  else{$linkhref="index.php?str=$m_id&tp=2";}
  break;
  
  case 3:
  /*rewrite*/
  if(rewrite==1){$linkhref=gbprefix."-$anchor-$m_id-1.html";}
  else{$linkhref="index.php?str=$m_id&tp=3";}
  break;
  
  }
  
  $mtmp.="<li><a href='$linkhref'>$m_anchor</a></li>\n";
}

$mtmp.="</menu>";

?>
