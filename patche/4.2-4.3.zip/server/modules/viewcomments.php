<?php

/*pripojeni*/
$root="../";
include("../_connect.php");

/*limitovani autora*/
$continue=true;
if(isset($_GET['author'])){

  $langlimited="limited_";

  $getauthor=addslashes($_GET['author']);
  $authorid=@mysql_query("SELECT id,name FROM `".tabprefix."-users` WHERE name='$getauthor'");
  $authorid=@mysql_fetch_array($authorid);

  if($authorid['name']!=""){
  $authorlimit=" WHERE author=".$authorid['id'];
  $getauthor="&author=".$getauthor;
  }
  else{
  $continue=false;
  }

}
else{
$getauthor="";
$authorlimit="";
$langlimited="";
}

/*vlozeni hlavicky*/
$moduletitle="viewcomments_".$langlimited."title";
include("moduleheader.php");

?>

<body>

<div class="board">
<div class="board-padding">
<a href="../">&lt; <?php lang('global_backtomain', 'e'); ?></a><br><br>

<h1><?php lang('viewcomments_'.$langlimited.'title', 'e'); ?></h1>
<p><?php lang('viewcomments_'.$langlimited.'p', 'e'); ?></p>

<hr size="1" color="<?php echo $st_linecolor; ?>">
<div id="results">

<?php

  /*----------ZPRACOVANI VSTUPNICH PARAMETRU STRANKOVANI----------*/
  if(isset($_GET['s'])){
  $startpage=$_GET['s'];
  $startpage=intval($startpage);
  if($startpage!=0){$startpage-=1;}
  }
  else{
  $startpage=0;
  }
  $start=$startpage*$st_limit;

  /*----------VYHLEDANI----------*/
  if($continue==true){
  
    $comments=@mysql_query("SELECT tp,home,author,text,subject FROM `".tabprefix."-comments`$authorlimit ORDER BY id DESC");
    $naslo=0;
    while($comment=@mysql_fetch_array($comments)){
    $naslo++;

      if($naslo>$start and $naslo<=$start+$st_limit){

        /*spocitani komentaru*/
        $commentscount=@mysql_query("SELECT id FROM `".tabprefix."-comments` WHERE home=".$comment['home']." AND tp=".$comment['tp']);
        $commentscount_number=0;
        while(@mysql_fetch_array($commentscount)){
        $commentscount_number++;
        }

        /*sestaveni odkazu*/
        $failed=false;

        switch($comment['tp']){

        case 1:
        $title4url=@mysql_query("SELECT anchor,visible FROM `".tabprefix."-menu` WHERE id=".$comment['home']);
        $title4url=@mysql_fetch_array($title4url);
        if($title4url['visible']==1){
          $title4url=$title4url['anchor'];
          $anchor=$title4url;
          $title4url=anchor($title4url);

          $id=$comment['home'];
            if(rewrite==1){$linkhref="../".secprefix."-$title4url-$id.html";}
            else{$linkhref=root."index.php?str=$id&tp=1";}
        }
        else{
        $failed=true;
        }
        break;

        case 2:
        $title4url=@mysql_query("SELECT title,visible FROM `".tabprefix."-articlecontent` WHERE id=".$comment['home'].$st_futureart);
        $title4url=@mysql_fetch_array($title4url);
        if($title4url['visible']==1){
          $title4url=$title4url['title'];
          $anchor=$title4url;
          $title4url=anchor($title4url);

          $id=$comment['home'];
            if(rewrite==1){$linkhref="../".artprefix."-$title4url-$id.html";}
            else{$linkhref=root."index.php?articleread=$id";}
        }
        else{
        $failed=true;
        }
        break;

        }

        $c_author=@mysql_query("SELECT name FROM `".tabprefix."-users` WHERE id=".$comment['author']);
        $c_author=@mysql_fetch_array($c_author);
        $c_author=$c_author['name'];
        if($failed==false){
        if($authorlimit==""){$authorinfo=" | <b>".lang('article_composter', 'r').":</b> $c_author";}else{$authorinfo="";}
        echo "<a href='$linkhref' class='title'>$anchor: ".$comment['subject']."</a><p class='cperex'>".strtr(textpart(stripwmcode($comment['text'])), $smajlici)."</p><div class='cinfo'><b>".lang('article_totalcomments', 'r').":</b> $commentscount_number".$authorinfo."</div>\n";
        }
        else{
        $naslo--;
        }

      }

    }


      /*----------VYPIS STRAN----------*/
      if($naslo!=0){

      $pocetstran=$naslo;
      $pocetstran=$pocetstran/$st_limit;
      $pocetstran=ceil($pocetstran);

      if($startpage>=0 and $startpage<=$pocetstran-1){

      if($startpage>9){$strana=$startpage-5;}
      else{$strana=0;}
      $odkazu=0;
      $back=$startpage-10;
      $forward=$startpage+10;
      echo "<div class='strany'><b>".lang('global_page', 'r')."</b>: ";
      if($startpage>=10){echo "<a href='viewcomments.php?s=$back".$getauthor."'>&lt;</a> ";}

      while($strana<$pocetstran and $odkazu<=$st_maxpages){
      $odkazu++;
      $stranaanchor=$strana+1;
      if($strana==$startpage){echo "<a href='viewcomments.php?s=$stranaanchor".$getauthor."' class='active'>$stranaanchor</a> ";}
      else{echo "<a href='viewcomments.php?s=$stranaanchor".$getauthor."'>$stranaanchor</a> ";}
      $strana++;
      }

      if($startpage<=$pocetstran-10){echo "<a href='viewcomments.php?s=$forward".$getauthor."'>&gt;</a> ";}

      echo "</div>";

      }
      else{
      lang('global_wrongpage', 'e');
      }

      }
      else{
      lang('comment_nokit', 'e');
      }

    }
    else{
    lang('global_msg_usernotexists', 'e');
    }

    

?>

</div>
</div>
</div>

</body>
</html>
