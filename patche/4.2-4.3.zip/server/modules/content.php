<?php
$lognise="<br><hr size='1' color='$st_linecolor'>\n<h2>".lang('comment_title', 'r')."</h2><p>".lang('comment_denied', 'r')."</p>";

/*----------VYPIS CLANKU----------*/
if(isset($_GET['articleread'])){
  /*nacteni dat*/
  $a_articleread=$_GET['articleread'];
  $a_articleread=intval($a_articleread);
  $a_content=@mysql_query("SELECT * FROM `".tabprefix."-articlecontent` WHERE id=$a_articleread");
  $a_content=@mysql_fetch_array($a_content);
  $a_comment=$a_content['comment'];

  /*modul*/
  if($a_comment=="" or ($a_content['date']>time() and !isset($_SESSION[systemuid.'login_aindicator']))){$chyba=true;}else{$chyba=false;}
  if($chyba==false){include("modules/article.php");}
  else{lang('content_notfound', 'e');}
}
else{

/*----------PARAMETRY PRO SEKCI NEBO UVODNI STRANA----------*/
$continue=true;

if($_GET['str']!="" and ($_GET['tp']==1 or $_GET['tp']==2 or $_GET['tp']==3)){
$c_str=$_GET['str'];
$c_str=intval($c_str);
$c_tp=$_GET['tp'];
$c_tp=intval($c_tp);
}
else {include("modules/mainpage.php");}

/*----------ROZLISENI PARAMETRU TP----------*/
if($continue==true){
switch($c_tp){

/*----------VYPIS SEKCE----------*/
case "1":
  /*nacteni dat*/
  $codecontent=@mysql_query("SELECT home,code,comment FROM `".tabprefix."-codecontent` WHERE home=$c_str");
  $codecontent=@mysql_fetch_array($codecontent);
  $c_comment=$codecontent['comment'];
  $c_home=$codecontent['home'];

  /*modul*/
  if($codecontent['comment']==""){$chyba=true;}else{$chyba=false;}
  if($chyba==false){include("modules/section.php");}
  else{lang('content_notfound', 'e');}
break;

/*----------VYPIS SEZNAMU CLANKU----------*/
case "2":
  /*nacteni dat*/
  $kategorie=@mysql_query("SELECT anchor FROM `".tabprefix."-menu` WHERE id=$c_str AND type=2");
  $kategorie=@mysql_fetch_array($kategorie);
  $kategorie=$kategorie['anchor'];
  $skategorie=anchor($kategorie);

  /*modul*/
  if($kategorie==""){$chyba=true;}else{$chyba=false;}
  if($chyba==false){include("modules/category.php");}
  else{lang('content_notfound', 'e');}
break;

/*----------KNIHA----------*/
case "3":
  /*nacteni dat*/
  $bookanchor=@mysql_query("SELECT anchor FROM `".tabprefix."-menu` WHERE id=$c_str");
  $bookanchor=@mysql_fetch_array($bookanchor);
  $bookanchor=$bookanchor['anchor'];

  /*modul*/
  if($bookanchor==""){$chyba=true;}else{$chyba=false;}
  if($chyba==false){include("modules/gbook.php");}
  else{lang('content_notfound', 'e');}
break;

}
}

}
?>
