<?php
session_start();
$root="../";
$moduletitle="article_rate";
include("../_connect.php");
include("moduleheader.php");

/*nacteni r a id*/
$r=$_GET['r'];
$r=intval($r);

$id=$_GET['id'];
$id=intval($_GET['id']);
$idtest=@mysql_query("SELECT title FROM `".tabprefix."-articlecontent` WHERE id=$id");
$idtest=@mysql_fetch_array($idtest);
$idtest=$idtest['title'];
if($r>=1 and $r<=5 and $idtest!=""){$continue=true;}
else{$continue=false;}
?>

<body>

<div class="board" style="width:275px;">
<div class="board-padding">
<center>

<h1><?php echo lang('article_rate', 'r'); ?></h1>
<?php
if($continue==true){

$a_rate=explode("|", $_SESSION[systemuid.'log_artrate']);
$a_ratenum=0;
$a_ratefound=false;
while($a_ratenum<=count($a_rate)){
$a_rateitem=$a_rate[$a_ratenum];
if($a_rateitem==$id){$a_ratefound=true; break;}
$a_ratenum++;
}

  /*vlozeni do logu a pripocteni pocitadla*/
  if($a_ratefound==false){
  $_SESSION[systemuid.'log_artrate'].="|$id";
  @mysql_query("UPDATE `".tabprefix."-articlecontent` SET rate_counter=rate_counter+1 WHERE id=$id");
  @mysql_query("UPDATE `".tabprefix."-articlecontent` SET rate_total=rate_total+$r WHERE id=$id");
  lang('global_rate_accepted', 'e');
  }
  else{
  lang('global_rate_denied', 'e');
  }


}
else{
lang('global_invalidinput', 'e');
}
?>

</center>
</div>
</div>

</body>
</html>
