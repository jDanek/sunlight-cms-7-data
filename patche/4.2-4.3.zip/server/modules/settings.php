<?php
$root="../";
include("startup.php");
if($login_indicator!=1){exit;}

/*nacteni stavajicich uziv. dat*/
$userdata=@mysql_query("SELECT name,password,email,sex,year,month,note FROM `".tabprefix."-users` WHERE id=$login_id");
$userdata=@mysql_fetch_array($userdata);
$userdata['email']=strtr($userdata['email'], $atback);

/*ulozeni nastaveni*/
if(isset($_POST['email'])){

  /*nacteni promennych*/
  $newpassword=$_POST['newpassword'];
  $newpassword2=$_POST['newpassword2'];
  $actualpass=$_POST['actualpassword'];
  $email=$_POST['email'];
  $email=trim($email);
  $note=$_POST['note'];
  $note=strtr($note, $trans);
  $note=substr($note, 0, 255);

    //pohlavi
    $sex=$_POST['sex'];
    $sex=intval($sex);
    if(!($sex==-1 or $sex==0 or $sex==1)){$sex=-1;}

    //mesic
    $month=$_POST['month'];
    $month=intval($month);
    if(!($month>=1 or $month<=12 or $month==-1)){$month=-1;}

    //rok
    $year=$_POST['year'];
    $year=intval($year);
    if(!($year>=date("Y")-110 or $year<=date("Y") or $year==-1)){$year=-1;}

    //deaktivace
    if($year==-1 xor $month==-1){$year=-1; $month=-1;}
  
  if($login_rights==2){$newname=$_POST['newname']; $newname=substr($newname, 0, 20); $newname=anchor($newname, false);}
  else{$newname=" ";}
  
  /*kontrola a ulozeni*/
  if($newpassword==$newpassword2){
  
  $namecheck=@mysql_query("SELECT name FROM `".tabprefix."-users` WHERE name='$newname'");
  $namecheck=@mysql_fetch_array($namecheck);
  $namecheck=$namecheck['name'];

  if(validate_email($email) and $newname!="" and ($namecheck=="" or $namecheck==$login_name)){
  
  $emailcheck=@mysql_query("SELECT name FROM `".tabprefix."-users` WHERE email='$email'");
  $emailcheck=mysql_fetch_array($emailcheck);
  $emailcheck=$emailcheck['name'];
  
  if($emailcheck=="" or $emailcheck==$userdata['name']){

    /*kontrola puvodniho hesla*/
    $continue=true;
    if($newpassword==""){
    $newpassword=$userdata['password'];
    }
    else{
      if(md5($actualpass)==$userdata['password']){
      $newpassword=md5($newpassword);
      }
      else{
      $continue=false;
      }
    }
  
    if($continue==true){
    
    /*aktualizace v db*/
    @mysql_query("UPDATE `".tabprefix."-users` SET email='$email' WHERE id=$login_id");
    @mysql_query("UPDATE `".tabprefix."-users` SET note='$note' WHERE id=$login_id");
    @mysql_query("UPDATE `".tabprefix."-users` SET password='$newpassword' WHERE id=$login_id");
    @mysql_query("UPDATE `".tabprefix."-users` SET year=$year WHERE id=$login_id");
    @mysql_query("UPDATE `".tabprefix."-users` SET month=$month WHERE id=$login_id");
    @mysql_query("UPDATE `".tabprefix."-users` SET sex=$sex WHERE id=$login_id");

    if($login_rights==2 and $newname!=$login_name){
    @mysql_query("UPDATE `".tabprefix."-users` SET name='$newname' WHERE id=$login_id");
    }

    /*data a zprava*/

      /*nacteni novych uziv. dat*/
      $userdata=@mysql_query("SELECT name,password,email,sex,year,month,note FROM `".tabprefix."-users` WHERE id=$login_id");
      $userdata=@mysql_fetch_array($userdata);
      $userdata['email']=strtr($userdata['email'], $atback);

    $msg=lang('global_settingssaved', 'r');
    
    }
    else{
    $msg=lang('global_msg_nosame', 'r');
    }
    
    }
    else{
    $msg=lang('global_msg_mailexists', 'r');
    }

  }
  else{
    if($namecheck!="" and $namecheck!=$login_name){
    $msg=lang('global_msg_userexists', 'r');
    }
    else{
    $msg=lang('global_msg_someempty', 'r');
    }
  }

  }
  else{
  $msg=lang('global_msg_nosame', 'r');
  }

}

$moduletitle="settings_title";
include("moduleheader.php");
?>

<body>

<?php include("msg.php"); ?>


<div class="board">
<div class="board-padding">

<a href="../">&lt; <?php lang('global_backtomain', 'e'); ?></a><br><br>
<h1><?php lang('settings_title', 'e'); ?></h1>
<p><?php lang('settings_p', 'e'); ?></p>
<?php if($login_rights==2){echo "<p>".lang('settings_p_special', 'r')."</p>";} ?>

<?php
/*javascript pro delku poznamky*/
$itext_maxlength=255;
$itext_name="note";
include("itext.inc");
?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="form">
<table>

<?php
/*pole pro zmenu jmena*/
if($login_rights==2){
echo "<tr>
<td><b>".lang('global_username', 'r')."</b></td>
<td><input type='text' name='newname' size='20' maxlength='20' value='".$userdata['name']."'></td>
</tr>
";
}
?>

<tr>
<td><b><?php lang('global_actualpass', 'e'); ?></b></td>
<td><input type="password" name="actualpassword" size="20" maxlength="255"></td>
</tr>

<tr>
<td><b><?php lang('global_newpass', 'e'); ?></b></td>
<td><input type="password" name="newpassword" size="20" maxlength="255"></td>
</tr>

<tr>
<td><b><?php lang('global_newpass', 'e'); ?> <?php lang('global_check', 'e'); ?></b></td>
<td><input type="password" name="newpassword2" size="20" maxlength="255"></td>
</tr>

<tr>
<td><b><?php lang('global_email', 'e'); ?></b></td>
<td><input type="text" name="email" size="20" value="<?php echo $userdata['email']; ?>"></td>
</tr>

<tr>
<td><b><?php lang('global_borndate', 'e'); ?></b></td>
<td>

  <select name="month">
  <option value='-1'>-</option>
  <?php
  $x=1;
  while($x<=12){
  if($x<10){$x="0$x";}
  if($x!=$userdata['month']){echo "<option value='$x'>$x</option>\n";}
  else{echo "<option value='$x' selected>$x</option>\n";}
  $x++;
  }
  ?>
  </select>&nbsp;

  <select name="year">
  <option value='-1'>-</option>
  <?php
  $x=date("Y");
  while($x>=date("Y")-110){
  if($x!=$userdata['year']){echo "<option value='$x'>$x</option>\n";}
  else{echo "<option value='$x' selected>$x</option>\n";}
  $x--;
  }
  ?>
  </select>&nbsp;<small><?php lang('settings_borndate_help', 'e'); ?></small>

</td>
</tr>

<tr>
<td><b><?php lang('global_sex', 'e'); ?></b></td>
<td>
<?php
switch($userdata['sex']){
case -1: $sex_undefined=" selected"; $sex_male=""; $sex_female=""; break;
case 0: $sex_undefined=""; $sex_male=" selected"; $sex_female=""; break;
case 1: $sex_undefined=""; $sex_male=""; $sex_female=" selected"; break;
}
?>
<select name="sex">
<option value="-1"<?php echo $sex_undefined; ?>>-</option>
<option value="0"<?php echo $sex_male; ?>><?php lang('global_sex_male', 'e'); ?></option>
<option value="1"<?php echo $sex_female; ?>><?php lang('global_sex_female', 'e'); ?></option>
</select>
</td>
</tr>

<tr valign="top">
<td><b><?php lang('global_note', 'e'); ?></b></td>
<td><textarea type="text" name="note" rows="4" cols="30"><?php echo $userdata['note']; ?></textarea></td>
</tr>

<tr><td></td>
<td>
<input type="submit" value="<?php lang('global_save', 'e'); ?> &gt;">
<input type="reset" value="<?php lang('global_reset', 'e'); ?>">
</td>
</tr>

</table>
</form>

</div>
</div>


</body>
</html>
