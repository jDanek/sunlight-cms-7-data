<?php
$root="../";
include("../_connect.php");

if(isset($_GET['id']) and $_GET['id']!=""){

$id=$_GET['id'];
$id=anchor($id, false);
if($id==anchor(lang('global_fableduser', 'r'), false)){$id="";}

}
else{
$id="";
}

$moduletitle="viewprofile_title";
include("moduleheader.php");
?>

<body>

<div class="board">
<div class="board-padding">

<a href="<?php referer(); ?>">&lt; <?php lang('global_goback', 'e'); ?></a><br><br>
<h1><?php lang('viewprofile_title', 'e'); ?></h1>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
<b><?php lang('global_user', 'e'); ?></b>:&nbsp;
<input type="text" name="id" size="20" value="<?php echo $id; ?>">
<input type="submit" value="<?php lang('global_view', 'e'); ?> &gt;">
</form>

<hr size="1" color="<?php echo $st_linecolor; ?>">

<?php
if($id!=""){

$userdata=@mysql_query("SELECT id,name,rights,email,sex,year,month,note FROM `".tabprefix."-users` WHERE name='$id'");
$userdata=@mysql_fetch_array($userdata);

  if($userdata['name']!=""){
  
  $userdata['email']=strtr($userdata['email'], $at);
  
  /*pocet zaslanych clanku*/
  if($userdata['rights']==1 or $userdata['rights']==2){

    $userart_data=@mysql_query("SELECT id FROM `".tabprefix."-articlecontent` WHERE author=".$userdata['id'].$st_futureart);
    $userart_count=0;
    while(@mysql_fetch_array($userart_data)){$userart_count++;}
    
    if($userart_count!=0){$userart_count_showlink=" - <a href='viewarticles.php?id=$id' target='_blank'>".lang('global_show', 'r')."</a>";}
    else{$userart_count_showlink="";}
    
    $userart="
    \n<tr>
    <td class='tdmain'>".lang('viewprofile_userart', 'r')."</td>
    <td>".$userart_count.$userart_count_showlink."</td>
    </tr>

    ";

  }
  else{
  $userart="";
  }

  /*textove vyjadreni prav*/
  switch($userdata['rights']){
  case 0: $userdata['rights']=lang('global_reader', 'r'); break;
  case 1: $userdata['rights']=lang('global_redactor', 'r'); break;
  case 2: if($userdata['id']!=0){$userdata['rights']=lang('global_administrator', 'r');}else{$userdata['rights']=lang('global_mainadministrator', 'r');} break;
  }
  
  /*textove vyjadreni pohlavi*/
  switch($userdata['sex']){
  case -1: $userdata['sex']="-"; break;
  case 0: $userdata['sex']=lang('global_sex_male', 'r'); break;
  case 1: $userdata['sex']=lang('global_sex_female', 'r'); break;
  }
  
  /*vypocet veku*/
  if($userdata['year']!=-1 and $userdata['month']!=-1){
  $userdata['age']=(date("Y")+(date("n")/12))-($userdata['year']+($userdata['month']/12));
    $dotpos=strpos($userdata['age'], ".");
    if($dotpos){
    $main=substr($userdata['age'], 0, $dotpos);
    $sub=substr($userdata['age'], $dotpos+1);
    $sub=substr($sub, 0, 1);
    $userdata['age']="$main.$sub";
    }
  }
  else{
  $userdata['age']="-";
  }
  
  /*spocitani komentaru*/
  $userdata_comments=@mysql_query("SELECT id,home,tp FROM `".tabprefix."-comments` WHERE author=".$userdata['id']);
  $userdata_totalcomments=0;
  while($userdata_comment=@mysql_fetch_array($userdata_comments)){
  
    $failed=false;
    if($userdata_comment['tp']==2){
    $adate=@mysql_query("SELECT date FROM `".tabprefix."-articlecontent` WHERE id=".$userdata_comment['home']);
    $adate=@mysql_fetch_array($adate);
    $adate=$adate['date'];
    if($adate>time()){$failed=true;}
    }
    
    if($failed==false){$userdata_totalcomments++;}

  }
  
  if($userdata_totalcomments!=0){
  $totalcomments_showlink=" - <a href='viewcomments.php?author=$id' target='_blank'>".lang('global_show', 'r')."</a>";
  }
  else{
  $totalcomments_showlink="";
  }
  
  /*zpracovani poznamky*/
  $userdata_note=$userdata['note'];
  if($userdata_note==""){
  $userdata_note="-";
  }
  else{
  $userdata_note=nl2br(parsewmcode($userdata_note));
  }
  
  
  
  /*nastaveni zobrazovani emailu*/
  if($st_showmail==1){
  $usermail="
  <tr>
  <td class='tdmain'>".lang('global_email', 'r').":</td>
  <td><a href='mailto:".$userdata['email']."'>".$userdata['email']."</a></td>
  </tr>";
  }
  else{
  $usermail="";
  }

  echo "
  <div id='viewprofile-border'>
  <table cellspacing='1' cellpadding='5' width='100%' id='viewprofile'>

  <tr>
  <td class='tdmain'>".lang('global_user', 'r').":</td>
  <td>".$userdata['name']."</td>
  </tr>
  
  <tr>
  <td class='tdmain'>".lang('global_rights', 'r').":</td>
  <td>".$userdata['rights']."</td>
  </tr>

  $usermail
  $userart
  <tr>
  <td class='tdmain'>".lang('global_totalcomments', 'r').":</td>
  <td>".$userdata_totalcomments.$totalcomments_showlink."</td>
  </tr>
  
  <tr>
  <td class='tdmain'>".lang('global_age', 'r').":</td>
  <td>".$userdata['age']."</td>
  </tr>
  
  <tr>
  <td class='tdmain'>".lang('global_sex', 'r').":</td>
  <td>".$userdata['sex']."</td>
  </tr>
  
  <tr valign='top'>
  <td class='tdmain'>".lang('global_note', 'r').":</td>
  <td>".$userdata_note."</td>
  </tr>

  </table>
  </div>
  ";
  
  }
  else{
  lang('global_msg_usernotexists', 'e');
  }
  
  
  }
  else{
  lang('global_msg_usernotexists', 'e');
  }
?>

</div>
</div>

</body>
</html>
