<?php

@mysql_query("ALTER TABLE `webman-bookcontent`  DEFAULT CHARACTER SET cp1250 COLLATE cp1250_general_ci;");
@mysql_query("ALTER TABLE `webman-boxcontent`  DEFAULT CHARACTER SET cp1250 COLLATE cp1250_general_ci;");
@mysql_query("ALTER TABLE `webman-votecontent`  DEFAULT CHARACTER SET cp1250 COLLATE cp1250_general_ci;");
@mysql_query("INSERT INTO `webman-settings` ( `variable` , `value` ) VALUES ('futureart', '0');");
@mysql_query("INSERT INTO `webman-settings` ( `variable` , `value` ) VALUES ('postwait', '30');");
@mysql_query("INSERT INTO `webman-settings` ( `variable` , `value` ) VALUES ('template', 'default');");
@mysql_query("INSERT INTO `webman-settings` ( `variable` , `value` ) VALUES ('invismain', '0');");
@mysql_query("DELETE FROM `webman-settings` WHERE variable='linecolor';");

?>
