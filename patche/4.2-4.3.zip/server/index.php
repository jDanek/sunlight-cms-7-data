<?php

/*priprava*/
$root="./"; include("modules/startup.php");

/*vlozeni layoutu*/
if($templatefile!=""){include($templatefile);}
else{include("modules/error.php");}

/*opodjeni*/
@mysql_close($connection);

?>
