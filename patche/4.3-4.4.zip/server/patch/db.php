<?php

@mysql_query("ALTER TABLE `".tabprefix."-articlecontent` RENAME `".tabprefix."-articles`;");
@mysql_query("ALTER TABLE `".tabprefix."-blockedip` RENAME `".tabprefix."-bans`;");
@mysql_query("ALTER TABLE `".tabprefix."-bookcontent` RENAME `".tabprefix."-books`;");
@mysql_query("ALTER TABLE `".tabprefix."-boxcontent` RENAME `".tabprefix."-boxes`;");
@mysql_query("ALTER TABLE `".tabprefix."-codecontent` RENAME `".tabprefix."-sections`;");
@mysql_query("ALTER TABLE `".tabprefix."-votecontent` RENAME `".tabprefix."-votes`;");
@mysql_query("INSERT INTO `".tabprefix."-settings` ( `variable` , `value` ) VALUES ('comment', '1');");
@mysql_query("INSERT INTO `".tabprefix."-settings` ( `variable` , `value` ) VALUES ('registration', '1');");
@mysql_query("INSERT INTO `".tabprefix."-settings` ( `variable` , `value` ) VALUES ('onlyregcon', '0');");
@mysql_query("INSERT INTO `".tabprefix."-settings` ( `variable` , `value` ) VALUES ('artrate', '1');");
@mysql_query("INSERT INTO `".tabprefix."-settings` ( `variable` , `value` ) VALUES ('artread', '1');");
@mysql_query("INSERT INTO `".tabprefix."-settings` ( `variable` , `value` ) VALUES ('artrealname', '0');");
@mysql_query("ALTER TABLE `".tabprefix."-menu` ADD `sublink` TINYINT NOT NULL AFTER `visible` ;");
@mysql_query("ALTER TABLE `".tabprefix."-articles` CHANGE `id` `id` INT( 6 ) NOT NULL, CHANGE `comment` `comment` TINYINT( 4 ) NOT NULL, CHANGE `home` `home` INT( 6 ) NOT NULL;");
@mysql_query("ALTER TABLE `".tabprefix."-comments` CHANGE `id` `id` INT( 6 ) NOT NULL , CHANGE `home` `home` INT( 6 ) NOT NULL , CHANGE `tp` `tp` TINYINT( 4 ) NOT NULL;");
@mysql_query("ALTER TABLE `".tabprefix."-menu` CHANGE `id` `id` INT( 6 ) NOT NULL , CHANGE `type` `type` TINYINT( 4 ) NOT NULL , CHANGE `visible` `visible` TINYINT( 4 ) NOT NULL , CHANGE `ord` `ord` SMALLINT( 6 ) NOT NULL;");
@mysql_query("ALTER TABLE `".tabprefix."-sections` CHANGE `id` `id` INT( 11 ) NOT NULL , CHANGE `home` `home` INT( 11 ) NOT NULL , CHANGE `comment` `comment` TINYINT( 4 ) NOT NULL;");
@mysql_query("ALTER TABLE `".tabprefix."-users` CHANGE `rights` `rights` TINYINT( 4 ) NOT NULL;");
@mysql_query("ALTER TABLE `".tabprefix."-articles` ADD `rate_allow` TINYINT NOT NULL ;");
@mysql_query("ALTER TABLE `".tabprefix."-users` ADD `realname` TINYTEXT NOT NULL AFTER `name` ;");
@mysql_query("CREATE TABLE `".tabprefix."-sboxes` (`id` INT NOT NULL ,`name` TINYTEXT NOT NULL) ENGINE = MYISAM ;");
@mysql_query("CREATE TABLE `".tabprefix."-sboxes-posts` (`id` INT NOT NULL ,`author` INT NOT NULL ,`name` TINYTEXT NOT NULL ,`date` BIGINT NOT NULL ,`text` TINYTEXT NOT NULL ,`ip` TINYTEXT NOT NULL) ENGINE = MYISAM ;");
@mysql_query("ALTER TABLE `".tabprefix."-sboxes-posts` ADD `home` INT NOT NULL AFTER `id` ;");
@mysql_query("ALTER TABLE `".tabprefix."-sboxes` CHANGE `name` `name` TINYTEXT CHARACTER SET cp1250 COLLATE cp1250_general_ci NOT NULL;");
@mysql_query("ALTER TABLE `".tabprefix."-sboxes-posts` CHANGE `name` `name` TINYTEXT CHARACTER SET cp1250 COLLATE cp1250_general_ci NOT NULL , CHANGE `text` `text` TINYTEXT CHARACTER SET cp1250 COLLATE cp1250_general_ci NOT NULL CHANGE `ip` `ip` TINYTEXT CHARACTER SET cp1250 COLLATE cp1250_general_ci NOT NULL;");
@mysql_query("ALTER TABLE `".tabprefix."-sboxes`  DEFAULT CHARACTER SET cp1250 COLLATE cp1250_general_ci");
@mysql_query("ALTER TABLE `".tabprefix."-sboxes-posts`  DEFAULT CHARACTER SET cp1250 COLLATE cp1250_general_ci");
@mysql_query("UPDATE `".tabprefix."-menu` SET showtitle=1");
@mysql_query("UPDATE `".tabprefix."-articles` SET rate_allow=1");
@mysql_query("ALTER TABLE `".tabprefix."-sboxes-posts` CHANGE `name` `name` TINYTEXT CHARACTER SET cp1250 COLLATE cp1250_general_ci NOT NULL , CHANGE `text` `text` TINYTEXT CHARACTER SET cp1250 COLLATE cp1250_general_ci NOT NULL, CHANGE `ip` `ip` TINYTEXT CHARACTER SET cp1250 COLLATE cp1250_general_ci NOT NULL;");


/*preformatovani zapisu hcm modulu*/
function reformathcm($content){
$hcm_array=array("latart","latart2","latcom","mailform","php","gallery","gallery2","randimg","randtxt","filelist","mrart","mrart2","randart","randart2","fulltextbox","vote","brart","brart2","menu","loginform","latcom2","sbox");
foreach($hcm_array as $hcm_item){
$oldstarttag="<!--hcm:$hcm_item:start-->";
$oldendtag="<!--hcm:$hcm_item:end-->";
$newstarttag="[hcm:$hcm_item]";
$newendtag="[/hcm:$hcm_item]";
$content=str_replace($oldstarttag, $newstarttag, $content);
$content=str_replace($oldendtag, $newendtag, $content);
}
return $content;
}


  /*boxy*/
  $data=mysql_query("SELECT id,content FROM `".tabprefix."-boxes`");
  while($dat=mysql_fetch_array($data)){
  $content=reformathcm($dat['content']);
  mysql_query("UPDATE `".tabprefix."-boxes` SET content='$content' WHERE id=".$dat['id']);
  }

  /*clanky*/
  $data=mysql_query("SELECT id,code FROM `".tabprefix."-articles`");
  while($dat=mysql_fetch_array($data)){
  $content=reformathcm($dat['code']);
  mysql_query("UPDATE `".tabprefix."-articles` SET code='$content' WHERE id=".$dat['id']);
  }
  
  /*sekce*/
  $data=mysql_query("SELECT id,code FROM `".tabprefix."-sections`");
  while($dat=mysql_fetch_array($data)){
  $content=reformathcm($dat['code']);
  mysql_query("UPDATE `".tabprefix."-sections` SET code='$content' WHERE id=".$dat['id']);
  }



?>
