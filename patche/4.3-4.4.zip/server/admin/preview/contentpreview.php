<?php

$root="../../";
include("../../_connect.php");

session_start();
if(!isset($_SESSION[systemuid.'login_aindicator'])){exit;}

$moduletitle="admin_forms_preview";
$moduleheader_code="<base href=\"$st_serverurl/\">\n";
include("../../modules/moduleheader.php");

?>

<body>

<div class="board">
<div class="board-padding">

<?php
if(isset($_POST['code'])){
$isdata=true;
$mode=intval($_POST['mode']);
$code=stripslashes($_POST['code']);
}
else{
$isdata=false;
}

?>

<h1><?php if($mode==1){lang('admin_preview_title_section', 'e');}else{lang('admin_preview_title_article', 'e');} ?></h1>
<p><?php lang('admin_preview_p', 'e'); ?></p>
<hr size="1" color="<?php echo $st_linecolor; ?>">
<br>

<?php

if($isdata==true){
  switch($mode){
  case 1: echo striphcm($code); break;
  case 2: $title=stripslashes($_POST['title']); $perex=stripslashes($_POST['perex']); echo "<h1>$title</h1><p class='aperex'>$perex</p>$code"; break;
  default: lang('global_msg_badinput', 'e'); break;
  }
}
else{
lang('global_msg_badinput', 'e');
}

?>

</div>
</div>

</body>
</html>
