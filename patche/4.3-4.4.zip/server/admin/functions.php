<?php

/*kontrola existence dat*/
function data_exists($input){
if($input==""){
echo "
<div id=\"adminerror\">
".lang('admin_error', 'r')."<br><br>
&lt; <a href=\"".$_SERVER['HTTP_REFERER']."\" onclick=\"history.go(-1); return false;\">".lang('global_goback', 'r')."</a>
</div>

</div></div></div></div>
<div id='shade-bottom'></div>

<div id=\"copyright\">".lang('admin_global_copyright', 'r')."</div>
</body>
</html>
";
exit;
}
}

/*vypis hlasky o zadnem obsahu*/
function content_exists($input){
if($input==0){lang('admin_global_nokit', 'e');}
}

/*logicky vyber tridy clanku*/
function artclass($visible, $date){
if($visible==0 and ($date<=time() or futureart=="")){$output="invisible";}
if($visible!=1 and $date>time() and futureart!=""){$output="invisible-future";}
if($visible==1 and ($date<=time() or futureart=="")){$output=false;}
if($visible==1 and ($date>time() and futureart!="")){$output="future";}
if($output!=false){$output=" class='$output'";}else{$output="";}
return $output;
}

/*checkboxy*/

  /*zatrhnuti*/
  function checkbox_activate($input, $return=false){
  if($input==1){
    if($return==false){echo " checked";}
    else{return " checked";}
  }
  }

  /*zpracovani vstupu*/
  function checkbox_load($input){
  if($input==""){return 0;}else{return 1;}
  }

  /*schovavani casti formularu*/
  function stuff_hide($input, $part){
  if($input==0){
    switch($part){
    case 1: echo "<span class='hidden'>"; break;
    case 2: echo "</span>"; break;
    }
  }
  }

/*seznamove funkce*/
function listanchor($input){
if(strlen($input)>24){$input=substr($input, 0, 21)."...";}
return $input;
}

function listcontentexists($input){
if($input==0){echo "<tr><td rowspan='3'>".lang('admin_global_nokit', 'r')."</td></tr>";}
}

?>
