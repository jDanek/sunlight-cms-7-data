<?php if($startupted!=true){exit;} ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<?php lang('global_headlink', 'e'); echo "\n"; ?>
<head>
<?php include("modules/head.php"); ?>
</head>

<body>

<div id="border-top"></div>
<div id="border-middle">
<div id="border-middle-padding">

<!--logo-->
<div id="usermenu"><?php include("modules/usermenu.php"); ?></div>
<div id="logo-border"><div id="logo"><a href="./" title="<?php echo $st_title; ?>"></a></div></div>
<div id="logo-line">&nbsp;</div>


  <!--column-first-->
  <div id="column-first">
  <div id="column-first-padding">
  <?php include("modules/boxes.php"); ?>
  </div>
  </div>

  <!--column-main-->
  <div id="column-main">
  <div id="column-main-padding">
  <?php include("modules/content.php"); ?>
  </div>
  </div>

<div class="cleaner"></div>



</div>
</div>
<div id="border-bottom"></div>

<!--copyright-->
<div id="copyright">
<div id="copyright-padding">
<?php lang('global_copyright', 'e'); ?>
</div>
</div>

</body>
</html>
