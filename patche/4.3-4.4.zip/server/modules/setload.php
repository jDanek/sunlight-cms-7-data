<?php
$settings=@mysql_query("SELECT * FROM `".tabprefix."-settings`");

while($item=@mysql_fetch_array($settings)){
$variable=$item['variable'];
$value=$item['value'];
eval('$st_'."$variable='$value';");
}

/*zpracovani hodnot*/

  /*artorder*/
  if($st_artorder==1){$st_artorder="date";}
  else{$st_artorder="id";}
  
  /*futureart*/
  if($st_futureart==0){
  $st_futureart=" AND date<=".time();
  $st_futureart2=" WHERE date<=".time();
  }
  else{
  $st_futureart="";
  $st_futureart2="";
  }
  
  /*invismain*/
  if($st_invismain==0){$st_invismain=" WHERE visible=1";}
  else{$st_invismain="";}

/*definovani globalnich*/
define('langfile', $st_langfile);
define('artorder', $st_artorder);
define('artread', $st_artread);
define('artrealname', $st_artrealname);
define('futureart', $st_futureart);
define('futureart2', $st_futureart2);
define('comment', $st_comment);
define('postwait', $st_postwait);
/*template a rewrite jsou v connectu*/
?>
