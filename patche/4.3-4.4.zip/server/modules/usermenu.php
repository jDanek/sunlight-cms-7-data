<?php
if($u_spacer==""){$u_spacer="&nbsp;|&nbsp;";}
if($u_hideusername==true){$u_username="";}else{$u_username="[$login_name]";}

if($login_indicator==1){
/*menu prihlaseneho*/
echo "
<a href='modules/logout.php'>$u_prefix".lang('usermenu_logout', 'r')." $u_username</a>$u_spacer
<a href='modules/settings.php'>$u_prefix".lang('usermenu_settings', 'r')."</a>$u_spacer
<a href='modules/viewprofile.php?id=$login_name'>$u_prefix".lang('usermenu_viewprofile', 'r')."</a>$u_spacer
<a href='modules/viewcomments.php'>$u_prefix".lang('usermenu_lastcomments', 'r')."</a>
";
}
else{
/*menu odhlaseneho*/
if($st_registration==1){$u_reglink="$u_spacer<a href='modules/register.php'>$u_prefix".lang('usermenu_register', 'r')."</a>";}else{$u_reglink="";}
echo "
<a href='modules/login.php'>$u_prefix".lang('usermenu_login', 'r')."</a>
$u_reglink
";
}

/*menu pro vsechny*/
echo "
$u_spacer<a href='modules/userlist.php'>$u_prefix".lang('usermenu_userlist', 'r')."</a>
";

?>
