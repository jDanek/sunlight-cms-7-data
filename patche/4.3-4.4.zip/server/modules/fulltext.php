<?php
$root="../";
$moduletitle="fulltext_title";
include("../_connect.php");
include("moduleheader.php");

/*nacteni hledej*/
$hledej=$_GET['hledej'];
$hledej=strtr($hledej, $trans);
?>

<body>

<div class="board">
<div class="board-padding">

<a href="../">&lt; <?php lang('global_backtomain', 'e'); ?></a><br><br>
<h1><?php lang('fulltext_title', 'e'); ?></h1>
<p><?php lang('fulltext_p', 'e'); ?></p>
<hr size="1" color="#b2b2b2">

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get" name="form" onsubmit="if(document.form.hledej.value==''){alert('<?php lang('global_somethingwrong', 'e'); ?>'); return false;}">
<input type="text" name="hledej" size="40" maxlength="256" value="<?php echo $hledej; ?>">
<input type="submit" value="<?php lang('fulltext_find', 'e'); ?>"><br>
</form>

<?php
if($hledej!=""){

/*----------ZPRACOVANI VSTUPNICH PARAMETRU HLEDANI----------*/

  /*kontrola*/
  $continue=false;
  if(strlen($hledej)<3){echo "<h2>".lang('fulltext_shortinput', 'r')."</h2>";}
  else{if(strlen($hledej)>128){echo "<h2>".lang('fulltext_longinput', 'r')."</h2>";}
  else{$pokracovat=true;}
  }

if($pokracovat==true){


$hledej=addslashes($hledej);
$hledej=substr($hledej, 0, 256);
$hledej=strtr($hledej, $trans);

echo "<h2>".lang('fulltext_resulttitle', 'r').":</h2><br><div id='results'>\n";

/*----------ZPRACOVANI VSTUPNICH PARAMETRU STRANKOVANI----------*/
if(isset($_GET['s'])){
$startpage=$_GET['s'];
$startpage=intval($startpage);
if($startpage!=0){$startpage-=1;}
}
else{
$startpage=0;
}
$start=$startpage*$st_limit;

/*----------VYHLEDAVANI----------*/
$perioda=1;
$naslo=0;
while($perioda!=3){

switch($perioda){

case 1:
  /*sekce*/
  $tabulka=@mysql_query("SELECT id,code,home FROM `".tabprefix."-sections` ORDER BY id DESC");
  while($radek=@mysql_fetch_array($tabulka)){
  $radek['perex']=textpart($radek['code']);
  $home=$radek['home'];
  $anchor=@mysql_query("SELECT anchor FROM `".tabprefix."-menu` WHERE id=$home");
  $anchor=@mysql_fetch_array($anchor);
  $anchor=$anchor['anchor'];
  $anchor4url=anchor($anchor);
  $fulltext=strpos(strtolower($radek['code']), strtolower($hledej));
  $fulltext2=strpos(strtolower($anchor), strtolower($hledej));
    if($fulltext!==false or $fulltext2!==false){
    $naslo++;
      if($naslo>$start and $naslo<=$start+$st_limit){

      /*rewrite*/
      if($st_rewrite==1){$linkhref="../$st_secprefix-$anchor4url-".$radek['home'].".html";}
      else{$linkhref="../index.php?str=".$radek['home']."&tp=1";}

      echo "<a href='$linkhref'><b>".$anchor."</b></a><div>".$radek['perex']."</div><hr size='1' color='$st_linecolor'>\n";
      }
    }
  }
break;

case 2:
  /*clanky*/
  $tabulka=@mysql_query("SELECT id,title,perex,code FROM `".tabprefix."-articles`$st_futureart2 ORDER BY $st_artorder DESC");
  while($radek=@mysql_fetch_array($tabulka)){
  $radek['code']=strip_tags($radek['code']);
  $radek['perex']=textpart($radek['perex']);
  $anchor4url=anchor($radek['title']);
  $fulltext=strpos(strtolower($radek['code']), strtolower($hledej));
  $fulltext2=strpos(strtolower($radek['title']), strtolower($hledej));
  $fulltext3=strpos(strtolower($radek['perex']), strtolower($hledej));
    if($fulltext!==false or $fulltext2!==false or $fulltext3!==false){
    $naslo++;
      if($naslo>$start and $naslo<=$start+$st_limit){

      /*rewrite*/
      if($st_rewrite==1){$linkhref="../$st_artprefix-$anchor4url-".$radek['id'].".html";}
      else{$linkhref="../index.php?art=".$radek['id'];}

      echo "<a href='$linkhref'><b>".$radek['title']."</b></a><div>".$radek['perex']."</div><hr size='1' color='$st_linecolor'>\n";
      }
    }
  }
break;

}

$perioda++;
}

  /*hlaska o nenalezeni*/
  if($naslo==0){
  lang('fulltext_notfound', 'e');
  }

/*----------VYPIS STRAN----------*/
if($naslo!=0){

  $pocetstran=$naslo;
  $pocetstran=$pocetstran/$st_limit;
  $pocetstran=ceil($pocetstran);

  if($startpage>=0 and $startpage<=$pocetstran-1){

  if($startpage>9){$strana=$startpage-5;}
  else{$strana=0;}
  $odkazu=0;
  $back=$startpage-10;
  $forward=$startpage+10;
  echo "<div class='strany'><b>".lang('global_page', 'r')."</b>: ";
  if($startpage>=10){echo "<a href='fulltext.php?hledej=$hledej&s=$back'>&lt;</a> ";}

  while($strana<$pocetstran and $odkazu<=$st_maxpages){
  $odkazu++;
  $stranaanchor=$strana+1;
  if($strana==$startpage){echo "<a href='fulltext.php?hledej=$hledej&s=$stranaanchor' class='active'>$stranaanchor</a> ";}
  else{echo "<a href='fulltext.php?hledej=$hledej&s=$stranaanchor'>$stranaanchor</a> ";}
  $strana++;
  }

  if($startpage<=$pocetstran-10){echo "<a href='fulltext.php?hledej=$hledej&s=$forward'>&gt;</a> ";}
  echo "</div>";

  }
  else{
  lang('global_wrongpage', 'e');
  }

}

echo "</div>";


}


}
?>

</div>
</div>

</body>
</html>
