<?php
session_start();
$root="../";
$moduletitle="vote_title";
include("../_connect.php");
include("moduleheader.php");

/*nacteni parametru*/
$a=$_GET['a'];
$a=intval($_GET['a']);

$vid=$_GET['vid'];
$vid=intval($vid);
$vdata=@mysql_query("SELECT question,answers,votes FROM `".tabprefix."-votes` WHERE id=$vid");
$vdata=@mysql_fetch_array($vdata);

  $continue=false;
  if($vdata['question']!=""){
  $answers=explode("#", $vdata['answers']);
    if($a>=0 and $a<=count($answers)-1){
    $votes=explode("#", $vdata['votes']);
    $votes[$a]++;
    $votes=implode("#", $votes);
    $continue=true;
    }
  }
?>

<body>

<div class="board" style="width:275px;">
<div class="board-padding">
<center>

<h1><?php echo lang('vote_title', 'r'); ?></h1>
<?php
if($continue==true){

$v_log=explode("|", $_SESSION[systemuid.'log_vote']);
$v_lognum=0;
$v_logfound=false;
while($v_lognum<=count($v_log)){
$v_logitem=$v_log[$v_lognum];
if($v_logitem==$vid){$v_logfound=true; break;}
$v_lognum++;
}

  /*vlozeni do logu a pripocteni pocitadla*/
  if($v_logfound==false){
  $_SESSION[systemuid.'log_vote'].="|$vid";
  @mysql_query("UPDATE `".tabprefix."-votes` SET votes='$votes' WHERE id=$vid");
  lang('global_rate_accepted', 'e');
  }
  else{
  lang('global_rate_denied', 'e');
  }


}
else{
lang('global_invalidinput', 'e');
}
?>

</center>
</div>
</div>

</body>
</html>
