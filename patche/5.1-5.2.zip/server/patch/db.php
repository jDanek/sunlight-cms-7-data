<?php

/*sql dotazy*/
@mysql_query("ALTER TABLE `".tabprefix."-users` CHANGE `note` `note` TEXT CHARACTER SET cp1250 COLLATE cp1250_general_ci NOT NULL;");
@mysql_query("INSERT INTO `".tabprefix."-settings` (`variable`, `value`) VALUES ('redadmreaders', '0');");
@mysql_query("INSERT INTO `".tabprefix."-settings` (`variable`, `value`) VALUES ('userlist', '1');");
@mysql_query("INSERT INTO `".tabprefix."-settings` (`variable`, `value`) VALUES ('adminmassmail', '0');");
@mysql_query("DELETE FROM `".tabprefix."-settings` WHERE variable='wysiwyg';");
@mysql_query("INSERT INTO `".tabprefix."-settings` (`variable` ,`value`) VALUES ('editor', '0');");
@mysql_query("INSERT INTO `".tabprefix."-settings` (variable,value) VALUES ('tpart', '256');");
@mysql_query("INSERT INTO `".tabprefix."-settings` (`variable` ,`value`) VALUES ('arthcm', '1');");

?>
