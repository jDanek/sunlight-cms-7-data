<?php

$sbox_name=@mysql_query("SELECT name FROM `".tabprefix."-sboxes` WHERE id=$id");
$sbox_name=@mysql_fetch_array($sbox_name);
$sbox_name=$sbox_name['name'];
if($sbox_name!="" and count($mparam)==2){


  if(!defined("sboxshown_$id")){
  define("sboxshown_$id", true);


    /*pridani prispevku*/
    if(isset($_POST['sbox_text'])){
    if($_POST['sbox_home']==$id){
    if($_SESSION[systemuid.'log_posttime']<time()-postwait){

      $trans=array("<" => "&lt;", ">" => "&gt;", "&" => "&amp;", "\"" => "&quot;");
      $text=$_POST['sbox_text'];
      $text=strtr($text, $trans);
      $text=substr($text, 0, 255);
      $name=$_POST['sbox_name'];
      $name=strtr($name, $trans);
      $name=substr($name, 0, 20);
      if(login_indicator!=1){$codecheck=$_POST['sbox_codecheck']; $codecheckr=code_decode($_POST['sbox_codecheckr']);}
      else{$codecheckr=-1; $codecheck=-1; $name=" ";}

      if($text!="" and $name!="" and $codecheck==$codecheckr){

        if(login_indicator==1){$name=""; $author=login_id;}
        else{$author=-1;}

        $date=time();
        $newid=@mysql_query("SELECT id FROM `".tabprefix."-sboxes-posts` ORDER BY id DESC LIMIT 1");
        $newid=@mysql_fetch_array($newid);
        $newid=$newid['id'];
        $newid++;
        $home=$id;
        $ip=$_SERVER['REMOTE_ADDR'];
        @mysql_query("INSERT INTO `".tabprefix."-sboxes-posts` (id,home,author,name,date,text,ip) VALUES ($newid,$home,$author,'$name',$date,'$text','$ip')");
        $_SESSION[systemuid.'log_posttime']=time();

      }
      else{$msg=lang('global_msg_badinput', 'r');}

    }
    else{$msg=str_replace("*postwait*", postwait, lang('global_msg_timelimit', 'r'));}
    include(root."modules/msg.php");
    }
    }

    /*nacteni prispevku*/
    $posts=@mysql_query("SELECT * FROM `".tabprefix."-sboxes-posts` WHERE home=$id ORDER BY id DESC");
    $postscode="";
    $highlight="1";

    $smajlici=array(
    "*01*"=>"<img src='".root."modules/templates/".template."/pics/smileys/01.gif' alt=':D' />",
    "*02*"=>"<img src='".root."modules/templates/".template."/pics/smileys/02.gif' alt=':P' />",
    "*03*"=>"<img src='".root."modules/templates/".template."/pics/smileys/03.gif' alt='8)' />",
    "*04*"=>"<img src='".root."modules/templates/".template."/pics/smileys/04.gif' alt=';)' />",
    "*05*"=>"<img src='".root."modules/templates/".template."/pics/smileys/05.gif' alt=':)' />",
    "*06*"=>"<img src='".root."modules/templates/".template."/pics/smileys/06.gif' alt=':S' />",
    "*07*"=>"<img src='".root."modules/templates/".template."/pics/smileys/07.gif' alt=':|' />",
    "*08*"=>"<img src='".root."modules/templates/".template."/pics/smileys/08.gif' alt=':(' />"
    );

    while($post=@mysql_fetch_array($posts)){

      /*nacteni dat autora*/
      $userdata=@mysql_query("SELECT name,rights FROM `".tabprefix."-users` WHERE id=".$post['author']);
      $userdata=@mysql_fetch_array($userdata);
      if($userdata['rights']==""){$userdata['rights']=0;}
      if(postaccess_allow($post['author'], $userdata['rights'], $post['date'])){$postadmin=" <a href='".modrewrite("sboxdel", false, true)."pid=".$post['id']."' onclick='return ask();' title='".lang('global_delete', 'r')."'>[x]</a>";}else{$postadmin="";}
      $itemdate=formatdate($post['date']);

        /*nastaveni hvezdy*/
        switch($userdata['rights']){
        case 1: $star="c"; break;
        case 2: if($post['author']!=0){$star="b";}else{$star="a";} break;
        default: $star="";
        }
        if($star!=""){$star="<img src='".root."modules/templates/".template."/pics/stars/$star.gif' class='star' alt='$star' /> ";}


      /*vyplivnuti radku*/
      $post['text']=strtr($post['text'], $smajlici);
      if($highlight==true){$class="2";}else{$class="1";}
      if($post['author']=="-1"){
      $postscode.="<div class='sbox-post$class'><b title='".lang('global_guest', 'r')."'>".$post['name']."</b>$postadmin: <span title='".formatdate($post['date'])."'>".$post['text']."</span></div>\n";
      }
      else{
      $postscode.="<div class='sbox-post$class'>".$star."<a href='".modrewrite("viewprofile", false, true)."id=".$userdata['name']."' title='".lang('global_viewprofile', 'r')."'>".$userdata['name']."</a>$postadmin: ".$post['text']."</div>\n";
      }

    $highlight=!$highlight;
    }

    /*priprava jmena*/
    if(login_indicator==1){
    $namecontent="<input class='txt' type='text' name='sbox_name' value='".login_name."' disabled='disabled' />";
    $codecheck="-1";
    $codecheck_code="";
    $codecheck_img="";
    }
    else{
    $namecontent="<input class='txt' type='text' maxlength='20' name='sbox_name' />";
    $codecheck=code_generate(4);
    $codecheck_code="<tr><td>".lang('global_codecheck', 'r')."</td><td><input class='txt' type='text' maxlength='8' name='sbox_codecheck' /></td></tr>";
    $codecheck_img="&nbsp;<img src='".root."modules/kod2.php?n=$codecheck' title='".lang('global_codecheckhelp', 'r')."' class='codecheck2' alt='".lang('global_codecheckhelp' ,'r')."' />";
    }

    /*vypis prispveku*/
    $mtmp.=
    textarea_smileys("sboxform$id", "sbox_text", "sbox".$id."_s")."
    <div class='sbox'>
    <div class='sbox-add'>
    <b>".lang('global_addpost', 'r')."</b>
    <div class='hr'><hr /></div>

    <form action='' method='post' name='sboxform$id'>
    <input type='hidden' name='sbox_home' value='$id' />
    <input type='hidden' name='sbox_codecheckr' value='$codecheck' />
    <table>
    <tr><td>".lang('global_yourname', 'r')."</td><td>$namecontent</td></tr>
    <tr><td>".lang('global_text', 'r')."</td><td><input class='txt' type='text' maxlength='255' name='sbox_text' /></td></tr>
    $codecheck_code
    <tr><td></td><td><input class='submit' type='submit' value='".lang('global_send', 'r')."' />$codecheck_img</td></tr>
    </table>

    <div class='hr'><hr /></div>
    <a href=\"javascript:sbox".$id."_s('01');\"><img src=\"".root."modules/templates/".template."/pics/smileys/01.gif\" alt=\"01\" /></a>
    <a href=\"javascript:sbox".$id."_s('02');\"><img src=\"".root."modules/templates/".template."/pics/smileys/02.gif\" alt=\"02\" /></a>
    <a href=\"javascript:sbox".$id."_s('03');\"><img src=\"".root."modules/templates/".template."/pics/smileys/03.gif\" alt=\"03\" /></a>
    <a href=\"javascript:sbox".$id."_s('04');\"><img src=\"".root."modules/templates/".template."/pics/smileys/04.gif\" alt=\"04\" /></a>
    <a href=\"javascript:sbox".$id."_s('05');\"><img src=\"".root."modules/templates/".template."/pics/smileys/05.gif\" alt=\"05\" /></a>
    <a href=\"javascript:sbox".$id."_s('06');\"><img src=\"".root."modules/templates/".template."/pics/smileys/06.gif\" alt=\"06\" /></a>
    <a href=\"javascript:sbox".$id."_s('07');\"><img src=\"".root."modules/templates/".template."/pics/smileys/07.gif\" alt=\"07\" /></a>
    <a href=\"javascript:sbox".$id."_s('08');\"><img src=\"".root."modules/templates/".template."/pics/smileys/08.gif\" alt=\"08\" /></a>

    </form>
    </div>
    <div class='sbox-posts' style='height:".$boxheight."px;'>
    $postscode
    </div>
    </div>
    ";


  }
  else{
  $mtmp.=lang('hcm_sbox_duplicated', 'r');
  }

}

?>
