<?php
$root="../../";
include("../../_connect.php");

/*odeslani*/
if(isset($_POST['text'])){

  /*nacteni promennych*/
  $receiver=$_POST['receiver'];
  $receiver=strtr($receiver, "#", "@");
  $sender=$_POST['sender'];
  $sender=trim($sender);
  $sender=substr($sender, 0, 128);
  $ip=$_SERVER['REMOTE_ADDR'];
  $sendtime=date("j.n. Y H:i");
  $subject=$_POST['subject'];
  $subject=trim($subject);
  $subject=strtr($subject, $trans);
  $text=$_POST['text'];
  $text=substr($text, 0, 102400);
  $text=trim($text);
  $text=lang('hcm_mailform_text', 'r')."\n-------------------------------\n".lang('global_subject', 'r').": $subject\n".lang('global_sender', 'r').": $sender\n".lang('global_sendtime', 'r').": $sendtime\n".lang('global_ip', 'r').": $ip\n".lang('global_adress', 'r').": $st_serverurl\n-------------------------------\n\n$text";
  $codecheck=$_POST['codecheck'];
  $codecheckr=$_POST['codecheckr'];
  $codecheckr=code_decode($codecheckr);

  if($text!="" and validate_email($sender) and $subject!="" and $codecheck==$codecheckr){
  @mail($receiver, $subject, $text, "Content-Type:text/plain;charset=win-1250\nReply-To:$sender");
  $msg=lang('hcm_mailform_sent', 'r');
  }
  else{
  $msg=lang('global_msg_someempty', 'r');
  }

}
else{
exit;
}

$moduletitle="hcm_mailform_title";
include("../moduleheader.php");
?>

<body>

<div class="board">
<div class="board-padding">

<a href="<?php referer(); ?>">&lt; <?php lang('global_goback', 'e'); ?></a><br /><br />
<b><?php echo $msg; ?></b>

</div>
</div>

</body>
</html>
