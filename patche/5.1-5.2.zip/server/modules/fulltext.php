<?php

/*nacteni hledej*/
$hledej=$_GET['hledej'];
$hledej=trim($hledej, "%_-. ");
$hledej=strtr($hledej, $trans);

?>


<h1><?php lang('fulltext_title', 'e'); ?></h1>
<p><?php lang('fulltext_p', 'e'); ?></p>

<div class="hr"><hr /></div>
<form action="<?php echo modrewrite("fulltext", true); ?>" method="get" name="form" onsubmit="if(document.form.hledej.value==''){alert('<?php lang('global_somethingwrong', 'e'); ?>'); return false;}">
<?php echo modrewrite_getinputs("fulltext"); ?>
<input type="text" name="hledej" size="40" maxlength="256" value="<?php echo $hledej; ?>" />
<input type="submit" value="<?php lang('global_find', 'e'); ?>" /><br />
</form>

<?php
if($hledej!=""){

/*----------ZPRACOVANI VSTUPNICH PARAMETRU HLEDANI----------*/

  /*kontrola*/
  $pokracovat=true;
  if(strlen($hledej)<3){echo "<h3>".lang('fulltext_shortinput', 'r')."</h3>"; $pokracovat=false;}
  if(strlen($hledej)>128){echo "<h3>".lang('fulltext_longinput', 'r')."</h3>"; $pokracovat=false;}

if($pokracovat==true){


$hledej=addslashes($hledej);
$hledej=substr($hledej, 0, 256);
$hledej=strtr($hledej, $trans);

echo "<h3>".lang('fulltext_resulttitle', 'r').":</h3><br />\n";

/*----------ZPRACOVANI VSTUPNICH PARAMETRU STRANKOVANI----------*/
if(isset($_GET['s'])){
$startpage=$_GET['s'];
$startpage=intval($startpage);
if($startpage!=0){$startpage-=1;}
}
else{
$startpage=0;
}
$start=$startpage*$st_limit;

/*----------VYHLEDAVANI----------*/
$perioda=1;
$naslo=0;
while($perioda!=3){

switch($perioda){

case 1:
  /*nacteni dat sekce*/
  $tabulka=@mysql_query("SELECT id,code,home FROM `".tabprefix."-sections` WHERE code LIKE '%$hledej%' ORDER BY id DESC");
  
  /*vypis*/
  while($radek=@mysql_fetch_array($tabulka)){

    $radek['code']=textpart(strip_tags(content_editor_process(striphcm($radek['code']))));
    $anchor=@mysql_query("SELECT anchor FROM `".tabprefix."-menu` WHERE id=".$radek['home']);
    $anchor=@mysql_fetch_array($anchor);
    $anchor=$anchor['anchor'];

    $naslo++;
    if($naslo>$start and $naslo<=$start+$st_limit){
    echo "<a href='".secrewrite($radek['home'], $anchor)."' class='title'>".$anchor."</a><p class='textpart'>".$radek['code']."</p>\n";
    }
  
  }
break;

case 2:
  /*nacteni dat clanku*/
  $tabulka=@mysql_query("SELECT id,title,perex,code FROM `".tabprefix."-articles` WHERE code LIKE '%$hledej%' OR title LIKE '%$hledej%' OR perex LIKE '%$hledej%'$st_futureart ORDER BY $st_artorder DESC");

  /*vypis*/
  while($radek=@mysql_fetch_array($tabulka)){
  
    $radek['perex']=textpart(striphcm($radek['perex']));
    $naslo++;
    if($naslo>$start and $naslo<=$start+$st_limit){
    echo "<a href='".artrewrite($radek['id'], $radek['title'])."' class='title'>".$radek['title']."</a><p class='textpart'>".$radek['perex']."</p>\n";
    }

  }
break;

}

$perioda++;
}

  /*hlaska o nenalezeni*/
  if($naslo==0){
  lang('fulltext_notfound', 'e');
  }

/*----------VYPIS STRAN----------*/
if($naslo!=0){

  $pocetstran=$naslo;
  $pocetstran=$pocetstran/$st_limit;
  $pocetstran=ceil($pocetstran);

  if($startpage>=0 and $startpage<=$pocetstran-1){

  if($startpage>9){$strana=$startpage-5;}
  else{$strana=0;}
  $odkazu=0;
  $back=$startpage-10;
  $forward=$startpage+10;
  echo "<div class='strany'><b>".lang('global_page', 'r')."</b>: ";
  if($startpage>=10){echo "<a href='".modrewrite("fulltext", false, true)."hledej=$hledej&amp;s=$back'>&lt;</a> ";}

  while($strana<$pocetstran and $odkazu<=$st_maxpages){
  $odkazu++;
  $stranaanchor=$strana+1;
  if($strana==$startpage){echo "<a href='".modrewrite("fulltext", false, true)."hledej=$hledej&amp;s=$stranaanchor' class='active'>$stranaanchor</a> ";}
  else{echo "<a href='".modrewrite("fulltext", false, true)."hledej=$hledej&amp;s=$stranaanchor'>$stranaanchor</a> ";}
  $strana++;
  }

  if($startpage<=$pocetstran-10){echo "<a href='".modrewrite("fulltext", false, true)."hledej=$hledej&amp;s=$forward'>&gt;</a> ";}
  echo "</div>";

  }
  else{
  lang('global_wrongpage', 'e');
  }

}


}


}
?>
