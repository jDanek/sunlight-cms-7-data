<?php
/*----PRIDANI PRISPEVKU----*/
if(isset($_POST['text'])){

if($_SESSION[systemuid.'log_posttime']<time()-$st_postwait){

  /*nacteni promennych*/
  $text=$_POST['text'];
  $text=substr($text, 0, 2048);
  $text=strtr($text, $trans);
  $text=trim($text);
  $date=time();
  $ip=$_SERVER['REMOTE_ADDR'];

  if($login_indicator==1){
  $author=$login_id;
  }
  else{
  $name=$_POST['name'];
  $name=anchor($name, false);
  $name=substr($name, 0, 20);
  $name=strtr($name, $trans);
  $codecheck=$_POST['codecheck'];
  $codecheckr=$_POST['codecheckr'];
  $codecheckr=code_decode($codecheckr);
  }
  
  /*kontrola a vlozeni*/
  if($text!="" and (($name!="" and $st_gbguests==1) or $login_indicator==1) and ($codecheck==$codecheckr or $login_indicator==1)){
    
    /*vypocet noveho id*/
    $newid=@mysql_query("SELECT id FROM `".tabprefix."-books` ORDER BY id DESC LIMIT 1");
    $newid=@mysql_fetch_array($newid);
    $newid=$newid['id'];
    $newid++;
  
    /*rozliseni a vlozeni*/
    if($login_indicator==1){
    @mysql_query("INSERT INTO `".tabprefix."-books` (id,home,author,name,date,text,ip) VALUES ($newid, $c_str, $login_id, '', '$date', '$text', '$ip')");
    }
    else{
    @mysql_query("INSERT INTO `".tabprefix."-books` (id,home,author,name,date,text,ip) VALUES ($newid, $c_str, -1, '$name', $date, '$text', '$ip')");
    }
    $_SESSION[systemuid.'log_posttime']=time();
    
  
  }
  else{
  $msg=lang('global_msg_badinput', 'r');
  }
  
}
else{
$msg=str_replace("*postwait*", $st_postwait, lang('global_msg_timelimit', 'r'));
}

}


/*----FORUMULAR-----*/
echo "<h1>$kniha</h1>\n<div class='hr'><hr /></div>";

include("modules/msg.php");

if($st_gbguests==1 or $login_indicator==1){

if($st_bbcode==1){$bbcode_help="<a href='".modrewrite("bbcodehelp")."' class='bbcodehelp'>[?]</a>";}else{$bbcode_help="";}

echo textarea_limit(2048, "bookform");

  /*rozpoznani prihlaseni*/
  if($login_indicator==1){
  $namecontent="<input type='text' name='name' class='ifield' value='$login_name' disabled='disabled' />";
  $checkcontent="";
  $codecheck="-1";
  $codecheckimg="";
  $jscodecheck="";
  }
  else{
  $namecontent="<input type='text' maxlength='20' name='name' class='ifield' />";
  $codecheck=code_generate(4);
  $jscodecheck=" || document.form.codecheck.value==''";
  $codecheckimg="&nbsp;<img src='modules/kod.php?n=".$codecheck."' alt='".lang('global_codecheckhelp', 'r')."' title='".lang('global_codecheckhelp', 'r')."' class='codecheck' />";
  $checkcontent="
  <tr>
  <td>".lang('global_codecheck', 'r')."&nbsp;</td>
  <td><input type='text' maxlength='8' name='codecheck' class='ifield' /></td>
  </tr>
  ";
  }

echo
textarea_smileys("bookform", "text")."
<form action='".bookrewrite($c_str, $kniha, 1)."' method='post' name='bookform' onsubmit=\"if(document.bookform.name.value=='' || document.bookform.text.value==''$jscodecheck){alert('".lang('global_somethingwrong', 'r')."'); return false;}\">
<input type='hidden' name='codecheckr' value='$codecheck' />

<table>

<tr>
<td>".lang('global_yourname', 'r')."&nbsp;</td>
<td>$namecontent</td>
</tr>

".$checkcontent."

<tr valign='top'>
<td>".lang('global_text', 'r')."</td>
<td><textarea name='text' class='itext' id='itext' rows='6' cols='45'></textarea></td>
</tr>

<tr>
<td></td>
<td>

<input type='submit' value='".lang('global_send', 'r')." &gt;' />
<input type='reset' value='".lang('global_empty', 'r')."' />

$bbcode_help

<a href=\"javascript:s('01');\"><img src=\"modules/templates/$st_template/pics/smileys/01.gif\" alt=\"01\" /></a>
<a href=\"javascript:s('02');\"><img src=\"modules/templates/$st_template/pics/smileys/02.gif\" alt=\"02\" /></a>
<a href=\"javascript:s('03');\"><img src=\"modules/templates/$st_template/pics/smileys/03.gif\" alt=\"03\" /></a>
<a href=\"javascript:s('04');\"><img src=\"modules/templates/$st_template/pics/smileys/04.gif\" alt=\"04\" /></a>
<a href=\"javascript:s('05');\"><img src=\"modules/templates/$st_template/pics/smileys/05.gif\" alt=\"05\" /></a>
<a href=\"javascript:s('06');\"><img src=\"modules/templates/$st_template/pics/smileys/06.gif\" alt=\"06\" /></a>
<a href=\"javascript:s('07');\"><img src=\"modules/templates/$st_template/pics/smileys/07.gif\" alt=\"07\" /></a>
<a href=\"javascript:s('08');\"><img src=\"modules/templates/$st_template/pics/smileys/08.gif\" alt=\"08\" /></a>

$codecheckimg
</td>
</tr>

</table>

</form>
";

}
else{
echo "<p>".lang('book_denied', 'r')."</p>";
$refer=1;
include("modules/loginform.php");
}

/*----VYPIS PRISPEVKU----*/

/*strankovani*/
if(isset($_GET['s'])){
$startpage=$_GET['s'];
$startpage=intval($startpage);
if($startpage!=0){$startpage-=1;}
}
else{
$startpage=0;
}

/*seznam stran*/
$strany=@mysql_query("SELECT id FROM `".tabprefix."-books` WHERE home=$c_str");
$pocetstran=0;

  /*spocitani stran*/
  while($strana=@mysql_fetch_array($strany)){$pocetstran++;}
  if($pocetstran==0){$pocetstran=1;}
  $pocetstran=$pocetstran/$st_limit;
  $pocetstran=ceil($pocetstran);

/*vypis stran*/
if($startpage>9){$strana=$startpage-5;}
else{$strana=0;}
$odkazu=0;
$back=$startpage-10;
$forward=$startpage+10;
$strankovani="<div class='strany'>".lang('global_page', 'r').": ";

if($startpage>=10){$strankovani.="<a href='".bookrewrite($c_str, $kniha, $back)."'>&lt;</a> ";}

while($strana<$pocetstran and $odkazu<=$st_maxpages){
$odkazu++;
$stranaanchor=$strana+1;

if($strana==$startpage){$strankovani.="<a href='".bookrewrite($c_str, $kniha, $stranaanchor)."' class='active'>$stranaanchor</a> ";}
else{$strankovani.="<a href='".bookrewrite($c_str, $kniha, $stranaanchor)."'>$stranaanchor</a> ";}
$strana++;
}

if($startpage<=$pocetstran-10){$strankovani.="<a href='".bookrewrite($c_str, $kniha, $forward)."'>&gt;</a> ";}
$strankovani.="</div>\n";

if($st_pagingmode==1 or $st_pagingmode==3){echo $strankovani;}

echo "<div id='posts'><div class='hr'><hr /></div>";

/*vypis prispevku*/
$start=$startpage*$st_limit;
$prispevku=0;
$bookcontent=@mysql_query("SELECT * FROM `".tabprefix."-books` WHERE home=$c_str ORDER BY id DESC LIMIT $start,$st_limit");
while($prispevek=@mysql_fetch_array($bookcontent)){
  $prispevku++;
  
  /*aplikace smajliku*/
  $prispevek['text']=strtr($prispevek['text'], $smajlici);
  
  /*nacteni dat autora*/
  $userdata=@mysql_query("SELECT name,rights FROM `".tabprefix."-users` WHERE id=".$prispevek['author']);
  $userdata=@mysql_fetch_array($userdata);
  if($userdata['rights']==""){$userdata['rights']=0;}
  if(postaccess_allow($prispevek['author'], $userdata['rights'], $prispevek['date'])){$postadmin=" | <a href='".modrewrite("bookdel", false, true)."bid=".$prispevek['id']."' onclick='return ask();' title='".lang('global_delete', 'r')."'>x</a> | <a href='".modrewrite("bookedit", false, true)."bid=".$prispevek['id']."' title='".lang('global_edit', 'r')."'>e</a>";}else{$postadmin="";}
  
  $itemdate=formatdate($prispevek['date']);
  
    /*nastaveni hvezdy*/
    switch($userdata['rights']){
    case 1: $star="c"; break;
    case 2: if($prispevek['author']!=0){$star="b";}else{$star="a";} break;
    default: $star="";
    }
    if($star!=""){$star="<img src='modules/templates/$st_template/pics/stars/$star.gif' class='star' alt='$star' /> ";}

  /*rozliseni a vypis prispevku*/
  if($st_bbcode==1){$prispevek['text']=parsebbcode($prispevek['text']);}
  $prispevek['text']=nl2br($prispevek['text']);
  
  if($prispevek['author']=="-1"){
  echo "<b title='".lang('global_guest', 'r')."'>".$prispevek['name']."</b> <span class='postadmin'>(<span title='".$prispevek['ip']."'>".$itemdate."</span>$postadmin)</span><p>".$prispevek['text']."</p><div class='hr'><hr /></div>\n";
  }
  else{
  echo $star."<a href='".modrewrite("viewprofile", false, true)."id=".$userdata['name']."' title='".lang('global_viewprofile', 'r')."'>".$userdata['name']."</a> <span class='postadmin'>(<span title='".$prispevek['ip']."'>".$itemdate."</span>$postadmin)</span><p>".$prispevek['text']."</p><div class='hr'><hr /></div>\n";
  }

}

echo "</div>";

if(($st_pagingmode==2 or $st_pagingmode==3) and $prispevku!=0){echo $strankovani;}


  /*hlaska o zadnych prispevcich*/
  if($prispevku==0){
  if($startpage==0){lang('book_nokit', 'e');}
  else{lang('global_wrongpage', 'e');}
  }


?>
