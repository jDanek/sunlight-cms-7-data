<?php

/*nacteni bid*/
if(isset($_GET['bid'])){
$bid=$_GET['bid'];
$bid=intval($bid);
}
else{
$bid=-1;
}
$done=0;


/*kontrola loginu*/

  /*nacteni autora*/
  $b_data=@mysql_query("SELECT author,date FROM `".tabprefix."-books` WHERE id=$bid");
  $b_data=@mysql_fetch_array($b_data);
  
  $b_author=$b_data['author'];
  if($b_author!=-1){
  $b_author_rights=@mysql_query("SELECT rights FROM `".tabprefix."-users` WHERE id=$b_author");
  $b_author_rights=@mysql_fetch_array($b_author_rights);
  $b_author_rights=$b_author_rights['rights'];
  }
  else{
  $b_author_rights=0;
  }

  /*smazani z db*/
  if(postaccess_allow($b_author, $b_author_rights, $b_data['date'])){
  @mysql_query("DELETE FROM `".tabprefix."-books` WHERE id=$bid");
  $done=1;
  }



include("msg.php");
?>


<h1><?php lang('post_delete', 'e'); ?></h1>
<div class="hr"><hr /></div>

<?php
if($done!=1){
echo "<b>".lang('global_denied', 'r')."</b>";
}
else{
echo "<p>".lang('global_actiondone', 'r')."<br />&lt; <a href='".referer(true)."'>".lang('global_goback', 'r')."</a></p>";
}
?>
