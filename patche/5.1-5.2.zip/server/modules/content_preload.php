<?php

if($st_regonly==0 or ($st_regonly==1 and $login_indicator==1) or $_GET['str']=="login"){


  /*----------CLANEK----------*/
  if(isset($_GET['art'])){
    /*nacteni dat*/
    $a_art=$_GET['art'];
    $a_art=intval($a_art);
    $a_content=@mysql_query("SELECT * FROM `".tabprefix."-articles` WHERE id=$a_art");
    $a_content=@mysql_fetch_array($a_content);
    $a_comment=$a_content['comment'];

    /*modul*/
    if($a_comment=="" or ($a_content['date']>time() and !isset($_SESSION[systemuid.'login_aindicator']))){
      $content_title=lang('content_notfound_title', 'r'); $content_preload.="lang('content_notfound', 'e');";
    }
    else{
      $c_regonly=@mysql_query("SELECT regonly FROM `".tabprefix."-menu` WHERE id=".$a_content['home']);
      $c_regonly=@mysql_fetch_array($c_regonly);
      $c_regonly=$c_regonly['regonly'];
      if($c_regonly==0 or ($c_regonly==1 and $login_indicator==1)){$content_title=$a_content['title']; $content_preload.="include('modules/article.php');";}
      else{$content_title=lang('global_onlyreg_title', 'r'); $content_preload.="content_regonlyform();";}
    }
  }
  else{


  /*----------PARAMETRY NEBO UVODNI STRANA----------*/
  $continue=true;

  if($_GET['str']!="" and ($_GET['tp']==1 or $_GET['tp']==2 or $_GET['tp']==3 or $_GET['tp']==4)){
  $c_tp=$_GET['tp'];
  $c_tp=intval($c_tp);
  $c_str=$_GET['str'];
  if($c_tp!=4){$c_str=intval($c_str);}
  }
  else{include("modules/mainpage.php");}

  /*----------ROZLISENI OBSAHU A VYPISY----------*/
  if($continue==true){
  switch($c_tp){

  /*----------SEKCE----------*/
  case "1":
    /*nacteni dat*/
    $codecontent=@mysql_query("SELECT home,code,comment FROM `".tabprefix."-sections` WHERE home=$c_str");
    $codecontent=@mysql_fetch_array($codecontent);
    $c_comment=$codecontent['comment'];
    $c_home=$codecontent['home'];
    $c_title=@mysql_fetch_array(@mysql_query("SELECT anchor FROM `".tabprefix."-menu` WHERE id=".$c_home));
    

    /*modul*/
    if($codecontent['comment']!=""){
      $c_regonly=@mysql_query("SELECT regonly FROM `".tabprefix."-menu` WHERE id=$c_home");
      $c_regonly=@mysql_fetch_array($c_regonly);
      $c_regonly=$c_regonly['regonly'];
      if($c_regonly==0 or ($c_regonly==1 and $login_indicator==1)){$content_title=$c_title=$c_title['anchor']; $content_preload.="include('modules/section.php');";}
      else{$content_title=lang('global_onlyreg_title', 'r'); $content_preload.="content_regonlyform();";}
    }
    else{
      $content_title=lang('content_notfound_title', 'r'); $content_preload.="lang('content_notfound', 'e');";
    }
  break;


  /*----------KATEGORIE----------*/
  case "2":
    /*nacteni dat*/
    $kategorie=@mysql_query("SELECT anchor FROM `".tabprefix."-menu` WHERE id=$c_str AND type=2");
    $kategorie=@mysql_fetch_array($kategorie);
    $kategorie=$kategorie['anchor'];

    /*modul*/
    if($kategorie!=""){
      $c_regonly=@mysql_query("SELECT regonly FROM `".tabprefix."-menu` WHERE id=$c_str");
      $c_regonly=@mysql_fetch_array($c_regonly);
      $c_regonly=$c_regonly['regonly'];
      if($c_regonly==0 or ($c_regonly==1 and $login_indicator==1)){$content_title=$kategorie; $content_preload.="include('modules/category.php');";}
      else{$content_title=lang('global_onlyreg_title', 'r'); $content_preload.="content_regonlyform();";}
    }
    else{
      $content_title=lang('content_notfound_title', 'r'); $content_preload.="lang('content_notfound', 'e');";
    }
  break;


  /*----------KNIHA----------*/
  case "3":
    /*nacteni dat*/
    $kniha=@mysql_query("SELECT anchor FROM `".tabprefix."-menu` WHERE id=$c_str");
    $kniha=@mysql_fetch_array($kniha);
    $kniha=$kniha['anchor'];

    /*modul*/
    if($kniha!=""){
      $c_regonly=@mysql_query("SELECT regonly FROM `".tabprefix."-menu` WHERE id=$c_str");
      $c_regonly=@mysql_fetch_array($c_regonly);
      $c_regonly=$c_regonly['regonly'];
      if($c_regonly==0 or ($c_regonly==1 and $login_indicator==1)){$content_title=$kniha; $content_preload.="include('modules/book.php');";}
      else{$content_title=lang('global_onlyreg_title', 'r'); $content_preload.="content_regonlyform();";}
    }
    else{
      $content_title=lang('content_notfound_title', 'r'); $content_preload.="lang('content_notfound', 'e');";
    }
  break;


  /*----------MODUL----------*/
  case "4":
  
  switch($c_str){
  case "vote": $content_title=lang('vote_title', 'r'); $continue=true; break;
  case "articlerate": $content_title=lang('article_rating', 'r'); $continue=true; break;
  case "bookdel": $content_title=lang('post_delete', 'r'); $continue=true; break;
  case "sboxdel": $content_title=lang('post_delete', 'r'); $continue=true; break;
  case "bookedit": $content_title=lang('book_edit', 'r'); $continue=true; break;
  case "commentdel": $content_title=lang('comment_delete', 'r'); $continue=true; break;
  case "commentedit": $content_title=lang('comment_edit', 'r'); $continue=true; break;
  case "fulltext": $content_title=lang('fulltext_title', 'r'); $continue=true; break;
  case "login": $content_title=lang('global_login', 'r'); $continue=true; break;
  case "register": if($st_registration==1){$content_title=lang('register_title', 'r'); $continue=true;}else{$continue=false;} break;
  case "settings": if($login_indicator==1){$content_title=lang('settings_title', 'r'); $continue=true;}else{$continue=false;} break;
  case "userlist": if($st_userlist==1){$content_title=lang('userlist_title', 'r'); $continue=true;}else{$continue=false;} break;
  case "viewarticles": $content_title=lang('viewarticles_title', 'r'); $continue=true; break;
  case "viewcomments": $content_title=lang('comment_title2', 'r'); $continue=true; break;
  case "viewprofile": $content_title=lang('viewprofile_title', 'r'); $continue=true; break;
  case "bbcodehelp": $content_title=lang('bbcode_help_title', 'r'); $continue=true; break;
  case "lostpassword": if($st_lostpass==1){$content_title=lang('lostpassword_title', 'r'); $continue=true;}else{$continue=false;} break;
  case "gallery": $content_title=lang('hcm_gallery_title', 'r'); $continue=true; break;
  default: $continue=false;
  }

  $modul="modules/$c_str.php";
  if(file_exists($modul) and $continue==true){$content_preload.="include('$modul');";}
  else{$content_title=lang('content_notfound_title', 'r'); $content_preload.="lang('content_notfound', 'e');";}
  break;


  }
  }

  }

}
else{
$content_title=lang('global_onlyreg_title', 'r'); $content_preload.="content_regonlyform();";
}

?>
