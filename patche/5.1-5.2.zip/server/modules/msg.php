<?php
if(isset($msg)){
echo "
<script type='text/javascript'>
//<![CDATA[
alert('$msg');
//]]>
</script>
<noscript>
<br />
<span class='msg'>$msg</span>
<br /><br />
</noscript>";
}
?>
