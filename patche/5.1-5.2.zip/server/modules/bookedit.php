<?php

/*nacteni bid*/
if(isset($_GET['bid'])){
$bid=$_GET['bid'];
$bid=intval($bid);
}
else{
$bid=-1;
}
$done=0;

/*kontrola loginu*/

  /*nacteni autora*/
  $b_data=@mysql_query("SELECT author,date,text FROM `".tabprefix."-books` WHERE id=$bid");
  $b_data=@mysql_fetch_array($b_data);

  $b_author=$b_data['author'];
  if($b_author!=-1){
  $b_author_rights=@mysql_query("SELECT rights FROM `".tabprefix."-users` WHERE id=$b_author");
  $b_author_rights=@mysql_fetch_array($b_author_rights);
  $b_author_rights=$b_author_rights['rights'];
  }
  else{
  $b_author_rights=0;
  }

  /*ulozeni do db*/
  $allowed=postaccess_allow($b_author, $b_author_rights, $b_data['date']);
  if($allowed==true){

    if(isset($_POST['mod_text'])){

      /*nacteni promennych*/
      $text=$_POST['mod_text'];
      $text=substr($text, 0, 2048);
      $text=strtr($text, $trans);
      $text=trim($text);
      
      /*kontrola a ulozeni*/
      if($text!=""){
      @mysql_query("UPDATE `".tabprefix."-books` SET text='$text' WHERE id=$bid");
      $done=1;
      }
      else{
      $msg=lang('global_msg_badinput', 'r');
      $done=0;
      }
    
    }
    else{
    $done=0;
    }

  }


include("msg.php");

?>


<h1><?php lang('book_edit', 'e'); ?></h1>
<div class="hr"><hr /></div>

<?php
if($allowed!=true){
echo "<b>".lang('global_denied', 'r')."</b>";
}
else{

  /*----hlaska o provedeni nebo formular pro editaci----*/
  if($done==1){
  
  /*hotovo*/
  $home=@mysql_query("SELECT home FROM `".tabprefix."-books` WHERE id=$bid");
  $home=@mysql_fetch_array($home);
  $anchor=@mysql_query("SELECT anchor FROM `".tabprefix."-menu` WHERE id=".$home['home']);
  $anchor=@mysql_fetch_array($anchor);
  echo "<p>".lang('global_actiondone', 'r')."<br />&lt; <a href='".bookrewrite($home['home'], $anchor['anchor'], 1)."'>".lang('global_goback', 'r')."</a></p>";
  
  }
  else{

  /*formular*/


  echo
  textarea_limit(2048, "bookform").
  textarea_smileys("bookform", "mod_text")."
  <form action='".modrewrite("bookedit", false, true)."bid=$bid' method='post' name='bookform' onsubmit=\"if(document.bookform.text.value==''$jscodecheck){alert('".lang('global_somethingwrong', 'r')."'); return false;}\">
  <input type='hidden' name='mod_codecheckr' value='$codecheck' />

  <table>

  <tr valign='top'>
  <td>".lang('global_text', 'r')."&nbsp;</td>
  <td><textarea name='mod_text' class='itext' id='itext' rows='6' cols='45'>".$b_data['text']."</textarea></td>
  </tr>

  <tr>
  <td></td>
  <td>
  <input type='submit' value='".lang('global_save', 'r')." &gt;' />
  <input type='reset' value='".lang('global_reset', 'r')."' onclick=\"return ask();\" />
  &nbsp;
  <a href=\"javascript:s('01');\"><img src=\"modules/templates/$st_template/pics/smileys/01.gif\" alt=\"01\" /></a>
  <a href=\"javascript:s('02');\"><img src=\"modules/templates/$st_template/pics/smileys/02.gif\" alt=\"02\" /></a>
  <a href=\"javascript:s('03');\"><img src=\"modules/templates/$st_template/pics/smileys/03.gif\" alt=\"03\" /></a>
  <a href=\"javascript:s('04');\"><img src=\"modules/templates/$st_template/pics/smileys/04.gif\" alt=\"04\" /></a>
  <a href=\"javascript:s('05');\"><img src=\"modules/templates/$st_template/pics/smileys/05.gif\" alt=\"05\" /></a>
  <a href=\"javascript:s('06');\"><img src=\"modules/templates/$st_template/pics/smileys/06.gif\" alt=\"06\" /></a>
  <a href=\"javascript:s('07');\"><img src=\"modules/templates/$st_template/pics/smileys/07.gif\" alt=\"07\" /></a>
  <a href=\"javascript:s('08');\"><img src=\"modules/templates/$st_template/pics/smileys/08.gif\" alt=\"08\" /></a>

  $codecheckimg
  </td>
  </tr>

  </table>

  </form>

  ";

  }

}
?>
