<?php

/*nacteni r a id*/
$r=$_GET['r'];
$r=intval($r);

$id=$_GET['id'];
$id=intval($_GET['id']);
$adata=@mysql_query("SELECT title,rate_allow,rate_ipcache,home FROM `".tabprefix."-articles` WHERE id=$id");
$adata=@mysql_fetch_array($adata);
if($adata['rate_ipcache']!=""){$ipcache=explode("|", $adata['rate_ipcache']);}else{$ipcache=array();}
$ip=$_SERVER['REMOTE_ADDR'];

/*kontrola opravneni*/
$regonly=@mysql_query("SELECT regonly FROM `".tabprefix."-menu` WHERE id=".$adata['home']);
$regonly=@mysql_fetch_array($regonly);
$regonly=$regonly['regonly'];
$allowed=$adata['rate_allow'];
$exists=$adata['title'];
if($r>=1 and $r<=5 and $exists!="" and $allowed==1 and ($regonly==0 or ($regonly==1 and $login_indicator==1))){$continue=true;}
else{$continue=false;}

?>


<h1><?php echo lang('article_rate', 'r'); ?></h1>
<p>
<?php
if($continue==true){

$a_rate=$ipcache;
$a_ratenum=0;
$a_ratefound=false;
while($a_ratenum<=count($a_rate)){
$a_rateitem=$a_rate[$a_ratenum];
if($a_rateitem==$ip){$a_ratefound=true; break;}
$a_ratenum++;
}

  /*vlozeni do logu a pripocteni pocitadla*/
  if($a_ratefound==false){
  
  $n_ipcache="";
  for($step=-1; $step<=497 and $step<=count($ipcache); $step++){

    if($step!=-1){
    if($ipcache[$step]!=""){$n_ipcache_item=$ipcache[$step];}else{continue;}
    }
    else{
    $n_ipcache_item=$ip;
    }

  $n_ipcache.=$n_ipcache_item."|";
  }
  
  @mysql_query("UPDATE `".tabprefix."-articles` SET rate_counter=rate_counter+1 WHERE id=$id");
  @mysql_query("UPDATE `".tabprefix."-articles` SET rate_total=rate_total+$r WHERE id=$id");
  @mysql_query("UPDATE `".tabprefix."-articles` SET rate_ipcache='$n_ipcache' WHERE id=$id");
  lang('global_rate_accepted', 'e');
  }
  else{
  lang('global_rate_denied', 'e');
  }


}
else{
lang('global_invalidinput', 'e');
}

echo "<br />&lt; <a href='".referer(true)."'>".lang('global_goback', 'r')."</a>";
?>

</p>
