<?php

if(!isset($box_column)){$box_column=0;}
else{$box_column=intval($box_column);}

$boxes=@mysql_query("SELECT title,showtitle,content FROM `".tabprefix."-boxes` WHERE visible=1 and panel=$box_column ORDER BY ord");
while($box=@mysql_fetch_array($boxes)){

  /*vypnuti paddingu*/
  if(strpos("##".$box['content'], "<!--noboxpadding-->")){
  $padding=false;
  $box['content']=str_replace("<!--noboxpadding-->", "", $box['content']);
  }
  else{
  $padding=true;
  }

/*zacatek boxu ->*/   echo "<div class='box'>\n";
/*titulek ->*/        if($box['showtitle']==1){echo "<div class='box-title'>".$box['title']."</div>\n";}
/*zacatek pad. ->*/   if($padding==true){echo "<div class='box-padding'>\n";}
/*obsah boxu ->*/     echo parsehcm($box['content'], true)."\n";
/*konec pad. ->*/     if($padding==true){echo "</div>\n";}
/*spodni okraj ->*/   if($box['showtitle']==1 and $st_boxbottom==true){echo "<div class='box-bottom'></div>\n";}
/*konec boxu ->*/     echo "</div>\n\n";

}

?>
