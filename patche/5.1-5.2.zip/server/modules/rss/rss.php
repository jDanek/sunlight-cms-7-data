<?php

/*pripojeni k db*/
$root="../../";
include("../../_connect.php");
if($st_rss!=1){exit;}

/*nastaveni rss modulu*/
header('content-type: text/xml; charset=windows-1250');
$clanku=$st_limit;     //pocet zobrazovanych clanku
$jazyk="cs";    //jazyk rss souboru, vetsinou cs

/*vypis hlavicky*/
echo "<";
echo "?xml version=\"1.0\" encoding=\"windows-1250\"?";
echo ">\n";
?>

<rss version="0.91">
<channel>

<?php

echo "
\t<title>$st_title</title>
\t<link>$st_serverurl/</link>
\t<description>$st_description</description>
\t<language>$jazyk</language>\n

<image>
\t<link>$st_serverurl/</link>
\t<title>$st_title</title>
\t<url>$st_serverurl/modules/rss/rss.gif</url>
\t<width>34</width>
\t<height>34</height>
</image>
";

$data=@mysql_query("SELECT title,perex,id FROM `".tabprefix."-articles`$st_futureart2 ORDER BY $st_artorder DESC LIMIT 0, $clanku");
while($item=mysql_fetch_array($data)){

$item['title']=trim(strip_tags($item['title']));
$item['perex']=trim(strip_tags($item['perex']));

$linkhref=$st_serverurl."/".artrewrite($item['id'], $item['title'], false);

echo "<item>
\t<title>".$item['title']."</title>
\t<description>".entity_to_decimal_value($item['perex'])."</description>
\t<link>".$linkhref."</link>
</item>\n
";

}

?>

</channel>
</rss>
