<?php

echo content_editor_process(parsehcm($codecontent['code'], true));
$sectitle=@mysql_query("SELECT anchor FROM `".tabprefix."-menu` WHERE id=$c_home");
$sectitle=@mysql_fetch_array($sectitle);
$sectitle=$sectitle['anchor'];

/*komentare*/
if($c_comment==1 and $st_comment==1){
include("modules/comment.php");
}

?>
