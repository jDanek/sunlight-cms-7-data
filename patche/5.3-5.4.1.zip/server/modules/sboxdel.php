<?php

/*nacteni bid*/
if(isset($_GET['pid'])){
$pid=$_GET['pid'];
$pid=intval($pid);
}
else{
$pid=-1;
}
$done=0;


/*kontrola loginu*/

  /*nacteni autora*/
  $sbox_data=@mysql_query("SELECT author,date FROM `".tabprefix."-sboxes-posts` WHERE id=$pid");
  $sbox_data=@mysql_fetch_array($sbox_data);
  
  $post_author=$sbox_data['author'];
  if($post_author!=-1){
  $post_author_rights=@mysql_query("SELECT rights FROM `".tabprefix."-users` WHERE id=$post_author");
  $post_author_rights=@mysql_fetch_array($post_author_rights);
  $post_author_rights=$post_author_rights['rights'];
  }
  else{
  $post_author_rights=0;
  }

  /*smazani z db*/
  if(postaccess_allow($post_author, $post_author_rights, $sbox_data['date'])){
  @mysql_query("DELETE FROM `".tabprefix."-sboxes-posts` WHERE id=$pid");
  $done=1;
  }


include("msg.php");
?>


<h1><?php lang('post_delete', 'e'); ?></h1>
<div class="hr"><hr /></div>

<?php
if($done!=1){
echo "<b>".lang('global_denied')."</b>";
}
else{
echo "<p>".lang('global_actiondone')."<br />&lt; <a href='".referer(true)."'>".lang('global_goback')."</a></p>";
}
?>
