<?php

/*nacteni bid*/
if(isset($_GET['bid'])){
$bid=$_GET['bid'];
$bid=intval($bid);
}
else{
$bid=-1;
}
$done=0;

/*kontrola loginu*/

  /*nacteni autora*/
  $b_data=@mysql_query("SELECT author,name,date,text FROM `".tabprefix."-books` WHERE id=$bid");
  $b_data=@mysql_fetch_array($b_data);

  $b_author=$b_data['author'];
  if($b_author!=-1){
  $b_author_rights=@mysql_query("SELECT rights FROM `".tabprefix."-users` WHERE id=$b_author");
  $b_author_rights=@mysql_fetch_array($b_author_rights);
  $b_author_rights=$b_author_rights['rights'];
  }
  else{
  $b_author_rights=0;
  }

  /*ulozeni do db*/
  $allowed=postaccess_allow($b_author, $b_author_rights, $b_data['date']);
  if($allowed==true){

    if(isset($_POST['mod_text'])){

      /*nacteni promennych*/
      $text=$_POST['mod_text'];
      $text=substr($text, 0, 2048);
      $text=strtr($text, $trans);
      $text=trim($text);

        if($b_author==-1){
        $name=$_POST['mod_name'];
        $name=anchor($name, false);
        $name=substr($name, 0, 20);
        }
      
      /*kontrola a ulozeni*/
      if($text!="" and ($name!="" or $b_author!=-1)){
      @mysql_query("UPDATE `".tabprefix."-books` SET text='$text' WHERE id=$bid");
      if($b_author==-1){@mysql_query("UPDATE `".tabprefix."-books` SET name='$name' WHERE id=$bid");}
      $done=1;
      }
      else{
      $msg=lang('global_msg_badinput');
      $done=0;
      }
    
    }
    else{
    $done=0;
    }

  }


include("msg.php");

/*odkaz pro navrat*/
$home=@mysql_query("SELECT home FROM `".tabprefix."-books` WHERE id=$bid");
$home=@mysql_fetch_array($home);
$anchor=@mysql_query("SELECT anchor FROM `".tabprefix."-menu` WHERE id=".$home['home']);
$anchor=@mysql_fetch_array($anchor);
$backlink="&lt; <a href='".bookrewrite($home['home'], $anchor['anchor'], 1)."'>".lang('global_goback')."</a>";
?>


<h1><?php lang('book_edit', 'e'); ?></h1>
<div class="hr"><hr /></div>

<?php
if($allowed!=true){
echo "<b>".lang('global_denied')."</b>";
}
else{

  /*----hlaska o provedeni nebo formular pro editaci----*/
  if($done==1){
  
  /*hotovo*/

  echo "<p>".lang('global_actiondone')."<br />$backlink</p>";
  
  }
  else{

  /*formular*/
  if($b_author==-1){
  $nameedit="
  <tr valign='top'>
  <td>".lang('global_yourname')."&nbsp;</td>
  <td><input type='text' class='ifield' name='mod_name' value='".$b_data['name']."' maxlength='20' /></td>
  </tr>
  ";
  }

  echo
  textarea_limit(2048, "bookform").
  textarea_smileys("bookform", "mod_text")."
  <form action='".modrewrite("bookedit", false, true)."bid=$bid' method='post' name='bookform' onsubmit=\"if(document.bookform.text.value==''$jscodecheck){alert('".lang('global_somethingwrong')."'); return false;}\">
  <input type='hidden' name='mod_codecheckr' value='$codecheck' />

  <table>

  $nameedit

  <tr valign='top'>
  <td>".lang('global_text')."&nbsp;</td>
  <td><textarea name='mod_text' class='itext' id='itext' rows='6' cols='45'>".$b_data['text']."</textarea></td>
  </tr>

  <tr>
  <td></td>
  <td>
  <input type='submit' value='".lang('global_save')." &gt;' />
  <input type='reset' value='".lang('global_reset')."' onclick=\"return ask();\" />
  &nbsp;
  ".getsmileyslist()."

  $codecheckimg
  </td>
  </tr>

  </table>

  </form>

  <br />$backlink
  ";

  }

}
?>
