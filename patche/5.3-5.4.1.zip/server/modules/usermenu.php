<?php

$mtmp="";
if($u_spacer==""){$u_spacer="&nbsp;|&nbsp;";}
if($u_hideusername==1){$u_username="";}else{$u_username="[".login_name."]";}


if(login_indicator==1){

  /*odhlaseni*/ $mtmp.="<a href='modules/logout.php'>$u_prefix".lang('usermenu_logout')." $u_username</a>$u_spacer";
  /*nastaveni*/ $mtmp.="<a href='".modrewrite("settings")."'>$u_prefix".lang('usermenu_settings')."</a>$u_spacer";
  /*profil*/    $mtmp.="<a href='".modrewrite("viewprofile", false, true)."id=".login_name."'>$u_prefix".lang('usermenu_viewprofile')."</a>";
  /*komentare*/ if(comment==1){$mtmp.="$u_spacer<a href='".modrewrite("viewcomments")."'>$u_prefix".lang('usermenu_lastcomments')."</a>";}
  
}
else{
  /*registrace*/   if(registration==1){$u_reglink="$u_spacer<a href='".modrewrite("register")."'>$u_prefix".lang('usermenu_register')."</a>";}else{$u_reglink="";}
  /*prihlasovani*/ $mtmp.="<a href='".modrewrite("login")."'>$u_prefix".lang('usermenu_login')."</a>$u_reglink";
}

/*seznam uzivatelu*/ if(userlist==1){$mtmp.="$u_spacer<a href='".modrewrite("userlist")."'>$u_prefix".lang('usermenu_userlist')."</a>";}

if($u_hcmmode!=true){echo $mtmp;}

?>
