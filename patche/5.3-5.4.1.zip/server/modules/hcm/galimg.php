<?php

$filename=$_GET['f'];
$filename="../../".$filename;
$newwidth=$_GET['w'];
$newwidth=intval($newwidth);
$suffix=strrpos($filename, ".");
$suffix=substr($filename, $suffix+1);
$suffix=strtolower($suffix);

if(file_exists($filename) and $newwidth>0 and $newwidth<=2048){

  /*kontrola pripony*/
  switch($suffix){
  case "jpg": $source=@imagecreatefromjpeg($filename); break;
  case "jpeg": $source=@imagecreatefromjpeg($filename); break;
  case "png": $source=@imagecreatefrompng($filename); break;
  case "gif": $source=@imagecreatefromgif($filename); break;
  default: exit;
  }
  
  /*vypocet rozmeru*/
  list($width, $height)=getimagesize($filename);
  $outputwidth=$newwidth;
  $outputheight=round(($height/$width)*$newwidth);

  /*vytvoreni nahledu*/
  $thumb=imagecreatetruecolor($outputwidth,$outputheight);
  imagecopyresampled($thumb, $source, 0, 0, 0, 0, $outputwidth, $outputheight, $width, $height);

  /*odeslani a ukonceni*/
  header("Content-type: image/jpeg");
  imagejpeg($thumb);
  imagedestroy($thumb);

}
?>
