<?php
$mtmp="
    <div class='search'>
    <form action='".modrewrite("fulltext", true)."' method='get'>
    ".modrewrite_getinputs("fulltext")."
    <input type='text' name='hledej' class='txt' />
    <input type='submit' value='".lang('global_find')."' class='submit' />
    </form>
    </div>
";
?>
