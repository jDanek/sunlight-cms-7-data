<?php

/*limitovani autora*/
$continue=true;
if(isset($_GET['author'])){

  $langlimited="limited_";

  $getauthor=addslashes($_GET['author']);
  $authorid=@mysql_query("SELECT id,name FROM `".tabprefix."-users` WHERE name='$getauthor'");
  $authorid=@mysql_fetch_array($authorid);

  if($authorid['name']!=""){
  $authorlimit=" WHERE author=".$authorid['id'];
  $getauthor="&amp;author=".$getauthor;
  }
  else{
  $continue=false;
  }

}
else{
$getauthor="";
$authorlimit="";
$langlimited="";
}

?>


<h1><?php lang('viewcomments_'.$langlimited.'title', 'e'); ?></h1>
<p><?php lang('viewcomments_'.$langlimited.'p', 'e'); ?></p>

<div class="hr"><hr /></div>

<?php

  /*----------ZPRACOVANI VSTUPNICH PARAMETRU STRANKOVANI----------*/
  if(isset($_GET['s'])){
  $startpage=$_GET['s'];
  $startpage=intval($startpage);
  if($startpage!=0){$startpage-=1;}
  }
  else{
  $startpage=0;
  }
  $start=$startpage*$st_limit;

  /*----------VYHLEDANI----------*/
  if($continue==true){
  
    $comments=@mysql_query("SELECT tp,home,author,text,subject FROM `".tabprefix."-comments`$authorlimit ORDER BY id DESC");
    $naslo=0;
    while($comment=@mysql_fetch_array($comments)){
    $naslo++;

      if($naslo>$start and $naslo<=$start+$st_limit){

        /*spocitani komentaru*/
        $commentscount=@mysql_query("SELECT id FROM `".tabprefix."-comments` WHERE home=".$comment['home']." AND tp=".$comment['tp']);
        $commentscount_number=0;
        while(@mysql_fetch_array($commentscount)){
        $commentscount_number++;
        }

        /*sestaveni odkazu*/
        switch($comment['tp']){

        case 1:
        $title=@mysql_query("SELECT anchor FROM `".tabprefix."-menu` WHERE id=".$comment['home']);
        $title=@mysql_fetch_array($title);
        $title=$title['anchor'];
        $id=$comment['home'];
        $linkhref=secrewrite($id, $title);
        break;

        case 2:
        $title=@mysql_query("SELECT title FROM `".tabprefix."-articles` WHERE id=".$comment['home'].$st_futureart);
        $title=@mysql_fetch_array($title);
        $title=$title['title'];
        $id=$comment['home'];
        $linkhref=artrewrite($id, $title);
        break;

        }

        $c_author=@mysql_query("SELECT name FROM `".tabprefix."-users` WHERE id=".$comment['author']);
        $c_author=@mysql_fetch_array($c_author);
        $c_author=$c_author['name'];
        if($authorlimit==""){$authorinfo=" | <b>".lang('article_composter').":</b> $c_author";}else{$authorinfo="";}
        $comment['text']=textpart(stripbbcode($comment['text']));
        if($st_smileys==1){$comment['text']=strtr($comment['text'], getsmileys());}
        echo "<a href='$linkhref' class='title'>$title: ".$comment['subject']."</a><p class='cperex'>".$comment['text']."</p><div class='cinfo'><b>".lang('article_totalcomments').":</b> $commentscount_number".$authorinfo."</div>\n";

      }

    }


      /*----------VYPIS STRAN----------*/
      if($naslo!=0){

      $pocetstran=$naslo;
      $pocetstran=$pocetstran/$st_limit;
      $pocetstran=ceil($pocetstran);

      if($startpage>=0 and $startpage<=$pocetstran-1){

      if($startpage>9){$strana=$startpage-5;}
      else{$strana=0;}
      $odkazu=0;
      $back=$startpage-10;
      $forward=$startpage+10;
      echo "<div class='strany'><b>".lang('global_page')."</b>: ";
      if($startpage>=10){echo "<a href='".modrewrite("viewcomments", false, true)."s=$back".$getauthor."'>&lt;</a> ";}

      while($strana<$pocetstran and $odkazu<=$st_maxpages){
      $odkazu++;
      $stranaanchor=$strana+1;
      if($strana==$startpage){echo "<a href='".modrewrite("viewcomments", false, true)."s=$stranaanchor".$getauthor."' class='active'>$stranaanchor</a> ";}
      else{echo "<a href='".modrewrite("viewcomments", false, true)."s=$stranaanchor".$getauthor."'>$stranaanchor</a> ";}
      $strana++;
      }

      if($startpage<=$pocetstran-10){echo "<a href='".modrewrite("viewcomments", false, true)."s=$forward".$getauthor."'>&gt;</a> ";}

      echo "</div>";

      }
      else{
      lang('global_wrongpage', 'e');
      }

      }
      else{
      lang('comment_nokit', 'e');
      }

    }
    else{
    lang('global_msg_usernotexists', 'e');
    }

    

?>
