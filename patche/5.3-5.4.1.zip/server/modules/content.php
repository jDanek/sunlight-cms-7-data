<?php

if(!isset($_GET['content_preload']) and !isset($_POST['content_preload']) and isset($indicators['preloaded'])){
eval($content_preload);
}
else{
lang('content_notfound', 'e');
}

?>
