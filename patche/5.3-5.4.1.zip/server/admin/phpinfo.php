<?php
include("check.php");
phpinfo();
?>
