<?php

/*-----kontrola existence dat-----*/
function data_exists($input){
if($input==""){
echo "
<div id=\"adminerror\">
".lang('admin_error')."<br /><br />
&lt; <a href=\"".ampersands($_SERVER['HTTP_REFERER'])."\" onclick=\"history.go(-1); return false;\">".lang('global_goback')."</a>
</div>

</div></div></div></div>
<div id='shade-bottom'></div>

<div id=\"copyright\">".lang('admin_global_copyright')."</div>
</body>
</html>
";
exit;
}
}

/*-----vypis hlasky o zadnem obsahu-----*/
function content_exists($input){
if($input==0){lang('admin_global_nokit', 'e');}
}

/*vkladani editoru*/
function content_editor(){
switch(editor){
case 1: return "include('tinymce.smf');"; break;
case 3: return "include('spaw.smf');"; break;
}
}

/*-----logicky vyber tridy clanku-----*/
function artclass($visible, $date){
if($visible==0 and ($date<=time() or futureart=="")){$output="invisible";}
if($visible!=1 and $date>time() and futureart!=""){$output="invisible-future";}
if($visible==1 and ($date<=time() or futureart=="")){$output=false;}
if($visible==1 and ($date>time() and futureart!="")){$output="future";}
if($output!=false){$output=" class='$output'";}else{$output="";}
return $output;
}

/*----schovavani elementu-----*/
function stuff_hide($input, $part){
if($input==0){
  switch($part){
  case 1: echo "<span class='hidden'>"; break;
  case 2: echo "</span>"; break;
  }
}
}

/*-----seznamove funkce-----*/
function listanchor($input){
if(strlen($input)>24){$input=substr($input, 0, 21)."...";}
return $input;
}

function listcontentexists($input){
if($input==0){echo "<tr><td colspan='2'>".lang('admin_global_nokit')."</td></tr>";}
}

/*-----seznam kategorii-----*/
function categoryselect($selectname, $select=-1){
$cats=@mysql_query("SELECT anchor,id FROM `".tabprefix."-menu` WHERE type=2 ORDER BY ord");
  $return="<select name='$selectname'>\n";
  $counter=0;
  while($cat=@mysql_fetch_array($cats)){
  if($select!=-1){if($cat['id']==$select){$selected=" selected='selected'";}else{$selected="";}}
  $return.="<option value='".$cat['id']."'".$selected.">".$cat['anchor']."</option>\n";
  $counter++;
  }
  if($counter==0){$return.="<option value='-1'>".lang('admin_global_nocats')."</option>\n";}
  $return.="\n</select>\n";
return $return;
}

/*-----seznam autoru-----*/
function authorselect($selected){
$return="";
  switch(login_rights){

  /*redaktor*/
  case 1:
  $return.=login_name."\n";
  $return.="<input type='hidden' name='author' value='".login_id."' />";
  break;

  /*admin*/
  case 2:
  $return.="<select name='author'>";
  $autori=@mysql_query("SELECT id,name FROM `".tabprefix."-users` WHERE rights=1 OR rights=2");
    while($autor=@mysql_fetch_array($autori)){
    if($autor['id']==$selected){$selected=" selected='selected'";}
    else{$selected="";}
    $return.="<option value='".$autor['id']."'$selected>".$autor['name']."</option>\n";
    }
  $return.="</select>";
  break;
  }
return $return;
}

?>
