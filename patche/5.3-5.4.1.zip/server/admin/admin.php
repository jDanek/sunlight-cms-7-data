<?php
include("check.php");
include("header.php");
include("functions.php")

?>

<script type="text/javascript">
//<![CDATA[
function ask(){if(!confirm('<?php lang('global_msg_doask', 'e'); ?>')){return false;}else{return true;}}
//]]>
</script>

<div id="shortcut-icons">
<a href="../" target="_blank" title="<?php lang('admin_icons_showmain', 'e'); ?>"><img src="pics/icon_showmain.gif" class="micon"  alt="<?php lang('admin_icons_showmain', 'e'); ?>" /></a>
<a href="admin.php" target="_blank" title="<?php lang('admin_icons_newwin', 'e'); ?>"><img src="pics/icon_newwin.gif" class="micon"  alt="<?php lang('admin_icons_newwin', 'e'); ?>" /></a>
<a href="admin.php?pg=docs" title="<?php lang('admin_icons_help', 'e'); ?>"><img src="pics/icon_help.gif" class="micon"  alt="<?php lang('admin_icons_help', 'e'); ?>" /></a>
</div>

<div id="shade-top"></div>
<div id="shade-middle">
<div id="container">
<div id="container-padding">

<!--logo-->
<div id="logo"><span><a><?php echo $login_name; ?></a> | <a href="logout.php"><?php lang('admin_logout', 'e'); ?></a></span></div>

<!--menu-->
<div id="menu">
<div id="menu-padding">

<?php
/*spolecne polozky home a sprava obsahu*/
echo "
<a href='admin.php?pg=home'>".lang('admin_mainmenu_home')."</a> |
<a href='admin.php?pg=content'>".lang('admin_mainmenu_content')."</a> |
";

/*sprava uzivatelu pro adminy*/
if($login_rights==2){echo "\n<a href='admin.php?pg=users'>".lang('admin_mainmenu_users')."</a> |";}

/*nastaveni systemu a blokovani pro hlavniho admina*/
if($login_id==0){
echo "
<a href='admin.php?pg=settings'>".lang('admin_mainmenu_settings')."</a> |
<a href='admin.php?pg=blocking'>".lang('admin_mainmenu_blocking')."</a> |
";
}

/*upload*/
if($login_rights==2 or $st_redcanup==1){echo "\n<a href='admin.php?pg=upload'>".lang('admin_mainmenu_upload')."</a> |";}

echo "\n<a href='admin.php?pg=docs'>".lang('admin_mainmenu_docs')."</a> |";
?>

</div>
</div>


<!--content-->
<div id="content">

<?php
/*vlozeni dle pg*/
if(isset($_GET['pg'])){

/*nacteni parametru pg*/
$pg=$_GET['pg'];
$pg=anchor($pg);

$accessgranted=true;

/*pristupova prava redaktoru*/
if($login_rights==1){
  switch($pg){
  case "blocking":
  case "content-boxes":
  case "content-deletebook":
  case "content-deletebox":
  case "content-deletecategory":
  case "content-deletesection":
  case "content-editbook":
  case "content-editbox":
  case "content-editcategory":
  case "content-editsection":
  case "content-menuanchor":
  case "content-menuorder":
  case "content-menusublinks":
  case "content-mergecats":
  case "content-newbook":
  case "content-newbox":
  case "content-newcategory":
  case "content-newsection":
  case "content-sboxes":
  case "settings":
  case "users-inactive":
  case "users-list":
  case "users-massemail":
  case "users-rate":
  case "users":
  $accessgranted=false; break;
  }
  if($pg=="upload" and $st_redcanup!=1){$accessgranted=false;}
}

/*pristupova prava administratoru*/
if($login_id!=0){
  switch($pg){
  case "blocking":
  case "settings":
  case "users-inactive":
  $accessgranted=false; break;
  }
  if($pg=="users-massemail" and $st_adminmassmail!=1){$accessgranted=false;}
}

/*pristupova prava k souborum _inc*/
if(substr($pg, 0, 4)=="_inc"){
$accessgranted=false;
}
else{
if($accessgranted!=false){$accessgranted=true;}
}

/*pridani cesty k parametru pg a vlozeni*/
$pg="modules/$pg.inc";

  if(file_exists($pg)){

    if($accessgranted==true){
    include($pg);
    }
    else{
    echo "<b>".lang('global_denied')."</b>";
    }

  }
  else{
  include("modules/home.inc");
  }

}
else{
include("modules/home.inc");
}

?>

</div>


</div>
</div>
</div>
<div id="shade-bottom"></div>

<!--copyright-->
<div id="copyright"><?php lang('admin_global_copyright', 'e'); ?></div>

</body>
</html>

<?php @mysql_close($connection) ?>
