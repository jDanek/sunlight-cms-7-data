<?php
$root="../";
include("../_connect.php");

if(isset($_GET['id']) and $_GET['id']!=""){

$uid=$_GET['id'];
$uid=anchor($uid, false);

}
else{
$uid="";
}

$moduletitle="viewarticles_title";
include("moduleheader.php");
?>

<body>

<div class="board">
<div class="board-padding">

<h1><?php lang('viewarticles_title', 'e'); ?></h1>
<p><?php lang('viewarticles_p', 'e'); ?></p>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
<b><?php lang('global_user', 'e'); ?></b>:&nbsp;
<input type="text" name="id" size="20" value="<?php echo $uid; ?>">
<input type="submit" value="<?php lang('global_view', 'e'); ?> &gt;">
</form>

<div id="results">

<?php
if($uid!=""){

$userdata=@mysql_query("SELECT id,name,rights FROM `".tabprefix."-users` WHERE name='$uid'");
$userdata=@mysql_fetch_array($userdata);

if($userdata['name']!=""){

  /*strankovani*/
  if(isset($_GET['s'])){
  $startpage=$_GET['s'];
  $startpage=intval($startpage);
  if($startpage!=0){$startpage-=1;}
  }
  else{
  $startpage=0;
  }

  /*seznam stran*/
  $strany=@mysql_query("SELECT id FROM `".tabprefix."-articlecontent` WHERE author=".$userdata['id']);
  $pocetstran=0;

    /*spocitani stran*/
    while($strana=@mysql_fetch_array($strany)){$pocetstran++;}
    if($pocetstran==0){$pocetstran=1;}
    $pocetstran=$pocetstran/$st_limit;
    $pocetstran=ceil($pocetstran);

  /*vypis stran*/
  if($startpage>9){$strana=$startpage-5;}
  else{$strana=0;}
  $odkazu=0;
  $back=$startpage-10;
  $forward=$startpage+10;
  $strankovani="<hr size='1' color='$st_linecolor'><div class='strany'>".lang('global_page', 'r').": ";

  $linkhref="viewarticles.php?id=$uid&s=$back";
  if($startpage>=10){$strankovani.="<a href='$linkhref'>&lt;</a> ";}

  while($strana<$pocetstran and $odkazu<=$st_maxpages){
  $odkazu++;
  $stranaanchor=$strana+1;

  $linkhref="viewarticles.php?id=$uid&s=$stranaanchor";
  if($strana==$startpage){$strankovani.="<a href='$linkhref' class='active'>$stranaanchor</a> ";}
  else{$strankovani.="<a href='$linkhref'>$stranaanchor</a> ";}
  $strana++;
  }

  $linkhref="viewarticles.php?id=$uid&s=$forward";
  if($startpage<=$pocetstran-10){$strankovani.="<a href='$linkhref'>&gt;</a> ";}
  $strankovani.="</div>\n";

  echo "<hr size='1' color='$st_linecolor'>";
  
  /*vypis seznamu clanku*/
  $start=$startpage*$st_limit;
  $articlecontent=@mysql_query("SELECT id,title,perex,date,author,opened,comment FROM `".tabprefix."-articlecontent` WHERE author=".$userdata['id']." ORDER BY id DESC LIMIT $start,$st_limit");

  $jsouclanky=false;
  while($item=@mysql_fetch_array($articlecontent)){
  if($jsouclanky==false){$jsouclanky=true;}

  $a_author=@mysql_query("SELECT name FROM `".tabprefix."-users` WHERE id=".$item['author']);
  $a_author=@mysql_fetch_array($a_author);

  $a_id=$item['id'];
  $a_title=$item['title'];
  $a_title4url=anchor($a_title);
  $a_perex=$item['perex'];
  $a_author=$a_author['name'];
  $a_date=$item['date'];
  $a_comment=$item['comment'];
  $a_opened=$item['opened'];

    /*spocitani komentaru*/
    $a_commentscount_code="";
    if($a_comment==1){
    $a_commentscount=@mysql_query("SELECT id FROM `".tabprefix."-comments` WHERE home=$a_id AND tp=2");
    $a_commentscount_number=0;
    while(@mysql_fetch_array($a_commentscount)){
    $a_commentscount_number++;
    }
    $a_commentscount_code=" | <b>".lang('article_totalcomments', 'r').":</b> $a_commentscount_number";
    }

  /*rewrite*/
  if($st_rewrite==1){$linkhref="../$st_artprefix-$a_title4url-$a_id.html";}
  else{$linkhref="../index.php?articleread=$a_id";}

  /*sestaveni a vypis*/
  $a_return="<a href='$linkhref'><h2>$a_title</h2></a><p class='cperex'>$a_perex</p><div class='cinfo'><b>".lang('article_author', 'r').":</b> $a_author | <b>".lang('article_posted', 'r').":</b> $a_date | <b>".lang('article_read', 'r').":</b> ".$a_opened."x$a_commentscount_code</div></p>\n";
  echo $a_return;
  }
  
  if($jsouclanky==true){
  echo $strankovani;
  }
  else{
    if($userdata['rights']==1 or $userdata['rights']==2){
    lang('viewarticles_nokit', 'e');
    }
    else{
    lang('global_invalidinput', 'e');
    }
  }
  
}
else{
$msg=lang('global_msg_usernotexists', 'r');
}

include("msg.php");
}
?>

</div>
</div>

</body>
</html>
