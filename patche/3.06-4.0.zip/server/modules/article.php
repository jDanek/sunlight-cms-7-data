<?php

$a_author=@mysql_query("SELECT name FROM `".tabprefix."-users` WHERE id=".$a_content['author']);
$a_author=@mysql_fetch_array($a_author);

/*nacteni promennych*/
$a_id=$a_content['id'];
$a_title=$a_content['title'];
$a_title4url=anchor($a_title);
$a_perex=$a_content['perex'];
$a_code=$a_content['code'];
//comment je uz v content.php
$a_author=$a_author['name'];
$a_date=$a_content['date'];
$a_home=$a_content['home'];
$a_opened=$a_content['opened'];

  /*zpracovani hodnoceni*/
  if($a_content['rate_counter']==0 or $a_content['rate_total']==0){
  $a_rating=lang('article_nonrated', 'r');
  }
  else{
  $a_rating=intval($a_content['rate_total']/$a_content['rate_counter'])." (".lang('global_total', 'r')." ".$a_content['rate_counter']." ".lang('global_votes', 'r').")";
  }

/*zjisteni nazvu kategorie*/
$kategorie=@mysql_query("SELECT anchor FROM `".tabprefix."-menu` WHERE id=$a_home");
$kategorie=@mysql_fetch_array($kategorie);
$kategorie=$kategorie['anchor'];
$kategorie4url=anchor($kategorie);

/*zapocitani zobrazeni*/
$a_readlog=explode("|", $_SESSION['readlog']);
$a_readlognum=0;
$a_readlogfound=false;
while($a_readlognum<=count($a_readlog)){
$a_readlogitem=$a_readlog[$a_readlognum];
if($a_readlogitem==$a_id){$a_readlogfound=true; break;}
$a_readlognum++;
}

  /*vlozeni do logu a pripocteni pocitadla*/
  if($a_readlogfound==false){
  $_SESSION['readlog'].="|$a_id";
  @mysql_query("UPDATE `".tabprefix."-articlecontent` SET opened=opened+1 WHERE id=$a_id");
  }

/*rewrite*/
if($st_rewrite==1){$linkhref="$st_catprefix-$kategorie4url-$a_home-1.html";}
else{$linkhref="index.php?str=$a_home&tp=2";}

$a_code=parsehcm($a_code);

echo lang('article_category', 'r')."
: <a href='$linkhref'>$kategorie</a>
<hr size='1' color='$st_linecolor'>
<h1>$a_title</h1>
<p class='aperex'>$a_perex</p>
$a_code
<p class='ainfo'>
<b>".lang('article_author', 'r').":</b> <a href='modules/viewprofile.php?id=$a_author'>$a_author</a><br>
<b>".lang('article_posted', 'r').":</b> $a_date<br>
<b>".lang('article_read', 'r').":</b> ".$a_opened."x<br>
<b>".lang('article_rating', 'r').":</b> ".$a_rating."<br>
<b>".lang('article_rate', 'r').":</b>&nbsp;
<a href='modules/article-rate.php?r=1&id=$a_id' target='_blank'>1</a> |
<a href='modules/article-rate.php?r=2&id=$a_id' target='_blank'>2</a> |
<a href='modules/article-rate.php?r=3&id=$a_id' target='_blank'>3</a> |
<a href='modules/article-rate.php?r=4&id=$a_id' target='_blank'>4</a> |
<a href='modules/article-rate.php?r=5&id=$a_id' target='_blank'>5</a>
</p>";

  if($a_comment==1){
  include("modules/comment.php");
  }
?>
