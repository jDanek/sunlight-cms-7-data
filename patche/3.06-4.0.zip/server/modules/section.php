<?php
echo parsehcm($codecontent['code'], true);
/*nacteni nazvu v menu pro mod_rewrite*/
$code_anchor=@mysql_query("SELECT anchor FROM `".tabprefix."-menu` WHERE id=$c_home");
$code_anchor=@mysql_fetch_array($code_anchor);
$code_anchor=$code_anchor['anchor'];
$code_anchor=anchor($code_anchor);

/*komentare*/
  if($c_comment==1){
  include("modules/comment.php");
  }
?>
