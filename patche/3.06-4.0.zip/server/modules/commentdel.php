<?php
$root="../";
include("startup.php");
$self=$_SERVER['PHP_SELF'];

/*nacteni cid*/
if(isset($_GET['cid'])){
$cid=$_GET['cid'];
$cid=intval($cid);
$self.="?cid=$cid";
}
else{
$error=lang('global_wrongrequest', 'r');
include("error.php");
exit;
}


/*kontrola loginu*/

  /*nacteni autora*/
  $c_author=@mysql_query("SELECT author FROM `".tabprefix."-comments` WHERE id=$cid");
  $c_author=@mysql_fetch_array($c_author);
  $c_author=$c_author['author'];
  $c_author_rights=@mysql_query("SELECT rights FROM `".tabprefix."-users` WHERE id=$c_author");
  $c_author_rights=@mysql_fetch_array($c_author_rights);
  $c_author_rights=$c_author_rights['rights'];

  /*smazani z db*/
  if($login_indicator==1 and $c_author!="" and ($c_author==$login_id or ($login_rights==1 or $login_rights==2))){
  
  $continue=false;
  switch($c_author_rights){
  case 0: $continue=true; break;
  case 1: if($login_rights==2 or $login_id==$c_author){$continue=true;} break;
  case 2: if($login_id==$c_author or $login_id==0){$continue=true;} break;
  }

  if($continue==true){
  @mysql_query("DELETE FROM `".tabprefix."-comments` WHERE id=$cid");
  $done=1;
  }

  }



$moduletitle="comment_delete";
include("moduleheader.php");
?>

<body>

<?php include("msg.php"); ?>

<div class="board">
<div class="board-padding">

<?php
if($done!=1){
echo "<b>".lang('global_denied', 'r')."</b>";
}
else{
echo "<b>".lang('global_actiondone', 'r')."</b>";
}
?>

</div>
</div>


</body>
</html>
