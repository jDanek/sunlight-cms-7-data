<?php
/*----PRIDANI PRISPEVKU----*/
if(isset($_POST['text'])){

if($_SESSION['log_posttime']<time()-$st_postwait){
$_SESSION['log_posttime']=time();

  /*nacteni promennych*/
  $text=$_POST['text'];
  $text=substr($text, 0, 2048);
  $text=strtr($text, $trans);
  $date=date("j.n Y H:i");
  $ip=$_SERVER['REMOTE_ADDR'];

  if($login_indicator==1){
  $author=$login_id;
  }
  else{
  $name=$_POST['name'];
  $name=anchor($name, false);
  $name=substr($name, 0, 20);
  $name=strtr($name, $trans);
  $codecheck=$_POST['codecheck'];
  $codecheckr=$_POST['codecheckr'];
  $codecheckr=code_decode($codecheckr);
  }
  
  /*kontrola a vlozeni*/
  if($text!="" and ($name!="" or $login_indicator==1) and ($codecheck==$codecheckr or $login_indicator==1)){
    
    /*vypocet noveho id*/
    $newid=@mysql_query("SELECT id FROM `".tabprefix."-bookcontent` ORDER BY id DESC LIMIT 1");
    $newid=@mysql_fetch_array($newid);
    $newid=$newid['id'];
    $newid++;
  
    /*rozliseni a vlozeni*/
    if($login_indicator==1){
    @mysql_query("INSERT INTO `".tabprefix."-bookcontent` (id,home,author,name,date,text,ip) VALUES ($newid, $c_str, $login_id, '', '$date', '$text', '$ip')");
    }
    else{
    @mysql_query("INSERT INTO `".tabprefix."-bookcontent` (id,home,author,name,date,text,ip) VALUES ($newid, $c_str, -1, '$name', '$date', '$text', '$ip')");  
    }
    
  
  }
  else{
  $msg=lang('global_msg_badinput', 'r');
  }
  
}
else{
$msg=lang('global_msg_timelimit', 'r');
}

}


/*----FORUMULAR-----*/
echo "<h1>$bookanchor</h1>";

include("modules/msg.php");

/*nastaveni akce*/
$bookanchor4url=anchor($bookanchor);
if($st_rewrite==1){$formaction="$st_gbprefix-$bookanchor4url-$c_str-1.html";}
else{$formaction="index.php?str=$c_str&tp=3";}


$itext_maxlength=2048;
include("modules/itext.inc");

  /*rozpoznani prihlaseni*/
  if($login_indicator==1){
  $namecontent="<input type='text' name='name' class='ifield' value='$login_name' disabled>";
  $checkcontent="";
  $codecheck="-1";
  $codecheckimg="";
  $jscodecheck="";
  }
  else{
  $namecontent="<input type='text' maxlength='20' name='name' class='ifield'>";
  $codecheck=code_generate(4);
  $jscodecheck=" || document.form.codecheck.value==''";
  $codecheckimg="&nbsp;<img src='modules/kod.php?n=".$codecheck."' alt='".lang('global_codecheckhelp', 'r')."' title='".lang('global_codecheckhelp', 'r')."'>";
  $checkcontent="
  <tr>
  <td>".lang('global_codecheck', 'r').":</td>
  <td><input type='text' maxlength='8' name='codecheck' class='ifield'></td>
  </tr>
  ";
  }

echo "<hr size='1' color='$st_linecolor'>

<script language='javascript' type='text/javascript'>
function s(id){
document.form.text.value=document.form.text.value+' *'+id+'* ';
}
</script>

<form action='$formaction' method='post' name='form' onsubmit=\"if(document.form.name.value=='' || document.form.text.value==''$jscodecheck){alert('".lang('global_somethingwrong', 'r')."'); return false;}\">
<input type='hidden' name='codecheckr' value='$codecheck'>

<table>

<tr>
<td>".lang('global_yourname', 'r').":</td>
<td>$namecontent</td>
</tr>

".$checkcontent."

<tr valign='top'>
<td>".lang('global_text', 'r').":</td>
<td><textarea name='text' class='itext' id='itext'></textarea></td>
</tr>

<tr>
<td></td>
<td>
<input type='submit' value='".lang('global_send', 'r')." &gt;'>
<input type='reset' value='".lang('global_empty', 'r')."'>
&nbsp;
<a href=\"javascript:s('01');\"><img src=\"pics/smileys/01.gif\" alt=\"01\"></a>
<a href=\"javascript:s('02');\"><img src=\"pics/smileys/02.gif\" alt=\"02\"></a>
<a href=\"javascript:s('03');\"><img src=\"pics/smileys/03.gif\" alt=\"03\"></a>
<a href=\"javascript:s('04');\"><img src=\"pics/smileys/04.gif\" alt=\"04\"></a>
<a href=\"javascript:s('05');\"><img src=\"pics/smileys/05.gif\" alt=\"05\"></a>
<a href=\"javascript:s('06');\"><img src=\"pics/smileys/06.gif\" alt=\"06\"></a>
<a href=\"javascript:s('07');\"><img src=\"pics/smileys/07.gif\" alt=\"07\"></a>
<a href=\"javascript:s('08');\"><img src=\"pics/smileys/08.gif\" alt=\"08\"></a>

$codecheckimg
</td>
</tr>

</table>

</form>
";


/*----VYPIS PRISPEVKU----*/

/*strankovani*/
if(isset($_GET['s'])){
$startpage=$_GET['s'];
$startpage=intval($startpage);
if($startpage!=0){$startpage-=1;}
}
else{
$startpage=0;
}

/*seznam stran*/
$strany=@mysql_query("SELECT id FROM `".tabprefix."-bookcontent` WHERE home=$c_str");
$pocetstran=0;

  /*spocitani stran*/
  while($strana=@mysql_fetch_array($strany)){$pocetstran++;}
  if($pocetstran==0){$pocetstran=1;}
  $pocetstran=$pocetstran/$st_limit;
  $pocetstran=ceil($pocetstran);

/*vypis stran*/
if($startpage>9){$strana=$startpage-5;}
else{$strana=0;}
$odkazu=0;
$back=$startpage-10;
$forward=$startpage+10;
$strankovani="<div class='strany'>".lang('global_page', 'r').": ";

/*rewrite*/
if($st_rewrite==1){$linkhref="$st_gbprefix-$bookanchor4url-$c_str-$back.html";}
else{$linkhref="index.php?str=$c_str&tp=3&s=$back";}

if($startpage>=10){$strankovani.="<a href='$linkhref'>&lt;</a> ";}

while($strana<$pocetstran and $odkazu<=$st_maxpages){
$odkazu++;
$stranaanchor=$strana+1;

/*rewrite*/
if($st_rewrite==1){$linkhref="$st_gbprefix-$bookanchor4url-$c_str-$stranaanchor.html";}
else{$linkhref="index.php?str=$c_str&tp=3&s=$stranaanchor";}

if($strana==$startpage){$strankovani.="<a href='$linkhref' class='active'>$stranaanchor</a> ";}
else{$strankovani.="<a href='$linkhref'>$stranaanchor</a> ";}
$strana++;
}

/*rewrite*/
if($st_rewrite==1){$linkhref="$st_gbprefix-$bookanchor4url-$c_str-$forward.html";}
else{$linkhref="index.php?str=$c_str&tp=3&s=$forward";}

if($startpage<=$pocetstran-10){$strankovani.="<a href='$linkhref'>&gt;</a> ";}
$strankovani.="</div><hr size='1' color='$st_linecolor'>\n";

if($st_pagingmode==1 or $st_pagingmode==3){echo $strankovani;}

echo "<div id='comments'>";

/*vypis prispevku*/
$start=$startpage*$st_limit;
$prispevku=0;
$bookcontent=@mysql_query("SELECT * FROM `".tabprefix."-bookcontent` WHERE home=$c_str ORDER BY id DESC LIMIT $start,$st_limit");
while($prispevek=@mysql_fetch_array($bookcontent)){
  $prispevku++;
  
  /*aplikace smajliku*/
  $smajlici=array(
  "*01*"=>"<img src='pics/smileys/01.gif' alt=':D'>",
  "*02*"=>"<img src='pics/smileys/02.gif' alt=':P'>",
  "*03*"=>"<img src='pics/smileys/03.gif' alt='8)'>",
  "*04*"=>"<img src='pics/smileys/04.gif' alt=';)'>",
  "*05*"=>"<img src='pics/smileys/05.gif' alt=':)'>",
  "*06*"=>"<img src='pics/smileys/06.gif' alt=':S'>",
  "*07*"=>"<img src='pics/smileys/07.gif' alt=':|'>",
  "*08*"=>"<img src='pics/smileys/08.gif' alt=':('>"
  );
  
  $prispevek['text']=strtr($prispevek['text'], $smajlici);
  
  /*nacteni dat autora*/
  $userdata=@mysql_query("SELECT name,rights FROM `".tabprefix."-users` WHERE id=".$prispevek['author']);
  $userdata=@mysql_fetch_array($userdata);
  if($userdata['rights']==""){$userdata['rights']=0;}
  if($login_indicator==1){if($prispevek['author']==$login_id or $login_id==0 or ($userdata['rights']==0 and $login_rights==1) or ($userdata['rights']==1 and $login_rights==2)){$commentdellink=" <a href='modules/gbookdel.php?bid=".$prispevek['id']."' target='_blank' onclick='return ask();'>x</a>";}else{$commentdellink="";}}

  /*rozliseni a vypis prispevku*/
  if($prispevek['author']=="-1"){
  echo "<b title='".lang('gbook_guest', 'r')."'>".$prispevek['name']."</b>, <span title='".$prispevek['ip']."'>".$prispevek['date']."</span>$commentdellink<p>".$prispevek['text']."</p><hr size='1' color='$st_linecolor'>\n";
  }
  else{
  echo "<a href='modules/viewprofile.php?id=".$userdata['name']."' title='".lang('comment_viewprofile', 'r')."'>".$userdata['name']."</a>, <span title='".$prispevek['ip']."'>".$prispevek['date']."</span>$commentdellink<p>".$prispevek['text']."</p><hr size='1' color='$st_linecolor'>\n";
  }
}

echo "</div>";

if(($st_pagingmode==2 or $st_pagingmode==3)and $prispevku!=0){echo $strankovani;}


  /*hlaska o zadnych prispevcich*/
  if($prispevku==0){
  if($startpage==0){lang('gbook_nokit', 'e');}
  else{lang('global_wrongpage', 'e');}
  }


?>
