<?php
$root="../";
include("../_connect.php");

$moduletitle="lastcomments_title";
include("moduleheader.php");
?>

<body>

<div class="board">
<div class="board-padding">
<a href="../">&lt; <?php lang('global_backtomain', 'e'); ?></a><br><br>

<h1><?php lang('lastcomments_title', 'e'); ?></h1>
<p><?php lang('lastcomments_p', 'e'); ?></p>

<div id="results">
<hr size="1" color="<?php echo $st_linecolor; ?>">

<?php

  /*----------ZPRACOVANI VSTUPNICH PARAMETRU STRANKOVANI----------*/
  if(isset($_GET['s'])){
  $startpage=$_GET['s'];
  $startpage=intval($startpage);
  if($startpage!=0){$startpage-=1;}
  }
  else{
  $startpage=0;
  }
  $start=$startpage*$st_limit;

  /*----------VYHLEDANI----------*/
  $comments=@mysql_query("SELECT DISTINCT tp,home FROM `".tabprefix."-comments` ORDER BY id DESC");
  $naslo=0;
  while($comment=@mysql_fetch_array($comments)){

    $naslo++;
    if($naslo>$start and $naslo<=$start+$st_limit){
    
      /*spocitani komentaru*/
      $commentscount=@mysql_query("SELECT id FROM `".tabprefix."-comments` WHERE home=".$comment['home']." AND tp=".$comment['tp']);
      $commentscount_number=0;
      while(@mysql_fetch_array($commentscount)){
      $commentscount_number++;
      }

      /*sestaveni odkazu*/
      $failed=false;

      switch($comment['tp']){

      case 1:
      $title4url=@mysql_query("SELECT anchor,visible FROM `".tabprefix."-menu` WHERE id=".$comment['home']);
      $title4url=@mysql_fetch_array($title4url);
      if($title4url['visible']==1){
        $title4url=$title4url['anchor'];
        $anchor=$title4url;
        $title4url=anchor($title4url);

        $id=$comment['home'];
          if(rewrite==1){$linkhref="../".secprefix."-$title4url-$id.html";}
          else{$linkhref="index.php?str=$id&tp=1";}
      }
      else{
      $failed=true;
      }
      break;

      case 2:
      $title4url=@mysql_query("SELECT title,visible FROM `".tabprefix."-articlecontent` WHERE id=".$comment['home']);
      $title4url=@mysql_fetch_array($title4url);
      if($title4url['visible']==1){
        $title4url=$title4url['title'];
        $anchor=$title4url;
        $title4url=anchor($title4url);

        $id=$comment['home'];
          if(rewrite==1){$linkhref="../".artprefix."-$title4url-$id.html";}
          else{$linkhref="index.php?articleread=$id";}
      }
      else{
      $failed=true;
      }
      break;

      }

      if($failed==false){echo "<a href='$linkhref'><b>$anchor</b></a> ($commentscount_number)<hr size='1' color='$st_linecolor'>\n";}

    }

  }


    /*----------VYPIS STRAN----------*/
    if($naslo!=0){

    $pocetstran=$naslo;
    $pocetstran=$pocetstran/$st_limit;
    $pocetstran=ceil($pocetstran);

    if($startpage>=0 and $startpage<=$pocetstran-1){

    if($startpage>9){$strana=$startpage-5;}
    else{$strana=0;}
    $odkazu=0;
    $back=$startpage-10;
    $forward=$startpage+10;
    echo "<div class='strany'><b>".lang('global_page', 'r')."</b>: ";
    if($startpage>=10){echo "<a href='lastcomments.php?s=$back'>&lt;</a> ";}

    while($strana<$pocetstran and $odkazu<=$st_maxpages){
    $odkazu++;
    $stranaanchor=$strana+1;
    if($strana==$startpage){echo "<a href='lastcomments.php?s=$stranaanchor' class='active'>$stranaanchor</a> ";}
    else{echo "<a href='lastcomments.php?s=$stranaanchor'>$stranaanchor</a> ";}
    $strana++;
    }

    if($startpage<=$pocetstran-10){echo "<a href='lastcomments.php?s=$forward'>&gt;</a> ";}

    echo "</div>";

    }
    else{
    lang('global_wrongpage', 'e');
    }

    }
    else{
    lang('comment_nokit', 'e');
    }

    echo "</div>";

?>

</div>
</div>

</body>
</html>
