<?php $root="./"; include("modules/startup.php"); ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<?php lang('global_headlink', 'e'); echo "\n"; ?>
<head>
<?php include("modules/head.php"); ?>
</head>

<body>

<!--usermenu-->
<div id="usermenu-border">
<div id="usermenu-inside">
<?php include("modules/usermenu.inc"); ?>
</div>
</div>

<div id="container">
<div id="container-padding">

<!--logo-->
<div id="logo">
<a href="./" title="<?php echo $st_title; ?>">
<span><?php echo $st_title; ?></span>
</a>
</div>

<div id="gradient">

  <!--column-first-->
  <div id="column-first">

    <!--menu-->
    <div class="box">
    <menu>
    <?php include("modules/menu.php"); ?>
    </menu>
    </div>
    
    <?php include("modules/boxes.php"); ?>
    
  </div>

  <!--column-main-->  
  <div id="column-main">
  
    <!--content-bigbox-->
    <div class="mainbox">
    <div class="mainbox-padding">
    <?php include("modules/content.php"); ?>
    </div>
    </div>

  </div>

<div class="cleaner"></div>

</div>

</div>
</div>

<!--copyright-line-->
<div id="copyright-border">
<div id="copyright-inside">
<?php lang('global_copyright', 'e'); ?>
</div>
</div>
<br>

</body>
</html>

<?php @mysql_close($connection); ?>
