<?php

/*zjisteni adresy serveru*/
$serverurl=$_SERVER['PHP_SELF'];
$serverurl=substr($serverurl, 1);
$serverurl="http://".getenv('SERVER_NAME')."/".$serverurl;
$serverurl=substr($serverurl, 0, strpos($serverurl, "/patch"));
if(substr($serverurl, -1)=="/"){$serverurl=substr($serverurl, 0, strlen($serverurl)-1);}

@mysql_query("CREATE TABLE `".tabprefix."-boxcontent` (`id` int(11) NOT NULL,`ord` smallint(6) NOT NULL,`visible` tinyint(4) NOT NULL,`panel` tinyint(4) NOT NULL,`title` tinytext character set cp1250 NOT NULL,`showtitle` tinyint(4) NOT NULL,`content` text character set cp1250 NOT NULL) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;");
@mysql_query("INSERT INTO `".tabprefix."-boxcontent` (id,ord,visible,panel,title,showtitle,content) VALUES(1,1,1,0,'Vyhled�v�n�',0,'<!--hcm:fulltextbox:start--><!--hcm:fulltextbox:end-->');");
@mysql_query("CREATE TABLE `".tabprefix."-votecontent` (`id` int(11) NOT NULL,`question` tinytext character set cp1250 NOT NULL,`answers` text character set cp1250 NOT NULL,`votes` text character set cp1250 NOT NULL,`author` int(11) NOT NULL) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;");
@mysql_query("ALTER TABLE `".tabprefix."-articlecontent` ADD `opened` INT NOT NULL AFTER `visible` ;");
@mysql_query("UPDATE `".tabprefix."-articlecontent` SET opened=0;");
@mysql_query("ALTER TABLE `".tabprefix."-users` ADD `year` SMALLINT NOT NULL AFTER `email` , ADD `month` TINYINT NOT NULL AFTER `year` , ADD `sex` TINYINT NOT NULL AFTER `email` ;");
@mysql_query("UPDATE `".tabprefix."-users` SET sex=-1;");
@mysql_query("UPDATE `".tabprefix."-users` SET year=-1;");
@mysql_query("UPDATE `".tabprefix."-users` SET month=-1;");
@mysql_query("INSERT INTO `".tabprefix."-settings` ( `variable` , `value` ) VALUES ('pagingmode', '1');");
@mysql_query("ALTER TABLE `".tabprefix."-articlecontent` ADD `rate_counter` INT NOT NULL , ADD `rate_total` INT NOT NULL ;");
@mysql_query("INSERT INTO `".tabprefix."-settings` ( `variable` , `value` )VALUES ('rss', '0');");
@mysql_query("INSERT INTO `".tabprefix."-settings` ( `variable` , `value` )VALUES ('serverurl', '$serverurl');");

?>
