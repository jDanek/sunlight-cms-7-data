<?php
$root="../";
$moduletitle="bbcode_help_title";
include("../_connect.php");
include("moduleheader.php");
?>

<body>

<div class="board">
<div class="board-padding">

<?php lang('bbcode_help_page', 'e'); ?>

</div>
</div>

</body>
</html>
