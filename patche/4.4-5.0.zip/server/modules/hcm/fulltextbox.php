<?php
$mtmp="
    <div class='search'>
    <form action='".root."modules/fulltext.php' method='get'>
    <input type='text' name='hledej' class='txt'>
    <input type='submit' value='".lang('fulltext_find', 'r')."' class='submit'>
    </form>
    </div>
";
?>
