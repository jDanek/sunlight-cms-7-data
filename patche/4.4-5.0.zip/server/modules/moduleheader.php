<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<?php lang('global_headlink', 'e'); echo "\n"; ?>
<head>
  <meta http-equiv="content-type" content="text/html; charset=windows-1250">
  <meta name="keywords" content="<?php echo $st_keywords; ?>">
  <meta name="description" content="<?php echo $st_description; ?>">
  <meta name="author" content="<?php echo $st_author; ?>">
  <link href="<?php echo $root."modules/templates/$st_template/"; ?>style.css" type="text/css" rel="stylesheet">
  <title><?php echo $st_title." ".$st_separator." ".lang($moduletitle, 'r'); ?></title>
  <?php if(isset($moduleheader_code)){echo $moduleheader_code;} ?>
</head>
