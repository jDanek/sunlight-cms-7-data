<?
/*nacteni prvni strany*/
$default=@mysql_query("SELECT id,type FROM `".tabprefix."-menu`$st_invismain ORDER BY ord LIMIT 1");
$default=mysql_fetch_array($default);
  if($default['type']!=""){
  $defid=$default['id'];
  $deftype=$default['type'];
  $c_str=$defid;
  $c_tp=$deftype;
  }
  else{
  lang('content_nokit', 'e');
  $continue=false;
  }
?>
