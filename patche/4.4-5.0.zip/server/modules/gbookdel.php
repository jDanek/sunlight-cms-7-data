<?php
$root="../";
include("startup.php");

/*nacteni bid*/
if(isset($_GET['bid'])){
$bid=$_GET['bid'];
$bid=intval($bid);
}
else{
$error=lang('global_wrongrequest', 'r');
include("error.php");
exit;
}


/*kontrola loginu*/

  /*nacteni autora*/
  $b_data=@mysql_query("SELECT author,date FROM `".tabprefix."-books` WHERE id=$bid");
  $b_data=@mysql_fetch_array($b_data);
  
  $b_author=$b_data['author'];
  if($b_author!=-1){
  $b_author_rights=@mysql_query("SELECT rights FROM `".tabprefix."-users` WHERE id=$b_author");
  $b_author_rights=@mysql_fetch_array($b_author_rights);
  $b_author_rights=$b_author_rights['rights'];
  }
  else{
  $b_author_rights=0;
  }

  /*smazani z db*/
  if($login_indicator==1 and $b_author!="" and (($b_author==$login_id and time()-$b_data['date']<=$st_postadmintimeout) or ($login_rights==1 or $login_rights==2))){
  
  $continue=false;
  switch($b_author_rights){
  case 0: $continue=true; break;
  case 1: if($login_rights==2 or $login_id==$b_author){$continue=true;} break;
  case 2: if($login_id==$b_author or $login_id==0){$continue=true;} break;
  }

  if($continue==true){
  @mysql_query("DELETE FROM `".tabprefix."-books` WHERE id=$bid");
  $done=1;
  }

  }



$moduletitle="post_delete";
include("moduleheader.php");
?>

<body>

<?php include("msg.php"); ?>

<div class="board">
<div class="board-padding">

<h1><?php lang('post_delete', 'e'); ?></h1>

<?php
if($done!=1){
echo "<b>".lang('global_denied', 'r')."</b>";
}
else{
echo "<b>".lang('global_actiondone', 'r')."</b>";
}
?>

</div>
</div>


</body>
</html>
