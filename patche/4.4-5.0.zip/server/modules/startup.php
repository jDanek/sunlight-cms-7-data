<?php

include($root."_connect.php");
$startupted=true;

/*nastaveni lokalnich promennych ze sessions*/
include($root."modules/sessions.php");

?>
