<?php

/*nastaveni rss modulu*/
$clanku=10;     //pocet zobrazovanych clanku
$jazyk="cs";    //jazyk rss souboru, vetsinou cs

/*pripojeni k db*/
$root="../../";
include("../../_connect.php");

/*vypis hlavicky*/
echo "<";
echo "?xml version=\"1.0\" encoding=\"windows-1250\"?";
echo ">\n";
?>

<rss version="0.91">
<channel>

<?php

echo "
\t<title>$st_title</title>
\t<link>$st_serverurl/</link>
\t<description>$st_description</description>
\t<language>$jazyk</language>\n

<image>
\t<link>$st_serverurl/</link>
\t<title>$st_title</title>
\t<url>$st_serverurl/modules/rss/rss.gif</url>
\t<width>34</width>
\t<height>34</height>
</image>
";

$data=@mysql_query("SELECT title,perex,id FROM `".tabprefix."-articles`$st_futureart2 ORDER BY $st_artorder DESC LIMIT 0, $clanku");
while($item=mysql_fetch_array($data)){
$anchor4url=anchor($item['title']);

if(rewrite==1){$linkhref="$st_serverurl/".artprefix."-$anchor4url-".$item['id'].".html";}
else{$linkhref="$st_serverurl/index.php?art=".$item['id'];}

$item['title']=trim(strip_tags($item['title']));
$item['perex']=trim(strip_tags($item['perex']));

echo "<item>
\t<title>".$item['title']."</title>
\t<description>".$item['perex']."</description>
\t<link>".$linkhref."</link>
</item>\n
";

}

?>

</channel>
</rss>
