<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<?php lang('global_headlink', 'e'); echo "\n"; ?>
<head>
  <meta http-equiv="content-type" content="text/html; charset=windows-1250">
  <link href="style.css" type="text/css" rel="stylesheet">
  <title>SunLight CMS <?php echo $systemversion; ?> - <?php lang('admin_title', 'e'); ?></title>
</head>

<body>
