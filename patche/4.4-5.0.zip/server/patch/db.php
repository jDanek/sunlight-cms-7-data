<?php

@mysql_query("UPDATE `".tabprefix."-settings` SET variable='bbcode' WHERE variable='wmcode';");
@mysql_query("ALTER TABLE `".tabprefix."-votes` ADD `locked` TINYINT NOT NULL AFTER `author`;");
@mysql_query("ALTER TABLE `".tabprefix."-votes` ADD `ipcache` TEXT NOT NULL AFTER `locked`;");
@mysql_query("ALTER TABLE `".tabprefix."-articles` ADD `rate_ipcache` TEXT NOT NULL AFTER `rate_allow`;");

?>
