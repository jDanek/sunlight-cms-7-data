<?php
$root="../";
define('root', $root);

/*instalace db*/
if(isset($_POST['akce'])){

      /*pripojeni*/
      $stopconnecting=true;
      include("../_connect.php");

      /*kontrola existence tabulek*/
      $controldatabase=@mysql_query("SHOW TABLES FROM $c_database");
      $controldatabase_matches=0;
      while($controldatabase_item=mysql_fetch_array($controldatabase)){
      switch($controldatabase_item[0]){
      case tabprefix."-articles":
      case tabprefix."-bans":
      case tabprefix."-books":
      case tabprefix."-boxes":
      case tabprefix."-sections":
      case tabprefix."-comments":
      case tabprefix."-menu":
      case tabprefix."-sboxes":
      case tabprefix."-sboxes-posts":
      case tabprefix."-settings":
      case tabprefix."-users":
      case tabprefix."-votes":
      $controldatabase_matches++; break;
      }
      }

      if($controldatabase_matches==12){
      /*provedeni sql dotazu a zprava*/
      include("db.php");
      @mysql_close($connection);
      $msg="Aktualizace MySQL datab�ze byla provedena. Sma�te slo�ku patch ze serveru!";
      }
      else{
      $msg="Aktualizace selhala - nebyly nalezeny v�echny tabulky.";
      }

}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.21 Transitional//EN">
<html>
<head>
  <meta http-equiv="content-type" content="text/html; charset=windows-1250">
  <link href="../modules/templates/default/style.css" type="text/css" rel="stylesheet">
  <title>Upgrade datab�ze verze 4.4 na 5.0</title>
</head>

<body>

<?php include("../modules/msg.php"); ?>

<div class="board">
<div class="board-padding">


<h1>Upgrade datab�ze verze 4.4 na 5.0</h1>
<p>Tento skript provede p�evod tabulek webMana 4.4 na verzi SunLight CMS 5.0. Pozor!
 Aktualizovat pouze datab�zi nesta��! Je nutn� aktualizovat i syst�mov� soubory webMana.
 V�ce informac� naleznete v souboru <i>ctimne.txt</i>. Po proveden� aktualizace sma�te
 slo�ku <i>patch</i> ze serveru!!</p>
 

<h2>Upozorn�n�</h2>
<p>Tento patch byl testov�n a shled�n pln� funk�n�m, ale p�esto doporu�uji p�ed
 jeho instalac� prov�st z�lohu datab�ze.</p>


<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<input type="hidden" name="akce" value="1">
<input type="submit" value="Prove� &gt;">
</form>


</div>
</div>


</body>
</html>
