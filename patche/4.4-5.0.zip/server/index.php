<?php

/*priprava*/
$root="./"; include("modules/startup.php");

/*vlozeni layoutu*/
include($templatefile);

/*odpojeni*/
mysql_close_connection($connection);

?>
