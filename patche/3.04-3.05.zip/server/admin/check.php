<?php
$root="../";
$administration_indicator=true;
include ("../_connect.php");

session_start();
$login_indicator=$_SESSION['login_aindicator'];
$login_id=$_SESSION['login_aid'];

$login_data=@mysql_query("SELECT rights,name FROM `".tabprefix."-users` WHERE id=$login_id");
$login_data=@mysql_fetch_array($login_data);

$login_name=$login_data['name'];
$login_rights=$login_data['rights'];

if($login_indicator!=1){
header("location: index.php");
exit;
}

else{
  if($login_rights=="" or $login_rights==0 or $login_name==""){
  echo "You're not supposed to be here.";
  unset($_SESSION['login_aindicator']);
  session_destroy();
  exit;
  }
}

?>
