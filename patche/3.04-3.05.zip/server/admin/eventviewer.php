<?php
include("check.php");
include("header.php");
?>

<style>
body {margin: 0px;}
</style>

<table cellspacing="0" cellpadding="2" id="events">
<tr><td class="title"><?php lang('admin_events_time', 'e'); ?></td><td class="title"><?php lang('admin_events_doer', 'e'); ?></td><td class="title"><?php lang('admin_events_event', 'e'); ?></td></tr>

<?php
$admineventscount=0;
$adminevents=@mysql_query("SELECT time,text,doer FROM `".tabprefix."-adminevents` ORDER BY id DESC");
while($adminevent=@mysql_fetch_array($adminevents)){
$doer=@mysql_query("SELECT name FROM `".tabprefix."-users` WHERE id=".$adminevent['doer']);
$doer=@mysql_fetch_array($doer);
$doer=$doer['name'];
echo "<tr><td class='time'>".$adminevent['time']."</td><td class='doer'>".$doer."</td><td>".$adminevent['text']."</td></tr>\n";
$admineventscount++;
}

/*smazani starych udalosti*/
if($admineventscount>50){
$smazpocet=$admineventscount-50;
$smaz=@mysql_query("SELECT id FROM `".tabprefix."-adminevents` LIMIT 50, $smazpocet");
while($smazid=mysql_fetch_array($smaz)){
$id=$smazid['id'];
@mysql_query("DELETE FROM `".tabprefix."-adminevents` WHERE id=$id");
}
}

?>

</table>

</body>
</html>
