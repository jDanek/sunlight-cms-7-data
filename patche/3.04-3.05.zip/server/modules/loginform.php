<?php
if($refer==1){$getrefer="?refer=1";}else{$getrefer="";}
echo "<form action=\"".root."modules/login.php$getrefer\" method=\"post\" name=\"form\" onsubmit=\"document.form.cryptedpass.value=hex_md5(document.form.password.value);document.form.password.value='';\">";
?>

<script type="text/javascript" language="javascript" src="<?php echo $root; ?>modules/md5.js">
</script>

<script type="text/javascript" language="javascript">
document.write("<input type='hidden' name='crypted' value='1'>");
document.write("<input type='hidden' name='cryptedpass' value=''>");
</script>
<noscript>
<input type="hidden" name="crypted" value="0">
</noscript>

<h3><?php lang('global_enterlogin', 'e'); ?></h3>
<p><?php lang('global_enterlogin_p', 'e'); ?> <a href="<?php echo root."modules/register.php"; ?>"><?php lang('global_enterlogin_p_link', 'e'); ?></a></p>

<table>

<tr>
<td><?php lang('global_user', 'e'); ?>&nbsp;&nbsp;</td>
<td><input type="text" size="20" name="name"></td>
</tr>

<tr>
<td><?php lang('global_pass', 'e'); ?></td>
<td><input type="password" size="20" name="password" maxlength="255"></td>
</tr>

<tr>
<td></td>
<td><input type="submit" value="<?php lang('global_continue', 'e'); ?> &gt;"></td>
</tr>

</table>
</form>
<br>
