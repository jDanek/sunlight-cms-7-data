<?php

/*-----funkce anchor-----*/
function anchor($input, $lower=true){

  /*odstraneni diakritiky*/
  $input=strtr($input, " �����؝����������������������������ž�����", "-eeEErRtTzZuUuUuUiIoOaAsSdDyYcCnNaAlLlLrRoO");

  /*odfiltrovani nepovolenych znaku*/
  $letterpos=0;
  $output="";
  while($letterpos<=strlen($input)){
  $letter=substr($input, $letterpos, 1);
  if($letter=="A" or $letter=="a" or $letter=="B" or $letter=="b" or $letter=="C" or $letter=="c" or $letter=="D" or $letter=="d" or $letter=="E" or $letter=="e" or $letter=="F" or $letter=="f" or $letter=="G" or $letter=="g" or $letter=="H" or $letter=="h" or $letter=="I" or $letter=="i" or $letter=="J" or $letter=="j" or $letter=="K" or $letter=="k" or $letter=="L" or $letter=="l" or $letter=="M" or $letter=="m" or $letter=="N" or $letter=="n" or $letter=="O" or $letter=="o" or $letter=="P" or $letter=="p" or $letter=="Q" or $letter=="q" or $letter=="R" or $letter=="r" or $letter=="S" or $letter=="s" or $letter=="T" or $letter=="t" or $letter=="U" or $letter=="u" or $letter=="V" or $letter=="v" or $letter=="W" or $letter=="w" or $letter=="X" or $letter=="x" or $letter=="Y" or $letter=="y" or $letter=="Z" or $letter=="z" or $letter=="0" or $letter=="1" or $letter=="2" or $letter=="3" or $letter=="4" or $letter=="5" or $letter=="6" or $letter=="7" or $letter=="8" or $letter=="9" or $letter=="_" or $letter=="-" or $letter=="."){$output.=$letter;}
  $letterpos++;
  }
  
  /*odfiltrovani opakovanych pomlcek, podtrzitek a tecek*/
  $count=0;
  $double="--";
  while($count!=3){
  
  $letterpos=0;
  while($letterpos<=strlen($output)){
  $letter=substr($output, $letterpos, 2);
    if($letter==$double){
    $output_start=substr($output, 0, $letterpos+1);
    $output_end=substr($output, $letterpos+2);
    $output=$output_start.$output_end;
    $letterpos-=1;
    }
  $letterpos++;
  }
  
  /*odstraneni pomlcek, podtrzitek a tecek ze zacatku a konce*/
  $letterpos=0;
  while($letterpos<=strlen($output)){
  if(substr($output, 0, 1)=="-"){$output=substr($output, 1); $letterpos=-1;}
  if(substr($output, -1)=="-"){$output=substr($output, 0, -1); $letterpos=-1;}
  if(substr($output, 0, 1)=="_"){$output=substr($output, 1); $letterpos=-1;}
  if(substr($output, -1)=="_"){$output=substr($output, 0, -1); $letterpos=-1;}
  if(substr($output, 0, 1)=="."){$output=substr($output, 1); $letterpos=-1;}
  if(substr($output, -1)=="."){$output=substr($output, 0, -1); $letterpos=-1;}
  $letterpos++;
  }

  $count++;
  if($count==1){$double="__";}
  else{$double="..";}
  
  }

if($lower==true){$output=strtolower($output);}
return $output;

}




/*-----lang funkce-----*/
$langfile=root."modules/language/".langfile;
define('langfile_load', true);

if(!file_exists($langfile)){
$langfile_default=root."modules/language/default.htm";
  if(!file_exists($langfile_default)){
  define('langfile_load', false);
  }
  else{
  $langfile=$langfile_default;
  }
}

  if(langfile_load==true){define('langfilecontent', file_get_contents($langfile));}
  else{define('langfilecontent', "");}

function lang($input, $param='r', $langfile=langfilecontent, $failed=langfile_load){

  /*vyhledani fraze souboru*/
  if($failed!=false){
  $langfile=langfilecontent;
  $startpos=strpos($langfile, "<$input>");
  $endpos=strpos($langfile, "</$input>");
  }

  /*nalezeni a vypis*/
  if($startpos!==false and $endpos!==false and $failed!=false){
  $start=$startpos+strlen("<$input>");
  $end=$endpos-$start;
  $langfile=substr($langfile, $start, $end);
     switch($param){
     case 'r': return $langfile; break;
     case 'e': echo $langfile; break;
      }
  }
  else{
     $lerror="LANGFILE_ERROR";
     switch($param){
     case 'r': return $lerror; break;
     case 'e': echo $lerror; break;
     }
  }

}



/*funkce pro zpracovani perexu*/
function perexedit($input){
$length=strlen($input);
$input=substr($input, 0, 128);
$input=strip_tags($input);
if($length>128){$input=$input."...";}
return $input;
}



/*-----funkce pro generovani kodu-----*/

  /*generovani*/
  function code_generate($length) {
  $x=0;
  $code="";
  while($x!=$length){
  $code.=mt_rand(1, 9);
  $x++;
  }
  $code=$code;
  
  $x=0;
  $output="";
  while($x!=$length){
  $output.=strrev(ord(substr($code, $x, 1))+4)."-";
  $x++;
  }
  $output=substr($output, 0, strlen($output)-1);
  $output=strrev($output);
  return $output;
  }

  /*dekodovani*/
  function code_decode($input){
  $input=strrev($input);
  $tokenize=strtok($input, "-");
  while($tokenize){
  $step=chr(strrev($tokenize)-4);
  $output.=$step;
  $tokenize=strtok("-");
  }

  return $output;
  }




/*-----funkce pro rozpoznani nebezpecne pripony-----*/
function uglysuffix($input){
$output=true;
$dotpos=strrpos($input, ".")+1;
$pripona=substr($input, $dotpos);
$pripona=strtolower($pripona);

switch($pripona){
case "php": break;
case "php3": break;
case "php4": break;
case "php5": break;
case "phtml": break;
case "py": break;
case "asp": break;
case "cgi": break;
case "shtml": break;
case "htaccess": break;
default: $output=false; break;
}

return $output;
}




/*-----funkce pro aplikaci modulu-----*/
function applyhcm($input, $php=false){

  $output="##".$input;


    /*lastarticles modul*/
    $mpos1=strpos($output, "<!--hcm:latart:start-->");
    $mpos2=strpos($output, "<!--hcm:latart:end-->");
    $mparam=substr($output, $mpos1+23, $mpos2-($mpos1+23));
    $mparam=trim($mparam);
    $mresult="";
    if($mpos1 and $mpos2 and $mparam!=""){
    $start=substr($output, 0, $mpos1);
    $end=substr($output, $mpos2+21);
    $mparam=floatval($mparam);
    $mparam=addslashes($mparam);

      $mdata=@mysql_query("SELECT title,perex,id,author,date,comment FROM `".tabprefix."-articlecontent` ORDER BY id DESC LIMIT 0, $mparam");
      while($mitem=mysql_fetch_array($mdata)){
      $anchor4url=anchor($mitem['title']);
        /*rewrite*/
        if(rewrite==1){$linkhref=artprefix."-$anchor4url-".$mitem['id'].".html";}
        else{$linkhref="index.php?articleread=".$mitem['id'];}
        
        /*spocitani komentaru*/
        $a_commentscount_code="";
        if($mitem['comment']==1){
        $a_commentscount=@mysql_query("SELECT id FROM `".tabprefix."-comments` WHERE home=".$mitem['id']." AND tp=2");
        $a_commentscount_number=0;
        while($commentscount_item=@mysql_fetch_array($a_commentscount)){
        $a_commentscount_number++;
        }
        $a_commentscount_code=" | <b>".lang('article_totalcomments', 'r').":</b> $a_commentscount_number";
        }
        
        $author=@mysql_fetch_array(@mysql_query("SELECT name FROM `".tabprefix."-users` WHERE id=".$mitem['author']));
        $author=$author['name'];
        
      $mtmp.="<a href='$linkhref'><h2>".$mitem['title']."</h2></a><p>".perexedit($mitem['perex'])."<br><span class='info'><b>".lang('article_author', 'r').":</b> $author | <b>".lang('article_posted', 'r').":</b> ".$mitem['date'].""."$a_commentscount_code</span></p>\n";
      }
      $mresult=$start."<div>".$mtmp."</div>".$end;
    }
    if($mresult!=""){$output=$mresult;}
    
    
    /*lastarticles2 modul*/
    $mpos1=strpos($output, "<!--hcm:latart2:start-->");
    $mpos2=strpos($output, "<!--hcm:latart2:end-->");
    $mparam=substr($output, $mpos1+24, $mpos2-($mpos1+24));
    $mparam=trim($mparam);
    $mresult="";
    if($mpos1 and $mpos2 and $mparam!=""){
    $start=substr($output, 0, $mpos1);
    $end=substr($output, $mpos2+22);
    $mparam=floatval($mparam);
    $mparam=addslashes($mparam);

      $mdata=@mysql_query("SELECT title,id FROM `".tabprefix."-articlecontent` ORDER BY id DESC LIMIT 0, $mparam");
      while($mitem=mysql_fetch_array($mdata)){
      $anchor4url=anchor($mitem['title']);
        /*rewrite*/
        if(rewrite==1){$linkhref=artprefix."-$anchor4url-".$mitem['id'].".html";}
        else{$linkhref="index.php?articleread=".$mitem['id'];}
      $mtmp.="<a href='$linkhref'><b>".$mitem['title']."</b></a><hr size='1' color='".linecolor."'>\n";
      }
      $mresult=$start."<div>".$mtmp."</div>".$end;
    }
    if($mresult!=""){$output=$mresult;}



    /*lastcomments modul*/
    $mpos1=strpos($output, "<!--hcm:latcom:start-->");
    $mpos2=strpos($output, "<!--hcm:latcom:end-->");
    $mparam=substr($output, $mpos1+23, $mpos2-($mpos1+23));
    $mparam=trim($mparam);
    $mparam=floatval($mparam);
    $mresult="";
    if($mpos1 and $mpos2 and $mparam!=""){
    $start=substr($output, 0, $mpos1);
    $end=substr($output, $mpos2+21);

  $comments=@mysql_query("SELECT DISTINCT tp,home FROM `".tabprefix."-comments` ORDER BY id DESC LIMIT 0, $mparam");
  while($comment=@mysql_fetch_array($comments)){


      /*sestaveni odkazu*/
      switch($comment['tp']){

      case 1:
      $title4url=@mysql_query("SELECT anchor FROM `".tabprefix."-menu` WHERE id=".$comment['home']);
      $title4url=@mysql_fetch_array($title4url);
      $title4url=$title4url['anchor'];
      $anchor=$title4url;
      $title4url=anchor($title4url);

      $id=$comment['home'];
        if($st_rewrite==1){$linkhref="../$st_secprefix-$title4url-$id.html";}
        else{$linkhref="../index.php?str=$id&tp=1";}
      break;

      case 2:
      $title4url=@mysql_query("SELECT title FROM `".tabprefix."-articlecontent` WHERE id=".$comment['home']);
      $title4url=@mysql_fetch_array($title4url);
      $title4url=$title4url['title'];
      $anchor=$title4url;
      $title4url=anchor($title4url);

      $id=$comment['home'];
        if($st_rewrite==1){$linkhref="../$st_artprefix-$title4url-$id.html";}
        else{$linkhref="../index.php?articleread=$id";}
      break;

      }

      $mresult.="<a href='$linkhref'><b>$anchor</b></a><br>\n";

  }
  
  $mresult=$start."<div>".$mresult."</div>".$end;

    }
    if($mresult!=""){$output=$mresult;}



    /*mailform modul*/
    $mpos1=strpos($output, "<!--hcm:mailform:start-->");
    $mpos2=strpos($output, "<!--hcm:mailform:end-->");
    $mparam=substr($output, $mpos1+25, $mpos2-($mpos1+25));
    $mparam=trim($mparam);
    $mresult="";
    if($mpos1 and $mpos2 and $mparam!=""){
    $start=substr($output, 0, $mpos1);
    $end=substr($output, $mpos2+23);
    $mparam=addslashes($mparam);
    $mparam=strtr($mparam, "@", "#");

      $codecheck=code_generate(4);
      
      $mtmp="
      <form action='".root."modules/hcm/mailform.php' method='post'>
      <input type='hidden' name='receiver' value='$mparam'>
      <input type='hidden' name='codecheckr' value='$codecheck'>

      <table>
      
      <tr>
      <td><b>".lang('global_email', 'r')."</b></td>
      <td><input type='text' name='sender' class='ifieldsmall' maxlength='128' value='@'></td>
      </tr>
      
      <tr>
      <td><b>".lang('global_subject', 'r')."</b></td>
      <td><input type='text' name='subject' class='ifieldsmall' maxlength='128'></td>
      </tr>
      
      <tr valign='top'>
      <td><b>".lang('global_text', 'r')."</b></td>
      <td><textarea name='text' class='itextsmall' id='itext'></textarea></td>
      </tr>
      
      <tr>
      <td><b>".lang('global_codecheck', 'r')."</b></td>
      <td><input type='text' name='codecheck' maxlength='8' class='ifieldsmall'></td>
      </tr>
      
      <tr>
      <td></td>
      <td><img src='".root."modules/kod.php?n=".$codecheck."' alt='".lang('global_codecheckhelp', 'r')."' title='".lang('global_codecheckhelp', 'r')."'></td>
      </tr>
      
      <tr>
      <td></td>
      <td>
      <input type='submit' value='".lang('global_send', 'r')."'>
      <input type='reset' value='".lang('global_reset', 'r')."'>
      </td>
      </tr>
      
      </table>
      </form>
      ";
      $mresult=$start."<div>".$mtmp."</div>".$end;
    }
    if($mresult!=""){$output=$mresult;}



    /*php modul*/
    if($php==true){
    $mpos1=strpos($output, "<!--hcm:php:start-->");
    $mpos2=strpos($output, "<!--hcm:php:end-->");
    $mparam=substr($output, $mpos1+20, $mpos2-($mpos1+20));
    $mparam=trim($mparam);
    $mresult="";
    if($mpos1 and $mpos2 and $mparam!=""){
    $start=substr($output, 0, $mpos1);
    $end=substr($output, $mpos2+18);

    eval($mparam);
    $mresult=$start.$end;

    }
    if($mresult!=""){$output=$mresult;}
    }



    /*galerie modul*/
    $mpos1=strpos($output, "<!--hcm:gallery:start-->");
    $mpos2=strpos($output, "<!--hcm:gallery:end-->");
    $mparam=substr($output, $mpos1+24, $mpos2-($mpos1+24));
    $mparam=trim($mparam);
    $mresult="";
    if($mpos1 and $mpos2 and $mparam!=""){
    $start=substr($output, 0, $mpos1);
    $end=substr($output, $mpos2+22);

    /*zpracovani cesty, sestaveni kodu*/
    if(substr($mparam, -1)!="/"){$mparam.="/";}
    $dir=$mparam;
    if(file_exists(root.$dir) and is_dir(root.$dir)){

    $gcode="";
    $handle=opendir(root.$dir);
    while($item=readdir($handle)){
    $suffix=strrpos($item, ".");
    $suffix=substr($item, $suffix+1);
    $suffix=strtolower($suffix);
    if($item=="." or $item==".." or is_dir(root.$dir.$item) or !($suffix=="jpeg" or $suffix=="jpg" or $suffix=="gif" or $suffix=="png")){continue;}
    $item_size=ceil(filesize(root.$dir.$item)/1024);
    $gcode.="<a href='".root."$dir$item' target='_blank' title='$item | ".$item_size."kB'><img src='".root."modules/hcm/gallery.php?path=$dir$item' border='0'></a>\n";
    }
    closedir($handle);

    }

    $mresult=$start."<div>".$gcode."</div>".$end;

    }
    if($mresult!=""){$output=$mresult;}



    /*galerie2 modul*/
    $mpos1=strpos($output, "<!--hcm:gallery2:start-->");
    $mpos2=strpos($output, "<!--hcm:gallery2:end-->");
    $mparam=substr($output, $mpos1+25, $mpos2-($mpos1+25));
    $mparam=trim($mparam);
    $mresult="";
    if($mpos1 and $mpos2 and $mparam!=""){
    $start=substr($output, 0, $mpos1);
    $end=substr($output, $mpos2+23);

    /*zpracovani cesty, sestaveni kodu*/
    if(substr($mparam, -1)!="/"){$mparam.="/";}
    $dir=$mparam;
    $fulldir=$dir."full/";
    $prevdir=$dir."prev/";
    
    if(file_exists(root.$dir) and is_dir(root.$dir) and file_exists(root.$fulldir) and is_dir(root.$fulldir) and file_exists(root.$prevdir) and is_dir(root.$prevdir)){
    
    $gcode="";
    $handle=opendir(root.$fulldir);
    while($item=readdir($handle)){
    $suffix=strrpos($item, ".");
    $suffix=substr($item, $suffix+1);
    $suffix=strtolower($suffix);
    if($item=="." or $item==".." or is_dir(root.$fulldir.$item) or !($suffix=="jpeg" or $suffix=="jpg" or $suffix=="gif" or $suffix=="png") or !file_exists(root.$prevdir.$item)){continue;}
    $item_size=ceil(filesize(root.$fulldir.$item)/1024);
    $gcode.="<a href='".root."$fulldir$item' target='_blank' title='$item | ".$item_size."kB'><img src='".root."$prevdir$item' border='0'></a>\n";
    }
    closedir($handle);

    
    }

    $mresult=$start."<div>".$gcode."</div>".$end;

    }
    if($mresult!=""){$output=$mresult;}
    

    /*randomimage modul*/
    $mpos1=strpos($output, "<!--hcm:randomimg:start-->");
    $mpos2=strpos($output, "<!--hcm:randomimg:end-->");
    $mparam=substr($output, $mpos1+26, $mpos2-($mpos1+26));
    $mparam=trim($mparam);
    $mresult="";
    if($mpos1 and $mpos2 and $mparam!=""){
    
    $start=substr($output, 0, $mpos1);
    $end=substr($output, $mpos2+24);
    if(substr($mparam, -1)!="/"){$mparam.="/";}
    $dir=$mparam;
    
      if(file_exists(root.$dir) and is_dir(root.$dir)){
      
      $handle=opendir(root.$dir);
      $items=array();
      $itemnum=0;
      while($item=readdir($handle)){
      $suffix=strrpos($item, ".");
      $suffix=substr($item, $suffix+1);
      $suffix=strtolower($suffix);
      if($item=="." or $item==".." or is_dir(root.$item) or !($suffix=="jpeg" or $suffix=="jpg" or $suffix=="gif" or $suffix=="png")){continue;}
      $items[$itemnum]=$item;
      $itemnum++;
      }
      
      closedir($handle);
      
      if($itemnum!=0){
      $ritem=array_rand($items);
      $rname=$items[$ritem];
      $mresult=$start."<img src='".root.$dir.$rname."'>".$end;
      }
      
      }

    }
    if($mresult!=""){$output=$mresult;}



    /*randomtext modul*/
    $mpos1=strpos($output, "<!--hcm:randomtxt:start-->");
    $mpos2=strpos($output, "<!--hcm:randomtxt:end-->");
    $mparam=substr($output, $mpos1+26, $mpos2-($mpos1+26));
    $mparam=trim($mparam);
    $mresult="";
    if($mpos1 and $mpos2 and $mparam!=""){
    
    $start=substr($output, 0, $mpos1);
    $end=substr($output, $mpos2+24);
    if(substr($mparam, -1)!="/"){$mparam.="/";}
    $dir=$mparam;
    
      if(file_exists(root.$dir) and is_dir(root.$dir)){
      
      $handle=opendir(root.$dir);
      $items=array();
      $itemnum=0;
      while($item=readdir($handle)){
      $suffix=strrpos($item, ".");
      $suffix=substr($item, $suffix+1);
      $suffix=strtolower($suffix);
      if($item=="." or $item==".." or is_dir(root.$item) or !($suffix=="txt" or $suffix=="html" or $suffix=="htm")){continue;}
      $items[$itemnum]=$item;
      $itemnum++;
      }
      
      closedir($handle);
      
      if($itemnum!=0){
      $ritem=array_rand($items);
      $rname=$items[$ritem];
      $rcontent=file_get_contents(root.$dir.$rname);
      $mresult=$start.$rcontent.$end;
      }
      
      }

    }
    if($mresult!=""){$output=$mresult;}

    

  $output=substr($output, 2);
  return $output;

}

?>
