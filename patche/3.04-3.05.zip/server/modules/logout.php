<?php
session_start();
unset($_SESSION['login_indicator']);
unset($_SESSION['login_id']);
unset($_SESSION['login_name']);
unset($_SESSION['login_rights']);
session_destroy();

if($securitylogout==false){
  $referer=$_SERVER['HTTP_REFERER'];
  if($referer!=""){header("location: $referer");}
  else{header("location: ../");}
  exit;
}
?>
