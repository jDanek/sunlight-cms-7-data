<?php
$settings=@mysql_query("SELECT * FROM `".tabprefix."-settings`");
while($item=@mysql_fetch_array($settings)){

$variable=$item['variable'];
$value=$item['value'];

switch($variable){
case "redcanup": $st_redcanup=$value; break;
case "wysiwyg": $st_wysiwyg=$value; break;
case "rewrite": $st_rewrite=$value; break;
case "atmask": $st_atmask=$value; break;
case "langfile": $st_langfile=$value; break;
case "separator": $st_separator=$value; break;
case "linecolor": $st_linecolor=$value; break;
case "limit": $st_limit=$value; break;
case "title": $st_title=$value; break;
case "author": $st_author=$value; break;
case "keywords": $st_keywords=$value; break;
case "description": $st_description=$value; break;
case "maxpages": $st_maxpages=$value; break;
}

}

/*definovani globalnich*/
define('langfile', $st_langfile);
define('linecolor', $st_linecolor);
define('rewrite', $st_rewrite);
?>
