<?php
@mysql_query("ALTER TABLE `".tabprefix."-articlecontent` ADD `visible` TINYINT NOT NULL ;");
@mysql_query("UPDATE `".tabprefix."-articlecontent` SET visible=1");
@mysql_query("INSERT INTO `".tabprefix."-settings` (variable,value) VALUES ('maxpages','20');");
?>
