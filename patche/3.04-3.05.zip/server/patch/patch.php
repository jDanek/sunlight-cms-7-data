<?php
$root="../";
define('root', $root);
define('langfile', 'default.htm');
include("../modules/funcload.php");

/*instalace db*/
if(isset($_POST['akce'])){

      /*pripojeni*/
      $stopconnecting=true;
      include("../_connect.php");

      /*kontrola existence tabulek*/
      $controldatabase=@mysql_query("SHOW TABLES FROM $c_database");
      $controldatabase_matches=0;
      while($controldatabase_item=mysql_fetch_array($controldatabase)){
      switch($controldatabase_item[0]){
      case tabprefix."-adminevents": $controldatabase_matches++; break;
      case tabprefix."-articlecontent": $controldatabase_matches++; break;
      case tabprefix."-bookcontent": $controldatabase_matches++; break;
      case tabprefix."-blockedip": $controldatabase_matches++; break;
      case tabprefix."-codecontent": $controldatabase_matches++; break;
      case tabprefix."-comments": $controldatabase_matches++; break;
      case tabprefix."-menu": $controldatabase_matches++; break;
      case tabprefix."-settings": $controldatabase_matches++; break;
      case tabprefix."-users": $controldatabase_matches++; break;
      }
      }

      if($controldatabase_matches==9){

      /*provedeni sql dotazu a zprava*/
      include("db.php");
      @mysql_close($connection);
      $msg="Aktualizace MySQL datab�ze prob�hla �sp�n�. Sma�te slo�ku patch ze serveru!";
      }
      else{
      $msg="Aktualizace selhala. matches=$controldatabase_matches";
      }

}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta http-equiv="content-type" content="text/html; charset=windows-1250">
  <link href="style.css" type="text/css" rel="stylesheet">
  <title>Upgrade datab�ze verze 3.04 na 3.05</title>
</head>

<body>

<?php include("../modules/msg.php"); ?>

<div class="board">
<div class="board-padding">


<h1>Upgrade datab�ze verze 3.04 na 3.05</h1>
<p>Tento skript provede aktualizaci tabulek verze 3.04 na 3.05 v MySQL datab�zi. Pozor!
 Aktualizovat pouze datab�zi nesta��! Je nutn� aktualizovat i syst�mov� soubory webMana.
 V�ce informac� naleznete v souboru <i>ctimne.txt</i>. Po proveden� aktualizace sma�te
 slo�ku <i>patch</i> ze serveru!!</p>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<input type="hidden" name="akce" value="1">
<input type="submit" value="Prove� &gt;">
</form>


</div>
</div>


</body>
</html>
