<?php

/*-----header pro kodovani-----*/
header("Content-Type: text/html; charset=windows-1250");


/*-----zakazane parametry-----*/
$denied_params=array("rootpath", "indicators", "content_preload", "securitylogout", "installmode", "gzip", "testquery", "root", "login_indicator", "login_id", "login_name", "login_rights");
foreach($denied_params as $param){if(isset($_GET[$param]) or isset($_POST[$param])){exit;}}


/*-----definovani root-----*/
if(isset($rootpath['path'])){define('root', $rootpath['path']);}
else{define('root', "./");}


/*-----vlozeni pristupovych dat-----*/
include(root."_access.php");


/*-----aktivace gzip-----*/
if($gzip==true){if(!ini_get('zlib.output_compression')){ob_start("ob_gzhandler");}}


/*-----definovani globalni promenne prefixu-----*/
if($c_tabprefix!=""){
define('tabprefix', $c_tabprefix);
}
else{
$error="Musite zadat prefix (promenna c_tabprafix)!.";
include(root."modules/error.php");
exit;
}


/*-----pripojeni k mysql-----*/
$connection=@mysql_connect($c_server, $c_user, $c_password);
@mysql_query("set names 'cp1250'");
$db=@mysql_select_db($c_database);

  /*kontrola*/
  if(!$connection or !$db){
  $error="Pripojeni k databazi se nezdarilo, <b>chyba je pravdepodobne v pristupovych udajich</b>. Odpoved MySQL serveru muzete videt nize.";
  include(root."modules/error.php");
  echo "<pre>".mysql_error()."</pre>";
  exit;
  }

if(!isset($indicators['installmode'])){

  /*-----kontrola, zda neexistuje slozka install-----*/
  if(file_exists(root."install/")){
  $error="Prosim zkontrolujte, zda se adresar <i>install</i> nenachazi na serveru a pripadne jej smazte.";
  include(root."modules/error.php");
  exit;
  }


  /*-----kontrola, zda neexistuje slozka patch-----*/
  if(file_exists(root."patch/")){
  $error="Prosim zkontrolujte, zda se adresar <i>patch</i> nenachazi na serveru a pripadne jej smazte.";
  include(root."modules/error.php");
  exit;
  }
  
  
  /*-----testovaci dotaz-----*/
  if($testquery==true){
  $test=@mysql_query("SELECT COUNT(*) FROM `".tabprefix."-settings`");
  if(@mysql_result($test, 0)!=49){$error="Zvolena databaze <i>$c_database</i> neobsahuje vsechny tabulky systemu nebo neni jeji verze shodna s verzi systemu."; include(root."modules/error.php"); exit;}
  }

}


/*-----nacteni nastaveni a systemovych promennych, kontrola nastaveni -----*/
include(root."modules/setload.php");

  /*-----systemove promenne-----*/
  define('systemversion', "6.0");
  define('systembuild', "1");
  define('systemverb', systemversion.".".systembuild);
  $trans=array("<" => "&lt;",">"=>"&gt;","\""=>"&quot;","'"=>"&#39;","&"=>"&amp;");
  $antislash=array("/"=>"-","\\"=>"-");
  $at=array("@"=>$st_atmask);
  $atback=array($st_atmask=>"@");

    /*konstanty*/
    define("rewritesuffix", ".html");
    define("secprefix", "sekce");
    define("catprefix", "kategorie");
    define("artprefix", "clanek");
    define("bookprefix", "kniha");
    define("modprefix", "modul");
    define("forumprefix", "forum");
    define("galprefix", "galerie");
    define("gpostprefix", "rozcestnik");
    define("systemuid", md5($c_tabprefix."_".$c_database)."_");

    /*-----kontrola rewrite pluginu-----*/
    if(!file_exists(root.".htaccess") and $st_rewrite==1){$st_rewrite=0;}
    define('rewrite', $st_rewrite);

    /*-----kontrola editoru-----*/
    switch($st_editor){
    case 1: if(!file_exists(root."admin/tinymce.smf")){$st_editor=0;} break;
    case 2: if(!file_exists(root."admin/texy.smf")){$st_editor=0;} break;
    }
    define('editor', $st_editor);

    /*nacteni funkci*/
    include(root."modules/funcload.php");

    /*zruseni pristupovych udaju*/
    if(!isset($indicators['installmode'])){
    unset($c_server);
    unset($c_user);
    unset($c_password);
    unset($c_database);
    }

    /*kontrola verze jazykoveho souboru*/
    if(lang('_slfver')!=systemversion){$error="Zvoleny jazykovy soubor '$st_langfile' neni kompatibilni s touto verzi systemu!"; include(root."modules/error.php"); exit;}


/*-----motiv-----*/
$set_template=root."modules/templates/$st_template/layout.php";
$indicators['templatefile_loaded']=true;
if(file_exists($set_template)){$templatefile=$set_template;}
else{
$seektemplate=opendir(root."modules/templates/");
$seektemplate_index=0;
$seektemplate_array=array();
  while($seektemplate_item=readdir($seektemplate)){
  if($seektemplate_item!="." and $seektemplate_item!=".." and is_dir(root."modules/templates/$seektemplate_item") and file_exists(root."modules/templates/$seektemplate_item/layout.php")){
  $seektemplate_array[$seektemplate_index]=$seektemplate_item;
  $seektemplate_index++;
  }
  }
  if(count($seektemplate_array)!=0){$templatefile=root."modules/templates/".$seektemplate_array[0]."/layout.php"; $st_template=$seektemplate_array[0];}
  else{$templatefile=""; $st_template="";}
}
define('template', $st_template);

  /*nacteni nastaveni motivu*/
  $allowed_params=array("version","item_title_tag","item_perex_tag","item_info_tag","item_info_highlight_tag","item_info_separator","boxes_ancestor_tag","boxes_child_tag","boxes_child_content_tag","boxes_title_tag","boxes_title_position","boxes_title_content_tag","boxes_bottom_tag","boxes_bottom_position","boxes_two_columns","menu_ancestor_tag","menu_child_tag","menu_suffix","usermenu_item_prefix","usermenu_item_suffix","usermenu_trimitems","usermenu_showname","smileys_tag","auto_write_headings");
  
  if($st_template!=""){
  $config=substr($templatefile, 0, strpos($templatefile, "layout.php"));
  $config.="config.ini";
  $config=@file_get_contents($config);
  $config=explode("\n", $config);
  $counter=0;
  foreach($config as $line){
    if(ord($line)!=13 and ord($line)!=0 and $line!=""){
      $aspos=strpos($line, "=");
      $linear[0]=substr($line, 0, $aspos);
      $linear[1]=substr($line, $aspos+1);
      if(in_array(anchor($linear[0]), $allowed_params)){
        $newvar="template_".anchor($linear[0]);
        if(@!defined($newvar)){@define($newvar, strtolower(trim(trim($linear[1]), "'\"")));}
      }
    }
  }

  /*kontrola nastaveni vsech parametru*/
  $forced_params_passed=true;
  foreach($allowed_params as $param){if(!defined("template_".$param)){$forced_params_passed=false; break;}}

    /*zpracovani hodnot*/
    if(!isset($indicators['administration'])){
    if($forced_params_passed!=true){$error="Zvoleny motiv <i>$st_template</i> nema nastaveny vsechny parametry!"; include(root."modules/error.php"); exit;}
    if(floatval(template_version)!=systemversion){$error="Zvoleny motiv <i>$st_template</i> neni kompatibilni s touto verzi systemu! Je urcen pro verzi ".$template['version']."."; include(root."modules/error.php"); exit;}
    }

  }
  if($st_smileys==1){$smajlici=getsmileys();}

  /*error*/
  if($st_template=="" and !isset($indicators['administration'])){
  $error="Nebyl nalezen zadny motiv vzhledu (slozka modules/templates/)!";
  include(root."modules/error.php");
  exit;
  }


/*-----kontrola ip, blokovani-----*/
if(!isset($indicators['administration']))
$addr=$_SERVER['REMOTE_ADDR'];
$blockedips=@mysql_query("SELECT adress FROM `".tabprefix."-bans`");
while($blockedip=@mysql_fetch_array($blockedips)){
  $blockedip_match=strpos("##".$addr, $blockedip['adress']);
  if($blockedip_match==2){exit;}
}

?>
