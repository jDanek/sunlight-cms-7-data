<?php

/*sestaveni akce formulare*/
if(isset($_GET['art'])){
$home=$a_art; $tp=2;
$formaction=artrewrite($a_art, $a_title, false);
}
else{
$home=$c_str; $tp=1;
$formaction=secrewrite($c_str, $sectitle, false);
}

if($login_indicator==1){

/*bbcode*/
if($st_bbcode==1){$bbcode_help="&nbsp;<a href='".modrewrite("bbcodehelp")."' class='bbcodehelp'>[?]</a>";}else{$bbcode_help="";}

/*formular*/
echo
textarea_limit(2048, "commentform").
textarea_smileys("commentform", "text").
textarea_answer("commentform", "text").
"
<br /><div class='hr'><hr /></div>
<h2>".lang('comment_title')."</h2>

<form action='modules/post.php' method='post' name='commentform' onsubmit=\"if(document.commentform.subject.value=='' ||  document.commentform.text.value==''){alert('".lang('global_somethingwrong')."'); return false;}\">
<input type='hidden' name='returnurl' value='$formaction' />
<input type='hidden' name='posttype' value='1' />
<input type='hidden' name='home' value='$home' />
<input type='hidden' name='tp' value='$tp' />

<table>

<tr>
<td>".lang('global_subject')."</td>
<td><input type='text' maxlength='32' name='subject' class='ifield' /></td>
</tr>

<tr valign='top'>
<td>".lang('global_text')."</td>
<td><textarea name='text' class='itext' id='itext' rows='6' cols='45'></textarea></td>
</tr>

<tr>
<td></td>
<td>
<input type='submit' value='".lang('global_send')." &gt;' />
<input type='reset' value='".lang('global_empty')."' onclick='return ask();' />$bbcode_help

".getsmileyslist()."

</td>
</tr>

</table>

</form>
";

}
else{
echo "<br /><div class='hr'><hr /></div>\n<h2>".lang('comment_title')."</h2><p>".lang('comment_denied')."</p>";
$refer=1;
include("modules/loginform.php");
}

/*nadpis2*/
echo "
<h2>".lang('comment_title2')."</h2>
<div class='hr'><hr /></div>
<div id='posts'>
";

/*vypis komentaru*/
$comments=@mysql_query("SELECT * FROM `".tabprefix."-comments` WHERE home=$home AND tp=$tp ORDER BY id DESC");
  $commentcount=0;
  while($c_item=@mysql_fetch_array($comments)){
  
  /*nacteni dat autora*/
  if($c_item['author']!=-2){
  $userdata=@mysql_query("SELECT name,rights FROM `".tabprefix."-users` WHERE id=".$c_item['author']);
  $userdata=@mysql_fetch_array($userdata);
  $nameformat="<a href='".modrewrite("viewprofile", false, true)."id=".$userdata['name']."' title='".lang('global_viewprofile')."'>".$userdata['name']."</a>";
  }
  else{
  $userdata['name']=lang('global_fableduser');
  $userdata['rights']=0;
  $nameformat="<a>".$userdata['name']."</a>";
  }
  
    /*nastaveni hvezdy*/
    switch($userdata['rights']){
    case 1: $star="c"; break;
    case 2: if($c_item['author']!=0){$star="b";}else{$star="a";} break;
    default: $star="";
    }
    if($star!=""){$star="<img src='modules/templates/$st_template/pics/stars/$star.gif' class='star' alt='$star' /> ";}
  
    if(postaccess_allow($c_item['author'], $userdata['rights'], $c_item['date'])){$commentadmin=" | <a href='modules/commentdel.php?cid=".$c_item['id']."' onclick='return ask();' title='".lang('global_delete')."'>x</a> | <a href='".modrewrite("commentedit", false, true)."cid=".$c_item['id']."' title='".lang('global_edit')."'>e</a>";}else{$commentadmin="";}
    
    $itemdate=formatdate($c_item['date']);
    if($st_bbcode==1){$c_item['text']=parsebbcode($c_item['text']);}
    if($st_smileys==1){$c_item['text']=strtr($c_item['text'], getsmileys());}
    $c_item['text']=nl2br($c_item['text']);
    if(login_indicator==1){$answer="<a href=\"javascript:answer('".$userdata['name']."');\">".lang('post_answer')."</a>";}else{$answer="";}
    echo $star.$nameformat.", <b>".$c_item['subject']."</b> <span class='postadmin'>(<span title='".$c_item['ip']."'>".$itemdate."</span>$commentadmin)</span> $answer<p>".$c_item['text']."</p><div class='hr'><hr /></div>\n";
    $commentcount++;

  }
  
  /*hlaska o zadnych komentarich*/
  if($commentcount==0){
  echo "<p>".lang('comment_nokit')."</p>";
  }

echo "</div>";
?>
