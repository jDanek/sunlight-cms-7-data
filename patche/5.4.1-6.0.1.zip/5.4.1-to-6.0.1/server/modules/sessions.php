<?php

session_start();
if(isset($_SESSION[systemuid.'login_indicator'])){

$login_indicator=$_SESSION[systemuid.'login_indicator'];
$login_id=$_SESSION[systemuid.'login_id'];

$login_data=@mysql_query("SELECT rights,name FROM `".tabprefix."-users` WHERE id=$login_id");
$login_data=@mysql_fetch_array($login_data);

$login_name=$login_data['name'];
$login_rights=$login_data['rights'];

  /*definovani globalnich*/
  define('login_indicator', $login_indicator);
  define('login_id', $login_id);
  define('login_name', $login_name);
  define('login_rights', $login_rights);

  /*bezpecnostni kontrola existence*/
  $existtest=@mysql_query("SELECT name FROM `".tabprefix."-users` WHERE id=$login_id");
  $existtest=@mysql_fetch_array($existtest);
  $existtest=$existtest['name'];
  if($existtest=="" or $existtest!=$login_name){
  $indicators['securitylogout']=1;
  echo "You're not supposed to be here.";
  include(root."modules/logout.php");
  exit;
  }
  
  /*zaznamenani casu aktivity*/
  @mysql_query("UPDATE `".tabprefix."-users` SET lastact=".time()." WHERE id=$login_id");

}
else{
$login_indicator=0;
$login_rights=-1;
define('login_indicator', 0);
}

?>
