<?php

/*nacteni cid*/
if(isset($_GET['cid'])){
$cid=$_GET['cid'];
$cid=intval($cid);
}
else{
$cid=-1;
}
$done=0;


/*kontrola loginu*/

  /*nacteni autora*/
  $c_data=@mysql_query("SELECT author,date,text,subject FROM `".tabprefix."-comments` WHERE id=$cid");
  $c_data=@mysql_fetch_array($c_data);

  $c_author=$c_data['author'];
  if($c_author!=-2){
  $c_author_rights=@mysql_query("SELECT rights FROM `".tabprefix."-users` WHERE id=$c_author");
  $c_author_rights=@mysql_fetch_array($c_author_rights);
  $c_author_rights=$c_author_rights['rights'];
  }
  else{
  $c_author_rights=0;
  }

  /*smazani z db*/
  $allowed=postaccess_allow($c_author, $c_author_rights, $c_data['date']);
  if($allowed==true){
  
    /*ulozeni*/
    if(isset($_POST['mod_text'])){
    
    /*nacteni promennych*/
    $ic_text=$_POST['mod_text'];
    $ic_subject=$_POST['mod_subject'];

    /*kontrola a uprava promennych*/

      /*aplikace maximalni delky*/
      $ic_text=substr($ic_text, 0, 2048);
      $ic_subject=substr($ic_subject, 0, 32);

      /*aplikace znakovych filtru*/
      $ic_text=strtr($ic_text, $trans);
      $ic_subject=strtr($ic_subject, $trans);

      /*odstraneni mezer*/
      $ic_text=trim($ic_text);
      $ic_subject=trim($ic_subject);

      /*kontrola zadani*/
      if($ic_text!="" and $ic_subject!=""){
      $valid=true;
      }
      else{
      $valid=false;
      }
      
    /*ulozeni do db*/
    if($valid==true){
    @mysql_query("UPDATE `".tabprefix."-comments` SET text='$ic_text' WHERE id=$cid");
    @mysql_query("UPDATE `".tabprefix."-comments` SET subject='$ic_subject' WHERE id=$cid");
    $done=1;
    }
    else{
    $msg=lang('global_msg_badinput');
    $done=0;
    }

    }
    else{
    $done=0;
    }

  }

include("msg.php");


/*navratovy odkaz*/
$home=@mysql_query("SELECT home,tp FROM `".tabprefix."-comments` WHERE id=$cid");
$home=@mysql_fetch_array($home);

switch($home['tp']){

case 1:
$anchor=@mysql_query("SELECT anchor FROM `".tabprefix."-menu` WHERE id=".$home['home']);
$anchor=@mysql_fetch_array($anchor);
$backlink=secrewrite($home['home'], $anchor['anchor']);
break;

case 2:
$anchor=@mysql_query("SELECT title FROM `".tabprefix."-articles` WHERE id=".$home['home']);
$anchor=@mysql_fetch_array($anchor);
$backlink=artrewrite($home['home'], $anchor['title']);
break;

}

$backlink="<a href='$backlink'>&lt; ".lang('global_goback')."</a>";

?>




<?php if(template_auto_write_headings=="true"){echo "<h1>".lang('comment_edit')."</h1><div class='hr'><hr /></div>";} ?>


<?php
if($allowed!=true){
echo "<b>".lang('global_denied')."</b>";
}
else{

  /*----hlaska o provedeni nebo formular pro editaci----*/
  if($done==1){
  echo "<p>".lang('global_actiondone')."<br />$backlink</p>";
  }
  else{

  /*formular*/
  echo
  textarea_limit(2048, "commentform").
  textarea_smileys("commentform", "mod_text")."
  <form action='".modrewrite("commentedit", false, true)."cid=$cid' method='post' name='commentform' onsubmit=\"if(document.commentform.subject.value=='' ||  document.commentform.text.value==''){alert('".lang('global_somethingwrong')."'); return false;}\">

  <table>

  <tr>
  <td>".lang('global_subject')."</td>
  <td><input type='text' maxlength='32' name='mod_subject' class='ifield' value='".$c_data['subject']."' /></td>
  </tr>

  <tr valign='top'>
  <td>".lang('global_text')."</td>
  <td><textarea name='mod_text' class='itext' id='itext' rows='6' cols='45'>".$c_data['text']."</textarea></td>
  </tr>

  <tr>
  <td></td>
  <td>
  <input type='submit' value='".lang('global_save')." &gt;' />
  <input type='reset' value='".lang('global_reset')."' onclick=\"return ask();\" />
  &nbsp;
  ".getsmileyslist()."
  </td>
  </tr>

  </table>

  </form>
  
  <br />$backlink
  ";
  
  }

}
?>
