<?php

/*nastaveni*/
$mtmp="";
if(template_usermenu_showname=="true"){$u_username="[".login_name."]";}else{$u_username="";}

/*poskladani*/
if(login_indicator==1){

  /*odhlaseni*/ $mtmp.=template_usermenu_item_prefix."<a href='modules/logout.php'>$u_prefix".lang('usermenu_logout')." $u_username</a>".template_usermenu_item_suffix;
  /*nastaveni*/ $mtmp.=template_usermenu_item_prefix."<a href='".modrewrite("settings")."'>$u_prefix".lang('usermenu_settings')."</a>".template_usermenu_item_suffix;
  /*profil*/    $mtmp.=template_usermenu_item_prefix."<a href='".modrewrite("viewprofile", false, true)."id=".login_name."'>".lang('usermenu_viewprofile')."</a>".template_usermenu_item_suffix;
  /*komentare*/ if(comment==1){$mtmp.=template_usermenu_item_prefix."<a href='".modrewrite("viewcomments")."'>$u_prefix".lang('usermenu_lastcomments')."</a>".template_usermenu_item_suffix;}

}
else{
  /*prihlasovani*/ $mtmp.=template_usermenu_item_prefix."<a href='".modrewrite("login")."'>$u_prefix".lang('usermenu_login')."</a>".template_usermenu_item_suffix;
  /*registrace*/   if(registration==1){$mtmp.=template_usermenu_item_prefix."<a href='".modrewrite("register")."'>$u_prefix".lang('usermenu_register')."</a>".template_usermenu_item_suffix;}
}

  /*seznam uzivatelu*/ if(userlist==1){$mtmp.=template_usermenu_item_prefix."<a href='".modrewrite("userlist")."'>$u_prefix".lang('usermenu_userlist')."</a>".template_usermenu_item_suffix;}
  
/*trimovani*/
if(template_usermenu_trimitems=="true"){$mtmp=trim($mtmp, template_usermenu_item_prefix); $mtmp=trim($mtmp, template_usermenu_item_suffix);}

/*vycisteni*/
unset($u_username);

?>
