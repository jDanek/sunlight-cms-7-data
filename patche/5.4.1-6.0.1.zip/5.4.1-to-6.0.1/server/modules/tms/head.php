  <meta http-equiv="content-type" content="text/html; charset=windows-1250" />
  <meta name="generator" content="SunLight CMS <?php echo systemverb; ?>" />
  <meta name="keywords" content="<?php echo $st_keywords; ?>" />
  <meta name="description" content="<?php echo $st_description; ?>" />
  <meta name="author" content="<?php echo $st_author; ?>" />
  <link href="modules/templates/<?php echo $st_template ?>/style.css" type="text/css" rel="stylesheet" />
  <?php if($st_rss==1){echo "<link href='modules/rss/rss.php' type='application/rss+xml' rel='alternate' />";} ?>
  <script type="text/javascript">
  //<![CDATA[
  function ask(){if(!confirm('<?php lang('global_msg_doask', 1); ?>')){return false;}else{return true;}}
  //]]>
  </script>
  <title><?php if(isset($content_title)){$pagetitle=" ".$st_separator." ".$content_title;}else{$pagetitle="";} echo $st_title.$pagetitle; ?></title>
