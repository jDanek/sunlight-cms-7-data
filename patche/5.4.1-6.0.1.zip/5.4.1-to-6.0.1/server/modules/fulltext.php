<?php

/*nacteni hledej*/
$hledej=$_GET['hledej'];
$hledej=trim($hledej, "%_-. ");
$hledej=strtr($hledej, $trans);

?>


<?php if(template_auto_write_headings=="true"){echo "<h1>".lang('fulltext_title')."</h1>";} ?>
<p><?php lang('fulltext_p', 1); ?></p>

<div class="hr"><hr /></div>
<form action="<?php echo modrewrite("fulltext", true); ?>" method="get" name="form" onsubmit="if(document.form.hledej.value==''){alert('<?php lang('global_somethingwrong', 1); ?>'); return false;}">
<?php echo modrewrite_getinputs("fulltext"); ?>
<input type="text" name="hledej" size="40" maxlength="256" value="<?php echo $hledej; ?>" />
<input type="submit" value="<?php lang('global_find', 1); ?>" /><br />
</form>

<?php
if($hledej!=""){

/*----------ZPRACOVANI VSTUPNICH PARAMETRU HLEDANI----------*/

  /*kontrola*/
  $pokracovat=true;
  if(strlen($hledej)<3){echo "<h3>".lang('fulltext_shortinput')."</h3>"; $pokracovat=false;}
  if(strlen($hledej)>128){echo "<h3>".lang('fulltext_longinput')."</h3>"; $pokracovat=false;}

if($pokracovat==true){


$hledej=addslashes($hledej);
$hledej=substr($hledej, 0, 256);
$hledej=strtr($hledej, $trans);

echo "<h3>".lang('fulltext_resulttitle').":</h3><br />\n";

/*----------ZPRACOVANI VSTUPNICH PARAMETRU STRANKOVANI----------*/
if(isset($_GET['s'])){
$startpage=$_GET['s'];
$startpage=intval($startpage);
if($startpage!=0){$startpage-=1;}
}
else{
$startpage=0;
}
$start=$startpage*$st_limit;

/*----------VYHLEDAVANI----------*/
$naslo=0;
for($perioda=0;$perioda<=8;$perioda++){
if($perioda==5){$perioda=6;}

  if($perioda!=4){
    /*polozky v menu*/
    $tabulka=@mysql_query("SELECT id,code,anchor FROM `".tabprefix."-menu` WHERE type=$perioda AND (code LIKE '%$hledej%' OR anchor LIKE '%$hledej%')");

    /*vypis*/
    while($radek=@mysql_fetch_array($tabulka)){
      $radek['code']=textpart(strip_tags(content_editor_process(striphcm($radek['code']))));
      $naslo++;
        if($naslo>$start and $naslo<=$start+$st_limit){
           switch($perioda){
            case 1: $linkhref=secrewrite($radek['id'], $radek['anchor']); break;
            case 2: $linkhref=catrewrite($radek['id'], $radek['anchor'], 1); break;
            case 3: $linkhref=bookrewrite($radek['id'], $radek['anchor'], 1); break;
            case 6: $linkhref=forumrewrite($radek['id'], $radek['anchor']); break;
            case 7: $linkhref=galrewrite($radek['id'], $radek['anchor']); break;
            case 8: $linkhref=gpostrewrite($radek['id'], $radek['anchor']); break;
            }
        echo "<".template_item_title_tag." class='title'><a href='$linkhref'>".$radek['anchor']."</a></".template_item_title_tag."><".template_item_perex_tag." class='textpart'>".$radek['code']."</".template_item_perex_tag.">\n";
        }
    }
  }
  else{
    /*clanek*/
    $tabulka=@mysql_query("SELECT id,title,perex,code FROM `".tabprefix."-articles` WHERE code LIKE '%$hledej%' OR title LIKE '%$hledej%' OR perex LIKE '%$hledej%'$st_futureart ORDER BY $st_artorder");

    /*vypis*/
    while($radek=@mysql_fetch_array($tabulka)){
      $radek['perex']=textpart(striphcm($radek['perex']));
      $naslo++;
      if($naslo>$start and $naslo<=$start+$st_limit){
      echo "<".template_item_title_tag." class='title'><a href='".artrewrite($radek['id'], $radek['title'])."'>".$radek['title']."</a></".template_item_title_tag."><".template_item_perex_tag." class='textpart'>".$radek['perex']."</".template_item_perex_tag.">\n";
      }
    }
  }

}

  /*hlaska o nenalezeni*/
  if($naslo==0){
  lang('fulltext_notfound', 1);
  }

/*----------VYPIS STRAN----------*/
if($naslo!=0){

  $pocetstran=$naslo;
  $pocetstran=$pocetstran/$st_limit;
  $pocetstran=ceil($pocetstran);

  if($startpage>=0 and $startpage<=$pocetstran-1){

  if($startpage>9){$strana=$startpage-5;}
  else{$strana=0;}
  $odkazu=0;
  $back=$startpage-10;
  $forward=$startpage+10;
  echo "<div class='strany'>".lang('global_page').": ";
  if($startpage>=10){echo "<a href='".modrewrite("fulltext", false, true)."hledej=$hledej&amp;s=$back'>&lt;</a> ";}

  while($strana<$pocetstran and $odkazu<=$st_maxpages){
  $odkazu++;
  $stranaanchor=$strana+1;
  if($strana==$startpage){echo "<a href='".modrewrite("fulltext", false, true)."hledej=$hledej&amp;s=$stranaanchor' class='active'>$stranaanchor</a> ";}
  else{echo "<a href='".modrewrite("fulltext", false, true)."hledej=$hledej&amp;s=$stranaanchor'>$stranaanchor</a> ";}
  $strana++;
  }

  if($startpage<=$pocetstran-10){echo "<a href='".modrewrite("fulltext", false, true)."hledej=$hledej&amp;s=$forward'>&gt;</a> ";}
  echo "</div>";

  }
  else{
  lang('global_wrongpage', 1);
  }

}


}


}
?>
