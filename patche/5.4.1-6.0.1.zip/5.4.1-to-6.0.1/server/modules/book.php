<?php

/*----FORUMULAR-----*/
if(template_auto_write_headings=="true"){echo "<h1>$kniha</h1>";}
if($bcontent['code']!=""){echo "<p>".$bcontent['code']."</p>";}
echo "<div class='hr'><hr /></div>";

if($st_gbguests==1 or $login_indicator==1){

if($st_bbcode==1){$bbcode_help="<a href='".modrewrite("bbcodehelp")."' class='bbcodehelp'>[?]</a>";}else{$bbcode_help="";}

echo textarea_limit(2048, "bookform");

  /*rozpoznani prihlaseni*/
  if($login_indicator==1){
  $namecontent="<input type='text' name='name' class='ifield' value='$login_name' disabled='disabled' />";
  $checkcontent="";
  $codecheck="-1";
  $jscodecheck="";
  }
  else{
  $namecontent="<input type='text' maxlength='20' name='name' class='ifield' />";
  if($st_codecheck==1){
  $codecheck=code_generate();
  $jscodecheck=" || document.form.codecheck.value==''";
  $checkcontent="
  <tr>
  <td>".lang('global_codecheck')."&nbsp;</td>
  <td><input type='text' maxlength='8' name='codecheck' class='ifieldxsmall' />&nbsp;<img src='modules/kod.php?n=".$codecheck."' alt='".lang('global_codecheckhelp')."' title='".lang('global_codecheckhelp')."' class='codecheck-post' /></td>
  </tr>
  ";
  }else{$codecheck=-1; $jscodecheck="";}
  }

echo
textarea_smileys("bookform", "text").textarea_answer("bookform", "text")."
<form action='modules/post.php' method='post' name='bookform' onsubmit=\"if(document.bookform.name.value=='' || document.bookform.subject.value=='' || document.bookform.text.value==''$jscodecheck){alert('".lang('global_somethingwrong')."'); return false;}\">
<input type='hidden' name='codecheckr' value='$codecheck' />
<input type='hidden' name='returnurl' value='".bookrewrite($c_str, $kniha, 1, false)."' />
<input type='hidden' name='posttype' value='2' />
<input type='hidden' name='home' value='$c_str' />
<input type='hidden' name='tp' value='3' />

<table>

<tr>
<td>".lang('global_yourname')."&nbsp;</td>
<td>$namecontent</td>
</tr>

<tr>
<td>".lang('global_subject')."</td>
<td><input type='text' maxlength='32' name='subject' class='ifield' /></td>
</tr>

".$checkcontent."

<tr valign='top'>
<td>".lang('global_text')."</td>
<td><textarea name='text' class='itext' id='itext' rows='6' cols='45'></textarea></td>
</tr>

<tr>
<td></td>
<td>

<input type='submit' value='".lang('global_send')." &gt;' />
<input type='reset' value='".lang('global_empty')."' onclick='return ask();' />

$bbcode_help
".getsmileyslist()."
</td>
</tr>

</table>

</form>
";

}
else{
echo "<p>".lang('post_regonly')."</p>";
$refer=1;
include("modules/loginform.php");
}

/*----VYPIS PRISPEVKU----*/

/*strankovani*/
if(isset($_GET['s'])){
$startpage=$_GET['s'];
$startpage=intval($startpage);
if($startpage!=0){$startpage-=1;}
}
else{
$startpage=0;
}

/*seznam stran*/

  /*spocitani stran*/
  $pocetstran=0;
  $pocetstran=@mysql_result(@mysql_query("SELECT COUNT(*) FROM `".tabprefix."-posts` WHERE home=$c_str"), 0);
  if($pocetstran==0){$pocetstran=1;}
  $pocetstran=$pocetstran/$st_postlimit;
  $pocetstran=ceil($pocetstran);

/*vypis stran*/
if($startpage>9){$strana=$startpage-5;}
else{$strana=0;}
$odkazu=0;
$back=$startpage-10;
$forward=$startpage+10;
$strankovani="<div class='strany'>".lang('global_page').": ";

if($startpage>=10){$strankovani.="<a href='".bookrewrite($c_str, $kniha, $back)."'>&lt;</a> ";}

while($strana<$pocetstran and $odkazu<=$st_maxpages){
$odkazu++;
$stranaanchor=$strana+1;

if($strana==$startpage){$strankovani.="<a href='".bookrewrite($c_str, $kniha, $stranaanchor)."' class='active'>$stranaanchor</a> ";}
else{$strankovani.="<a href='".bookrewrite($c_str, $kniha, $stranaanchor)."'>$stranaanchor</a> ";}
$strana++;
}

if($startpage<=$pocetstran-10){$strankovani.="<a href='".bookrewrite($c_str, $kniha, $forward)."'>&gt;</a> ";}
$strankovani.="</div>\n";

if($st_pagingmode==1 or $st_pagingmode==3){echo $strankovani;}

echo "<div id='posts'><div class='hr'><hr /></div>";

/*vypis prispevku*/
$start=$startpage*$st_postlimit;
$prispevku=0;
$bookcontent=@mysql_query("SELECT * FROM `".tabprefix."-posts` WHERE home=$c_str ORDER BY id DESC LIMIT $start,$st_postlimit");
while($prispevek=@mysql_fetch_array($bookcontent)){
  $prispevku++;

  /*nacteni dat autora*/
  $userdata=@mysql_query("SELECT name,rights FROM `".tabprefix."-users` WHERE id=".$prispevek['author']);
  $userdata=@mysql_fetch_array($userdata);
  if($userdata['rights']==""){$userdata['rights']=0;}
  if(postaccess_allow($prispevek['author'], $userdata['rights'], $prispevek['date'])){$postadmin=" | <a href='modules/postdel.php?pid=".$prispevek['id']."' onclick='return ask();' title='".lang('global_delete')."'>x</a> | <a href='".modrewrite("postedit", false, true)."pid=".$prispevek['id']."' title='".lang('global_edit')."'>e</a>";}else{$postadmin="";}

  $itemdate=formatdate($prispevek['date']);

    /*nastaveni hvezdy*/
    switch($userdata['rights']){
    case 1: $star="c"; break;
    case 2: if($prispevek['author']!=0){$star="b";}else{$star="a";} break;
    default: $star="";
    }
    if($star!=""){$star="<img src='modules/templates/$st_template/pics/stars/$star.gif' class='star' alt='$star' /> ";}

  /*rozliseni a vypis prispevku*/
  if($st_bbcode==1){$prispevek['text']=parsebbcode($prispevek['text']);}
  if($st_smileys==1){$prispevek['text']=strtr($prispevek['text'], getsmileys());}
  $prispevek['text']=nl2br($prispevek['text']);

  if($prispevek['author']=="-1"){
  $answer="<a href=\"javascript:answer('".$prispevek['name']."');\">".lang('post_answer')."</a>";
  echo "<b title='".lang('global_guest')."'>".$prispevek['name']."</b>, <b>".$prispevek['subject']."</b> <span class='postadmin'>(<span title='".$prispevek['ip']."'>".$itemdate."</span>$postadmin)</span> $answer<p>".$prispevek['text']."</p><div class='hr'><hr /></div>\n";
  }
  else{
  $answer="<a href=\"javascript:answer('".$userdata['name']."');\">".lang('post_answer')."</a>";
  echo $star."<a href='".modrewrite("viewprofile", false, true)."id=".$userdata['name']."' title='".lang('global_viewprofile')."'>".$userdata['name']."</a>, <b>".$prispevek['subject']."</b> <span class='postadmin'>(<span title='".$prispevek['ip']."'>".$itemdate."</span>$postadmin)</span> $answer<p>".$prispevek['text']."</p><div class='hr'><hr /></div>\n";
  }

}

echo "</div>";

if(($st_pagingmode==2 or $st_pagingmode==3) and $prispevku!=0){echo $strankovani;}


  /*hlaska o zadnych prispevcich*/
  if($prispevku==0){
  if($startpage==0){lang('post_nokit', 1);}
  else{lang('global_wrongpage', 1);}
  }


?>
