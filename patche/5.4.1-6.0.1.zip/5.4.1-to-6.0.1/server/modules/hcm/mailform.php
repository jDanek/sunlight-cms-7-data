<?php

$rootpath=array("path"=>"../../");
include("../../_connect.php");

/*odeslani*/
if(isset($_POST['text'])){

  /*nacteni promennych*/
  $receiver=$_POST['receiver'];
  $receiver=strtr($receiver, "#", "@");
  $sender=$_POST['sender'];
  $sender=trim($sender);
  $sender=substr($sender, 0, 128);
  $ip=$_SERVER['REMOTE_ADDR'];
  $sendtime=date("j.n. Y H:i");
  $subject=$_POST['subject'];
  $subject=trim($subject);
  $subject=strtr($subject, $trans);
  $text=$_POST['text'];
  $text=substr($text, 0, 102400);
  $text=trim($text);
  $text=lang('hcm_mailform_text')."\n-------------------------------\n".lang('global_subject').": $subject\n".lang('global_sender').": $sender\n".lang('global_sendtime').": $sendtime\n".lang('global_ip').": $ip\n".lang('global_adress').": $st_serverurl\n-------------------------------\n\n$text";
  $codecheck=$_POST['codecheck'];
  $codecheckr=$_POST['codecheckr'];
  $codecheckr=code_decode($codecheckr);

  if($text!="" and validate_email($sender) and $subject!="" and ($codecheck==$codecheckr or $st_codecheck==0)){

    //nacteni prilohy
    if(is_uploaded_file($_FILES['priloha']['tmp_name'])){
    $jepriloha=true;
    $priloha_nazev=$_FILES['priloha']['name'];
    $priloha_tmpname=$_FILES['priloha']['tmp_name'];
    $priloha_obsah=file_get_contents($priloha_tmpname);
    $priloha_obsah=chunk_split(base64_encode($priloha_obsah));
    }
    else{
    $jepriloha=false;
    }
    
    //sestaveni emailu
    
      //ZAKLADNI HLAVICKA, ZNAKOVA SADA, ODESILATEL, BOUNDARY
      $hlavicky ="Reply-To: $sender\n";
      $hlavicky.="MIME-Version: 1.0\n";
      $hlavicky.="Content-Type: multipart/mixed;\n";
      $hlavicky.=" boundary=\"==Multipart_Boundary_x000x\"";

      //TEXT EMAILU, KODOVANI CASTI
      $telo.="This is a multi-part message in MIME format.\n\n";
      $telo.="--==Multipart_Boundary_x000x\n";
      $telo.="Content-Type: text/plain; charset=win-1250\n";
      $telo.="Content-Transfer-Encoding: 7bit\n\n";
      $telo.="\n$text\n";

      //PRIPOJENI ZAKLADNI PRILOHY
      if($jepriloha==true){
      $telo.="--==Multipart_Boundary_x000x\n";
      $telo.="Content-Type: {application/octet-stream};\n";
      $telo.=" name=\"{$priloha_nazev}\"\n";
      $telo.="Content-Transfer-Encoding: base64\n\n";
      $telo.=$priloha_obsah."\n\n";
      }
  
  
  @mail($receiver, anchor($subject, false, true), $telo, $hlavicky);
  $msg=lang('hcm_mailform_sent');
  }
  else{
  $msg=lang('global_msg_someempty');
  }

}
else{
exit;
}

$moduletitle="hcm_mailform_title";
include("../moduleheader.php");

?>

<body>

<div class="board">
<div class="board-padding">

<a href="<?php referer(false, true); ?>">&lt; <?php lang('global_goback', 1); ?></a><br /><br />
<b><?php echo $msg; ?></b>

</div>
</div>

</body>
</html>
