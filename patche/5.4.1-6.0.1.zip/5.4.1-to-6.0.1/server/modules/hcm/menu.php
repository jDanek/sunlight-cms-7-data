<?php

/*nacteni limitu*/
if($limit==true){$limit=" AND ord>=$lstart AND ord<=$lend ";}
else{$limit=" ";}

/*nacteni dat z menu*/
$menu=@mysql_query("SELECT id,anchor,type,sublink,ord,regonly FROM `".tabprefix."-menu` WHERE visible=1 AND level=1 AND type!=5".$limit."ORDER BY ord");

/*seskladani menu*/
$mtmp="";
if(template_menu_ancestor_tag!=""){$mtmp.="<".template_menu_ancestor_tag." class='menu'>";}

  while($item=@mysql_fetch_array($menu)){

    /*nacteni promennych k polozce*/
    $m_id=$item['id'];
    $m_anchor=$item['anchor'];
    $m_type=$item['type'];
    $m_sublink=$item['sublink'];

    /*sublink trida*/
    if($m_sublink==1){$class=" class='sub'";}else{$class="";}

    /*odkaz*/
    $target="";
    switch($m_type){
    case 1: $linkhref=secrewrite($m_id, $m_anchor); break;
    case 2: $linkhref=catrewrite($m_id, $m_anchor, 1); break;
    case 3: $linkhref=bookrewrite($m_id, $m_anchor, 1); break;
    case 4: $linkhref=linkrewrite($m_id); $target=linkrewrite_gettarget($m_id); break;
    case 6: $linkhref=forumrewrite($m_id, $m_anchor); break;
    case 7: $linkhref=galrewrite($m_id, $m_anchor); break;
    case 8: $linkhref=gpostrewrite($m_id, $m_anchor); break;
    }

  if(template_menu_child_tag!=""){$mtmp.="<".template_menu_child_tag.">";}
  $mtmp.="<a href='".$linkhref."'".$class.$target.">".$m_anchor."</a>";
  if(template_menu_child_tag!=""){$mtmp.="</".template_menu_child_tag.">";}

  }

if(template_menu_ancestor_tag!=""){$mtmp.="</".template_menu_ancestor_tag.">";}
if(template_menu_suffix!=""){$mtmp.=template_menu_suffix;}

/*oddefinovani pouzitych promennych*/
unset($lstart); unset($lend);

?>
