<?php

$sbox_name=@mysql_query("SELECT name FROM `".tabprefix."-sboxes` WHERE id=$id");
$sbox_name=@mysql_fetch_array($sbox_name);
$sbox_name=$sbox_name['name'];
if($sbox_name!="" and count($mparam)==2){


  if(!defined("sboxshown_$id")){
  define("sboxshown_$id", true);

    /*nacteni prispevku*/
    $posts=@mysql_query("SELECT * FROM `".tabprefix."-sboxes-posts` WHERE home=$id ORDER BY id DESC");
    $postscode="";

    while($post=@mysql_fetch_array($posts)){

      /*nacteni dat autora*/
      $userdata=@mysql_query("SELECT name,rights FROM `".tabprefix."-users` WHERE id=".$post['author']);
      $userdata=@mysql_fetch_array($userdata);
      if($userdata['rights']==""){$userdata['rights']=0;}
      if(postaccess_allow($post['author'], $userdata['rights'], $post['date'])){$postadmin=" <a href='modules/sboxdel.php?pid=".$post['id']."' onclick='return ask();' title='".lang('global_delete')."'>[x]</a>";}else{$postadmin="";}
      $itemdate=formatdate($post['date']);

        /*nastaveni hvezdy*/
        switch($userdata['rights']){
        case 1: $star="c"; break;
        case 2: if($post['author']!=0){$star="b";}else{$star="a";} break;
        default: $star="";
        }
        if($star!=""){$star="<img src='".root."modules/templates/".template."/pics/stars/$star.gif' class='star' alt='$star' /> ";}


      /*vyplivnuti radku*/
      if(smileys==1){$post['text']=strtr($post['text'], getsmileys());}
      if($post['author']=="-1"){
      $postscode.="<div class='sbox-post'><span title='".lang('global_guest')." | IP=".$post['ip']."' class='guestname'>".$post['name']."</span>$postadmin: <span title='".formatdate($post['date'])."'>".$post['text']."</span></div>\n";
      }
      else{
      $postscode.="<div class='sbox-post'>".$star."<a href='".modrewrite("viewprofile", false, true)."id=".$userdata['name']."' title='".lang('global_viewprofile')." | IP=".$post['ip']."'>".$userdata['name']."</a>$postadmin: ".$post['text']."</div>\n";
      }

    }

    /*priprava jmena*/
    if(login_indicator==1){
    $namecontent="<input class='txt' type='text' name='sbox_name' value='".login_name."' disabled='disabled' />";
    $codecheck="-1";
    $codecheck_code="";
    $codecheck_img="";
    }
    else{
    $namecontent="<input class='txt' type='text' maxlength='20' name='sbox_name' />";
    if(codecheck==1){
    $codecheck=code_generate();
    $codecheck_code="<tr><td>".lang('global_codecheck')."</td><td><input class='txt' type='text' maxlength='8' name='sbox_codecheck' /></td></tr>";
    $codecheck_img="&nbsp;<img src='".root."modules/kod2.php?n=$codecheck' title='".lang('global_codecheckhelp')."' class='codecheck2' alt='".lang('global_codecheckhelp' ,'r')."' />";
    }else{$codecheck="-1"; $codecheck_code=""; $codecheck_img="";}
    }
    
    /*vypis prispveku*/
    $mtmp.=
    textarea_smileys("sboxform$id", "sbox_text", "sbox".$id."_s")."
    <div class='sbox'>
    <div class='sbox-add'>
    <div class='sbox-add-title'>".lang('global_addpost')."</div>
    <form action='modules/post.php' method='post' name='sboxform$id'>
    <input type='hidden' name='sbox_codecheckr' value='$codecheck' />
    <input type='hidden' name='returnurl' value='referer' />
    <input type='hidden' name='posttype' value='3' />
    <input type='hidden' name='home' value='$id' />
    <input type='hidden' name='tp' value='4' />
    
    <table>
    <tr><td>".lang('global_yourname')."</td><td>$namecontent</td></tr>
    <tr><td>".lang('global_text')."</td><td><input class='txt' type='text' maxlength='255' name='sbox_text' /></td></tr>
    $codecheck_code
    <tr><td></td><td><input class='submit' type='submit' value='".lang('global_send')."' />$codecheck_img</td></tr>
    </table>

    ".getsmileyslist("sbox".$id."_s")."

    </form>
    </div>
    <div class='sbox-posts' style='height:".$boxheight."px;'>
    $postscode
    </div>
    </div>
    ";


  }
  else{
  $mtmp.=lang('hcm_sbox_duplicated');
  }

}

?>
