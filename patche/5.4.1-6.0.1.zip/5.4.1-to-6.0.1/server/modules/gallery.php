<?php

/*nacteni parametru*/
$galcode=explode("|", $galdata['code']);
$dir=trim($galcode[0]);
$width=intval(trim($galcode[1]));
if(substr($dir, -1)!="/"){$dir.="/";}
$direrror=false;
if(!file_exists(root.$dir) or !is_dir(root.$dir)){$direrror=true;}

/*hlavicka*/
if(template_auto_write_headings=="true"){echo "<h1>".$galdata['anchor']."</h1>";}
if($galcode[2]!=""){echo "<p>".$galcode[2]."</p>";}

/*chyba adresare*/
if($direrror==true){
lang('gallery_direrror', 1);
}
else{


/*----------ZPRACOVANI VSTUPNICH PARAMETRU STRANKOVANI----------*/
if(isset($_GET['s'])){
$startpage=$_GET['s'];
$startpage=intval($startpage);
if($startpage!=0){$startpage-=1;}
}
else{
$startpage=0;
}
$start=$startpage*$st_limit;

/*----------NALEZENI OBRAZKU----------*/

/*otevreni slozky*/
$handle=opendir(root.$dir);
$gcode_array=array();
$index=0;

/*nacteni a serazeni obsahu*/
while($item=readdir($handle)){
$suffix=strrpos($item, ".");
$suffix=substr($item, $suffix+1);
$suffix=strtolower($suffix);
if($item=="." or $item==".." or is_dir(root.$dir.$item) or !($suffix=="jpeg" or $suffix=="jpg" or $suffix=="gif" or $suffix=="png")){continue;}
$gcode_array[$index]=$item;
$index++;
}
closedir($handle);
natsort($gcode_array);
reset($gcode_array);

/*vypis*/
$naslo=0;
$obrazky="";
while($naslo<=count($gcode_array)-1){
$naslo++;

  if($naslo>$start and $naslo<=$start+$st_limit){
  $item_size=ceil(filesize(root.$dir.$gcode_array[$naslo])/1024);
  $obrazky.="<a href='".root."$dir".current($gcode_array)."' target='_blank' title='".current($gcode_array)." | ".$item_size."kB'><img src='".root."modules/hcm/galimg.php?f=$dir".current($gcode_array)."&amp;w=$width' alt='".current($gcode_array)."' /></a>\n";

  }

next($gcode_array);
}


/*----------VYPOCET STRAN----------*/
$message="";
$strankovani="";
if($naslo!=0){

$pocetstran=$naslo;
$pocetstran=$pocetstran/$st_limit;
$pocetstran=ceil($pocetstran);

if($startpage>=0 and $startpage<=$pocetstran-1){

if($startpage>9){$strana=$startpage-5;}
else{$strana=0;}
$odkazu=0;
$back=$startpage-10;
$forward=$startpage+10;
$strankovani.="<div class='hr'><hr /></div><div class='strany'>".lang('global_page').": ";
if($startpage>=10){$strankovani.="<a href='".galrewrite($c_str, $galdata['anchor'], $back)."'>&lt;</a> ";}

while($strana<$pocetstran and $odkazu<=$st_maxpages){
$odkazu++;
$stranaanchor=$strana+1;
if($strana==$startpage){$strankovani.="<a href='".galrewrite($c_str, $galdata['anchor'], $stranaanchor)."' class='active'>$stranaanchor</a> ";}
else{$strankovani.="<a href='".galrewrite($c_str, $galdata['anchor'], $stranaanchor)."'>$stranaanchor</a> ";}
$strana++;
}

if($startpage<=$pocetstran-10){$strankovani.="<a href='".galrewrite($c_str, $galdata['anchor'], $forward)."'>&gt;</a> ";}

$strankovani.="</div>";

}
else{
$message=lang('global_wrongpage');
}

}
else{
$message=lang('gallery_nokit');
}




/*----------VYPIS GALERIE----------*/

if($st_pagingmode==1 or $st_pagingmode==3){echo $strankovani."<div class='hr'><hr /></div>";}
if($message==""){echo $obrazky;}else{echo $message;}
if($st_pagingmode==2 or $st_pagingmode==3){echo $strankovani;}




}

?>
