<?php

$root="../";
define('root', "../");
include("funcload.php");

$img=imagecreate(26,10);
$n=$_GET['n'];
$n=code_decode($n);

/*barvy*/
$bg=imagecolorallocate($img, 255, 255, 255);
$text=imagecolorallocate($img, 64, 64, 64);
$tmaveseda=imagecolorallocate($img, 120, 120, 120);
$seda=imagecolorallocate($img, 200, 200, 200);
$svetleseda=imagecolorallocate($img, 225, 225, 225);

/*vykresleni svetlesedych bodu*/
$pocet=0;
while($pocet<=30){
imagesetpixel($img,mt_rand(0, 26),mt_rand(0, 10),$svetleseda);
$pocet++;
}

/*vykresleni tmavesedych bodu*/
$pocet=0;
while($pocet<=10){
imagesetpixel($img,mt_rand(0, 26),mt_rand(0, 10),$tmaveseda);
$pocet++;
}

/*vykresleni sedych car*/
$pocet=0;
while($pocet<=3){
imageline($img,mt_rand(0, 26),mt_rand(0, 10),mt_rand(0, 68),mt_rand(0, 16),$seda);
$pocet++;
}

/*vypis textu*/
imagestring($img, 2, 1, -2, $n, $text);

/*odeslani a ukonceni*/
header("Content-type: image/PNG");
imagepng($img);
imagedestroy($img);

?>
