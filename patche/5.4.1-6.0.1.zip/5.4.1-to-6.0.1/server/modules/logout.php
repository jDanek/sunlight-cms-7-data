<?php

session_start();

/*pripojeni*/
if(!isset($indicators['securitylogout'])){
$rootpath=array("path"=>"../");
include("../_connect.php");
}

/*vymazani casu posledni aktivity*/
@mysql_query("UPDATE `".tabprefix."-users` SET lastact=0 WHERE id=".$_SESSION[systemuid.'login_id']);

/*odstraneni sessions*/
unset($_SESSION[systemuid.'login_indicator']);
unset($_SESSION[systemuid.'login_id']);
unset($_SESSION[systemuid.'login_name']);
unset($_SESSION[systemuid.'login_rights']);

/*presmerovani*/
if(!isset($indicators['securitylogout'])){
  $referer=$_SERVER['HTTP_REFERER'];
  if($referer!="" and !ismodule($referer)){header("location: $referer");}
  else{header("location: ../");}
  exit;
}

?>
