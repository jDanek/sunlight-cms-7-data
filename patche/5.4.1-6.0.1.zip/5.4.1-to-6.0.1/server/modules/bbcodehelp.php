<?php
echo "<a href='".referer(true, true)."'>&lt; ".lang('global_goback')."</a><br /><br />";
lang('bbcode_help_page', 1);
?>
