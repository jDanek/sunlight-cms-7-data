<?php

/*hlavicka*/
if(template_auto_write_headings=="true"){echo "<h1>".$gpostdata['anchor']."</h1>";}
if($gpostdata['code']!=""){echo "<p>".$gpostdata['code']."</p>";}
if(template_auto_write_headings=="true" or $gpostdata['code']!=""){echo "<div class='hr'><hr /></div>";}

$items=@mysql_query("SELECT * FROM `".tabprefix."-gpitems` WHERE home=$c_str ORDER BY ord");
$content_exists=0;
while($item=@mysql_fetch_array($items)){
  
  //nacteni titulku
  if($item['type']!=0){$anchor=@mysql_fetch_array(@mysql_query("SELECT anchor FROM `".tabprefix."-menu` WHERE id=".$item['target']." AND type=".$item['type'])); $anchor=$anchor['anchor'];}
  else{$anchor=@mysql_fetch_array(@mysql_query("SELECT title FROM `".tabprefix."-articles` WHERE id=".$item['target'])); $anchor=$anchor['title'];}
  if($anchor==""){continue;}
  
  //nacteni dodatecnych informaci
  $iteminfo="";
  switch($item['type']){
  
    //clanek
    case 0:
      $adata=@mysql_fetch_array(@mysql_query("SELECT * FROM `".tabprefix."-articles` WHERE id=".$item['target']));

            /*spocitani komentaru*/
            $a_commentscount_code="";
            if($adata['comment']==1 and comment==1){
            $a_commentscount=@mysql_query("SELECT id FROM `".tabprefix."-comments` WHERE home=".$adata['id']." AND tp=2");
            $a_commentscount_number=0;
            while($commentscount_item=@mysql_fetch_array($a_commentscount)){
            $a_commentscount_number++;
            }
            $a_commentscount_code=" ".template_item_info_separator." <".template_item_info_highlight_tag.">".lang('article_totalcomments').":</".template_item_info_highlight_tag."> $a_commentscount_number";
            }

            /*zobrazeni poctu precteni*/
            if(artread==1){$a_opened_code=" ".template_item_info_separator." <".template_item_info_highlight_tag.">".lang('article_read').":</".template_item_info_highlight_tag."> ".$adata['opened']."x";}
            else{$a_opened_code="";}

            $author=@mysql_fetch_array(@mysql_query("SELECT name,realname FROM `".tabprefix."-users` WHERE id=".$adata['author']));
            if(artrealname==1 and $author['realname']!=""){$authoranchor=$author['realname'];}
            else{$authoranchor=$author['name'];}

            $adata['date']=formatdate($adata['date']);
            $iteminfo="<".template_item_info_highlight_tag.">".lang('article_author').":</".template_item_info_highlight_tag."> $authoranchor ".template_item_info_separator." <".template_item_info_highlight_tag.">".lang('article_posted').":</".template_item_info_highlight_tag."> ".$adata['date'].$a_opened_code.$a_commentscount_code;
    break;

    //kategorie
    case 2: $counter=@mysql_result(@mysql_query("SELECT COUNT(*) FROM `".tabprefix."-articles` WHERE home=".$item['target']), 0); $iteminfo="<".template_item_info_highlight_tag.">".lang('article_number').":</".template_item_info_highlight_tag."> $counter"; break;

    //kniha, forum
    case 3: case 6: $counter=@mysql_result(@mysql_query("SELECT COUNT(*) FROM `".tabprefix."-posts` WHERE home=".$item['target']), 0); $iteminfo="<".template_item_info_highlight_tag.">".lang('forum_posts').":</".template_item_info_highlight_tag."> $counter"; break;

  }

  //sestaveni adresy okdazu
  $target="";
  switch($item['type']){
  case 0: $linkhref=artrewrite($item['target'], $anchor); break;
  case 1: $linkhref=secrewrite($item['target'], $anchor); break;
  case 2: $linkhref=catrewrite($item['target'], $anchor, 1); break;
  case 3: $linkhref=bookrewrite($item['target'], $anchor, 1); break;
  case 4: $linkhref=linkrewrite($item['target']); $target=linkrewrite_gettarget($item['target']); break;
  case 6: $linkhref=forumrewrite($item['target'], $anchor); break;
  case 7: $linkhref=galrewrite($item['target'], $anchor); break;
  case 8: $linkhref=gpostrewrite($item['target'], $anchor); break;
  }

  //vypis
  echo "<".template_item_title_tag." class='title'><a href='$linkhref'$target>".$item['title']."</a></".template_item_title_tag."><".template_item_perex_tag." class='cperex'>".$item['perex']."</".template_item_perex_tag."><".template_item_info_tag." class='cinfo'>$iteminfo</".template_item_info_tag.">";
  $content_exists++;

}

  /*hlaska o zadnych polozkach*/
  if($content_exists==0){lang('global_noitems', 1);}

?>
