<?php

$vipmsg=false;

/*nacteni stavajicich uziv. dat*/
$userdata=@mysql_query("SELECT name,realname,password,email,sex,year,month,note,massmail FROM `".tabprefix."-users` WHERE id=$login_id");
$userdata=@mysql_fetch_array($userdata);
$userdata['email']=strtr($userdata['email'], $atback);

/*ulozeni nastaveni*/
if(isset($_POST['mod_email'])){

  /*nacteni promennych*/
  $realname=$_POST['mod_realname'];
  $realname=substr($realname, 0, 42);
  $realname=strtr($realname, $trans);
  $newpassword=$_POST['mod_newpassword'];
  $newpassword2=$_POST['mod_newpassword2'];
  $actualpass=$_POST['mod_actualpassword'];
  $email=$_POST['mod_email'];
  $email=trim($email);
  $note=$_POST['mod_note'];
  $note=trim($note);
  $note=strtr($note, $trans);
  $note=substr($note, 0, 1024);
  $massmail=checkbox_load($_POST['mod_massmail']);

    /*pohlavi*/
    $sex=$_POST['mod_sex'];
    $sex=intval($sex);
    if(!($sex==-1 or $sex==0 or $sex==1)){$sex=-1;}

    /*mesic*/
    $month=$_POST['mod_month'];
    $month=intval($month);
    if(!($month>=1 or $month<=12 or $month==-1)){$month=-1;}

    /*rok*/
    $year=$_POST['mod_year'];
    $year=intval($year);
    if(!($year>=date("Y")-110 or $year<=date("Y") or $year==-1)){$year=-1;}

    /*deaktivace*/
    if($year==-1 xor $month==-1){$year=-1; $month=-1;}
  
  if($login_rights==2){$newname=$_POST['mod_newname']; $newname=substr($newname, 0, 20); $newname=anchor($newname, false);}
  else{$newname=" ";}
  
  /*kontrola a ulozeni*/
  if($newpassword==$newpassword2){
  
  $namecheck=@mysql_query("SELECT name FROM `".tabprefix."-users` WHERE name='$newname'");
  $namecheck=@mysql_fetch_array($namecheck);
  $namecheck=$namecheck['name'];

  if(validate_email($email) and $newname!="" and ($namecheck=="" or $namecheck==$login_name)){
  
  $emailcheck=@mysql_query("SELECT name FROM `".tabprefix."-users` WHERE email='$email'");
  $emailcheck=mysql_fetch_array($emailcheck);
  $emailcheck=$emailcheck['name'];
  
  if($emailcheck=="" or $emailcheck==$userdata['name']){

    /*kontrola puvodniho hesla*/
    $continue=true;
    if($newpassword==""){
    $newpassword=$userdata['password'];
    }
    else{
      if(md5($actualpass)==$userdata['password']){
      $newpassword=md5($newpassword);
      }
      else{
      $continue=false;
      }
    }
  
    if($continue==true){
    
    /*aktualizace v db*/
    @mysql_query("UPDATE `".tabprefix."-users` SET realname='$realname' WHERE id=$login_id");
    @mysql_query("UPDATE `".tabprefix."-users` SET email='$email' WHERE id=$login_id");
    @mysql_query("UPDATE `".tabprefix."-users` SET note='$note' WHERE id=$login_id");
    @mysql_query("UPDATE `".tabprefix."-users` SET password='$newpassword' WHERE id=$login_id");
    @mysql_query("UPDATE `".tabprefix."-users` SET year=$year WHERE id=$login_id");
    @mysql_query("UPDATE `".tabprefix."-users` SET month=$month WHERE id=$login_id");
    @mysql_query("UPDATE `".tabprefix."-users` SET sex=$sex WHERE id=$login_id");
    @mysql_query("UPDATE `".tabprefix."-users` SET massmail=$massmail WHERE id=$login_id");

    if($login_rights==2 and $newname!=$login_name){
    @mysql_query("UPDATE `".tabprefix."-users` SET name='$newname' WHERE id=$login_id");
    }

    /*data a zprava*/

      /*nacteni novych uziv. dat*/
      $userdata=@mysql_query("SELECT name,realname,password,email,sex,year,month,note,massmail FROM `".tabprefix."-users` WHERE id=$login_id");
      $userdata=@mysql_fetch_array($userdata);
      $userdata['email']=strtr($userdata['email'], $atback);

    $msg=lang('global_settingssaved');
    $vipmsg=true;
    
    }
    else{
    $msg=lang('global_msg_nosame');
    }
    
    }
    else{
    $msg=lang('global_msg_mailexists');
    }

  }
  else{
    if($namecheck!="" and $namecheck!=$login_name){
    $msg=lang('global_msg_userexists');
    }
    else{
    $msg=lang('global_msg_someempty');
    }
  }

  }
  else{
  $msg=lang('global_msg_nosame');
  }

}

if($vipmsg==false){include("modules/msg.php");}

/*hlavicka*/
if(template_auto_write_headings=="true"){echo "<h1>".lang('settings_title')."</h1>";}
if($login_rights==2){echo "<p>".lang('settings_p_special')."</p>";}else{echo "<br />";}

/*javascript pro delku poznamky*/
echo textarea_limit(1024, "settingsform", "mod_note");

/*vip msg*/
if($vipmsg==true and $msg!=""){echo "<div class='msg'>$msg</div><br />";}

?>

<form action="<?php echo modrewrite("settings"); ?>" method="post" name="settingsform">

<fieldset>
<legend><b><?php lang('settings_updata', 1); ?></b></legend>
<p class="mini"><?php lang('settings_updata_p', 1); ?></p>
<table>

<?php
/*pole pro zmenu jmena*/
if($login_rights==2){
echo "<tr>
<td><b>".lang('global_username')."</b> <span class='markstar'>*</span></td>
<td><input type='text' name='mod_newname' size='20' class='ifieldverysmall' maxlength='20' value='".$userdata['name']."' /></td>
</tr>
";
}
?>

<tr valign="top">
<td><b><?php lang('global_email', 1); ?></b> <span class="markstar">*</span></td>
<td>
<input type="text" name="mod_email" size="20" class="ifieldverysmall" value="<?php echo $userdata['email']; ?>" /><br />
<input type="checkbox" name="mod_massmail" value="1"<?php checkbox_activate($userdata['massmail']) ?> /> <?php lang('settings_massmail', 1); ?><br /><br />
</td>
</tr>

<tr>
<td><b><?php lang('global_realname', 1); ?></b></td>
<td><input type="text" name="mod_realname" size="20" class="ifieldverysmall" maxlength="42" value="<?php echo $userdata['realname']; ?>" /></td>
</tr>

<tr>
<td><b><?php lang('global_borndate', 1); ?></b></td>
<td>

  <select name="mod_month">
  <option value='-1'>-</option>
  <?php
  $x=1;
  while($x<=12){
  if($x<10){$x="0$x";}
  if($x!=$userdata['month']){echo "<option value='$x'>$x</option>\n";}
  else{echo "<option value='$x' selected='selected'>$x</option>\n";}
  $x++;
  }
  ?>
  </select>&nbsp;

  <select name="mod_year">
  <option value='-1'>-</option>
  <?php
  $x=date("Y");
  while($x>=date("Y")-110){
  if($x!=$userdata['year']){echo "<option value='$x'>$x</option>\n";}
  else{echo "<option value='$x' selected='selected'>$x</option>\n";}
  $x--;
  }
  ?>
  </select>&nbsp;<small><?php lang('settings_borndate_help', 1); ?></small>

</td>
</tr>

<tr>
<td><b><?php lang('global_sex', 1); ?></b></td>
<td>
<?php
switch($userdata['sex']){
case -1: $sex_undefined=" selected='selected'"; $sex_male=""; $sex_female=""; break;
case 0: $sex_undefined=""; $sex_male=" selected='selected'"; $sex_female=""; break;
case 1: $sex_undefined=""; $sex_male=""; $sex_female=" selected='selected'"; break;
}
?>
<select name="mod_sex">
<option value="-1"<?php echo $sex_undefined; ?>>-</option>
<option value="0"<?php echo $sex_male; ?>><?php lang('global_sex_male', 1); ?></option>
<option value="1"<?php echo $sex_female; ?>><?php lang('global_sex_female', 1); ?></option>
</select>
</td>
</tr>

</table>
</fieldset>


<fieldset>
<legend><b><?php lang('settings_password', 1); ?></b></legend>
<p class="mini"><?php lang('settings_password_p', 1); ?></p>
<table>

<tr>
<td><b><?php lang('global_actualpass', 1); ?></b></td>
<td><input type="password" name="mod_actualpassword" size="20" class="ifieldverysmall" maxlength="255" /></td>
</tr>

<tr>
<td><b><?php lang('global_newpass', 1); ?></b></td>
<td><input type="password" name="mod_newpassword" size="20" class="ifieldverysmall" maxlength="255" /></td>
</tr>

<tr>
<td><b><?php lang('global_newpass', 1); ?> <?php lang('global_check', 1); ?></b></td>
<td><input type="password" name="mod_newpassword2" size="20" class="ifieldverysmall" maxlength="255" /></td>
</tr>

</table>
</fieldset>


<fieldset>
<legend><b><?php lang('settings_other', 1); ?></b></legend>
<?php if($st_bbcode==1){echo "<p class='mini'>".lang('settings_other_p')."</p>";} ?>
<table>

<tr valign="top">
<td><b><?php lang('global_note', 1); ?></b>&nbsp;</td>
<td>
<?php echo textarea_smileys("settingsform", "mod_note"); ?>
<textarea name="mod_note" class="itextsmall" rows="4" cols="28"><?php echo $userdata['note']; ?></textarea>
</td>
</tr>


<?php
if($st_smileys==1){
echo "
<tr><td></td>
<td>
".getsmileyslist()."
</td></tr>
";
}
?>

</table>
</fieldset>


<input type="submit" value="<?php lang('global_save', 1); ?> &gt;" />
<input type="reset" value="<?php lang('global_reset', 1); ?>" onclick="return ask();" />


</form>
