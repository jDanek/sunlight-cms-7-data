<?php
if(isset($error)){
echo "<font style='color:red;'><b>Chyba systemu:</b><br />$error</font>";
}
?>
