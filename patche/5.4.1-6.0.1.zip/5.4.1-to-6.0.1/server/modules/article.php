<?php

/*-----nacteni autora-----*/
$a_author=@mysql_query("SELECT name,realname FROM `".tabprefix."-users` WHERE id=".$a_content['author']);
$a_author=@mysql_fetch_array($a_author);
if($st_artrealname==1 and $a_author['realname']!=""){$a_authoranchor=$a_author['realname'];}
else{$a_authoranchor=$a_author['name'];}

/*-----nacteni promennych-----*/
$a_id=$a_content['id'];
$a_title=$a_content['title'];
$a_perex=$a_content['perex'];
$a_code=$a_content['code'];
$a_date=$a_content['date'];
$a_date=formatdate($a_date);
$a_home=$a_content['home'];
$a_opened=$a_content['opened'];

/*-----zpracovani hodnoceni-----*/
if($a_content['rate_allow']==1 and $st_artrate==1){
  if($a_content['rate_counter']==0 or $a_content['rate_total']==0){
  $a_rating=lang('global_notrated');
  }
  else{
  $a_rating=round($a_content['rate_total']/$a_content['rate_counter'], 1)." (".lang('global_total')." ".$a_content['rate_counter']." ".lang('global_votes').")";
  }
  
  if(!in_array($_SERVER['REMOTE_ADDR'], explode("|", $a_content['rate_ipcache']))){
  $href1=" href='".root."modules/articlerate.php?r=1&amp;id=$a_id'";
  $href2=" href='".root."modules/articlerate.php?r=2&amp;id=$a_id'";
  $href3=" href='".root."modules/articlerate.php?r=3&amp;id=$a_id'";
  $href4=" href='".root."modules/articlerate.php?r=4&amp;id=$a_id'";
  $href5=" href='".root."modules/articlerate.php?r=5&amp;id=$a_id'";
  }
  else{$href1=""; $href2=""; $href3=""; $href4=""; $href5="";}
  
  $a_ratingcode="
  <b>".lang('article_rating').":</b> ".$a_rating."<br />
  <b>".lang('article_rate').":</b>&nbsp;
  <a$href1>1</a> |
  <a$href2>2</a> |
  <a$href3>3</a> |
  <a$href4>4</a> |
  <a$href5>5</a> ".lang('article_rate_help')."<br />
  ";
}
else{
$a_ratingcode="";
}

/*-----zjisteni nazvu kategorie-----*/
$kategorie=@mysql_query("SELECT anchor,visible FROM `".tabprefix."-menu` WHERE id=$a_home");
$kategorie=@mysql_fetch_array($kategorie);
$kategorie_visible=$kategorie['visible'];
$kategorie=$kategorie['anchor'];

/*-----zapocitani zobrazeni-----*/
$a_readlog=explode("|", $_SESSION[systemuid.'readlog']);
$a_readlognum=0;
$a_readlogfound=false;
while($a_readlognum<=count($a_readlog)){
$a_readlogitem=$a_readlog[$a_readlognum];
if($a_readlogitem==$a_id){$a_readlogfound=true; break;}
$a_readlognum++;
}

  /*vlozeni do logu a pripocteni pocitadla*/
  if($a_readlogfound==false){
  $_SESSION[systemuid.'readlog'].="|$a_id";
  @mysql_query("UPDATE `".tabprefix."-articles` SET opened=opened+1 WHERE id=$a_id");
  }


/*-----zobrazeni id clanku pro redaktory a administratory-----*/
if(isset($_SESSION[systemuid.'login_aindicator'])){
$a_showidcode="\n<b><i>".lang('article_id').":</i></b> $a_id<br />";
}
else{
$a_showidcode="";
}

/*-----zobrazeni poctu precteni-----*/
if($st_artread==1){$a_readcode="<b>".lang('article_read').":</b> ".$a_opened."x<br />";}
else{$a_readcode="";}

/*-----odkaz na tisk-----*/
if($st_artprint==1){$a_printcode="<br /><a href='modules/print/print.php?art=$a_id' target='_blank'><img src='modules/templates/$st_template/pics/system/print.gif' alt='print' /> ".lang('article_print')."</a><br />";}
else{$a_readcode="";}

/*-----navigace clanku-----*/
if($a_content['visible']==1 and $kategorie_visible==1){$artnavigation=lang('article_category').": <a href='".catrewrite($a_home, $kategorie, 1)."'>$kategorie</a><div class='hr'><hr /></div>";}
else{$artnavigation="";}

/*-----nalezeni souvisejicich clanku-----*/
$a_relatedcode="";
$a_relateddata="";
$cond1="target";
$cond2="home";
for($x=0;$x<2;$x++){
  $a_related=@mysql_query("SELECT $cond1 FROM `".tabprefix."-relatedarticles` WHERE $cond2=$a_id ORDER BY ord");
  if(@mysql_num_rows($a_related)!=0){
    while($a_related_item=@mysql_fetch_array($a_related)){
    $reltitle=@mysql_fetch_array(@mysql_query("SELECT title FROM `".tabprefix."-articles` WHERE id=".$a_related_item[$cond1]));
    if($reltitle!=""){$a_relateddata.="<a class='arelated' href='".artrewrite($a_related_item[$cond1], $reltitle['title'])."'>".$reltitle['title']."</a><br />";}
    }
  }
$cond1="home";
$cond2="target";
}

if($a_relateddata!=""){
$a_relatedcode="
<td>
<h2>".lang('article_related')."</h2>
<p class='ainfo'>
$a_relateddata
</p>
</td>
";
}

/*-----vyhodnoceni obsahu-----*/
if($st_arthcm==1){$a_code=content_editor_process(parsehcm($a_code, true));}
else{$a_code=content_editor_process($a_code);}

echo $artnavigation;
if(template_auto_write_headings=="true"){echo "<h1>$a_title</h1>";}
echo "
<p class='aperex'>$a_perex</p>
".$a_code."

<table id='ainfotable'>
<tr valign='top'>

  <td>
  <p class='ainfo'>
  <b>".lang('article_author').":</b> <a href='".modrewrite("viewprofile", false, true)."id=".$a_author['name']."'>$a_authoranchor</a><br />
  <b>".lang('article_posted').":</b> $a_date<br />
  $a_readcode
  $a_ratingcode
  $a_showidcode
  $a_printcode
  </p>
  </td>
  
  $a_relatedcode
  
</tr>
</table>
";

  if($a_comment==1 and $st_comment==1){
  include("modules/comment.php");
  }

?>
