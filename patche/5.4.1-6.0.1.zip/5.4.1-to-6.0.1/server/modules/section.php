<?php

echo content_editor_process(parsehcm($codecontent['code'], true));
$sectitle=$c_title;

/*komentare*/
if($c_comment==1 and $st_comment==1){
include("modules/comment.php");
}

?>
