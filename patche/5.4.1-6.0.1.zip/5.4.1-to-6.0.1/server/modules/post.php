<?php

/*pripojeni*/
$rootpath=array("path"=>"../");
include("../_connect.php");
include("sessions.php");

/*rozliseni typu, vlozeni do db*/
$returnurl=$_POST['returnurl'];
$p_home=intval($_POST['home']);
$p_tp=intval($_POST['tp']);
$ip=$_SERVER['REMOTE_ADDR'];

      /*test existence cile*/
      $secondtest=false;
      switch($p_tp){
      case 1: case 3: case 6: $existtest=@mysql_query("SELECT COUNT(*) FROM `".tabprefix."-menu` WHERE id=$p_home AND type=$p_tp"); if($p_tp==6){$secondtest=true; $existtest2=@mysql_query("SELECT COUNT(*) FROM `".tabprefix."-topics` WHERE id=".intval($_POST['topic']));} break;
      case 2: $existtest=@mysql_query("SELECT COUNT(*) FROM `".tabprefix."-articles` WHERE id=$p_home"); break;
      case 4: $existtest=@mysql_query("SELECT COUNT(*) FROM `".tabprefix."-sboxes` WHERE id=$p_home"); break;
      }
      if(@mysql_result($existtest, 0)==0 or ($secondtest==true and @mysql_result($existtest2, 0)==0)){$msg=lang('global_wrongrequest');}
      else{

if($_SESSION[systemuid.'log_posttime']<time()-$st_postwait){

switch($_POST['posttype']){

  /*komentare*/
  case 1:

    if(isset($_POST['subject']) and $login_indicator==1){

      /*nacteni promennych*/
      $ic_home=$p_home;
      $ic_tp=$p_tp;

      $ic_text=$_POST['text'];
      $ic_subject=$_POST['subject'];
      $ic_date=time();
      $ic_ip=$_SERVER['REMOTE_ADDR'];
      



      /*kontrola a uprava promennych*/

        /*aplikace maximalni delky*/
        $ic_text=substr($ic_text, 0, 2048);
        $ic_subject=substr($ic_subject, 0, 32);

        /*odstraneni mezer*/
        $ic_text=trim($ic_text);
        $ic_subject=trim($ic_subject);

        /*odfiltrovani znaku*/
        $ic_text=strtr($ic_text, $trans);
        $ic_subject=strtr($ic_subject, $trans);

        /*kontrola zadani*/
        if($ic_text!="" and $ic_subject!=""){
        $continue=true;
        }
        else{
        $continue=false;
        }


      /*vypocet id a vlozeni*/
      if($continue==true){
      $vypocetid=@mysql_query("SELECT id FROM `".tabprefix."-comments` ORDER BY id DESC LIMIT 1");
      $vypocetid=@mysql_fetch_array($vypocetid);
      $newid=$vypocetid['id'];
      $newid++;
      @mysql_query("INSERT INTO `".tabprefix."-comments` (id,author,text,home,subject,date,tp,ip) VALUES ($newid,$login_id,'$ic_text','$ic_home','$ic_subject',$ic_date,'$ic_tp','$ic_ip')");
      }
      else{
      $msg=lang('global_msg_badinput');
      }

    }
  
  break;
  
  
  /*knihy, fora*/
  case 2:
  
    /*nacteni promennych*/
    $c_str=$p_home;
    $text=$_POST['text'];
    $text=substr($text, 0, 2048);
    $text=trim($text);
    $text=strtr($text, $trans);
    $subject=$_POST['subject'];
    $subject=substr($subject, 0, 32);
    $subject=trim($subject);
    $subject=strtr($subject, $trans);
    $date=time();
    
      /*tema pro fora*/
      if(isset($_POST['topic']) and $p_tp==6){$topic=intval($_POST['topic']);}
      else{$topic=-1;}

    if($login_indicator==1){
    $author=$login_id;
    }
    else{
    $name=$_POST['name'];
    $name=anchor($name, false);
    $name=substr($name, 0, 20);
    $codecheck=$_POST['codecheck'];
    $codecheckr=$_POST['codecheckr'];
    $codecheckr=code_decode($codecheckr);
    }
    
    /*uzamknuto a/nebo pouze pro registrovane*/
    $violation=false;
    if($topic==-1){
      $checkdata=@mysql_fetch_array(@mysql_query("SELECT regonly FROM `".tabprefix."-menu` WHERE id=$c_str AND type=3"));
      if(($checkdata['regonly']==1 or $st_gbguests==0) and $login_indicator!=1){$violation=true;}
    }
    else{
    $checkdata=@mysql_fetch_array(@mysql_query("SELECT regonly FROM `".tabprefix."-menu` WHERE id=$c_str AND type=6"));
    $checkdata2=@mysql_fetch_array(@mysql_query("SELECT regonly,locked FROM `".tabprefix."-topics` WHERE home=$c_str"));
    if((($checkdata['regonly']==1 or $checkdata2['regonly']==1) and $login_indicator!=1) or ($checkdata2['locked']==1 and $login_rights!=2)){$violation=true;}
    }

    /*kontrola a vlozeni*/
    if($violation==false){
      if($text!="" and $subject!="" and (($name!="" and $st_gbguests==1) or $login_indicator==1) and ($codecheck==$codecheckr or $login_indicator==1 or $st_codecheck==0)){

        /*vypocet noveho id*/
        $newid=@mysql_query("SELECT id FROM `".tabprefix."-posts` ORDER BY id DESC LIMIT 1");
        $newid=@mysql_fetch_array($newid);
        $newid=$newid['id'];
        $newid++;

        /*rozliseni a vlozeni*/
        if($login_indicator==1){
        @mysql_query("INSERT INTO `".tabprefix."-posts` (id,home,topic,author,name,date,text,subject,ip) VALUES ($newid,$c_str,$topic,$login_id,'','$date','$text','$subject','$ip')");
        }
        else{
        @mysql_query("INSERT INTO `".tabprefix."-posts` (id,home,topic,author,name,date,text,subject,ip) VALUES ($newid,$c_str,$topic,-1,'$name',$date,'$text','$subject','$ip')");
        }

      }
      else{
      $msg=lang('global_msg_badinput');
      }
    }
    else{
    $msg=lang('global_wrongrequest');
    }
  
  break;
  
  
  /*sboxy*/
  case 3:

      $text=$_POST['sbox_text'];
      $text=strtr($text, $trans);
      $text=substr($text, 0, 255);
      $name=$_POST['sbox_name'];
      $name=strtr($name, $trans);
      $name=substr($name, 0, 20);
      if($login_indicator!=1){$codecheck=$_POST['sbox_codecheck']; $codecheckr=code_decode($_POST['sbox_codecheckr']);}
      else{$codecheckr=-1; $codecheck=-1; $name=" ";}

      if($text!="" and $name!="" and ($codecheck==$codecheckr or $st_codecheck==0)){

        if($login_indicator==1){$name=""; $author=$login_id;}
        else{$author=-1;}

        $date=time();

        $newid=@mysql_query("SELECT id FROM `".tabprefix."-sboxes-posts` ORDER BY id DESC LIMIT 1");
        $newid=@mysql_fetch_array($newid);
        $newid=$newid['id'];
        $newid++;

        $home=$p_home;
        @mysql_query("INSERT INTO `".tabprefix."-sboxes-posts` (id,home,author,name,date,text,ip) VALUES ($newid,$home,$author,'$name',$date,'$text','$ip')");
        $_SESSION[systemuid.'log_posttime']=time();

      }
      else{$msg=lang('global_msg_badinput');}
  
  break;


}
}
else{
$msg=str_replace("*postwait*", $st_postwait, lang('global_msg_timelimit'));
}

}

/*presmerovani*/

  /*zpracovani cesty*/
  if($returnurl!="referer"){
  $exit=root.$returnurl;
  }
  else{
  if($_SERVER['HTTP_REFERER']!=""){$exit=$_SERVER['HTTP_REFERER'];}
  else{$exit="../";}
  }

if($msg==""){
$_SESSION[systemuid.'log_posttime']=time();
header("location: $exit"); exit;
}
else{
  $moduletitle="post_title";
  include("moduleheader.php");
  echo "
  <body>

  <div class='board'>
  <div class='board-padding'>

  <h1>".lang('post_title')."</h1>

  <p>$msg</p>
  <p><a href='$exit'>&lt; ".lang('global_goback')."</a></p>

  </div>
  </div>

  </body>
  </html>
  ";
}

?>
