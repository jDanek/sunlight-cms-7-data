<?php
if($refer!=0){$getrefer="refer=$refer";}else{$getrefer="";}
echo "<form action=\"".modrewrite("login", false, true)."$getrefer\" method=\"post\" name=\"loginform\" onsubmit=\"document.loginform.cryptedpass.value=hex_md5(document.loginform.password.value);document.loginform.password.value='';\">";
if(isset($_POST['loginmodulereferer'])){echo "<input type='hidden' name='loginmodulereferer' value='".$_POST['loginmodulereferer']."' />";}
else{if($loginmodulerefer==true and $_SERVER['HTTP_REFERER']!='' and $refer!=-1){echo "<input type='hidden' name='loginmodulereferer' value='".ampersands($_SERVER['HTTP_REFERER'])."' />";}}
?>

<script type="text/javascript" src="<?php echo root; ?>modules/md5.js">
</script>

<script type="text/javascript">
//<![CDATA[
document.write("<input type='hidden' name='crypted' value='1' />");
document.write("<input type='hidden' name='cryptedpass' value='' />");
//]]>
</script>
<noscript>
<input type="hidden" name="crypted" value="0" />
</noscript>

<h3><?php lang('login_entertitle', 1); ?></h3>

<table>

<tr>
<td><?php lang('global_user', 1); ?>&nbsp;&nbsp;</td>
<td><input type="text" size="20" name="name" /></td>
</tr>

<tr>
<td><?php lang('global_pass', 1); ?></td>
<td><input type="password" size="20" name="password" maxlength="255" /></td>
</tr>

<tr>
<td></td>
<td><input type="submit" value="<?php lang('global_continue', 1); ?> &gt;" /></td>
</tr>

</table>
</form>

<?php
//sestaveni odkazu
if(registration==1){$link1="<a href='".modrewrite("register")."'>".lang('register_link')." &gt;</a>";}else{$link1="";}
if(lostpass==1){$link2="<a href='".root.modrewrite("lostpassword", false, true)."mode=1'>".lang('lostpassword_link')." &gt;</a>";}else{$link2="";}

//vypis odkazu
if($link1!="" or $link2!=""){
echo "<p>";
if($link1!=""){echo $link1; if($link2!=""){echo "<br />\n";}}
if($link2!=""){echo $link2;}
echo "</p>";
}
?>
