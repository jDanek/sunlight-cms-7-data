<?php

/*pripojeni*/
$rootpath=array("path"=>"../");
include("../_connect.php");
include("sessions.php");

/*nacteni pid*/
if(isset($_GET['pid'])){
$pid=$_GET['pid'];
$pid=intval($pid);
}
else{
$pid=-1;
}
$done=0;


/*kontrola loginu*/

  /*nacteni autora*/
  $b_data=@mysql_query("SELECT author,date FROM `".tabprefix."-posts` WHERE id=$pid");
  $b_data=@mysql_fetch_array($b_data);
  
  $b_author=$b_data['author'];
  if($b_author!=-1){
  $b_author_rights=@mysql_query("SELECT rights FROM `".tabprefix."-users` WHERE id=$b_author");
  $b_author_rights=@mysql_fetch_array($b_author_rights);
  $b_author_rights=$b_author_rights['rights'];
  }
  else{
  $b_author_rights=0;
  }

  /*smazani z db*/
  if(postaccess_allow($b_author, $b_author_rights, $b_data['date'])){
  @mysql_query("DELETE FROM `".tabprefix."-posts` WHERE id=$pid");
  $done=1;
  }

header("location: ".referer(true));
exit;

?>
