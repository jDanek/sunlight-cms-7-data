<?php echo "<"; ?>?xml version="1.0" encoding="windows-1250"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="cs">
<head>
[tm:head][/tm:head]
</head>

<body>

<!-- header -->
<div id="header">
	<div id="logo">
		<h1><a href="./">[tm:title][/tm:title]</a></h1>
		<h2>[tm:description][/tm:description]</h2>
	</div>
	<div id="menu">
  <ul>[tm:usermenu][/tm:usermenu]</ul>
	</div>
</div>

<!-- start page -->
<div id="page">

	<!-- content -->
	<div id="content">
	<div id="content-pad">
  [tm:content][/tm:content]
	</div>
	</div>

  <!-- sidebar -->
	<div id="sidebar">
  [tm:boxes][/tm:boxes]
	</div>
	<div class="cleaner"></div>
	
</div>

<!-- footer -->
<div id="footer"></div>
[tm:banner]1,<br />[/tm:banner]
<p id="legal">Design by <a href="http://www.nodethirtythree.com/">NodeThirtyThree</a> | [tm:links][/tm:links]</p>

</body>
</html>
