<?php if(template_auto_write_headings=="true"){echo "<h1>".lang('userlist_title')."</h1>";} ?>
<p><?php lang('userlist_p', 1); ?></p>

<?php
/*nacteni promennych pro filtrovani*/

  /*limit*/
  $filter_limit=$_GET['limit'];
  $filter_limit=intval($filter_limit);
  
  if($filter_limit==0 or $filter_limit=="" or $filter_limit>999){
  $filter_limit=100;
  }

  /*prava*/
  $filter_rightss=$_GET['rights'];
  $filter_rightss=addslashes($filter_rightss);
  switch($filter_rightss){
  case "all": $filter_rights=""; $f_all="selected='selected'"; $f_readers=""; $f_redaction=""; break;
  case "readers": $filter_rights="WHERE rights=0"; $f_all=""; $f_readers="selected='selected'"; $f_redaction=""; break;
  case "redaction": $filter_rights="WHERE rights=1 OR rights=2"; $f_all=""; $f_readers=""; $f_redaction="selected"; break;
  default: $filter_rights=""; $f_all="selected='selected'"; $f_readers=""; $f_redaction=""; break;
  }

/*filtr-formular*/
echo "
<form action='".modrewrite("userlist", true)."' method='get'>
".modrewrite_getinputs("userlist")."

<b>".lang('global_filter')."</b>&nbsp;

<select name='rights'>
<option value='all' $f_all>".lang('global_all')."</option>
<option value='readers' $f_readers>".lang('global_readers')."</option>
<option value='redaction' $f_redaction>".lang('global_adminsandredactors')."</option>
</select>&nbsp;

-&nbsp;<input type='text' size='2' maxlength='3' name='limit' value='$filter_limit' />&nbsp;
".lang('global_perpage').".&nbsp;
<input type='submit' value='".lang('global_justfilter')."' />

</form>
";

/*strankovani*/
if(isset($_GET['s'])){
$startpage=$_GET['s'];
$startpage=intval($startpage);
}
else{
$startpage=0;
}

/*seznam stran*/

  /*spocitani stran*/
  $pocetstran=0;
  $pocetstran=@mysql_result(@mysql_query("SELECT COUNT(*) FROM `".tabprefix."-users` $filter_rights"), 0);
  if($pocetstran==0){$pocetstran=1;}
  $pocetstran=$pocetstran/$filter_limit;
  $pocetstran=ceil($pocetstran);

/*vypis stran*/
if($startpage>9){$strana=$startpage-5;}
else{$strana=0;}
$odkazu=0;
$back=$startpage-10;
$forward=$startpage+10;
echo "<div class='hr'><hr /></div><div class='strany'>".lang('global_page').": ";
if($startpage>=10){echo "<a href='".modrewrite("userlist", false, true)."rights=$filter_rightss&amp;limit=$filter_limit&amp;s=$back'>&lt;</a> ";}

while($strana<$pocetstran and $odkazu<=$st_maxpages){
$odkazu++;
$stranaanchor=$strana+1;
if($strana==$startpage){echo "<a href='".modrewrite("userlist", false, true)."rights=$filter_rightss&amp;limit=$filter_limit&amp;s=$strana' class='active'>$stranaanchor</a> ";}
else{echo "<a href='".modrewrite("userlist", false, true)."rights=$filter_rightss&amp;limit=$filter_limit&amp;s=$strana'>$stranaanchor</a> ";}
$strana++;
}

if($startpage<=$pocetstran-10){echo "<a href='".modrewrite("userlist", false, true)."rights=$filter_rightss&amp;limit=$filter_limit&amp;s=$forward'>&gt;</a> ";}
echo "</div><div class='hr'><hr /></div>\n";

/*vypis uzivatelu*/
echo "<table id='userlist' cellspacing='0'>\n<tr><td class='maintd'>".lang('global_user')."</td><td class='maintd'>".lang('global_rights')."</td></tr>\n";
$start=$startpage*$filter_limit;
$idlist=@mysql_query("SELECT id,name,rights FROM `".tabprefix."-users` $filter_rights ORDER BY rights DESC LIMIT $start,$filter_limit");

while($iditem=@mysql_fetch_array($idlist)){
$iditem['email']=strtr($iditem['email'], $at);

switch($iditem['rights']){
case 0: $idprava=lang('global_reader'); $star=""; break;
case 1: $idprava=lang('global_redactor'); $star="c"; break;
case 2: if($iditem['id']!=0){$idprava=lang('global_administrator'); $star="b";}else{$idprava=lang('global_mainadministrator'); $star="a";} break;
}
if($star!=""){$star="<img src='modules/templates/$st_template/pics/stars/$star.gif' class='star' alt='$star' /> ";}

$idcode="<tr><td>$star<a href='".modrewrite("viewprofile", false, true)."id=".$iditem['name']."'>".$iditem['name']."</a></td><td>".$idprava."</td></tr>\n";
echo $idcode;
}
?>

</table>

<?php echo "<br /><b>".lang('userlist_totalusers').":</b> ".@mysql_result(@mysql_query("SELECT COUNT(*) FROM `".tabprefix."-users`"), 0); ?>
