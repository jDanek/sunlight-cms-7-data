<?php

$content_preload="";
$indicators['preloaded']=1;

if($st_regonly==0 or ($st_regonly==1 and $login_indicator==1) or $_GET['str']=="login"){


  /*----------CLANEK----------*/
  if(isset($_GET['art'])){
    /*nacteni dat*/
    $a_art=$_GET['art'];
    $a_art=intval($a_art);
    $a_content=@mysql_query("SELECT * FROM `".tabprefix."-articles` WHERE id=$a_art");
    $a_content=@mysql_fetch_array($a_content);
    $a_comment=$a_content['comment'];

    /*modul*/
    if($a_comment=="" or ($a_content['date']>time() and !isset($_SESSION[systemuid.'login_aindicator']))){
      $content_title=lang('content_notfound_title'); $content_preload.="lang('content_notfound', 1);";
    }
    else{
      $c_regonly=@mysql_query("SELECT regonly FROM `".tabprefix."-menu` WHERE id=".$a_content['home']);
      $c_regonly=@mysql_fetch_array($c_regonly);
      $c_regonly=$c_regonly['regonly'];
      if($c_regonly==0 or ($c_regonly==1 and $login_indicator==1)){$content_title=$a_content['title']; $content_preload.="include('modules/article.php');";}
      else{$content_title=lang('global_onlyreg_title'); $content_preload.="content_regonlyform();";}
    }
  }
  else{


  /*----------PARAMETRY NEBO UVODNI STRANA----------*/
  $continue=true;

  if($_GET['str']!=""){
  $c_tp=$_GET['tp'];
  $c_tp=intval($c_tp);
  $c_str=$_GET['str'];
  if($c_tp!=4){$c_str=intval($c_str);}
  }
  else{include("modules/mainpage.php");}

  /*----------ROZLISENI OBSAHU A VYPISY----------*/
  if($continue==true){
  
  switch($c_tp){

  /*----------SEKCE----------*/
  case "1":
    /*nacteni dat*/
    $codecontent=@mysql_query("SELECT regonly,anchor,code,comment FROM `".tabprefix."-menu` WHERE id=$c_str AND type=1");
    $codecontent=@mysql_fetch_array($codecontent);
    $c_comment=$codecontent['comment'];
    $c_title=$codecontent['anchor'];
    $c_regonly=$codecontent['regonly'];

    /*modul*/
    if($codecontent['comment']!=""){
      if($c_regonly==0 or ($c_regonly==1 and $login_indicator==1)){$content_title=$c_title; $content_preload.="include('modules/section.php');";}
      else{$content_title=lang('global_onlyreg_title'); $content_preload.="content_regonlyform();";}
    }
    else{
      $content_title=lang('content_notfound_title'); $content_preload.="lang('content_notfound', 1);";
    }
  break;


  /*----------KATEGORIE----------*/
  case "2":
    /*nacteni dat*/
    $ccontent=@mysql_query("SELECT anchor,regonly,code FROM `".tabprefix."-menu` WHERE id=$c_str AND type=2");
    $ccontent=@mysql_fetch_array($ccontent);
    $kategorie=$ccontent['anchor'];
    $c_regonly=$ccontent['regonly'];
    
    /*modul*/
    if($kategorie!=""){
      if($c_regonly==0 or ($c_regonly==1 and $login_indicator==1)){$content_title=$kategorie; $content_preload.="include('modules/category.php');";}
      else{$content_title=lang('global_onlyreg_title'); $content_preload.="content_regonlyform();";}
    }
    else{
      $content_title=lang('content_notfound_title'); $content_preload.="lang('content_notfound', 1);";
    }
  break;


  /*----------KNIHA----------*/
  case "3":
    /*nacteni dat*/
    $bcontent=@mysql_query("SELECT anchor,code,regonly FROM `".tabprefix."-menu` WHERE id=$c_str AND type=3");
    $bcontent=@mysql_fetch_array($bcontent);
    $kniha=$bcontent['anchor'];
    $c_regonly=$bcontent['regonly'];

    /*modul*/
    if($kniha!=""){
      if($c_regonly==0 or ($c_regonly==1 and $login_indicator==1)){$content_title=$kniha; $content_preload.="include('modules/book.php');";}
      else{$content_title=lang('global_onlyreg_title'); $content_preload.="content_regonlyform();";}
    }
    else{
      $content_title=lang('content_notfound_title'); $content_preload.="lang('content_notfound', 1);";
    }
  break;


  /*----------MODUL----------*/
  case "4":
  
  switch($c_str){
  case "postedit": $content_title=lang('post_edit'); $continue=true; break;
  case "commentedit": $content_title=lang('comment_edit'); $continue=true; break;
  case "fulltext": $content_title=lang('fulltext_title'); $continue=true; break;
  case "login": $content_title=lang('global_login'); $continue=true; break;
  case "register": if($st_registration==1){$content_title=lang('register_title'); $continue=true;}else{$continue=false;} break;
  case "settings": if($login_indicator==1){$content_title=lang('settings_title'); $continue=true;}else{$continue=false;} break;
  case "userlist": if($st_userlist==1){$content_title=lang('userlist_title'); $continue=true;}else{$continue=false;} break;
  case "viewarticles": $content_title=lang('viewarticles_title'); $continue=true; break;
  case "viewcomments": $content_title=lang('comment_title2'); $continue=true; break;
  case "viewprofile": $content_title=lang('viewprofile_title'); $continue=true; break;
  case "bbcodehelp": $content_title=lang('bbcode_help_title'); $continue=true; break;
  case "lostpassword": if($st_lostpass==1){$content_title=lang('lostpassword_title'); $continue=true;}else{$continue=false;} break;
  default: $continue=false;
  }

  $modul="modules/$c_str.php";
  if(file_exists($modul) and $continue==true){$content_preload.="include('$modul');";}
  else{$content_title=lang('content_notfound_title'); $content_preload.="lang('content_notfound', 1);";}
  break;


  /*----------FORUM---------*/
  case 6:
    /*nacteni dat*/
    $forumdata=@mysql_query("SELECT regonly,anchor,code FROM `".tabprefix."-menu` WHERE id=$c_str AND type=6");
    $forumdata=@mysql_fetch_array($forumdata);
    $f_regonly=$forumdata['regonly'];
    $f_title=$forumdata['anchor'];

    /*modul*/
    if($forumdata['anchor']!=""){
      if($f_regonly==0 or ($f_regonly==1 and $login_indicator==1)){$content_title=$f_title; $content_preload.="include('modules/forum.php');";}
      else{$content_title=lang('global_onlyreg_title'); $content_preload.="content_regonlyform();";}
    }
    else{
      $content_title=lang('content_notfound_title'); $content_preload.="lang('content_notfound', 1);";
    }
  break;
  
  
  /*----------GALERIE---------*/
  case 7:
    /*nacteni dat*/
    $galdata=@mysql_query("SELECT regonly,anchor,code FROM `".tabprefix."-menu` WHERE id=$c_str AND type=7");
    $galdata=@mysql_fetch_array($galdata);
    $g_title=$galdata['anchor'];
    $g_regonly=$galdata['regonly'];

    /*modul*/
    if($galdata['anchor']!=""){
      if($g_regonly==0 or ($g_regonly==1 and $login_indicator==1)){$content_title=$g_title; $content_preload.="include('modules/gallery.php');";}
      else{$content_title=lang('global_onlyreg_title'); $content_preload.="content_regonlyform();";}
    }
    else{
      $content_title=lang('content_notfound_title'); $content_preload.="lang('content_notfound', 1);";
    }
  break;


  /*----------ROZCESTNIK---------*/
  case 8:
    /*nacteni dat*/
    $gpostdata=@mysql_query("SELECT regonly,anchor,code FROM `".tabprefix."-menu` WHERE id=$c_str AND type=8");
    $gpostdata=@mysql_fetch_array($gpostdata);
    $gp_regonly=$gpostdata['regonly'];
    $gp_title=$gpostdata['anchor'];

    /*modul*/
    if($gpostdata['anchor']!=""){
      if($gp_regonly==0 or ($gp_regonly==1 and $login_indicator==1)){$content_title=$gp_title; $content_preload.="include('modules/gpost.php');";}
      else{$content_title=lang('global_onlyreg_title'); $content_preload.="content_regonlyform();";}
    }
    else{
      $content_title=lang('content_notfound_title'); $content_preload.="lang('content_notfound', 1);";
    }
  break;


  /*----------ERROR----------*/
  default: $content_title=lang('content_notfound_title'); $content_preload.="lang('content_notfound', 1);";

  }
  
  }

  }

}
else{
$content_title=lang('global_onlyreg_title'); $content_preload.="content_regonlyform();";
}

?>
