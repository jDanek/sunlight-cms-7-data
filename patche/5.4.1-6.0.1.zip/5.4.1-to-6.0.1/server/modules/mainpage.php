<?

$default=@mysql_query("SELECT id,type FROM `".tabprefix."-menu` WHERE level=1 AND type!=4 AND type!=5".$st_invismain." ORDER BY ord LIMIT 1");

if(@mysql_num_rows($default)!=0){
  $default=@mysql_fetch_array($default);
  $defid=$default['id'];
  $deftype=$default['type'];
  $c_str=$defid;
  $c_tp=$deftype;
  }
else{
  $content_preload.="lang('content_nokit', 1);";
  $continue=false;
}

?>
