<?php

/*-----kontrola existence dat-----*/
function data_exists($input){
if($input==""){
echo "
<div id=\"adminerror\">
".lang('admin_error')."<br /><br />
<a href=\"".ampersands($_SERVER['HTTP_REFERER'])."\" onclick=\"history.go(-1); return false;\">&lt; ".lang('global_goback')."</a>
</div>

</div></div></div></div>
<div id='shade-bottom'></div>

<hr class='hidden' />
<div id=\"copyright\">".lang('admin_global_copyright')."</div>
</body>
</html>
";
exit;
}
}

/*-----vypis hlasky o zadnem obsahu-----*/
function content_exists($input){
if($input==0){lang('admin_global_nokit', 1);}
}

/*vkladani editoru*/
function content_editor(){
switch(editor){
case 1: return "include('tinymce.smf');"; break;
case 3: return "include('spaw.smf');"; break;
}
}

/*-----logicky vyber tridy clanku-----*/
function artclass($visible, $date){
if($visible==0 and ($date<=time() or futureart=="")){$output="invisible";}
if($visible!=1 and $date>time() and futureart!=""){$output="invisible-future";}
if($visible==1 and ($date<=time() or futureart=="")){$output=false;}
if($visible==1 and ($date>time() and futureart!="")){$output="future";}
if($output!=false){$output=" class='$output'";}else{$output="";}
return $output;
}

/*----schovavani elementu-----*/
function stuff_hide($input, $part){
if($input==0){
  switch($part){
  case 1: echo "<span class='hidden'>"; break;
  case 2: echo "</span>"; break;
  }
}
}

function hideifred($return=false){
if(login_rights==1){
  if($return==false){echo " class='hidden'";}
  else{return " class='hidden'";}
}
}

/*-----seznamove funkce-----*/
function listanchor($input){
if(strlen($input)>24){$input=substr($input, 0, 21)."...";}
return $input;
}

function listcontentexists($input){
if($input==0){echo "<tr><td colspan='2'>".lang('admin_global_nokit')."</td></tr>";}
}

/*-----seznam kategorii-----*/
function categoryselect($selectname, $select=-1){
$return="<select name='$selectname'>\n";
    for($level=1; $level>=0; $level--){
    $cats=@mysql_query("SELECT anchor,id FROM `".tabprefix."-menu` WHERE type=2 AND level=$level ORDER BY ord");
    $counter=0;
    while($cat=@mysql_fetch_array($cats)){
    if($select!=-1){if($cat['id']==$select){$selected=" selected='selected'";}else{$selected="";}}
    $return.="<option value='".$cat['id']."'".$selected.">".$cat['anchor']."</option>\n";
    $counter++;
    }
    }
    if($counter==0){$return.="<option value='-1'>".lang('admin_global_nocats')."</option>\n";}
$return.="\n</select>\n";
return $return;
}

/*-----seznam autoru-----*/
function authorselect($current){
$return="";
  switch(login_rights){

  /*redaktor*/
  case 1:
  $return.=login_name."\n";
  $return.="<input type='hidden' name='author' value='".login_id."' />";
  break;

  /*admin*/
  case 2:
  $return.="<select name='author'>";
  $autori=@mysql_query("SELECT id,name FROM `".tabprefix."-users` WHERE rights=1 OR rights=2");
    while($autor=@mysql_fetch_array($autori)){
    if($autor['id']==$current){$selected=" selected='selected'";}
    else{$selected="";}
    $return.="<option value='".$autor['id']."'$selected>".$autor['name']."</option>\n";
    }
  $return.="</select>";
  break;
  }
return $return;
}

/*-----zobrazovani id polozky-----*/
function showitemid($id){
echo "&nbsp;&nbsp;<b>".lang('admin_forms_itemid').":</b> ".$id;
}

/*-----zobrazovani id polozky-----*/
function selectctype($sel=-1){
$tp_array=array(1,2,0,3,4,6,7,8);
$return="";
  foreach($tp_array as $tp){
  switch($tp){
  case 0: $title=lang('admin_content_article'); break;
  case 1: $title=lang('admin_content_section'); break;
  case 2: $title=lang('admin_content_category'); break;
  case 3: $title=lang('admin_content_book'); break;
  case 4: $title=lang('admin_content_link'); break;
  case 6: $title=lang('admin_content_forum'); break;
  case 7: $title=lang('admin_content_gallery'); break;
  case 8: $title=lang('admin_content_gpost'); break;
  }
  if($sel==$tp){$selected=" selected='selected'";}else{$selected="";}
  $return.="<option value='$tp'$selected>$title</option>";
  }
return $return;
}

?>
