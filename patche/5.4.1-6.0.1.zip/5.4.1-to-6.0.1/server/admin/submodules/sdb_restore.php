<?php

//nastaveni
$id="sdb_restore";
$title="admin_other_sdb_restore";
include("header.php");


//obnova
$returnlink=false;
$logout=false;

  //nacteni souboru
  if(is_uploaded_file($_FILES['sdbfile']['tmp_name']) and strtolower(substr(trim($_FILES['sdbfile']['name']), strrpos(trim($_FILES['sdbfile']['name']), ".")+1))=="sdb"){
  $restdata=file_get_contents($_FILES['sdbfile']['tmp_name']);
  $restdata=gzinflate(base64_decode($restdata));
  
    //kontrola verze zalohy
    $version=substr($restdata, 3, strpos($restdata, "|")-3);
    if($version!=systemversion){
    $msg=str_replace("*version*", strtr($version, $trans), lang('admin_other_sdb_restore_badversion'));
    $returnlink=true;
    }
    else{

      //prepsani nazvu tabulek
      $tablenames=array(
      "[*-articles-*]"          =>tabprefix."-articles",
      "[*-bans-*]"              =>tabprefix."-bans",
      "[*-posts-*]"             =>tabprefix."-posts",
      "[*-boxes-*]"             =>tabprefix."-boxes",
      "[*-comments-*]"          =>tabprefix."-comments",
      "[*-menu-*]"              =>tabprefix."-menu",
      "[*-sboxes-*]"            =>tabprefix."-sboxes",
      "[*-sboxes-posts-*]"      =>tabprefix."-sboxes-posts",
      "[*-settings-*]"          =>tabprefix."-settings",
      "[*-users-*]"             =>tabprefix."-users",
      "[*-votes-*]"             =>tabprefix."-votes",
      "[*-topics-*]"            =>tabprefix."-topics",
      "[*-gpitems-*]"           =>tabprefix."-gpitems",
      "[*-relatedarticles-*]"   =>tabprefix."-relatedarticles",
      "[*-banners-*]"           =>tabprefix."-banners",
      );
      $restdata=strtr($restdata, $tablenames);
      
      //provedeni obnovy
      $restdata=explode("\n", $restdata);
      foreach($restdata as $query){
      if($query!=""){@mysql_query($query);}
      }
      $msg=lang('admin_other_sdb_restore_done')."<hr />";
      $logout=true;

    }
  
  }
  else{
  $msg=lang('admin_other_sdb_restore_failure');
  $returnlink=true;
  }


?>

<div id="padding">
<h1><?php lang('admin_other_sdb_restore', 1); ?></h1>
<p><?php echo $msg; if($returnlink==true){echo "\n<p><a href='../admin.php?pg=other-sdb'>&lt; ".lang('global_goback')."</a></p>"; } ?></p>

</div>
</body>
</html>

<?php if($logout==true){$indicators['securitylogout']=true; include("../logout.php");} ?>
