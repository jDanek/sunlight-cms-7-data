<?php echo "<"; ?>?xml version="1.0" encoding="windows-1250"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="cs">
<head>
  <meta http-equiv="content-type" content="text/html; charset=windows-1250" />
  <link href="<?php if(isset($adminstyle)){echo "../";} ?>style.css" type="text/css" rel="stylesheet" />
  <title><?php if($customtitle!=true){lang($title, 1);}else{echo $title;} ?></title>

<script type="text/javascript">
//<![CDATA[
function ask(){if(!confirm('<?php lang('global_msg_doask', 1); ?>')){return false;}else{return true;}}
//]]>
</script>

</head>

<body>
