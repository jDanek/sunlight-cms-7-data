<?php
$id="massemail_getmails";
$title="admin_users_massemail_getmails";
include("header.php");
?>

<div id="padding">
<h1><?php lang('admin_users_massemail_getmails', 1); ?></h1>
<div class="hr"><hr /></div>


<form action="massemail_getmails.php" method="post">
<input type="hidden" name="akce" value="1" />
<?php lang('global_readers', 1); ?> <input type="checkbox" name="0" value="1" />&nbsp;
<?php lang('global_redactors', 1); ?> <input type="checkbox" name="1" value="1" />&nbsp;
<?php lang('global_admins', 1); ?> <input type="checkbox" name="2" value="1" />&nbsp;|
&nbsp;<?php lang('admin_users_massemail_getmails_linemode', 1); ?> <input type="checkbox" name="linemode" value="1" checked="checked" />&nbsp;
<input type="submit" value="<?php lang('global_do', 1); ?> &gt;" />
</form>
<div class="hr"><hr /></div>


<?php
if(isset($_POST['akce'])){

  /*zjisteni prijemcu*/
  $x=0;
  $first=true;
  $receiver_rights="WHERE (";
  while($x<=2){
    if(isset($_POST[$x])){
    $separator=" OR";
    if($first==true){$first=false; $separator="";}
    $receiver_rights.="$separator rights=$x";
    }
  $x++;
  }
  $receiver_rights.=" ) AND massmail=1";

  /*urceni separatoru*/
  if(checkbox_load($_POST['linemode'])==1){$separator=",";}
  else{$separator="<br />";}

  /*vypis*/
  $receivers=@mysql_query("SELECT email FROM `".tabprefix."-users` $receiver_rights");
  $receivers_code="";
  while($receiver=@mysql_fetch_array($receivers)){$receivers_code.=$separator.$receiver['email'];}
  if($receivers_code!=""){if($separator!="<br />"){$receivers_code=substr($receivers_code, 1); echo "<br />";} echo $receivers_code;}else{lang('admin_users_massemail_noreceivers', 1);}

}
?>


</div>
</body>
</html>
