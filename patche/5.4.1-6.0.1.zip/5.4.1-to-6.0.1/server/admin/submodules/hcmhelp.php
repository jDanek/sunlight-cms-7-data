<?php

$id="hcmhelp";
$title="admin_icons_hcm_title";
$adminstyle=true;
include("header.php");

/*vypis stranky*/
echo "<div id='altcontainer'><div id='altcontainer-crop'>";
lang('admin_docs_text_hcm', 1);

?>

</div></div>
</body>
</html>
