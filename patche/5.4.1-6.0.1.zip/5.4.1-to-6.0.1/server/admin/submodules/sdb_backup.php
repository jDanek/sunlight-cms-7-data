<?php

//nastaveni
$id="sdb_backup";
$nohead=true;
include("header.php");
$result="";


//seznam tabulek
$tables=array(
array(tabprefix."-articles", "[*-articles-*]"),
array(tabprefix."-bans", "[*-bans-*]"),
array(tabprefix."-posts", "[*-posts-*]"),
array(tabprefix."-boxes", "[*-boxes-*]"),
array(tabprefix."-comments", "[*-comments-*]"),
array(tabprefix."-menu", "[*-menu-*]"),
array(tabprefix."-sboxes", "[*-sboxes-*]"),
array(tabprefix."-sboxes-posts", "[*-sboxes-posts-*]"),
array(tabprefix."-settings", "[*-settings-*]"),
array(tabprefix."-users", "[*-users-*]"),
array(tabprefix."-votes", "[*-votes-*]"),
array(tabprefix."-topics", "[*-topics-*]"),
array(tabprefix."-gpitems", "[*-gpitems-*]"),
array(tabprefix."-relatedarticles", "[*-relatedarticles-*]"),
array(tabprefix."-banners", "[*-banners-*]")
);


//cyklovani tabulkami
foreach($tables as $table){

$result.="-- Table: ".$table[0]."\n-- ================================================\n";
$result.="TRUNCATE TABLE `".$table[1]."`\n";
$tabledata=@mysql_query("SELECT * FROM `".$table[0]."`");

  //cyklovani radky
  while($row=@mysql_fetch_array($tabledata)){

    //nacteni sloupcu
    $columns=@mysql_query("SHOW COLUMNS FROM `".$table[0]."`");
    $counter=0;
    $columns_list="";
    while($column=@mysql_fetch_array($columns)){
    $columns_data[$counter]=array($column[0], $column[1]);
    $columns_list.="`".$column[0]."`,";
    $counter++;
    }
    $columns_list=trim($columns_list, ",");

    //sestaveni radku
    $column=0;
    $columns_number=(count($row))/2;
    $wresult="";
    while($column<$columns_number){
      switch($columns_data[$column][1]){
      case "int(6)": case "tinyint(4)": case "bigint(20)": case "int(4)": case "int(11)": case "smallint(6)": $quote=""; break;
      case "mediumtext": case "tinytext": case "text": $quote="'"; break;
      default: $quote=""; break;
      }
    $wresult.=$quote.mysql_escape_string($row[$column]).$quote.",";
    $feedcnt++;
    $column++;
    }
    $wresult=trim($wresult, ",");
    $result.="INSERT INTO `".$table[1]."` ($columns_list) VALUES ($wresult)\n";

  }

$result.="\n\n\n";

}


//vystup

  //pripojeni informaci
  $result="-- ".systemversion."|SunLight CMS Database Backup|DO NOT EDIT\n\n".$result;

include("../../_access.php");
$filename=$c_database."_".date("j_n_Y").".sdb";
header("Content-Description: File Transfer");
header("Content-Type: application/force-download");
header("Content-Disposition: attachment; filename=\"$filename\"");
echo chunk_split(base64_encode(gzdeflate($result)));
exit;

?>
