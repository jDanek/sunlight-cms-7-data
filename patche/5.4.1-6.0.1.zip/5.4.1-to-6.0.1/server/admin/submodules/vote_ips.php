<?php

$id="vote_ips";
$title="admin_forms_showvoteips";
include("header.php");

/*nacteni vid*/
$vid=intval($_GET['vid']);

/*vypis adres*/
echo "<div id='padding'><h1>".lang('admin_forms_showvoteips')."</h1><div class='hr'><hr /></div>";

$ips=@mysql_fetch_array(@mysql_query("SELECT ipcache FROM `".tabprefix."-votes` WHERE id=$vid"));
$ips=explode("|", $ips['ipcache']);
foreach($ips as $ip){
echo $ip."<br />";
}

?>

</div>
</body>
</html>
