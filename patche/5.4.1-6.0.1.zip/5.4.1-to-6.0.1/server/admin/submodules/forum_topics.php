<?php

$id="forum_topics";
$title="Forum topics";
$customtitle=true;
include("header.php");

/*nacteni fid*/
$fid=intval($_GET['fid']);
$existtest=@mysql_result(@mysql_query("SELECT COUNT(*) FROM `".tabprefix."-menu` WHERE id=$fid AND type=6"), 0);
if($existtest==0){exit;}

/*akce*/
if(isset($_GET['action'])){
$action=intval($_GET['action']);

  switch($action){

  /*ulozeni*/
  case 1:
  foreach($_POST as $key=>$value){
  $key=explode("-", $key);
  $key[0]=intval($key[0]);
    $str="";
    $go=true;
    switch($key[1]){
    case "ord": $value=intval($value); break;
    case "title": $value=strtr($value, $trans); $str="'"; if($value==""){$value=lang('global_noname');} break;
    case "perex": $str="'"; if($value==""){$value=lang('global_noname');} break;
    case "regonly_current": $key[1]="regonly"; $value=checkbox_load($_POST[$key[0]."-regonly"]); break;
    case "locked_current": $key[1]="locked"; $value=checkbox_load($_POST[$key[0]."-locked"]); break;
    case "visible_current": $key[1]="visible"; $value=checkbox_load($_POST[$key[0]."-visible"]); break;
    default: $go=false; break;
    }
  if($go==true){@mysql_query("UPDATE `".tabprefix."-topics` SET ".$key[1]."=$str$value$str WHERE id=".$key[0]);}
  }
  break;
  
  /*smazani*/
  case 2:
  $tid=intval($_GET['tid']);
  @mysql_query("DELETE FROM `".tabprefix."-topics` WHERE id=$tid");
  @mysql_query("DELETE FROM `".tabprefix."-posts` WHERE home=$fid AND topic=$tid");
  break;
  
  /*vytvoreni*/
  case 3:
  $ord=intval($_POST['ord']);
  $title=strtr($_POST['title'], $trans);
  $perex=$_POST['perex'];
    if($title!=""){
    $newid=@mysql_fetch_array(@mysql_query("SELECT id FROM `".tabprefix."-topics` ORDER BY id DESC LIMIT 1"));
    $newid=$newid['id']+1;
    @mysql_query("INSERT INTO `".tabprefix."-topics` (id,title,perex,ord,home,locked,visible,regonly) VALUES ($newid,'$title','$perex',$ord,$fid,0,1,0)");
    }
    else{
    $msg=lang('global_msg_someempty');
    include("../../modules/msg.php");
    }
  break;
  
  /*vymazani prispevku*/
  case 4:
  $tid=intval($_GET['tid']);
  @mysql_query("DELETE FROM `".tabprefix."-posts` WHERE home=$fid AND topic=$tid");
  break;

  }

}

?>

<table class="contenttable">
<tr>
<td class="contenttable-box" style="border:none;padding-bottom:0px;">

  <!--novy-->
  <form action="forum_topics.php?fid=<?php echo $fid; ?>&amp;action=3" method="post" class="inline">
  <img src="../pics/icon_new.gif" class="contenttable-icon" alt="new" />&nbsp;
  <input type="text" name="ord" value="0" class="input2" />
  <input type="text" name="title" value="<?php lang('admin_forms_title', 1); ?>" size="14" />
  <input type="text" name="perex" value="<?php lang('admin_forms_description', 1); ?>" size="24" />
  <input type="submit" value="<?php lang('global_create', 1); ?> &gt;" />
  </form>

  <div class="hr"><hr /></div><br />

  <!--seznam-->
  <form action="forum_topics.php?fid=<?php echo $fid; ?>&amp;action=1" method="post">
  <table class="contenttable-list">
  <tr><td><b><?php lang('admin_forms_order', 1); ?></b></td><td><b><?php lang('admin_forms_title', 1); ?></b></td><td><b><?php lang('admin_forms_description', 1); ?></b></td><td><b><?php lang('admin_forms_settings', 1); ?></b></td><td><b><?php lang('global_action', 1); ?></b></td></tr>

    <?php

    $items=@mysql_query("SELECT * FROM `".tabprefix."-topics` WHERE home=$fid ORDER BY ord");
    $highlight=true;
    while($item=mysql_fetch_array($items)){
    $highlight=!$highlight;
    if($highlight==true){$hclass=" class='highlight'";}else{$hclass="";}
    echo "
    <tr$hclass>
    <td><input type='text' name='".$item['id']."-ord' value=\"".$item['ord']."\" class='input2' /></td>
    <td><input type='text' name='".$item['id']."-title' value=\"".$item['title']."\" size='8' /></td>
    <td><input type='text' name='".$item['id']."-perex' value=\"".strtr($item['perex'], $trans)."\" size='14' /></td>
    <td>
    ".lang('admin_forms_regonly')." <input type='checkbox' name='".$item['id']."-regonly' value='1'".checkbox_activate($item['regonly'], true)." /><input type='hidden' name='".$item['id']."-regonly_current' value='".$item['regonly']."' />&nbsp;
    ".lang('admin_forms_closed')." <input type='checkbox' name='".$item['id']."-locked' value='1'".checkbox_activate($item['locked'], true)." /><input type='hidden' name='".$item['id']."-locked_current' value='".$item['locked']."' />&nbsp;
    ".lang('admin_forms_visible')." <input type='checkbox' name='".$item['id']."-visible' value='1'".checkbox_activate($item['visible'], true)." /><input type='hidden' name='".$item['id']."-visible_current' value='".$item['visible']."' />
    </td>
    <td>
    <img src='../pics/icon_deleteposts.gif' class='contenttable-icon' alt='delete' />&nbsp;<a href='forum_topics.php?fid=$fid&amp;tid=".$item['id']."&amp;action=4' onclick='return ask();'>".lang('admin_forms_delposts')."</a>&nbsp;
    <img src='../pics/icon_delete.gif' class='contenttable-icon' alt='delete' />&nbsp;<a href='forum_topics.php?fid=$fid&amp;tid=".$item['id']."&amp;action=2' onclick='return ask();'>".lang('global_delete')."</a>
    </td>
    </tr>
    \n";
    }

    ?>

  </table>
  <input type="submit" value="<?php lang('admin_forms_savetopics', 1); ?> &gt;" />&nbsp;<input type="reset" value="<?php lang('global_reset', 1); ?>" onclick="return ask();" />
  </form>

</td>
</tr>
</table>

</body>
</html>
