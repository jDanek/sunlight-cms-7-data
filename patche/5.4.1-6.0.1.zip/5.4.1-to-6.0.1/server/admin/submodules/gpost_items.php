<?php

$id="gpost_items";
$title="Gpost items";
$customtitle=true;
include("header.php");

/*nacteni gid*/
$gid=intval($_GET['gid']);
$existtest=@mysql_result(@mysql_query("SELECT COUNT(*) FROM `".tabprefix."-menu` WHERE id=$gid AND type=8"), 0);
if($existtest==0){exit;}

/*akce*/
if(isset($_GET['action'])){
$action=intval($_GET['action']);

  switch($action){

  /*ulozeni*/
  case 1:
  foreach($_POST as $key=>$value){
  $key=explode("-", $key);
  $key[0]=intval($key[0]);
    $str="";
    $go=true;
    switch($key[1]){
    case "ord": $value=intval($value); break;
    case "type": $value=intval($value); if($value<0 or $value>8 or $value==5){$value=1;} break;
    case "target": $value=intval($value); break;
    case "title": $value=strtr($value, $trans); $str="'"; if($value==""){$value=lang('global_noname');} break;
    case "perex": $str="'"; if($value==""){$value=lang('global_noname');} break;
    default: $go=false; break;
    }
  if($go==true){@mysql_query("UPDATE `".tabprefix."-gpitems` SET ".$key[1]."=$str$value$str WHERE id=".$key[0]);}
  }
  break;
  
  /*smazani*/
  case 2:
  $gpitid=intval($_GET['gpitid']);
  @mysql_query("DELETE FROM `".tabprefix."-gpitems` WHERE id=$gpitid AND home=$gid");
  break;
  
  /*vytvoreni*/
  case 3:
  $ord=intval($_POST['ord']);
  $type=intval($_POST['type']);
  if($type<0 or $type>8 or $type==5){$type=1;}
  $target=intval($_POST['target']);
  $title=strtr($_POST['title'], $trans);
  $perex=$_POST['perex'];
    if($title!=""){
    $newid=@mysql_fetch_array(@mysql_query("SELECT id FROM `".tabprefix."-gpitems` ORDER BY id DESC LIMIT 1"));
    $newid=$newid['id']+1;
    @mysql_query("INSERT INTO `".tabprefix."-gpitems` (id,home,ord,target,type,title,perex) VALUES ($newid,$gid,$ord,$target,$type,'$title','$perex')");
    }
    else{
    $msg=lang('global_msg_someempty');
    include("../../modules/msg.php");
    }
  break;

  }

}

?>

<table class="contenttable">
<tr>
<td class="contenttable-box" style="border:none;padding-bottom:0px;">

  <!--novy-->
  <form action="gpost_items.php?gid=<?php echo $gid; ?>&amp;action=3" method="post" class="inline">
  <img src="../pics/icon_new.gif" class="contenttable-icon" alt="new" />&nbsp;
  <input type="text" name="ord" value="0" class="input2" />
  <?php echo "<select name='type'>".selectctype()."</select>"; ?>
  <input type="text" name="target" value="<?php lang('admin_forms_target', 1); ?>" class="input4" />
  <input type="text" name="title" value="<?php lang('admin_forms_title', 1); ?>" size="14" />
  <input type="text" name="perex" value="<?php lang('admin_forms_description', 1); ?>" size="24" />
  <input type="submit" value="<?php lang('global_create', 1); ?> &gt;" />
  </form>
  
  <div class="hr"><hr /></div>
  <b><?php lang('admin_forms_type', 1); ?></b> - <?php lang('admin_forms_help_type', 1); ?><br />
  <b><?php lang('admin_forms_target', 1); ?></b> - <?php lang('admin_forms_help_target', 1); ?><br />
  <b><?php lang('global_note', 1); ?>:</b> <?php lang('admin_gpost_notfoundnote', 1); ?>
  <div class="hr"><hr /></div><br />

  <!--seznam-->
  <form action="gpost_items.php?gid=<?php echo $gid; ?>&amp;action=1" method="post">
  <table class="contenttable-list">
  <tr><td><b><?php lang('admin_forms_order', 1); ?></b></td><td><b><?php lang('admin_forms_type', 1); ?></b></td><td><b><?php lang('admin_forms_target', 1); ?></b></td><td><b><?php lang('admin_forms_title', 1); ?></b></td><td><b><?php lang('admin_forms_description', 1); ?></b></td><td><b><?php lang('global_action', 1); ?></b></td></tr>

    <?php

    $items=@mysql_query("SELECT * FROM `".tabprefix."-gpitems` WHERE home=$gid ORDER BY ord");
    $highlight=true;
    while($item=mysql_fetch_array($items)){
    
      //nacteni titulku
      if($item['type']!=0){$anchor=@mysql_fetch_array(@mysql_query("SELECT anchor FROM `".tabprefix."-menu` WHERE id=".$item['target']." AND type=".$item['type'])); $anchor=$anchor['anchor'];}
      else{$anchor=@mysql_fetch_array(@mysql_query("SELECT title FROM `".tabprefix."-articles` WHERE id=".$item['target'])); $anchor=$anchor['title'];}
      if($anchor==""){$notfound=true;}else{$notfound=false;}
    
    //vypis
    $highlight=!$highlight;
    if($notfound==false){if($highlight==true){$hclass=" class='highlight'";}else{$hclass="";}}
    else{$hclass=" class='notfound'";}
    
    echo "
    <tr$hclass>
    <td><input type='text' name='".$item['id']."-ord' value=\"".$item['ord']."\" class='input2' /></td>
    <td><select name='".$item['id']."-type'>".selectctype($item['type'])."</select></td>
    <td><input type='text' name='".$item['id']."-target' value=\"".$item['target']."\" class='input4' /></td>
    <td><input type='text' name='".$item['id']."-title' value=\"".$item['title']."\" size='18' title='$anchor' /></td>
    <td><input type='text' name='".$item['id']."-perex' value=\"".strtr($item['perex'], $trans)."\" size='48' /></td>
    <td><img src='../pics/icon_delete.gif' class='contenttable-icon' alt='delete' />&nbsp;<a href='gpost_items.php?gid=$gid&amp;gpitid=".$item['id']."&amp;action=2' onclick='return ask();'>".lang('global_delete')."</a></td>
    </tr>
    \n";
    }

    ?>

  </table>
  <input type="submit" value="<?php lang('admin_forms_saveitems', 1); ?> &gt;" />&nbsp;<input type="reset" value="<?php lang('global_reset', 1); ?>" onclick="return ask();" />
  </form>

</td>
</tr>
</table>

</body>
</html>
