<?php

$id="article_related";
$title="Related articles";
$customtitle=true;
include("header.php");

/*nacteni aid*/
$aid=intval($_GET['aid']);
$existtest=@mysql_result(@mysql_query("SELECT COUNT(*) FROM `".tabprefix."-articles` WHERE id=$aid"), 0);
if($existtest==0){exit;}

/*akce*/
if(isset($_GET['action'])){
$action=intval($_GET['action']);

  switch($action){

  /*ulozeni*/
  case 1:
  foreach($_POST as $key=>$value){
  $key=explode("-", $key);
  $key[0]=intval($key[0]);
    $str="";
    $go=true;
    switch($key[1]){
    case "ord": $value=intval($value); break;
    case "type": $value=intval($value); if($value<0 or $value>8 or $value==5){$value=1;} break;
    case "target": $value=intval($value); break;
    case "title": $value=strtr($value, $trans); $str="'"; if($value==""){$value=lang('global_noname');} break;
    case "perex": $value=strtr($value, $trans); $str="'"; if($value==""){$value=lang('global_noname');} break;
    default: $go=false; break;
    }
  if($go==true){@mysql_query("UPDATE `".tabprefix."-relatedarticles` SET ".$key[1]."=$str$value$str WHERE id=".$key[0]);}
  }
  break;

  /*smazani*/
  case 2:
  $itemid=intval($_GET['itemid']);
  @mysql_query("DELETE FROM `".tabprefix."-relatedarticles` WHERE id=$itemid AND home=$aid");
  break;

  /*vytvoreni*/
  case 3:
  $ord=intval($_POST['ord']);
  $target=intval($_POST['target']);

    $newid=@mysql_fetch_array(@mysql_query("SELECT id FROM `".tabprefix."-relatedarticles` ORDER BY id DESC LIMIT 1"));
    $newid=$newid['id']+1;
    @mysql_query("INSERT INTO `".tabprefix."-relatedarticles` (id,home,ord,target) VALUES ($newid,$aid,$ord,$target)");
    
  break;

  }

}

?>

<table class="contenttable">
<tr>
<td class="contenttable-box" style="border:none;padding-bottom:0px;">

  <!--novy-->
  <form action="article_related.php?aid=<?php echo $aid; ?>&amp;action=3" method="post" class="inline">
  <img src="../pics/icon_new.gif" class="contenttable-icon" alt="new" />&nbsp;
  <input type="text" name="ord" value="0" class="input2" />
  <input type="text" name="target" value="<?php lang('admin_forms_target', 1); ?>" size="24" />
  <input type="submit" value="<?php lang('global_create', 1); ?> &gt;" />
  </form>

  <div class="hr"><hr /></div>
  <b><?php lang('admin_forms_target', 1); ?></b> - <?php lang('admin_forms_help_target_art', 1); ?><br />
  <b><?php lang('global_note', 1); ?>:</b> <?php lang('admin_gpost_notfoundnote', 1); ?>
  <div class="hr"><hr /></div><br />

  <!--seznam-->
  <form action="article_related.php?aid=<?php echo $aid; ?>&amp;action=1" method="post">
  <table class="contenttable-list">
  <tr><td><b><?php lang('admin_forms_order', 1); ?></b></td><td><b><?php lang('admin_forms_target', 1); ?></b></td><td><b><?php lang('admin_forms_title', 1); ?></b></td><td><b><?php lang('global_action', 1); ?></b></td></tr>

    <?php

    $items=@mysql_query("SELECT * FROM `".tabprefix."-relatedarticles` WHERE home=$aid ORDER BY ord");
    $highlight=true;
    while($item=mysql_fetch_array($items)){

      //nacteni titulku
      $anchor=@mysql_fetch_array(@mysql_query("SELECT title FROM `".tabprefix."-articles` WHERE id=".$item['target'])); $anchor=$anchor['title'];
      if($anchor==""){$notfound=true;}else{$notfound=false;}

    //vypis
    $highlight=!$highlight;
    if($notfound==false){if($highlight==true){$hclass=" class='highlight'";}else{$hclass="";}}
    else{$hclass=" class='notfound'";}

    echo "
    <tr$hclass>
    <td><input type='text' name='".$item['id']."-ord' value=\"".$item['ord']."\" class='input2' /></td>
    <td><input type='text' name='".$item['id']."-target' value=\"".$item['target']."\" size='24' /></td>
    <td>".listanchor($anchor)."</td>
    <td><img src='../pics/icon_delete.gif' class='contenttable-icon' alt='delete' />&nbsp;<a href='article_related.php?aid=$aid&amp;itemid=".$item['id']."&amp;action=2' onclick='return ask();'>".lang('global_delete')."</a></td>
    </tr>
    \n";
    }

    ?>

  </table>
  <input type="submit" value="<?php lang('admin_forms_saveitems', 1); ?> &gt;" />&nbsp;<input type="reset" value="<?php lang('global_reset', 1); ?>" onclick="return ask();" />
  </form>
  
  <?php
  $items=@mysql_query("SELECT home FROM `".tabprefix."-relatedarticles` WHERE target=$aid ORDER BY ord");
  $counter=0;
  $a_inherited="";
  while($item=@mysql_fetch_array($items)){
  $reltitle=@mysql_fetch_array(@mysql_query("SELECT title FROM `".tabprefix."-articles` WHERE id=".$item['home']));
  if($reltitle!=""){$a_inherited.="<a href='".artrewrite($item['home'], $reltitle['title'])."' target='_blank'>".$reltitle['title']."</a><br />";}
  $counter++;
  }
  
  if($counter!=0){
  echo "<br /><div class='hr'><hr /></div><h2>".lang('admin_forms_articles_inherited')."</h2>".$a_inherited;
  }
  ?>

</td>
</tr>
</table>

</body>
</html>
