<?php

$rootpath=array("path"=>"../../");
include("../../_connect.php");

session_start();
if(!isset($_SESSION[systemuid.'login_aindicator'])){exit;}

$moduletitle="admin_forms_preview";
$moduleheader_code="<base href=\"$st_serverurl/\" />\n";
include("../../modules/moduleheader.php");

?>

<body>

<div class="board">
<div class="board-padding">

<?php
//echo "<pre>"; print_r($_POST); echo "</pre>";

if(isset($_POST['code'])){
  $isdata=true;
  $mode=intval($_POST['mode']);
  $code=content_editor_process(striphcm(stripslashes($_POST['code'])));
}
else{
  $isdata=false;
}
?>

<h1>
<?php
switch($mode){
case 1: lang('admin_preview_title_section', 1); break;
case 2: lang('admin_preview_title_article', 1); break;
case 3: lang('admin_preview_title_massmail', 1); break;
}
?>
</h1>

<?php lang('admin_preview_p', 1); ?>
<div class="hr"><hr /></div>
<br />

<?php

if($isdata==true){
  switch($mode){
  case 1: echo $code; break;
  case 2: $perex=stripslashes($_POST['perex']); $title=stripslashes(strtr($_POST['title'], $trans)); echo "<h1>$title</h1><p class='aperex'>$perex</p>$code"; break;
  case 3: if($_POST['ctype']==1){$code=nl2br(strtr($code, $trans));} echo $code; break;
  default: lang('global_msg_badinput', 1); break;
  }
}
else{
lang('global_msg_badinput', 1);
}

?>

</div>
</div>

</body>
</html>
