<?php
include("check.php");
include("header.php");
include("functions.php")

?>

<script type="text/javascript">
//<![CDATA[
function ask(){if(!confirm('<?php lang('global_msg_doask', 1); ?>')){return false;}else{return true;}}
//]]>
</script>

<div id="shortcut-icons">
<a href="../" target="_blank" title="<?php lang('admin_icons_showmain', 1); ?>"><img src="pics/icon_showmain.gif" class="micon"  alt="<?php lang('admin_icons_showmain', 1); ?>" /></a>
<a href="admin.php" target="_blank" title="<?php lang('admin_icons_newwin', 1); ?>"><img src="pics/icon_newwin.gif" class="micon"  alt="<?php lang('admin_icons_newwin', 1); ?>" /></a>
<a href="submodules/hcmhelp.php" target="_blank" title="<?php lang('admin_icons_hcm', 1); ?>"><img src="pics/icon_hcm.gif" class="micon"  alt="<?php lang('admin_icons_hcm', 1); ?>" /></a>
<a href="admin.php?pg=docs" title="<?php lang('admin_icons_help', 1); ?>"><img src="pics/icon_help.gif" class="micon"  alt="<?php lang('admin_icons_help', 1); ?>" /></a>
</div>

<div id="shade-top"></div>
<div id="shade-middle">
<div id="container">
<div id="container-padding">

<!--logo-->
<div id="logo"><span><a><?php echo $login_name; ?></a> | <a href="logout.php"><?php lang('admin_logout', 1); ?></a></span></div>

<!--menu-->
<hr class="hidden" />
<div id="menu">
<div id="menu-padding">
<?php
/*uvod*/              echo "<a href='admin.php?pg=home'>".lang('admin_mainmenu_home')."</a> | ";
/*sprava obsahu*/     echo "<a href='admin.php?pg=content'>".lang('admin_mainmenu_content')."</a> | ";
/*sprava uzivatelu*/  if($login_rights==2){echo "\n<a href='admin.php?pg=users'>".lang('admin_mainmenu_users')."</a> | ";}
/*nastaveni*/         if($login_id==0){echo "<a href='admin.php?pg=settings'>".lang('admin_mainmenu_settings')."</a> | ";}
/*upload*/            if(($login_rights==2 and $st_admcanup==1) or ($login_rights==1 and $st_redcanup==1) or $login_id==0){echo "<a href='admin.php?pg=upload'>".lang('admin_mainmenu_upload')."</a> | ";}
/*ostatni*/           if($login_id==0 or ($login_rights==2 and $st_admbanners==1)){echo "<a href='admin.php?pg=other'>".lang('admin_mainmenu_other')."</a> | ";}
/*dokumentace*/       echo "<a href='admin.php?pg=docs'>".lang('admin_mainmenu_docs')."</a>";
?>
</div>
</div>
<hr class="hidden" />

<!--content-->
<div id="content">

<?php
/*vlozeni dle pg*/
if(isset($_GET['pg'])){

/*nacteni parametru pg*/
$pg=$_GET['pg'];
$pg=anchor($pg);

$accessgranted=true;

/*pristupova prava redaktoru*/
if($login_rights==1){
  switch($pg){
  case "other-blocking":
  case "content-boxes":
  case "content-deletebook":
  case "content-deletebox":
  case "content-deletecategory":
  case "content-deleteforum":
  case "content-deletelink":
  case "content-deletesection":
  case "content-deleteseparator":
  case "content-editbook":
  case "content-editbox":
  case "content-editcategory":
  case "content-editforum":
  case "content-editlink":
  case "content-editsection":
  case "content-editseparator":
  case "content-menuanchor":
  case "content-menuorder":
  case "content-menusublinks":
  case "content-mergecats":
  case "content-newbook":
  case "content-newbox":
  case "content-newcategory":
  case "content-newforum":
  case "content-newlink":
  case "content-newsection":
  case "content-newseparator":
  case "content-newvote":
  case "content-sboxes":
  case "settings":
  case "users-inactive":
  case "users-list":
  case "users-massemail":
  case "users-rate":
  case "users":
  case "other":
  case "other-sdb":
  case "other-banners":
  $accessgranted=false; break;
  }
  if($pg=="upload" and $st_redcanup!=1){$accessgranted=false;}
  if(($pg=="content-deletevote" or $pg=="content-editvote" or $pg=="content-newvote" or $pg=="content-votes") and $st_redvote!=1){$accessgranted=false;}
}

/*pristupova prava administratoru*/
if($login_id!=0){
  switch($pg){
  case "other-blocking":
  case "settings":
  case "users-inactive":
  case "other-sdb":
  $accessgranted=false; break;
  }
  if($pg=="users-massemail" and $st_adminmassmail!=1){$accessgranted=false;}
  if($pg=="upload" and $st_admcanup!=1){$accessgranted=false;}
  if(($pg=="other-banners" or $pg=="other") and $st_admbanners!=1){$accessgranted=false;}
}

/*pristupova prava k souborum _inc*/
if(substr($pg, 0, 4)=="_inc"){
$accessgranted=false;
}
else{
if($accessgranted!=false){$accessgranted=true;}
}

/*pridani cesty k parametru pg a vlozeni*/
$pg="modules/$pg.inc";

  if(file_exists($pg)){

    if($accessgranted==true){
    include($pg);
    }
    else{
    echo "<b>".lang('global_denied')."</b>";
    }

  }
  else{
  include("modules/home.inc");
  }

}
else{
include("modules/home.inc");
}

?>

</div>


</div>
</div>
</div>
<div id="shade-bottom"></div>

<!--copyright-->
<hr class="hidden" />
<div id="copyright"><?php lang('admin_global_copyright', 1); ?></div>

</body>
</html>

<?php @mysql_close($connection) ?>
