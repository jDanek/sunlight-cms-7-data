<?php

/*inicializace*/
$rootpath=array("path"=>"./");
include("_connect.php");
include("modules/sessions.php");
include("modules/content_preload.php");

/*vlozeni layoutu*/
if(!isset($_GET['templatefile']) and !isset($_POST['templatefile']) and isset($indicators['templatefile_loaded'])){
eval(parsetm(file_get_contents($templatefile)));
}

/*odpojeni*/
@mysql_close($connection);

?>
