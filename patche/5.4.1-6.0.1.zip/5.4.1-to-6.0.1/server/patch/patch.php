<?php

/*pripojeni*/
$rootpath=array("path"=>"../");
$indicators['installmode']=1;
include("../_connect.php");

/*instalace*/
if(isset($_POST['akce'])){

  //nacteni promennych
  if(isset($_POST['agree'])){$agree=true;}else{$agree=false;}

  //kontrola
  if($agree==true){

      //zalohovani obsahu tabulky sections
      $sections=@mysql_query("SELECT * FROM `".tabprefix."-sections`");

      //provedeni
      $mysql_errors="";
      $query_replace=array("*tabprefix*"=>tabprefix);
      $query=file_get_contents("query.sql");
      if($rewritetabs==1){$query=file_get_contents("rewrite.sql")."\n".$query;}
      $query=explode("\n", strtr($query, $query_replace));
      foreach($query as $line){
      if(ord($line)!=13 and ord($line)!=0 and $line!=""){
      @mysql_query(trim(trim($line), ";"));
      $mysql_errors.=mysql_error();
      }
      }
      
      //obnova tabulky sections
      while($section=@mysql_fetch_array($sections)){
      @mysql_query("UPDATE `".tabprefix."-menu` SET code='".mysql_escape_string($section['code'])."' WHERE id=".$section['home']);
      @mysql_query("UPDATE `".tabprefix."-menu` SET comment='".$section['comment']."' WHERE id=".$section['home']);
      }

      //hlaska
      if(trim($mysql_errors)==""){$msg="Patch byl aplikov�n. Sma�te slo�ku patch ze serveru.";}
      else{$msg="P�i aplikaci do�lo k chyb�. V�ce informac� v souboru ctimne.txt.";}

  }else{$msg="Pro aplikaci patche mus�te souhlasit s novou licenc�.";}

}

?>

<?php echo "<"; ?>?xml version="1.0" encoding="windows-1250"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="cs">
<head>
  <meta http-equiv="content-type" content="text/html; charset=windows-1250" />
  <style type="text/css">
  body {font-size: 13px; color: black; background-color: white; font-family: Arial, Helvetica, sans-serif;}
  .msg {font-weight: bold;}
  </style>
  <title>Patch datab�ze SunLight CMS - 5.4.1 na 6.0.1</title>
</head>

<body>

<?php

//zprava
include("../modules/msg.php");

?>

<form action="patch.php" method="post">

<h1>Patch datab�ze SunLight CMS - 5.4.1 na 6.0.1</h1>
<p>
Do�lo ke zm�n� licence z open source na freeware a s t�mto
vstupuje v platnost jej� nov� zn�n� (n�e), kter� se t�k�
verze 6.0.0 a nov�j��ch. Pro v�echny verze star�� ne� 6.0.0
plat� p�vodn� zn�n� a licence open source. Poru�ujete-li dosavadn�m
zp�sobem pou�it� syst�mu novou licenci, mus�te tyto nedostatky
odstranit nebo nesm�te patch aplikovat.
</p>

<h2>Nov� zn�n� licence</h2>
<ul>
<li>sunlight cms (d�le jen syst�m) je FREEWARE</li>
<li>syst�m je poskytov�n zdarma pro nev�d�le�n� ��ely (komer�n� vyu�it� je mo�n� a� po dohod� s autorem)</li>
<li>nen� povoleno poskytovat nebo pronaj�mat syst�m nebo jeho ��st za �platu (vyj�mku tvo�� pouze vlastn� motivy, dopl�kov� moduly, jazykov� soubory a body dohodnut� s autorem)</li>
<li>do syst�mu sm� b�t zasahov�no jen se souhlasem autora (net�k� se - viz obsah z�vorek v��e)</li>
<li>prost�ednictv�m syst�mu nesm� b�t publikov�n obsah, kter� poru�uje platn� z�kony dan� zem�</li>
<li>instalac� a/nebo pou��v�n�m syst�mu potvrzujete souhlas s licenc�</li>
<li>autor si vyhrazuje pr�vo na zm�nu zn�n� licence, zm�ny vstupuj� v platnost dnem uve�ejn�n�</li>
<li>tato licence je platn� pro v�echny verze syst�mu od 6.0.0 (v�etn�) a jej� aktu�ln� zn�n� je uvedeno na domovsk�ch str�nk�ch</li>
</ul>

<input type="checkbox" name="agree" value="1" /> potvrzuji souhlas s novou licenc� a to, �e dosavadn�m zp�sobem pou�it� syst�mu ji neporu�uji

<hr />

<p>P�ed aplikac� patche prove�te z�lohu va�� datab�ze.</p>

<input type="hidden" name="akce" value="1" />
<input type="submit" value="Aplikovat patch &gt;" />
</form>

</body>
</html>
