<?php

if(!defined('_core')) {
exit;
}


$type = 4;
require "require/sub/content-editscript-init.php";
require "require/sub/content-editscript.php";