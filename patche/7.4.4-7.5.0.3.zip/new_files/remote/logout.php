<?php

if(!defined('_core')) {
define('_indexroot', '../');
require _indexroot."require/load.php";
}


if(_xsrfCheck(true)) _userLogout();
_returnHeader();