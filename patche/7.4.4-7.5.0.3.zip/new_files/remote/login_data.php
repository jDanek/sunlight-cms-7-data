<?php

define('_indexroot', '../');
define('_header', '');
require _indexroot."require/load.php";


header('Cache-Control: no-cache, must-revalidate');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
header('Content-type: application/json');


_checkKeys('_POST', array('username'));
if(_loginindicator) die;



$username = DB::esc($_POST['username']);
$email = (strpos($_POST['username'], '@') !== false);
$q = DB::row(DB::query("SELECT id,salt FROM `"._mysql_prefix."-users` WHERE `".($email ? 'email' : 'username')."`='".$username."'".((!$email && $username !== '') ? ' OR publicname=\''.$username.'\'' : '')));
if($q === false) echo '{"success":false}';
else echo '{"success":true,"data":['.$q['id'].',"'.$q['salt'].'"]}';
die;