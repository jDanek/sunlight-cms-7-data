if(!sl_login_script) {
    var sl_login_script = true;
    $(document).ready(function(){
    
        // focus
        var focus_form = $('form[name=login_form]').get(0);
        if(focus_form) $(focus_form).find('input[name=username]').focus();
        
        // funkce pri odeslani formu
        $('form[name=login_form]').submit(function(){
            
            // nacist inputy
            var form = $(this);
            var uname = form.find('input[name=username]').get(0);
            var passw = form.find('input[name=password]').get(0);
            var secure = form.find('input[name=secure]').get(0);
            var submit = form.find('input[type=submit]').get(0);
            
            // nacist zadane jmeno a heslo
            var passw_val = $(passw).attr('value');
            var uname_val = $(uname).attr('value');
            if(passw_val === '' || uname_val === '') return false;
            
            // kontrola klice pro prihlaseni
            if(sl_login_key === undefined || sl_login_key === '') return false;
            
            // deaktivovat form
            $(form).find('input').attr('disabled', 'disabled');
            
            // funkce pro aktivaci formu
            function form_activate(){
                $(form).find('input').removeAttr('disabled');
            }
            
            // nacasovat aktivaci
            var timeout = setTimeout(function(){form_activate();}, 4000);
            
            // nacist data
            $.ajax(sl_indexroot+'remote/login_data.php',{
                cache: false,
                type: 'POST',
                dataType: 'json',
                data: {username: uname_val},
                success: function(res) {
                    
                    // aktivovat form
                    clearTimeout(timeout);
                    form_activate();
                    
                    // pouzit data
                    if(res.success) {
                        
                        // deaktivovat pouze jmeno a heslo
                        $(uname).attr('disabled', 'disabled');
                        $(passw).attr('disabled', 'disabled');
                        
                        // vypocitat a vyplnit prihlasovaci token
                        var hash = res.data[0]+'$'+Crypto.HMAC(Crypto.MD5, Crypto.MD5(res.data[1]+passw_val+res.data[1]), sl_login_key);
                        $(secure).attr('value', hash);
                        
                    }
                    
                    // odeslat formular
                    form.unbind('submit');
                    form.submit();
                        
                },
                error: function() {
                    
                    // aktivovat form
                    clearTimeout(timeout);
                    form_activate();
                    
                }
            });
            
            return false;
    
        });
    });
}