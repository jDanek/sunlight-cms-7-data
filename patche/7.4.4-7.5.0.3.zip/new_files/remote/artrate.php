<?php

define('_indexroot', '../');
require _indexroot."require/load.php";
if(_ratemode == 0) {
exit;
}




_checkKeys('_POST', array('id'));
$id = intval($_POST['id']);


$article_exists = false;


$continue = false;
$query = DB::query("SELECT id,title_seo,time,confirmed,public,home1,home2,home3,rateon FROM `"._mysql_prefix."-articles` WHERE id=".$id);
if(DB::size($query) != 0) {
$article_exists = true;
$query = DB::row($query);
if(isset($_POST['r'])) {
$r = round($_POST['r'] / 10) * 10;
if(_iplogCheck(3, $id) and _xsrfCheck() and $query['rateon'] == 1 and _articleAccess($query) == 1 and $r <= 100 and $r >= 0) {
$continue = true;
}
}
}


if($continue) {
DB::query("UPDATE `"._mysql_prefix."-articles` SET ratenum=ratenum+1,ratesum=ratesum+".$r." WHERE id=".$id);
_iplogUpdate(3, $id);
}


if($article_exists) {
$aurl = _linkArticle($id, $query['title_seo'])."#ainfo";
} else {
$aurl = "";
}
header("location: "._url.'/'.$aurl);