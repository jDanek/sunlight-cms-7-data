<?php

// pripojeni k db
require 'config.php';
$con = @mysql_connect($server, $user, $password);
if(!is_resource($con)) die('Nepodarilo se pripojit k databazi!<br>'.mysql_error());
if(!@mysql_select_db($database)) die('Nepodarilo se zvolit aktualni databazi!');
mysql_query('SET NAMES `utf8`');

// zjisteni verze db
$q = mysql_query('SELECT val FROM `'.$prefix.'-settings` WHERE var=\'dbversion\'');
if(!is_resource($q) || mysql_num_rows($q) !== 1) die('Nepodarilo se zjistit verzi databaze!');
$q = mysql_fetch_assoc($q);
$q = $q['val'];

// kontrola verze db
if($q !== '7.4.4') {
    if($q === '7.5.0') die('Patch byl jiz aplikovan, smazte soubor patch.php!');
    die('Nespravna verze databaze!');
}

// priprava sql dotazu
$sql = array();
$sql[] = 'INSERT INTO `'.$prefix.'-settings` (`var` ,`val`)VALUES (\'admin_index_custom\', \'\')';
$sql[] = 'INSERT INTO `'.$prefix.'-settings` (`var` ,`val`)VALUES (\'admin_index_custom_pos\', \'1\')';
$sql[] = 'INSERT INTO `'.$prefix.'-settings` (`var` ,`val`)VALUES (\'adminscheme_mode\', \'0\')';
$sql[] = 'INSERT INTO `'.$prefix.'-settings` (`var` ,`val`)VALUES (\'extend_enabled\', \'0\')';
$sql[] = 'DELETE FROM `'.$prefix.'-settings` WHERE `var`=\'modrewrite_type\'';
$sql[] = 'ALTER TABLE `'.$prefix.'-root` ADD `title_seo` VARCHAR( 64 ) NOT NULL AFTER `title`';
$sql[] = 'ALTER TABLE `'.$prefix.'-root` ADD INDEX ( `title_seo` )';
$sql[] = 'ALTER TABLE `'.$prefix.'-articles` ADD `title_seo` VARCHAR( 64 ) NOT NULL AFTER `title`';
$sql[] = 'ALTER TABLE `'.$prefix.'-articles` ADD INDEX ( `title_seo` )'; 
$sql[] = 'INSERT INTO `'.$prefix.'-settings` (`var` ,`val`)VALUES (\'index_page_id\', \'-1\')';
$sql[] = 'UPDATE `'.$prefix.'-settings` SET `val` = \'7.5.0\' WHERE `var` = \'dbversion\'';
$sql[] = 'UPDATE `'.$prefix.'-settings` SET `val` = `val`+1 WHERE `var` = \'cacheid\'';
$sql[] = 'ALTER TABLE `'.$prefix.'-root` ADD `autotitle` BOOLEAN NOT NULL DEFAULT \'0\' AFTER `public`';
$sql[] = 'UPDATE `'.$prefix.'-root` SET `autotitle`=`var2` WHERE `type`=1';
$sql[] = 'UPDATE `'.$prefix.'-root` SET `var2`=0 WHERE `type`=1';
$sql[] = 'UPDATE `'.$prefix.'-root` SET `autotitle`=1 WHERE `type`!=1';
$sql[] = 'DROP TABLE `'.$prefix.'-messages`';
$sql[] = 'CREATE TABLE `'.$prefix.'-pm` (`id` int(11) NOT NULL AUTO_INCREMENT,`sender` int(11) NOT NULL,`sender_readtime` int(11) NOT NULL DEFAULT \'0\',`sender_deleted` tinyint(1) NOT NULL DEFAULT \'0\',`receiver` int(11) NOT NULL,`receiver_readtime` int(11) NOT NULL DEFAULT \'0\',`receiver_deleted` tinyint(1) NOT NULL DEFAULT \'0\',`update_time` int(11) NOT NULL DEFAULT \'0\',PRIMARY KEY (`id`),KEY `sender` (`sender`),KEY `receiver` (`receiver`),KEY `update_time` (`update_time`),KEY `sender_deleted` (`sender_deleted`),KEY `receiver_deleted` (`receiver_deleted`)) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1';
$sql[] = 'CREATE TABLE `'.$prefix.'-redir` (`id` int(11) NOT NULL AUTO_INCREMENT,`old` varchar(64) NOT NULL,`new` varchar(64) NOT NULL,`active` tinyint(1) NOT NULL DEFAULT \'1\',PRIMARY KEY (`id`),KEY `old` (`old`),KEY `active` (`active`)) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1';
$sql[] = 'ALTER TABLE `'.$prefix.'-users` CHANGE `username` `username` VARCHAR( 24 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL';
$sql[] = 'ALTER TABLE `'.$prefix.'-users` CHANGE `publicname` `publicname` VARCHAR( 24 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL'; 
$sql[] = 'ALTER TABLE `'.$prefix.'-users` CHANGE `password` `password` VARCHAR( 32 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL';
$sql[] = 'ALTER TABLE `'.$prefix.'-users` CHANGE `language` `language` VARCHAR( 12 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL';
$sql[] = 'ALTER TABLE `'.$prefix.'-users` CHANGE `ip` `ip` VARCHAR( 15 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL';
$sql[] = 'ALTER TABLE `'.$prefix.'-root` CHANGE `title` `title` VARCHAR( 96 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL'; 
$sql[] = 'ALTER TABLE `'.$prefix.'-boxes` CHANGE `title` `title` VARCHAR( 32 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL';
$sql[] = 'ALTER TABLE `'.$prefix.'-groups` CHANGE `title` `title` VARCHAR( 32 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL';
$sql[] = 'ALTER TABLE `'.$prefix.'-groups` CHANGE `icon` `icon` VARCHAR( 16 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL';
$sql[] = 'ALTER TABLE `'.$prefix.'-images` CHANGE `title` `title` VARCHAR( 32 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL';
$sql[] = 'ALTER TABLE `'.$prefix.'-iplog` CHANGE `ip` `ip` VARCHAR( 15 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL';
$sql[] = 'ALTER TABLE `'.$prefix.'-polls` CHANGE `votes` `votes` TINYTEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL';
$sql[] = 'ALTER TABLE `'.$prefix.'-polls` CHANGE `question` `question` VARCHAR( 96 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL'; 
$sql[] = 'ALTER TABLE `'.$prefix.'-posts` CHANGE `subject` `subject` VARCHAR( 48 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL';
$sql[] = 'ALTER TABLE `'.$prefix.'-posts` CHANGE `guest` `guest` VARCHAR( 24 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL';
$sql[] = 'ALTER TABLE `'.$prefix.'-posts` CHANGE `ip` `ip` VARCHAR( 15 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL';
$sql[] = 'ALTER TABLE `'.$prefix.'-sboxes` CHANGE `title` `title` VARCHAR( 64 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL'; 
$sql[] = 'ALTER TABLE `'.$prefix.'-user-activation` CHANGE `username` `username` VARCHAR( 24 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL'; 
$sql[] = 'ALTER TABLE `'.$prefix.'-user-activation` CHANGE `password` `password` VARCHAR( 32 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL';
$sql[] = 'ALTER TABLE `'.$prefix.'-user-activation` CHANGE `salt` `salt` VARCHAR( 8 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL';
$sql[] = 'ALTER TABLE `'.$prefix.'-user-activation` CHANGE `ip` `ip` VARCHAR( 15 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL';
$sql[] = 'ALTER TABLE `'.$prefix.'-articles` ADD  `picture_uid` VARCHAR( 13 ) NULL DEFAULT NULL AFTER  `perex`';
$sql[] = 'INSERT INTO `'.$prefix.'-settings` (`var` ,`val`)VALUES (\'article_pic_w\',  \'200\'), (\'article_pic_h\',  \'200\')';
$sql[] = 'ALTER TABLE `'.$prefix.'-root` CHANGE  `var1`  `var1` INT NOT NULL ,CHANGE  `var2`  `var2` INT NOT NULL ,CHANGE  `var3`  `var3` INT NOT NULL';
$sql[] = 'ALTER TABLE `'.$prefix.'-root` ADD  `var4` INT NOT NULL ,ADD INDEX ( `var4` )';
$sql[] = 'UPDATE `'.$prefix.'-root` SET `var4`=1 WHERE `type`=2';
$sql[] = 'UPDATE `'.$prefix.'-root` SET `var4`=ROUND(4/3*var3) WHERE `type`=5';
$sql[] = 'ALTER TABLE `'.$prefix.'-groups` ADD  `color` VARCHAR( 16 ) NOT NULL DEFAULT  \'\' AFTER  `icon`';
$sql[] = 'INSERT INTO  `'.$prefix.'-settings` (`var` ,`val`)VALUES (\'topic_hot_ratio\',  \'20\')';
$sql[] = 'ALTER TABLE `'.$prefix.'-users` CHANGE `avatar` `avatar` VARCHAR( 13 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL';
$sql[] = 'UPDATE `'.$prefix.'-users` SET `avatar`=NULL';
$sql[] = 'INSERT INTO `'.$prefix.'-settings` (`var`,`val`) VALUES (\'install_check\', \'1\'),(\'ajaxfm\', \'0\'),(\'proxy_mode\', \'0\')';
$sql[] = 'ALTER TABLE  `'.$prefix.'-boxes` ADD  `class` VARCHAR( 24 ) NULL DEFAULT NULL';
$sql[] = 'ALTER TABLE `'.$prefix.'-root` ADD `level` INT NOT NULL DEFAULT \'0\' AFTER `public`, ADD INDEX ( `level` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-articles` DROP INDEX `author` ';
$sql[] = 'ALTER TABLE `'.$prefix.'-articles` ADD INDEX ( `author` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-articles` ADD INDEX ( `home1` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-articles` ADD INDEX ( `home2` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-articles` ADD INDEX ( `home3` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-articles` ADD INDEX ( `time` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-articles` ADD INDEX ( `visible` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-articles` ADD INDEX ( `public` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-articles` ADD INDEX ( `confirmed` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-articles` ADD INDEX ( `ratenum` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-articles` ADD INDEX ( `ratesum` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-boxes` DROP INDEX `visible` ';
$sql[] = 'ALTER TABLE `'.$prefix.'-boxes` ADD INDEX ( `ord` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-boxes` ADD INDEX ( `visible` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-boxes` ADD INDEX ( `public` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-boxes` ADD INDEX ( `column` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-groups` ADD INDEX ( `level` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-groups` ADD INDEX ( `blocked` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-groups` ADD INDEX ( `reglist` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-images` ADD INDEX ( `ord` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-iplog` DROP INDEX `ip` ';
$sql[] = 'ALTER TABLE `'.$prefix.'-iplog` ADD INDEX ( `ip` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-iplog` ADD INDEX ( `type` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-iplog` ADD INDEX ( `time` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-iplog` ADD INDEX ( `var` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-posts` DROP INDEX `type` ';
$sql[] = 'ALTER TABLE `'.$prefix.'-posts` ADD INDEX ( `type` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-posts` ADD INDEX ( `home` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-posts` ADD INDEX ( `xhome` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-posts` ADD INDEX ( `author` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-posts` ADD INDEX ( `time` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-root` DROP INDEX `type` ';
$sql[] = 'ALTER TABLE `'.$prefix.'-root` ADD INDEX ( `type` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-root` ADD INDEX ( `intersection` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-root` ADD INDEX ( `ord` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-root` ADD INDEX ( `visible` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-root` ADD INDEX ( `public` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-root` ADD INDEX ( `autotitle` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-root` ADD INDEX ( `var1` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-root` ADD INDEX ( `var2` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-root` ADD INDEX ( `var3` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-root` ADD INDEX ( `var4` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-users` DROP INDEX `group` ';
$sql[] = 'ALTER TABLE `'.$prefix.'-users` ADD INDEX ( `group` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-users` ADD INDEX ( `logincounter` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-users` ADD INDEX ( `registertime` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-users` ADD INDEX ( `activitytime` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-users` ADD INDEX ( `blocked` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-users` ADD INDEX ( `massemail` ) ';
$sql[] = 'ALTER TABLE `'.$prefix.'-groups` ADD `descr` VARCHAR( 128 ) NOT NULL DEFAULT \'\' AFTER `title`';
$sql[] = 'ALTER TABLE `'.$prefix.'-users` ADD `avatar_mode` TINYINT NOT NULL DEFAULT \'0\' AFTER `avatar`';
$sql[] = 'ALTER TABLE `'.$prefix.'-root` ADD `keywords` VARCHAR( 128 ) NOT NULL DEFAULT \'\' AFTER `title_seo` ,ADD `description` VARCHAR( 128 ) NOT NULL DEFAULT \'\' AFTER `keywords`';
$sql[] = 'ALTER TABLE `'.$prefix.'-articles` ADD `keywords` VARCHAR( 128 ) NOT NULL DEFAULT \'\' AFTER `title_seo` , ADD `description` VARCHAR( 128 ) NOT NULL DEFAULT \'\' AFTER `keywords`';


// provedeni
for($i = 0; isset($sql[$i]); ++$i) {
    mysql_query($sql[$i]);
    $error = mysql_error();
    if(!empty($error)) die('Chyba pri aktualizaci databaze!<br><br>Chyba:'.$error.'<br><br>SQL dotaz:<br>'.$sql[$i]);
}

// prevedeni # na odradkovani u anket
$q = mysql_query('SELECT id,answers FROM `'.$prefix.'-polls`');
while($r = mysql_fetch_assoc($q)) {
	$r['answers'] = str_replace(array("\n", '#'), array('', "\n"), $r['answers']);
	mysql_query('UPDATE `'.$prefix.'-polls` SET answers=\''.mysql_escape_string($r['answers']).'\' WHERE id='.$r['id']);
}
mysql_free_result($q);

// funkce _anchorStr
function _anchorStr($input, $lower = true)
{

    //diakritika a mezery
    static $trans = array(' ' => '-', 'é' => 'e', 'ě' => 'e', 'É' => 'E', 'Ě' => 'E', 'ř' => 'r', 'Ř' => 'R', 'ť' => 't', 'Ť' => 'T', 'ž' => 'z', 'Ž' => 'Z', 'ú' => 'u', 'Ú' => 'U', 'ů' => 'u', 'Ů' => 'U', 'ü' => 'u', 'Ü' => 'U', 'í' => 'i', 'Í' => 'I', 'ó' => 'o', 'Ó' => 'O', 'á' => 'a', 'Á' => 'A', 'š' => 's', 'Š' => 'S', 'ď' => 'd', 'Ď' => 'D', 'ý' => 'y', 'Ý' => 'Y', 'č' => 'c', 'Č' => 'C', 'ň' => 'n', 'Ň' => 'N', 'ä' => 'a', 'Ä' => 'A', 'ĺ' => 'l', 'Ĺ' => 'L', 'ľ' => 'l', 'Ľ' => 'L', 'ŕ' => 'r', 'Ŕ' => 'R', 'ö' => 'o', 'Ö' => 'O');
    $input = strtr($input, $trans);

    //odfiltrovani nepovolenych znaku
    static $allow = array('A' => 0, 'a' => 1, 'B' => 2, 'b' => 3, 'C' => 4, 'c' => 5, 'D' => 6, 'd' => 7, 'E' => 8, 'e' => 9, 'F' => 10, 'f' => 11, 'G' => 12, 'g' => 13, 'H' => 14, 'h' => 15, 'I' => 16, 'i' => 17, 'J' => 18, 'j' => 19, 'K' => 20, 'k' => 21, 'L' => 22, 'l' => 23, 'M' => 24, 'm' => 25, 'N' => 26, 'n' => 27, 'O' => 28, 'o' => 29, 'P' => 30, 'p' => 31, 'Q' => 32, 'q' => 33, 'R' => 34, 'r' => 35, 'S' => 36, 's' => 37, 'T' => 38, 't' => 39, 'U' => 40, 'u' => 41, 'V' => 42, 'v' => 43, 'W' => 44, 'w' => 45, 'X' => 46, 'x' => 47, 'Y' => 48, 'y' => 49, 'Z' => 50, 'z' => 51, '0' => 52, '1' => 53, '2' => 54, '3' => 55, '4' => 56, '5' => 57, '6' => 58, '7' => 59, '8' => 60, '9' => 61, '.' => 62, '-' => 63), //
        $lowermap = array("A" => "a", "B" => "b", "C" => "c", "D" => "d", "E" => "e", "F" => "f", "G" => "g", "H" => "h", "I" => "i", "J" => "j", "K" => "k", "L" => "l", "M" => "m", "N" => "n", "O" => "o", "P" => "p", "Q" => "q", "R" => "r", "S" => "s", "T" => "t", "U" => "u", "V" => "v", "W" => "w", "X" => "x", "Y" => "y", "Z" => "z");
    $output = "";
    for($i = 0; isset($input[$i]); ++$i) {
        $char = $input[$i];
        if(isset($allow[$char])) {
            if($lower && isset($lowermap[$char])) $output .= $lowermap[$char];
            else  $output .= $char;
        }
    }

    //dvojite symboly
    $from = array('|--+|', '|\.\.+|', '|\.-+|', '|-\.+|');
    $to = array('-', '.', '.', '-');
    $output = preg_replace($from, $to, $output);

    //orezani
    $output = trim($output, "-_.");

    //return
    return $output;

}

// vygenerovat seo titulky ke strankam a clankum
$tables = array($prefix.'-root', $prefix.'-articles');
for($i = 0; isset($tables[$i]); ++$i) {
	$table = '`'.$tables[$i].'`';
	$q = mysql_query('SELECT `id`,`title` FROM '.$table.' WHERE `title_seo`=\'\''.(($i === 0) ? ' AND `type`!=4' : ''));
	while($r = mysql_fetch_assoc($q)) {
		$seo = _anchorStr($r['title']);
		mysql_query('UPDATE '.$table.' SET `title_seo`=\''.mysql_escape_string($seo).'\' WHERE `id`='.$r['id']);
	}
	mysql_free_result($q);
}

// vyhledat a vyresit duplikaty
$loop = 0;
do {
	$duplicates = 0;
	++$loop;
	for($i = 0; isset($tables[$i]); ++$i) {
		$table = '`'.$tables[$i].'`';
		$skip = array();
		$q = mysql_query('SELECT `id`,`title_seo` FROM '.$table);
		while($r = mysql_fetch_assoc($q)) {
			$q2 = mysql_query('SELECT `id`,`title_seo` FROM '.$table.' WHERE `title_seo`=\''.$r['title_seo'].'\' AND `id`!='.$r['id']);
			$n = 2;
			while($r2 = mysql_fetch_assoc($q2)) {
				if(isset($skip[$r2['id']])) continue;
				++$duplicates;
				mysql_query('UPDATE '.$table.' SET `title_seo`=\''.$r2['title_seo'].'-'.$n.'\' WHERE `id`='.$r2['id']);
				$skip[$r['id']] = true;
				++$n;
			}
			mysql_free_result($q2);
		}
		mysql_free_result($q);
	}
} while($duplicates != 0 && $loop < 10);

// zaregistrovat existujici avatary
$dir = @opendir('pictures/avatars/');
if(is_resource($dir)) {
    while($item = readdir($dir)) {
        if($item === '.' || $item === '..' || substr($item, -4) !== '.jpg') continue;
        $id = (0 + substr($item, 0, -4));
        mysql_query('UPDATE `'.$prefix.'-users` SET avatar=\''.$id.'\' WHERE id='.$id);
    }
} else echo 'Nepovedlo se zaregistrovat existujici avatary ve slozce pictures/avatars/!!<br>';

// ok
echo 'OK! Databaze byla aktualizovana na verzi 7.5.0.';
if(!@unlink(__FILE__)) echo '<br>Smazte soubor patch.php!';
if(file_exists('.htaccess')) echo '<br><br> <strong style="color:#ff0000;">POZOR!</strong> Zda se, ze pouzivate mod_rewrite modul.<br>Ve verzi 7.5.0 byl zmenen a <strong style="color:#ff0000;">je treba vygenerovat novy soubor <em>.htaccess</em>!!</strong><br>Pouzijte <a href="http://sunlight.shira.cz/feedback/modrewrite.php">generator na oficialnim webu</a>.';
