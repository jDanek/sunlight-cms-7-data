<?php

if(!defined('_core')) {
exit;
}


function _HCM_linkart($id = null, $text = null, $nove_okno = false)
{
$id = intval($id);
$query = DB::query("SELECT title,title_seo FROM `"._mysql_prefix."-articles` WHERE id=".$id);
if(isset($nove_okno) and _boolean($nove_okno)) {
$target = " target='_blank'";
} else {
$target = "";
}
if(DB::size($query) != 0) {
$query = DB::row($query);
if(isset($text) and $text != "") {
$query['title'] = $text;
}
return "<a href='"._linkArticle($id, $query['title_seo'])."'".$target.">".$query['title']."</a>";
}
}