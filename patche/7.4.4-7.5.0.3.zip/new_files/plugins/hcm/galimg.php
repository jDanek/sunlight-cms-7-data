<?php

if(!defined('_core')) {
exit;
}


function _HCM_galimg($galerie = "", $typ = 1, $rozmery = null, $limit = null)
{


$result = "";
$galerie = _sqlWhereColumn("home", $galerie);
if(isset($limit)) $limit = abs(intval($limit));
else $limit = 1;


if(isset($rozmery)) {
$rozmery = explode('/', $rozmery);
if(sizeof($rozmery) === 2) {

$x = intval($rozmery[0]);
$y = intval($rozmery[1]);
}
else {

$x = null;
$y = intval($rozmery[0]);
}
} else {

$x = null;
$y = 128;
}


switch($typ) {
case 2:
$razeni = "RAND()";
break;
default:
$razeni = "id DESC";
}


$rimgs = DB::query("SELECT id,title,prev,full FROM `"._mysql_prefix."-images` WHERE ".$galerie." ORDER BY ".$razeni." LIMIT ".$limit);
while($rimg = DB::row($rimgs)) $result .= _galleryImage($rimg, "hcm".$GLOBALS['__hcm_uid'], $x, $y);
return $result;

}