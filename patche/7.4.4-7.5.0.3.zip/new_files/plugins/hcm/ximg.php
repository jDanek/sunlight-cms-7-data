<?php

if(!defined('_core')) {
exit;
}


function _HCM_ximg($cesta = '', $extrakod = null)
{

$ralt = basename($cesta);
if(($dotpos = mb_strrpos($ralt, ".")) !== false) $ralt = mb_substr($ralt, 0, $dotpos);


if(isset($extrakod)) $rpluscode = " ".$extrakod;
else $rpluscode = "";
return "<img src='"._htmlStr($cesta)."' alt='".$ralt."'".$rpluscode." />";
}
