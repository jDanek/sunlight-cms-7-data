<?php

if(!defined('_core')) {
exit;
}




















function _postsOutput($type, $home, $vars, $force_locked = false, $url = null)
{
global $_lang;




$desc = "DESC ";
$ordercol = 'id';
$countcond = "type=".$type." AND xhome=-1 AND home=".$home;
$locked_textid = '';
$autolast = false;
$postlink = false;


if(!isset($url)) $url = _indexOutput_url;
$url_html = _htmlStr($url);

switch($type) {


case 1:
$posttype = 1;
$xhome = -1;
$subclass = "comments";
$title = $_lang['posts.comments'];
$addlink = $_lang['posts.addcomment'];
$nopostsmessage = $_lang['posts.nocomments'];
$postsperpage = _commentsperpage;
$canpost = _loginright_postcomments;
$locked = _boolean($vars);
$replynote = true;
break;


case 2:
$posttype = 2;
$xhome = -1;
$subclass = "comments";
$title = $_lang['posts.comments'];
$addlink = $_lang['posts.addcomment'];
$nopostsmessage = $_lang['posts.nocomments'];
$postsperpage = _commentsperpage;
$canpost = _loginright_postcomments;
$locked = _boolean($vars);
$replynote = true;
break;


case 3:
$posttype = 3;
$xhome = -1;
$subclass = "book";
$title = null;
$addlink = $_lang['posts.addpost'];
$nopostsmessage = $_lang['posts.noposts'];
$postsperpage = $vars[0];
$canpost = $vars[1];
$locked = _boolean($vars[2]);
$replynote = true;
break;


case 5:
$posttype = 5;
$xhome = -1;
$subclass = "book";
$title = null;
$addlink = $_lang['posts.addtopic'];
$nopostsmessage = $_lang['posts.notopics'];
$postsperpage = $vars[0];
$canpost = $vars[1];
$locked = _boolean($vars[2]);
$replynote = true;
$ordercol = 'bumptime';
$locked_textid = '3';
break;


case 6:
$posttype = 5;
$xhome = $vars[3];
$subclass = "book";
$title = null;
$addlink = $_lang['posts.addanswer'];
$nopostsmessage = $_lang['posts.noanswers'];
$postsperpage = $vars[0];
$canpost = $vars[1];
$locked = _boolean($vars[2]);
$replynote = false;
$desc = "";
$countcond = "type=5 AND xhome=".$xhome." AND home=".$home;
$autolast = isset($_GET['autolast']);
$postlink = true;
break;


case 7:
$posttype = 6;
$xhome = null;
$subclass = "book";
$title = null;
$addlink = $_lang['posts.addanswer'];
$nopostsmessage = $_lang['posts.noanswers'];
$postsperpage = _messagesperpage;
$canpost = true;
$locked = _boolean($vars[0]);
$replynote = false;
$desc = "";
$countcond = "type=6 AND home=".$home;
$locked_textid = '4';
$autolast = true;
break;

}


if($force_locked) $locked = true;


$output = "
  <div class='anchor'><a name='posts'></a></div>
  <div class='posts-".$subclass."'>
  ";

if($title != null) {
$output .= "<h2>".$title._linkRss($home, $posttype)."</h2>\n";
}

$output .= "<div class='posts-form'>\n";


$paging = _resultPaging($url_html, $postsperpage, "posts", $countcond, "#posts", null, $autolast);


if(isset($_GET['r'])) {
switch($_GET['r']) {
case 0:
$output .= _formMessage(2, $_lang['posts.failed']);
break;
case 1:
$output .= _formMessage(1, $_lang[(($type != 5) ? 'posts.added' : 'posts.topicadded')]);
break;
case 2:
$output .= _formMessage(2, str_replace("*postsendexpire*", _postsendexpire, $_lang['misc.requestlimit']));
break;
case 3:
$output .= _formMessage(2, $_lang['posts.guestnamedenied']);
break;
case 4:
$output .= _formMessage(2, $_lang['xsrf.msg']);
break;
}
}


if(!$locked and (isset($_GET['addpost']) or isset($_GET['replyto']))) {


if($xhome == -1) {
if(isset($_GET['replyto']) and $_GET['replyto'] != -1) {
$reply = intval($_GET['replyto']);
if($replynote) {
$output .= "<p>".$_lang['posts.replynote']." (<a href='".$url_html."#posts'>".$_lang['global.cancel']."</a>).</p>";
}
} else {
$reply = -1;
}
} else {
$reply = $xhome;
}


if($canpost) {
$form = _uniForm("postform", array('posttype' => $type, 'posttarget' => $home, 'xhome' => $reply, 'url' => $url));
$output .= $form[0];
} else {
$loginform = _uniForm("login", array(), true);
$output .= "<p>".$_lang['posts.loginrequired']."</p>".$loginform[0];
}

} else {
if(!$locked) {
$output .= "<a href='"._addGetToLink($url_html, "addpost&amp;page=".$paging[2])."#posts'><strong>".$addlink." &gt;</strong></a>";
} else {
$output .= "<img src='"._templateImage("icons/lock.png")."' alt='stop' class='icon' /> <strong>".$_lang['posts.locked'.$locked_textid]."</strong>";
}
}

$output .= "</div>
<div class='hr'><hr /></div>\n\n";


if(_pagingmode == 1 or _pagingmode == 2) {
$output .= $paging[0];
}

$query = DB::query("SELECT ".(($type != 5) ? "*" : "id,author,guest,subject,time,ip,locked,bumptime,(SELECT COUNT(id) FROM `"._mysql_prefix."-posts` WHERE type=5 AND xhome=topic.id) AS answer_count")." FROM `"._mysql_prefix."-posts` AS topic WHERE topic.type=".$posttype.(isset($xhome) ? " AND topic.xhome=".$xhome : '')." AND topic.home=".$home." ORDER BY ".$ordercol.' '.$desc.$paging[1]);
if(DB::size($query) != 0) {


if($type != 5) {
$hl = true;
while($item = DB::row($query)) {


if($item['guest'] == "") $author = _linkUser($item['author'], "post-author");
else $author = "<span class='post-author-guest' title='"._showIP($item['ip'])."'>".$item['guest']."</span>";


$post_access = _postAccess($item);
if($type < 6 or $post_access) {
$actlinks = " <span class='post-actions'>";
if($type < 6) $actlinks .= "<a href='"._addGetToLink($url_html, "replyto=".$item['id'])."#posts'>".$_lang['posts.reply']."</a>";
if($post_access) $actlinks .= (($type < 6) ? " " : '')."<a href='index.php?m=editpost&amp;id=".$item['id']."'>".$_lang['global.edit']."</a>";
$actlinks .= "</span>";
} else $actlinks = "";


if(_show_avatars) $avatar = _getAvatar($item['author']);
else $avatar = null;


$hl = !$hl;
_extend('call', 'posts.post', array('item' => &$item, 'avatar' => &$avatar, 'type' => $type));
$output .= "<div class='post".($hl ? ' post-hl' : '')."'><div class='post-head'".(!$postlink ? " id='post-".$item['id']."'" : '').">".$author.", ";
if($type < 6) $output .= "<span class='post-subject'>".$item['subject']."</span> ";
$output .= "<span class='post-info'>("._formatTime($item['time']).")</span>".$actlinks.($postlink ? "<a class='post-postlink' href='"._addGetToLink($url_html, 'page='.$paging[2])."#post-".$item['id']."' id=\"post-".$item['id']."\">#".str_pad($item['id'], 6, '0', STR_PAD_LEFT)."</a>" : '')."</div><div class='post-body".(isset($avatar) ? ' post-body-withavatar' : '')."'>".$avatar.'<div class="post-body-text">'._parsePost($item['text'])."</div></div></div>\n";


if($type < 6) {
$answers = DB::query("SELECT * FROM `"._mysql_prefix."-posts` WHERE type=".$type." AND home=".$home." AND xhome=".$item['id']." ORDER BY id");
while($answer = DB::row($answers)) {


if($answer['guest'] == "") $author = _linkUser($answer['author'], "post-author");
else $author = "<span class='post-author-guest' title='"._showIP($answer['ip'])."'>".$answer['guest']."</span>";


if(_postAccess($answer)) $actlinks = " <span class='post-actions'><a href='index.php?m=editpost&amp;id=".$answer['id']."'>".$_lang['global.edit']."</a></span>";
else $actlinks = "";


if(_show_avatars) $avatar = _getAvatar($answer['author']);
else $avatar = null;

_extend('call', 'posts.post', array('item' => &$answer, 'avatar' => &$avatar, 'type' => $type));
$output .= "<div class='post-answer'".(!$postlink ? " id='post-".$answer['id']."'" : '')."><div class='post-head'>".$author." ".$_lang['posts.replied']." <span class='post-info'>("._formatTime($answer['time']).")</span>".$actlinks."</div><div class='post-body".(isset($avatar) ? ' post-body-withavatar' : '')."'>".$avatar.'<div class="post-body-text">'._parsePost($answer['text'])."</div></div></div>\n";
}
}

}
if(_pagingmode == 2 or _pagingmode == 3) {
$output .= "<br />".$paging[0];
}
} else {


$hl = false;
$output .= "\n<table class='topic-table'>\n<thead><tr><td colspan='2'><strong>".$_lang['posts.topic']."</strong></td><td><strong>".$_lang['global.answersnum']."</strong></td><td><strong>".$_lang['global.lastanswer']."</strong></td></tr></thead>\n<tbody>\n";
while($item = DB::row($query)) {


if($item['guest'] == "") $author = _linkUser($item['author'], "post-author", false, false, 16);
else $author = "<span class='post-author-guest' title='"._showIP($item['ip'])."'>"._cutStr($item['guest'], 16)."</span>";


$lastpost = "-";
if($item['answer_count'] != 0) {
$lastpost = DB::query("SELECT author,guest FROM `"._mysql_prefix."-posts` WHERE xhome=".$item['id']." ORDER BY id DESC LIMIT 1");
if(DB::size($lastpost) != 0) {
$lastpost = DB::row($lastpost);
if($lastpost['author'] != -1) $lastpost = _linkUser($lastpost['author'], "post-author", false, false, 16);
else $lastpost = "<span class='post-author-guest'>"._cutStr($lastpost['guest'], 16)."</span>";
}
}


if($item['locked']) $icon = 'locked';
elseif($item['answer_count'] == 0) $icon = 'new';
elseif($item['answer_count'] < _topic_hot_ratio) $icon = 'normal';
else $icon = 'hot';


$tpages = '';
$tpages_num = ceil($item['answer_count'] / _commentsperpage);
if($tpages_num == 0) $tpages_num = 1;
if($tpages_num > 1) {
$tpages .= '<span class=\'topic-pages\'>';
for($i = 1; $i <= 3 && $i <= $tpages_num; ++$i) {
$tpages .= "<a href='index.php?m=topic&amp;id=".$item['id']."&amp;page=".$i."#posts'>".$i.'</a>';
}
if($tpages_num > 3) $tpages .= "<a href='index.php?m=topic&amp;id=".$item['id']."&amp;page=".$tpages_num."'>".$tpages_num.' &rarr;</a>';
$tpages .= '</span>';
}


$output .= "<tr class='topic-".$icon.($hl ? ' topic-hl' : '')."'><td class='topic-icon-cell'><a href='index.php?m=topic&amp;id=".$item['id']."'><img src='"._templateImage('icons/topic-'.$icon.'.png')."' alt='".$_lang['posts.topic.'.$icon]."' /></a></td><td class='topic-main-cell'><a href='index.php?m=topic&amp;id=".$item['id']."'>".$item['subject']."</a>".$tpages."<br />".$author." <small class='post-info'>("._formatTime($item['time']).")</small></td><td>".$item['answer_count']."</td><td>".$lastpost.(($item['answer_count'] != 0) ? "<br /><small class='post-info'>("._formatTime($item['bumptime']).")</small>" : '')."</td></tr>\n";
$hl = !$hl;
}
$output .= "</tbody></table><br />\n\n";
if(_pagingmode == 2 or _pagingmode == 3) {
$output .= $paging[0]."<br />";
}


$output .= "\n<div class='hr'><hr /></div><br />\n<h3>".$_lang['posts.forum.lastact']."</h3>\n";
$query = DB::query("SELECT xhome,author,guest,time FROM `"._mysql_prefix."-posts` WHERE type=5 AND home=".$home." AND xhome!=-1 ORDER BY id DESC LIMIT "._extratopicslimit);
if(DB::size($query) != 0) {
$output .= "<ul>\n";
while($item = DB::row($query)) {
$topic = DB::row(DB::query("SELECT id,subject FROM `"._mysql_prefix."-posts` WHERE id=".$item['xhome']));
if($item['guest'] == "") $author = _linkUser($item['author']);
else $author = "<span class='post-author-guest'>".$item['guest']."</span>";
$output .= "<li><a href='index.php?m=topic&amp;id=".$topic['id']."'>".$topic['subject']."</a>&nbsp;&nbsp;<small>(".$_lang['global.postauthor']." ".$author." "._formatTime($item['time']).")</small></li>\n";
}
$output .= "</ul>\n\n";

} else $output .= "<p>".$_lang['global.nokit']."</p>";

}

} else {
$output .= "<p>".$nopostsmessage."</p>";
}


$output .= "</div>";
return $output;
}