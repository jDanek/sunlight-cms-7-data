<?php

if(!defined('_core')) {
exit;
}


$topictitle = "";
$forumtitle = "";
$continue = false;

if(isset($_GET['id'])) {
$id = intval($_GET['id']);
$query = DB::query("SELECT * FROM `"._mysql_prefix."-posts` WHERE id=".$id." AND type=5 AND xhome=-1");
if(DB::size($query) != 0) {
$query = DB::row($query);
$topictitle = $query['subject'];
$homedata = DB::row(DB::query("SELECT page.id,page.title,page.title_seo,page.public,page.level,page.var1,page.var2,page.var3,inter.public AS inter_public,inter.level AS inter_level FROM `"._mysql_prefix."-root` AS page LEFT JOIN `"._mysql_prefix."-root` AS inter ON(page.intersection=inter.id) WHERE page.id=".$query['home']));
$forumtitle = $homedata['title'];
$continue = true;
if(_publicAccess($homedata['public'], $homedata['level']) && (!isset($homedata['inter_public']) || _publicAccess($homedata['inter_public'], $homedata['inter_level']))) $need2login = false;
else $need2login = true;
}
}


if($continue) {
define('_indexOutput_url', "index.php?m=topic&id=".$id);

if(!$need2login) {


$module .= "<a href='"._addGetToLink(_linkRoot($homedata['id'], $homedata['title_seo']), "page="._resultPagingGetItemPage($homedata['var1'], "posts", "bumptime>".$query['bumptime']." AND xhome=-1 AND type=5 AND home=".$homedata['id']))."' class='backlink'>&lt; ".$_lang['global.return']."</a>\n";
if(_template_autoheadings) $module .= "<h1>".$homedata['title']."</h1>\n<div class='hr'><hr /></div>\n";
if(_postAccess($query)) $editlink = " <a href='index.php?m=editpost&amp;id=".$id."'><img src='"._templateImage("icons/edit.png")."' alt='edit' class='icon' title='".$_lang['mod.editpost']."' /></a>".(_loginright_locktopics ? "&nbsp;<a href='index.php?m=locktopic&amp;id=".$id."'><img src='"._templateImage("icons/".(($query['locked'] == 1) ? 'un' : '')."lock.png")."' alt='lock' class='icon' title='".($_lang['mod.locktopic'.(($query['locked'] == 1) ? '2' : '')])."' /></a>": '');
else $editlink = "";
if($query['guest'] == "") $author = _linkUser($query['author'], "post-author");
else $author = "<span class='post-author-guest' title='"._showIP($query['ip'])."'>".$query['guest']."</span>";

$module .= "
<h2>".$_lang['posts.topic'].": ".$query['subject']._linkRSS($id, 6).$editlink."</h2>
<p><small>".$_lang['global.postauthor']." ".$author." "._formatTime($query['time'])."</small></p>
<p>"._parsePost($query['text'])."</p>
";


require_once (_indexroot.'require/functions-posts.php');
$module .= _postsOutput(6, $homedata['id'], array(_commentsperpage, _publicAccess($homedata['var3']), $homedata['var2'], $id), ($query['locked'] == 1));

} else {

$form = _uniForm("notpublic");
$module .= $form[0];

}

} else {
define('_indexOutput_url', "index.php?m=topic");
if(_template_autoheadings) {
$module .= "<h1>".$_lang['global.error404.title']."</h1>\n";
}
$module .= _formMessage(2, $_lang['posts.topic.notfound']);
$found = false;
}


if($forumtitle != "" and $topictitle != "") define('_indexOutput_title', $forumtitle." "._titleseparator." ".$topictitle);
else define('_indexOutput_title', $_lang['mod.topic']);