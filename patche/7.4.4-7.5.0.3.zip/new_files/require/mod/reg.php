<?php

if(!defined('_core')) {
exit;
}


function _tmpRegister($mode, $group, $username, $pass_and_salt, $massemail, $ip, $email)
{


if($mode == 0) {
DB::query("INSERT INTO `"._mysql_prefix."-users` (`group`,levelshift,username,password,salt,logincounter,registertime,activitytime,blocked,massemail,wysiwyg,language,ip,email,web,skype,msn,jabber,icq,note) VALUES (".$group.",0,'".$username."','".$pass_and_salt[0]."','".$pass_and_salt[1]."',0,".time().",".time().",0,".$massemail.",0,'','"._userip."','".$email."','','','','',0,'')");
_extend('call', 'mod.reg.success', array('user_id' => DB::insertID()));
return;
}


$code = str_replace('.', '-', uniqid('', true));
DB::query("INSERT INTO `"._mysql_prefix."-user-activation` (`code`,`expire`,`group`,`username`,`password`,`salt`,`massemail`,`ip`,`email`) VALUES('".$code."',".(time() + 3600).",".$group.",'".$username."','".$pass_and_salt[0]."','".$pass_and_salt[1]."',".$massemail.",'".$ip."','".$email."')");
return $code;

}


if(isset($_GET['confirm']) && _registration_confirm) {


if(_template_autoheadings == 1) $module .= "<h1>".$_lang['mod.reg.confirm']."</h1>";


if(!_iplogCheck(6)) {
$module .= _formMessage(3, str_replace('*limit*', _accactexpire / 60, $_lang['mod.reg.confirm.limit']));
return;
}


$code = DB::esc(trim($_GET['confirm']));
if(strlen($code) !== 23) {
$module .= _formMessage(3, $_lang['mod.reg.confirm.badcode']);
return;
}


DB::query('DELETE FROM `'._mysql_prefix.'-user-activation` WHERE `expire`<'.time());


$query = DB::query('SELECT * FROM `'._mysql_prefix.'-user-activation` WHERE `code`="'.$code.'"');


if(DB::size($query) === 0) {

_iplogUpdate(6);
$module .= _formMessage(3, $_lang['mod.reg.confirm.notfound']);
return;
}


$query = DB::row($query);


if(DB::result(DB::query('SELECT COUNT(*) FROM `'._mysql_prefix.'-users` WHERE `username`="'.$query['username'].'" OR `email`="'.$query['email'].'"'), 0) != 0) {

$module .= _formMessage(3, $_lang['mod.reg.confirm.emailornametaken']);
return;
}


_tmpRegister(0, $query['group'], $query['username'], array($query['password'], $query['salt']), $query['massemail'], $query['ip'], $query['email']);
$module .= "<p>".str_replace("*username*", $query['username'], $_lang['mod.reg.done'])."</p>";


DB::query('DELETE FROM `'._mysql_prefix.'-user-activation` WHERE `id`='.$query['id']);


return;

}


$phase = 0;
$message = "";
if(isset($_POST['username'])) {

$errors = array();


if(!_iplogCheck(5)) {
$errors[] = str_replace("*postsendexpire*", _postsendexpire, $_lang['misc.requestlimit']);
}


$username = $_POST['username'];
if(mb_strlen($username) > 24) {
$username = mb_substr($username, 0, 24);
}
$username = DB::esc(_anchorStr($username, false));
if($username == "") {
$errors[] = $_lang['admin.users.edit.badusername'];
} elseif(DB::result(DB::query("SELECT COUNT(id) FROM `"._mysql_prefix."-users` WHERE username='".$username."' OR publicname='".$username."'"), 0) != 0) {
$errors[] = $_lang['admin.users.edit.userexists'];
}

$password = $_POST['password'];
$password2 = $_POST['password2'];
if($password != $password2) {
$errors[] = $_lang['mod.reg.nosame'];
}
if($password != "") {
$password = _md5Salt($password);
} else {
$errors[] = $_lang['mod.reg.passwordneeded'];
}

$email = DB::esc(trim($_POST['email']));
if(!_validateEmail($email)) {
$errors[] = $_lang['admin.users.edit.bademail'];
}
if(DB::result(DB::query("SELECT COUNT(id) FROM `"._mysql_prefix."-users` WHERE email='".$email."'"), 0) != 0) {
$errors[] = $_lang['admin.users.edit.emailexists'];
}

if(!_captchaCheck()) {
$errors[] = $_lang['captcha.failure'];
}

$massemail = _checkboxLoad('massemail');

if(_registration_grouplist and isset($_POST['group'])) {
$group = intval($_POST['group']);
$groupdata = DB::query("SELECT id FROM `"._mysql_prefix."-groups` WHERE id=".$group." AND blocked=0 AND reglist=1");
if(DB::size($groupdata) == 0) {
$errors[] = $_lang['global.badinput'];
}
} else {
$group = _defaultgroup;
}

if(_rules != "" and !_checkboxLoad("agreement")) {
$errors[] = $_lang['mod.reg.rules.disagreed'];
}


if(count($errors) == 0) {
_iplogUpdate(5);
$code = _tmpRegister(_registration_confirm, $group, $username, $password, $massemail, _userip, $email);
if(isset($code)) {

$phase = 2;
$domain = _getDomain();
$mail = _mail($email, str_replace('*domain*', $domain, $_lang['mod.reg.confirm.subject']), str_replace(array('*username*', '*domain*', '*url*', '*ip*', '*date*', '*code*'), array($username, $domain, _url, _userip, _formatTime(time()), $code), $_lang['mod.reg.confirm.text']), "Content-Type: text/plain; charset=UTF-8\n"._sysMailHeader());
} else $phase = 1;
} else {
$message = _formMessage(2, _eventList($errors, 'errors'));
}

}


if(_template_autoheadings == 1) {
$module .= "<h1>".$_lang['mod.reg']."</h1>";
}

switch($phase) {


case 0:

$groupselect = array(null);
if(_registration_grouplist) {
$groupselect_items = DB::query("SELECT id,title FROM `"._mysql_prefix."-groups` WHERE `blocked`=0 AND reglist=1 ORDER BY title");
if(DB::size($groupselect_items) != 0) {
$groupselect_content = "";
while($groupselect_item = DB::row($groupselect_items)) {
$groupselect_content .= "<option value='".$groupselect_item['id']."'".(($groupselect_item['id'] == _defaultgroup) ? " selected='selected'" : '').">".$groupselect_item['title']."</option>\n";
}
$groupselect = array($_lang['global.group'], "<select name='group'>".$groupselect_content."</select>");
}
}


if(_rules != "") {
$rules = array("<div class='hr'><hr /></div><h2>".$_lang['mod.reg.rules']."</h2>"._rules."<br /><label><input type='checkbox' name='agreement' value='1'"._checkboxActivate(isset($_POST['agreement']))." /> ".$_lang['mod.reg.rules.agreement']."</label><div class='hr'><hr /></div><br />", "", true);
} else {
$rules = array(null);
}


$captcha = _captchaInit();
$module .= "<p class='bborder'>".$_lang['mod.reg.p'].(_registration_confirm ? ' '.$_lang['mod.reg.confirm.extratext'] : '')."</p>";
$module .= $message._formOutput("regform", "index.php?m=reg", array(array($_lang['login.username'], "<input type='text' name='username' class='inputsmall' maxlength='24'"._restorePostValue('username')." />"), array($_lang['login.password'], "<input type='password' name='password' class='inputsmall' />"), array($_lang['login.password']." (".$_lang['global.check'].")", "<input type='password' name='password2' class='inputsmall' />"), array($_lang['global.email'], "<input type='text' name='email' class='inputsmall' "._restorePostValue('email', '@')." />"), array($_lang['mod.settings.massemail'], "<input type='checkbox' name='massemail' value='1' checked='checked' /> ".$_lang['mod.settings.massemail.label']), $groupselect, $captcha, $rules, ), array("username", "email", "password", "password2"), $_lang['mod.reg.submit'.(_registration_confirm ? '2' : '')]);
break;


case 1:
$module .= "<p>".str_replace("*username*", $username, $_lang['mod.reg.done'])."</p>";
break;


case 2:
$module .= _formMessage(1, str_replace('*email*', $email, $_lang['mod.reg.confirm.sent']));
break;

}