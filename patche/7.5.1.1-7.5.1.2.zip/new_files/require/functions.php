<?php

if(!defined('_core')) {
exit;
}












function _articlePreview($art, $info = true, $perex = true, $comment_count = null)
{


static $overload;
if(null === $overload) {
_extend('call', 'article.preview', array('callback' => &$overload));
if(null === $overload) $overload = false;
}
if(false !== $overload) return call_user_func($overload, $art, $info, $perex, $comment_count);

global $_lang;


$link = _linkArticle($art['id'], $art['title_seo']);
$output = "<h2 class='list-title'><a href='".$link."'>".$art['title']."</a></h2>";


if($perex == true) {
$output .= "<p class='list-perex'>".(isset($art['picture_uid']) ? "<a href='".$link."'><img class='list-perex-image' src='"._pictureStorageGet(_indexroot.'pictures/articles/', null, $art['picture_uid'], 'jpg')."' alt='".$art['title']."' /></a>" : '').$art['perex']."</p>";
}


if($info == true) {


if($art['comments'] == 1 and _comments and $comment_count !== null) $info_comments = _template_listinfoseparator."<span>".$_lang['article.comments'].":</span> ".$comment_count;
else $info_comments = "";

$output .= "
  <div class='list-info'>
  <span>".$_lang['article.author'].":</span> "._linkUser($art['author'], null, true)._template_listinfoseparator."<span>".$_lang['article.posted'].":</span> "._formatTime($art['time'])._template_listinfoseparator."<span>".$_lang['article.readed'].":</span> ".$art['readed']."x".$info_comments."</div>";

} elseif($perex && isset($art['picture_uid'])) $output .= "<div class='cleaner'></div>\n";

return $output."\n";
}










function _galleryImage($img, $lightboxid = null, $width = null, $height = 0)
{
$content = "<a href='".(!_isAbsolutePath($img['full']) ? _indexroot : '').$img['full']."' target='_blank'".(isset($lightboxid) ? " class='lightbox' rel='lb_".$lightboxid."'" : '').(($img['title'] != "") ? " title='".$img['title']."'" : '').">";
if($img['prev'] != "") $content .= "<img src='".(!_isAbsolutePath($img['prev']) ? _indexroot : '').$img['prev']."' alt='".(($img['title'] != "") ? $img['title'] : _htmlStr(basename($img['full'])))."' />";
else $content .= "<img src='"._indexroot."remote/imgprev.php?id=".$img['id'].(($height != 0) ? "&amp;h=".$height : '').((isset($width) ? '&amp;w='.$width : '')).'&amp;'.sprintf('%u', crc32($img['full']))."' alt='".(($img['title'] != "") ? $img['title'] : _htmlStr(basename($img['full'])))."' />";
$content .= "</a>\n";
return $content;
}






function _captchaInit()
{

if(_captcha and !_loginindicator) {
global $_lang, $__captcha_counter;
++$__captcha_counter;
if(!isset($_SESSION[_sessionprefix.'captcha_code']) or !is_array($_SESSION[_sessionprefix.'captcha_code'])) {
$_SESSION[_sessionprefix.'captcha_code'] = array();
}
$_SESSION[_sessionprefix.'captcha_code'][$__captcha_counter] = array(mb_strtoupper(_wordGenMarkov(6)), false);
return array($_lang['captcha.input'], "<input type='text' name='_cp' class='inputc' maxlength='6' /><img src='"._indexroot."remote/cimage.php?n=".$__captcha_counter."' alt='captcha' title='".$_lang['captcha.help']."' class='cimage' /><input type='hidden' name='_cn' value='".$__captcha_counter."' />", true);
} else {
return array("", "");
}

}






function _captchaCheck()
{


static $disa_f = array('0', 'Q'), $disa_t = array('O', 'O');


if(_captcha and !_loginindicator) {
if(isset($_POST['_cp']) and isset($_POST['_cn']) and isset($_SESSION[_sessionprefix.'captcha_code'][$_POST['_cn']])) {
if(str_replace($disa_f, $disa_t, $_SESSION[_sessionprefix.'captcha_code'][$_POST['_cn']][0]) == str_replace($disa_f, $disa_t, mb_strtoupper($_POST['_cp']))) {
$return = true;
} else $return = false;
unset($_SESSION[_sessionprefix.'captcha_code'][$_POST['_cn']]);
return $return;
} else return false;
} else return true;

}









function _checkVersion($type, $version, $get = false)
{


switch($type) {
case 'database':
$cmp_versions = array('7.5.1');
break;
break;
case 'language_file':
$cmp_versions = array('7.5.1');
break;
case 'template':
$cmp_versions = array('2.1');
break;
default:
$cmp_versions = array();
break;
}


if(!$get) {
return in_array($version, $cmp_versions);
} else {
return $cmp_versions;
}

}







function _deleteUser($id)
{


if($id == 0) return;
$udata = DB::row(DB::query("SELECT username,avatar FROM `"._mysql_prefix."-users` WHERE id=".$id));
if($udata === false) return false;


DB::query("DELETE FROM `"._mysql_prefix."-users` WHERE id=".$id);
DB::query("DELETE `"._mysql_prefix."-pm`,post FROM `"._mysql_prefix."-pm` LEFT JOIN `"._mysql_prefix."-posts` AS post ON (post.type=6 AND post.home=`"._mysql_prefix."-pm`.id) WHERE receiver=".$id." OR sender=".$id);
DB::query("UPDATE `"._mysql_prefix."-posts` SET guest='".$udata['username']."',author=-1 WHERE author=".$id);
DB::query("UPDATE `"._mysql_prefix."-articles` SET author=0 WHERE author=".$id);
DB::query("UPDATE `"._mysql_prefix."-polls` SET author=0 WHERE author=".$id);


if(isset($udata['avatar'])) @unlink(_indexroot.'pictures/avatars/'.$udata['avatar'].'.jpg');
return true;

}







function _evalBox($code)
{
$output = "";
$eval = eval($code);
if(isset($eval)) return $eval;
return $output;
}








function _eventList($events, $intro = null)
{


if($intro != null) {
if($intro != "errors") $output = $intro;
else {
global $_lang;
$output = $_lang['misc.errorlog.intro'];
}
$output .= "\n";
} else $output = "";


$output .= "<ul>\n";
foreach($events as $item) $output .= "<li>".$item."</li>\n";
$output .= "</ul>";
return $output;
}







function _formatTime($timestamp)
{
return date(_time_format, $timestamp);
}








function _formMessage($type, $string)
{
return "\n<div class='message".$type."'>$string</div>\n";
}
















function _formOutput($name, $action, $cells, $check = null, $submittext = null, $codenexttosubmit = null)
{
global $_lang;


if($check != null) {
$checkcode = _jsCheckForm($name, $check);
} else {
$checkcode = "";
}

if($submittext != null) {
$submit = $submittext;
} else {
$submit = $_lang['global.send'];
}


$output = "
<form action='".$action."' method='post' name='".$name."'".$checkcode.">
<table>";


foreach($cells as $cell) {
if($cell[0] != "") {
$output .= "
    <tr".((isset($cell[2]) and $cell[2] == true) ? " valign='top'" : '').">
    <td class='rpad'".(($cell[1] == "") ? " colspan='2'" : '').">".(($cell[1] != "") ? "<strong>" : '').$cell[0].(($cell[1] != "") ? "</strong>" : '')."</td>
    ".(($cell[1] != "") ? "<td>".$cell[1]."</td>" : '')."
    </tr>";
$lastcell = $cell;
}
}


$output .= "
  <tr>
  ".((isset($lastcell[1]) and $lastcell[1] != "") ? "<td></td><td>" : "<td colspan='2'>")."
  <input type='submit' value='".$submit."' />".$codenexttosubmit."</td>
  </tr>

</table>
</form>";

return $output;
}






function _getRightsArray()
{
return array("level", "administration", "adminsettings", "adminusers", "admingroups", "admincontent", "adminsection", "admincategory", "adminbook", "adminseparator", "admingallery", "adminlink", "adminintersection", "adminforum", "adminpluginpage", "adminart", "adminallart", "adminchangeartauthor", "adminpoll", "adminpollall", "adminsbox", "adminbox", "adminconfirm", "adminneedconfirm", "adminfman", "adminfmanlimit", "adminfmanplus", "adminhcmphp", "adminbackup", "adminmassemail", "adminbans", "adminposts", "changeusername", "unlimitedpostaccess", "locktopics", "stickytopics", "movetopics", "postcomments", "artrate", "pollvote", "selfdestruction");
}







function _userHasNotRight($name)
{
if(mb_substr($name, 0, 1) != "-") {
$negations = array("adminfmanlimit", "adminneedconfirm");
if(!in_array($name, $negations)) {
return !constant('_loginright_'.$name);
} else {
return constant('_loginright_'.$name);
}
} else {
return true;
}
}









function _getPostformControls($form, $area, $ignorebbcode = false)
{
$output = "";


if(_bbcode and _template_bbcode_buttons and !$ignorebbcode) {


static $bbtags;
if(!isset($bbtags)) $bbtags = _parseBBCode(null, true);


foreach($bbtags as $tag => $vars) {
if(!isset($vars[4])) continue;
$icon = (($vars[4] === 1) ? _templateImage("bbcode/".$tag.".png") : $vars[4]);
$output .= "<a href=\"#\" onclick=\"return _sysAddBBCode('".$form."','".$area."','".$tag."', ".($vars[0] ? 'true' : 'false').");\" class='bbcode-button'><img src=\"".$icon."\" alt=\"".$tag."\" /></a> ";
}
}


if(_smileys) {

if(_bbcode and !$ignorebbcode) $output .= "&nbsp;&nbsp;";
for($x = 1; $x <= _template_smileys; ++$x) $output .= "<a href=\"#\" onclick=\"return _sysAddSmiley('".$form."','".$area."',".$x.");\"><img src=\""._templateImage("smileys/".$x."."._template_smileys_format)."\" alt=\"".$x."\" title=\"".$x."\" /></a> ";


if(_template_smileys_list) {
global $_lang;
$output .= "&nbsp;<a href=\""._indexroot."remote/smileys.php\" target=\"_blank\" onclick=\"return _sysOpenWindow('"._indexroot."remote/smileys.php', 320, 475);\">".$_lang['misc.smileys.list.link']."</a>";
}

}

return "<span class='posts-form-buttons'>".trim($output)."</span>";
}



















function _iplogCheck($type, $var = null)
{


static $cleaned = false;
if(!$cleaned) {
DB::query("DELETE FROM `"._mysql_prefix."-iplog` WHERE (type=1 AND ".time()."-time>"._maxloginexpire.") OR (type=2 AND ".time()."-time>"._artreadexpire.") OR (type=3 AND ".time()."-time>"._artrateexpire.") OR (type=4 AND ".time()."-time>"._pollvoteexpire.") OR (type=5 AND ".time()."-time>"._postsendexpire.") OR (type=6 AND ".time()."-time>"._accactexpire.") OR (type=7 AND ".time()."-time>"._lostpassexpire.")");
$cleaned = true;
}


$return = true;
$querybasic = "SELECT * FROM `"._mysql_prefix."-iplog` WHERE ip='"._userip."' AND type=".$type;

switch($type) {


case 1:
$query = DB::query($querybasic);
if(DB::size($query) != 0) {
$query = DB::row($query);
if($query['var'] >= _maxloginattempts) {
$return = false;
}
}
break;


case 2:
case 3:
case 4:
$query = DB::query($querybasic." AND var=".$var);
if(DB::size($query) != 0) {
$return = false;
}
break;


case 5:
case 7:
$query = DB::query($querybasic);
if(DB::size($query) != 0) {
$return = false;
}
break;


case 6:
$query = DB::query($querybasic);
if(DB::size($query) != 0) {
$query = DB::row($query);
if($query['var'] >= 5) {
$return = false;
}
}
break;


}

return $return;
}








function _iplogUpdate($type, $var = null)
{
$querybasic = "SELECT * FROM `"._mysql_prefix."-iplog` WHERE ip='"._userip."' AND type=".$type;

switch($type) {


case 1:
$query = DB::query($querybasic);
if(DB::size($query) != 0) {
$query = DB::row($query);
DB::query("UPDATE `"._mysql_prefix."-iplog` SET var=".($query['var'] + 1)." WHERE id=".$query['id']);
} else {
DB::query("INSERT INTO `"._mysql_prefix."-iplog` (ip,type,time,var) VALUES ('"._userip."',1,".time().",1)");
}
break;


case 2:
DB::query("INSERT INTO `"._mysql_prefix."-iplog` (ip,type,time,var) VALUES ('"._userip."',2,".time().",".$var.")");
break;


case 3:
DB::query("INSERT INTO `"._mysql_prefix."-iplog` (ip,type,time,var) VALUES ('"._userip."',3,".time().",".$var.")");
break;


case 4:
DB::query("INSERT INTO `"._mysql_prefix."-iplog` (ip,type,time,var) VALUES ('"._userip."',4,".time().",".$var.")");
break;


case 5:
case 7:
DB::query("INSERT INTO `"._mysql_prefix."-iplog` (ip,type,time,var) VALUES ('"._userip."',".$type.",".time().",0)");
break;


case 6:
$query = DB::query($querybasic);
if(DB::size($query) != 0) {
$query = DB::row($query);
DB::query("UPDATE `"._mysql_prefix."-iplog` SET var=".($query['var'] + 1)." WHERE id=".$query['id']);
} else {
DB::query("INSERT INTO `"._mysql_prefix."-iplog` (ip,type,time,var) VALUES ('"._userip."',6,".time().",1)");
}
break;

}

}








function _jsCheckForm($form, $inputs)
{
global $_lang;


$output = " onsubmit=\"if(";
$count = count($inputs);
for($x = 1; $x <= $count; $x++) {
$output .= $form.".".$inputs[$x - 1].".value==''";
if($x != $count) {
$output .= " || ";
}
}
$output .= "){_sysAlert(1); return false;}\"";


return $output;

}









function _jsLimitLength($maxlength, $form, $name)
{
return "
<script type='text/javascript'>
//<![CDATA[
$(document).ready(function(){
    var events = ['keyup', 'mouseup', 'mousedown'];
    for(var i = 0; i < events.length; ++i) $(document)[events[i]](function(){
        _sysLimitTextArea(document.$form.$name, $maxlength);
    });
});

//]]>
</script>
";
}







function _levelCheck($targetuserid)
{

if(_loginindicator) {


$data = _userDataCache($targetuserid);


if(_loginright_level > $data['level'] or $data['id'] == _loginid) {
return true;
} else {
return false;
}

} else {
return false;
}

}








function _linkArticle($id, $anchor = null)
{

static $cache = array();
if(!isset($anchor)) {
if(isset($cache[$id])) $anchor = $cache[$id];
else {
$anchor = DB::row(DB::query("SELECT `title_seo` FROM `"._mysql_prefix."-articles` WHERE id=".$id));
if($anchor === false) $anchor = array('title_seo' => '---');
$cache[$id] = $anchor = $anchor['title_seo'];
}
}
return (_modrewrite ? $anchor : "index.php?a=".$anchor);

}








function _linkRoot($id, $anchor = null)
{

static $cache = array();
if($id == _index_page_id) return ((_indexroot === './') ? './' : '');
if(!isset($anchor)) {
if(isset($cache[$id])) $anchor = $cache[$id];
else {
$anchor = DB::row(DB::query("SELECT `title_seo` FROM `"._mysql_prefix."-root` WHERE id=".$id));
if($anchor === false) $anchor = array('title_seo' => '---');
$cache[$id] = $anchor = $anchor['title_seo'];
}
}
return (_modrewrite ? $anchor : "index.php?p=".$anchor);

}



















function _linkRSS($id, $type, $space = true)
{
global $_lang;
if(_rss) return ($space ? ' ' : '')."<a href='"._indexroot."remote/rss.php?tp=".$type."&amp;id=".$id."' target='_blank' title='".$_lang['rss.linktitle']."'><img src='"._templateImage("icons/rss.png")."' alt='rss' class='icon' /></a>";
return '';
}







function _userDataCache($id)
{


static $cache = array('-1' => array('id' => -1, 'publicname' => '', 'username' => '---', 'group' => '2', 'avatar' => null, 'avatar_mode' => null, 'icon' => '', 'level' => 0, 'color' => '')),
$extended = false,
$extra_cols = array(), $extra_joins = ''
;


if(!$extended) {
$extended = true;
$extend = array();
_extend('call', 'user.cache.init', array('extend' => &$extend));
for($i = 0; isset($extend[$i]); ++$i) {
for($ii = 0; isset($extend[$i][0][$ii]); ++$ii) $extra_cols[$extend[$i][0][$ii]] = $ii;
if(isset($extend[$i][1])) $extra_joins .= ' '.$extend[$i][1];
}
}


if(isset($cache[$id])) return $cache[$id];
else {
$q = DB::row(DB::query("SELECT u.id,u.publicname,u.username,u.group,u.avatar,g.icon,g.level,g.color".(!empty($extra_cols) ? ','.implode(',', array_keys($extra_cols)) : '')." FROM `"._mysql_prefix."-users` AS u JOIN `"._mysql_prefix."-groups` AS g ON (u.group=g.id)".$extra_joins." WHERE u.id=".$id));
if($q === false) $q = $cache[-1];
return ($cache[$id] = $q);
}

}













function _linkUser($id, $class = null, $plain = false, $onlyname = false, $namelengthlimit = null, $namesuffix = "", $ignore_publicname = false)
{


$data = _userDataCache($id);

if($onlyname == false) {


if($plain == false) $icon = (($data['icon'] != "") ? "<img src='"._indexroot."pictures/groupicons/".$data['icon']."' alt='icon' class='icon' /> " : '');
else $icon = "";


if($data['publicname'] != "" && !$ignore_publicname) $publicname = $data['publicname'];
else $publicname = $data['username'];


$class = " class='user-link-".$id." user-link-group-".$data['group'].(isset($class) ? ' '.$class : '')."'";


if($namelengthlimit != null) $publicname = _cutStr($publicname, $namelengthlimit);
$link = "<a href='"._indexroot."index.php?m=profile&amp;id=".$data['username']."'".$class.(_administration ? " target='_blank'" : '').(($data['color'] !== '' && !$plain) ? " style='color:".$data['color'].";'" : '').">".$publicname.$namesuffix."</a>";

} else {
$icon = "";
if($data['publicname'] != "" && !$ignore_publicname) $link = $data['publicname'].$namesuffix;
else $link = $data['username'].$namesuffix;
}

return $icon.$link;
}







function _mailto($email)
{
$email = str_replace("@", _atreplace, $email);
return "<a href='#' onclick='return _sysMai_lto(this);'>".$email."</a>";
}








function _parseHCM($input, $handler = '_parseHCM_module')
{
return preg_replace_callback('|\[hcm\](.*?)\[/hcm\]|s', $handler, $input);
}





function _parseHCM_loadmodule($module, $f_name)
{


$module = explode('/', $module, 2);
if(isset($module[1])) $module = basename($module[0]).'/'.basename($module[1]);
else $module = basename($module[0]);


$file = _indexroot.'plugins/hcm/'.$module.'.php';
if(file_exists($file)) {
require $file;
return function_exists($f_name);
}
}





function _parseHCM_module($match)
{
$GLOBALS['__hcm_uid']++;
$params = _parseStr($match[1]);
if(isset($params[0])) {
$f_name = '_HCM_'.str_replace('/', '_', $params[0]);
if(function_exists($f_name) or _parseHCM_loadmodule($params[0], $f_name)) {
return call_user_func_array($f_name, array_splice($params, 1));
}
}
}





function _parseHCM_filter($match)
{
global $__input;











$paramarray = _parseStr($match[1]);
$mresult = $match[0];
if(isset($paramarray[0])) {
$paramarray[0] = mb_strtolower($paramarray[0]);
if($__input == null or (isset($paramarray[0][0]) and $paramarray[0][0] === '_') or ($__input[0] and in_array($paramarray[0], $__input[1])) or (!$__input[0] and !in_array($paramarray[0], $__input[1]))) {
$mresult = "";
}
}
return $mresult;
}







function _filtrateHCM($content)
{


if(!_loginright_adminhcmphp) {
$filter = array('php', 'setlayout');
_extend('call', 'hcm.filter.php', array('filter' => &$filter));
$GLOBALS['__input'] = array(true, $filter);
$content = _parseHCM($content, '_parseHCM_filter');
unset($GLOBALS['__input']);
}
return $content;
}








function _parseBBCode($s, $get_tags = false)
{


static $tags = array(
'b' => array(true, false, true, true, 1),
'i' => array(true, false, true, true, 1),
'u' => array(true, false, true, true, 1),
'q' => array(true, false, true, true, null),
's' => array(true, false, true, true, 1),
'img' => array(true, false, false, false, 1),
'code' => array(true, true, false, true, 1),
'url' => array(true, true, true, false, 1),
'hr' => array(false, false, false, false, 1),
'color' => array(true, true, true, true, null),
'size' => array(true, true, true, true, null),
),
$syntax = array('[', ']', '/', '=', '"'),
$merged = false
;


if(!$merged) {
_extend('call', 'bbcode.extend.tags', array('tags' => &$tags));
$merged = true;
}


if($get_tags) return $tags;


$mode = 0;
$submode = 0;
$closing = false;
$parents = array();
$parents_n = -1;
$tag = '';
$output = '';
$buffer = '';
$arg = '';
$reset = 0;


for($i = 0; isset($s[$i]); ++$i) {


$char = $s[$i];


switch($mode) {


case 0:
if($char === $syntax[0]) {
$mode = 1;
if($parents_n === -1) $output .= $buffer;
else $parents[$parents_n][2] .= $buffer;
$buffer = '';
}
break;


case 1:
if(($ord = ord($char)) > 47 && $ord < 59 || $ord > 64 && $ord < 91 || $ord > 96 && $ord < 123) $tag .= $char;
elseif($tag === '' && $char === $syntax[2]) {

$closing = true;
break;
} elseif($char === $syntax[1]) {

$tag = mb_strtolower($tag);
if(isset($tags[$tag])) {
if($parents_n === -1 || $tags[$tag][2] || $tags[$tag][0] && $closing) {
if($tags[$tag][0]) {

if($closing) {
if($parents_n === -1 || $parents[$parents_n][0] !== $tag) $reset = 2;
else {
--$parents_n;
$pop = array_pop($parents);
$buffer = _parseBBCode_processTag($pop[0], $pop[1], $pop[2]);
if($parents_n === -1) $output .= $buffer;
else $parents[$parents_n][2] .= $buffer;
$reset = 1;
$char = '';
}
} elseif($parents_n === -1 || $tags[$parents[$parents_n][0]][3]) {

$parents[] = array($tag, $arg, '');
++$parents_n;
$buffer = '';
$char = '';
$reset = 1;
} else $reset = 7;
} else {

$buffer = _parseBBCode_processTag($tag, $arg);
if($parents_n === -1) $output .= $buffer;
else $parents[$parents_n][2] .= $buffer;
$reset = 1;
}
} else $reset = 3;
} else $reset = 4;
} elseif($char === $syntax[3]) {
if(isset($tags[$tag]) && $tags[$tag][1] === true && $arg === '' && !$closing) {
$mode = 2;
} else $reset = 5;
}
break;


case 2:


if($submode === 0) {
if($char === $syntax[4]) {

$submode = 1;
break;
} else $submode = 2;
}


if($submode === 1) {
if($char !== $syntax[4]) {

$arg .= $char;
break;
}
} elseif($char !== $syntax[1]) {

$arg .= $char;
break;
}


if($submode === 2) {

$mode = 1;
$char = '';
--$i;
} else {

if(isset($s[$i + 1]) && $s[$i + 1] === $syntax[1]) {
$mode = 1;
} else $reset = 6;
}

break;

}


$buffer .= $char;


if($reset !== 0) {
if($reset > 1) {
if($parents_n === -1) $output .= $buffer;
else $parents[$parents_n][2] .= $buffer;
}
$buffer = '';
$reset = 0;
$mode = 0;
$submode = 0;
$closing = false;
$tag = '';
$arg = '';
}

}



if($parents_n !== -1)
for($i = 0; isset($parents[$i]); ++$i) $output .= $parents[$i][2];
else $output .= $buffer;


return $output;

}




function _parseBBCode_processTag($tag, $arg = '', $buffer = null)
{


static $ext;
if(!isset($ext)) {
$ext = array();
_extend('call', 'bbcode.extend.proc', array('tags' => &$ext));
}


if(isset($ext[$tag])) return call_user_func($ext[$tag], $arg, $buffer);
switch($tag) {

case 'b':
if($buffer === '') return;
return '<strong>'.$buffer.'</strong>';

case 'i':
if($buffer === '') return;
return '<em>'.$buffer.'</em>';

case 'u':
if($buffer === '') return;
return '<u>'.$buffer.'</u>';

case 'q':
if($buffer === '') return;
return '<q>'.$buffer.'</q>';

case 's':
if($buffer === '') return;
return '<del>'.$buffer.'</del>';

case 'code':
if($buffer === '') return;
return '<span class="pre">'.$buffer.'</span>';

case 'url':
if($buffer === '') return;
if($arg !== '') $url = $arg;
else $url = $buffer;
$url = trim($url);
if(!_isSafeUrl($url)) $url = '#';
else $url = _addSchemeToURL($url);
return '<a href="'.str_replace(array("\r", "\n"), '', $url).'" rel="nofollow" target="_blank">'.$buffer.'</a>';

case 'hr':
return '<span class="hr"></span>';

case 'color':
static $colors = array('aqua' => 0, 'black' => 1, 'blue' => 2, 'fuchsia' => 3, 'gray' => 4, 'green' => 5, 'lime' => 6, 'maroon' => 7, 'navy' => 8, 'olive' => 9, 'orange' => 10, 'purple' => 11, 'red' => 12, 'silver' => 13, 'teal' => 14, 'white' => 15, 'yellow' => 16);
if($buffer === '') return;
if(preg_match('/^#[0-9A-Fa-f]{3,6}$/', $arg) !== 1) {
$arg = mb_strtolower($arg);
if(!isset($colors[$arg])) return $buffer;
}
return '<span style="color:'.$arg.';">'.$buffer.'</span>';

case 'size':
if($buffer === '') return;
$arg = intval($arg);
if($arg < 1 || $arg > 8) return $buffer;
return '<span style="font-size:'.round((0.5 + ($arg / 6)) * 100).'%;">'.$buffer.'</span>';

case 'img':
$buffer = trim($buffer);
if($buffer === '' || !_isSafeUrl($buffer)) return;
$buffer = _addSchemeToURL($buffer);
return '<img src="'.str_replace(array("\r", "\n"), '', $buffer).'" alt="img" class="bbcode-img" />';

}

}










function _parsePost($input, $smileys = true, $bbcode = true, $nl2br = true)
{


if(_smileys and $smileys) {
$input = preg_replace('/\*(\d{1,3})\*/s', '<img src=\''._indexroot.'plugins/templates/'._template.'/images/smileys/$1.'._template_smileys_format.'\' alt=\'$1\' class=\'post-smiley\' />', $input, 32);
}


if(_bbcode and $bbcode) $input = _parseBBCode($input);


if($nl2br) $input = nl2br($input);


return $input;

}







function _articleAccess($res)
{


if(!$res['confirmed'] || $res['time'] > time()) {
if(_loginright_adminconfirm || $res['author'] == _loginid) return 1;
return 0;
}


$homes = array($res['home1']);
if($res['home2'] != -1) $homes[] = $res['home2'];
if($res['home3'] != -1) $homes[] = $res['home3'];
$q = DB::query('SELECT home.public,home.level,inter.public AS inter_public,inter.level AS inter_level FROM `'._mysql_prefix.'-root` AS home LEFT JOIN `'._mysql_prefix.'-root` AS inter ON(home.intersection=inter.id) WHERE home.id IN('.implode(',', $homes).')');
while($r = DB::row($q)) {
if(_publicAccess($r['public'], $r['level']) && (!isset($r['inter_public']) || _publicAccess($r['inter_public'], $r['inter_level']))) {

return 1;
}
}
return 2;

}







function _postAccess($post)
{


if(_loginindicator) {

if(_loginid == $post['author'] && ($post['time'] + _postadmintime > time() || _loginright_unlimitedpostaccess)) {
return true;
} elseif(_loginright_adminposts) {

$data = _userDataCache($post['author']);
if(_loginright_level > $data['level']) return true;
}
}
return false;

}








function _publicAccess($public, $level = 0)
{
if((_loginindicator || $public == 1) && _loginright_level >= $level) return true;
return false;
}









function _restoreGetFdValue($name, $else = null, $noparam = false)
{

if($noparam) {
$param_start = "";
$param_end = "";
} else {
$param_start = " value='";
$param_end = "'";
}

if(isset($_GET['_formData'][$name])) {
return $param_start._htmlStr($_GET['_formData'][$name]).$param_end;
} else {
if($else != null) {
return $param_start._htmlStr($else).$param_end;
}
}

}



























function _resultPaging($url, $limit, $table, $conditions = "1", $linksuffix = "", $param = null, $autolast = false)
{
global $_lang;


if(is_string($table)) {
$table = explode(':', $table);
$alias = (isset($table[1]) ? $table[1] : null);
$table = $table[0];
} else $alias = null;


if(!isset($param)) $param = 'page';
if(is_string($table)) $count = DB::result(DB::query("SELECT COUNT(id) FROM `"._mysql_prefix."-".$table."`".(isset($alias) ? " AS {$alias}" : '')." WHERE ".$conditions), 0);
else $count = $table;
if($count == 0) $count = 1;

$pages = ceil($count / $limit);
if(isset($_GET[$param])) $s = abs(intval($_GET[$param]) - 1);
elseif($autolast) $s = $pages - 1;
else $s = 0;

if($s + 1 > $pages) $s = $pages - 1;
$start = $s * $limit;
$beginpage = $s + 1 - _showpages;
if($beginpage < 1) {
$endbonus = abs($beginpage) + 1;
$beginpage = 1;
} else {
$endbonus = 0;
}
$endpage = $s + 1 + _showpages + $endbonus;
if($endpage > $pages) {
$beginpage -= $endpage - $pages;
if($beginpage < 1) {
$beginpage = 1;
}
$endpage = $pages;
}




if(mb_substr_count($url, "?") == 0) {
$url .= "?";
} else {
$url .= "&amp;";
}

if($pages > 1) {
$paging = "<span>";
for($x = $beginpage; $x <= $endpage; $x++) {
if($x == $s + 1) {
$class = " class='act'";
} else {
$class = "";
}
$paging .= "<a href='".$url.$param."=".$x.$linksuffix."'".$class.">".$x."</a>\n";
if($x != $endpage) {
$paging .= " ";
}
}
$paging .= "</span>";




if($s + 1 != 1) {
$paging = "<a href='".$url.$param."=".($s).$linksuffix."'>&laquo; ".$_lang['global.previous']."</a>&nbsp;&nbsp;".$paging;
}
if($beginpage > 1) {
$paging = "<a href='".$url.$param."=1".$linksuffix."' title='".$_lang['global.first']."'>1</a> ... ".$paging;
}


if($s + 1 != $pages) {
$paging .= "&nbsp;&nbsp;<a href='".$url.$param."=".($s + 2).$linksuffix."'>".$_lang['global.next']." &raquo;</a>";
}
if($endpage < $pages) {
$paging .= " ... <a href='".$url.$param."=".$pages.$linksuffix."' title='".$_lang['global.last']."'>".$pages."</a>";
}

$paging = "\n<div class='paging'>\n".$_lang['global.paging'].":&nbsp;&nbsp;".$paging."\n</div>\n\n";
} else {
$paging = "";
}


$end_item = ($start + $limit - 1);
return array($paging, "LIMIT ".$start.", ".$limit, ($s + 1), $pages, $count, $start, (($end_item > $count - 1) ? $count - 1 : $end_item), $limit);

}









function _resultPagingGetItemPage($limit, $table, $conditions = "1")
{
$count = DB::result(DB::query("SELECT COUNT(id) FROM `"._mysql_prefix."-".$table."` WHERE ".$conditions), 0);
return intval($count / $limit) + 1;
}









function _resultPagingIsItemInRange($pagingdata, $itemnumber)
{
if($itemnumber >= $pagingdata[5] and $itemnumber <= $pagingdata[6]) return true;
return false;
}






function _returnHeader()
{


if(isset($_GET['_return']) and $_GET['_return'] != "") {


$url = $_GET['_return'];
if($url[0] === '/') $url = 'http://'._getDomain().$url;
else $url = _url.'/'.$url;
header("Location: ".$url);
exit;
}


if(isset($_SERVER['HTTP_REFERER']) and $_SERVER['HTTP_REFERER'] != "") header("Location: ".$_SERVER['HTTP_REFERER']);
else header("Location: "._url.'/');
exit;

}






function _sqlArticleWhereCategories($ids)
{
if($ids != null) {
$ids = _arrayRemoveValue(@explode("-", $ids), "");
$sql_code = "(";
$sql_count = count($ids);
$counter = 1;
foreach($ids as $rcat) {
$rcat = intval($rcat);
$sql_code .= "(home1=".$rcat." OR home2=".$rcat." OR home3=".$rcat.")";
if($counter != $sql_count) $sql_code .= " OR ";
++$counter;
}
$sql_code .= ")";
return $sql_code;
}
return "";
}








function _sqlArticleFilter($check_category_public = false, $exclude_invisible = true)
{
$output = "art.confirmed=1 AND art.time<=".time();
if($exclude_invisible) $output .= " AND art.visible=1";
if(!_loginindicator) $output .= " AND art.public=1";
if($check_category_public and !_loginindicator) $output .= " AND ((SELECT public FROM `"._mysql_prefix."-root` WHERE id=art.home1)=1 OR (SELECT public FROM `"._mysql_prefix."-root` WHERE id=art.home2)=1 OR (SELECT public FROM `"._mysql_prefix."-root` WHERE id=art.home3)=1)";
return $output;
}









function _sqlWhereColumn($column, $values, $isnumeric = true)
{
if($values != "all") {

$values = _arrayRemoveValue(explode("-", $values), "");
$values_count = count($values);
$sql = "";
$counter = 1;


foreach($values as $value) {


if($isnumeric) $value = intval($value);
else $value = "'".DB::esc($value)."'";


$sql .= $column."=".$value;
if($counter != $values_count) $sql .= " OR ";
++$counter;

}
} else $sql = "1";
return $sql;
}






function _systemFailure($msg)
{
if(!headers_sent()) {
header('HTTP/1.1 503 Service Temporarily Unavailable');
header('Retry-After: 600');
header('Content-Type: text/html; charset=UTF-8', true);
}
echo '<!DOCTYPE HTML><html><head><title>Selhání systému</title></head><body>';
_systemMessage("Selhání systému", "<p>".$msg."</p>");
echo '</body></html>';
exit;
}







function _systemMessage($title, $message)
{
echo "

<div style='text-align: center !important; margin: 10px !important;'>
<div style='text-align: left !important; margin: 0 auto !important; width: 600px !important; font-family: monospace !important; font-size: 13px !important; color: #000000 !important; background-color: #ffffff !important; border: 1px solid #ffffff !important; position: relative; z-index: 999;'>
<div style='border: 1px solid #000000 !important; padding: 10px; overflow: auto !important;'>
<h1 style='color: #000000 !important; font-size: 20px !important; border-bottom: 2px solid #ff6600 !important;'>".$title."</h1>
".$message."
</div>
</div>
</div>

";
}
















function _uniForm($id, $vars = array(), $notitle = false)
{


global $_lang;
$content = "";
$title = "";


switch($id) {



case "login":


$title = $_lang['login.title'];


if(isset($_GET['_mlr'])) {
switch($_GET['_mlr']) {
case 0:
$content .= _formMessage(2, $_lang['login.failure']);
break;
case 1:
if(_loginindicator and !_administration) {
$content .= _formMessage(1, $_lang['login.success']);
}
break;
case 2:
if(!_loginindicator) {
$content .= _formMessage(2, $_lang['login.blocked.message']);
}
break;
case 3:
if(!_loginindicator) {
$content .= _formMessage(3, $_lang['login.securitylogout']);
}
break;
case 4:
if(!_loginindicator) {
$content .= _formMessage(1, $_lang['login.selfremove']);
}
break;
case 5:
if(!_loginindicator) {
$content .= _formMessage(2, str_replace(array("*1*", "*2*"), array(_maxloginattempts, _maxloginexpire / 60), $_lang['login.attemptlimit']));
}
break;
case 6:
$content .= _formMessage(3, $_lang['xsrf.msg']);
break;
}
}


if(!_loginindicator) {


if(!isset($_SESSION[_sessionprefix.'login_key'])) $_SESSION[_sessionprefix.'login_key'] = uniqid('', true);
$token = $_SESSION[_sessionprefix.'login_key'];


$content .= "<script type='text/javascript'>/* <![CDATA[ */var sl_login_key='".$token."';/* ]]> */</script>
<script type='text/javascript' src='"._indexroot."remote/login.js?"._cacheid."'></script>";


if(isset($_GET['login_form_return'])) $return = $_GET['login_form_return'];
else $return = $_SERVER['REQUEST_URI'];


$form_url = parse_url($_SERVER['REQUEST_URI']);
if(isset($form_url['query'])) {
parse_str($form_url['query'], $form_url['query']);
unset($form_url['query']['_formData'], $form_url['query']['_mlr']);
$form_url = _buildURL($form_url);
} else $form_url = $_SERVER['REQUEST_URI'];



$content .= _formOutput(
"login_form",
_indexroot."remote/login.php?_return=".urlencode($return),
array(
array($_lang['login.username'], "<input type='text' name='username' class='inputmedium'"._restoreGetFdValue("username")." maxlength='24' />"),
array($_lang['login.password'], "<input type='password' name='password' class='inputmedium' />")
),
null,
$_lang['global.login'],
"&nbsp;&nbsp;<label><input type='checkbox' name='persistent' value='1' /> ".$_lang['login.persistent']."</label><input type='hidden' name='secure' value='0' /><input type='hidden' name='form_url' value='"._htmlStr($form_url)."' />
                    &nbsp;&nbsp;<label><input type='checkbox' name='ipbound' value='1' checked='checked' /> ".(isset($_lang['login.ipbound']) ? $_lang['login.ipbound'] : 'zabezpečené')."</label>"
);


if(_registration or _lostpass) {
$content .= "\n\n<p>\n".((_registration and !_administration) ? "<a href='"._indexroot."index.php?m=reg'>".$_lang['mod.reg']." &gt;</a>\n" : '').(_lostpass ? ((_registration and !_administration) ? "<br />" : '')."<a href='"._indexroot."index.php?m=lostpass'>".$_lang['mod.lostpass']." &gt;</a>\n" : '')."</p>";
}

} else {
$content .= "<p>".$_lang['login.ininfo']." <em>"._loginname."</em> - <a href='"._xsrfLink(_indexroot."remote/logout.php")."'>".$_lang['usermenu.logout']."</a>.</p>";
}

break;



case "notpublic":
$form = _uniForm("login", array(), true);
if(!isset($vars[0])) {
$vars[0] = false;
}
$content = "<p>".$_lang['notpublic.p'.(($vars[0] == true) ? '2' : '')]."</p>".$form[0];
$title = $_lang['notpublic.title'];
break;



case "postform":
$title = "";
$notitle = true;


$inputs = array();
$captcha = _captchaInit();
$content = _jsLimitLength(16384, "postform", "text");
if(_loginindicator == 0) $inputs[] = array($_lang['posts.guestname'], "<input type='text' name='guest' maxlength='24' class='inputsmall'"._restoreGetFdValue("guest")." />");
if($vars['xhome'] == -1) $inputs[] = array($_lang[(($vars['posttype'] != 5) ? 'posts.subject' : 'posts.topic')], "<input type='text' name='subject' class='input".(($vars['posttype'] != 5) ? 'small' : 'medium')."' maxlength='".(($vars['posttype'] != 5) ? 22 : 48)."'"._restoreGetFdValue("subject")." />");
$inputs[] = $captcha;
$inputs[] = array($_lang['posts.text'], "<textarea name='text' class='areamedium' rows='5' cols='33'>"._restoreGetFdValue("text", null, true)."</textarea><input type='hidden' name='_posttype' value='".$vars['posttype']."' /><input type='hidden' name='_posttarget' value='".$vars['posttarget']."' /><input type='hidden' name='_xhome' value='".$vars['xhome']."' />".(isset($vars['pluginflag']) ? "<input type='hidden' name='_pluginflag' value='".$vars['pluginflag']."' />" : ''), true);


$content .= _formOutput('postform', _addGetToLink(_indexroot."remote/post.php", "_return=".urlencode($vars['url']), false), $inputs, array("text"), null, _getPostformControls("postform", "text"));

break;


}


if((_template_autoheadings == 1 or _administration == 1) and $notitle == false) {
$content = "<h1>$title</h1>\n".$content;
}
return array($content, $title);

}







function _userLogout($destroy = true)
{
if(!defined('_loginindicator') or _loginindicator == 1) {
$_SESSION = array();
if($destroy) {
session_destroy();
setcookie(session_name(), '', time() - 3600, '/');
}
if(isset($_COOKIE[_sessionprefix."persistent_key"])) @setcookie(_sessionprefix."persistent_key", "", (time() - 3600), "/");
return true;
}
return false;
}








function _checkGD($check_format = null, $print_image = false)
{

if(function_exists("gd_info")) {
if(isset($check_format)) {

$info = gd_info();
$support = false;
switch(mb_strtolower($check_format)) {
case "png":
if(isset($info['PNG Support']) and $info['PNG Support'] == true) $support = true;
break;
case "jpg":
case "jpeg":
if((isset($info['JPG Support']) and $info['JPG Support'] == true) or (isset($info['JPEG Support']) and $info['JPEG Support'] == true)) $support = true;
break;
case "gif":
if(isset($info['GIF Read Support']) and $info['GIF Read Support'] == true) $support = true;
break;
}

if($support) return true;
elseif($print_image) $img = "2klEQVR4nGP538jyh4HlOwPLf5Y/LEdY/mtEsjDcaGRhYACKMDSy/NMC8h0YWJgmdLJsWyPP4nUKKH7BgOEgC4PeVm8GFgYmb6DKt+sYhIVZOCVe/ADpYgDJLkhocGRhkO4DyjL8CVgEJIH2AElXhoaDINP/MbB8285VPJ2FkVF1yWeWD+3Nn8RZJE8yAfWCTACBj0B1HwQYGA4A7Wdg+HJcdZETyAQGHqAwA5gl4MkwCcKCAijrgQwDy7+dHLINQnkJU4FiFk+Bgg1AX3gyKLQoQExmYFEAKQUAOQ48juT2O7oAAAAASUVORK5CYII=";
else return false;

} else return true;
} elseif(!$print_image) return false;
else $img = "zElEQVR4nGP538jyiYGFj4HlP8sClgSW/4f2szDYATEDUIShkYXBwpPl9R8GFtEzjWAxEP5z+YPDQRbmDQ4OQLEGhgUPQaIKYBKsi4HhIMvfhU4KQLbAywWOQHHuCY4sjO9/GDCwMCcjqX8n9IGB5XfCn2cToXpZN4H0/meAgI8sDB/qeyF2MvxlYHhwxVoUyGIG8v+DxQQmMqio/IO4CgiYwKz/v9kY/jMCWY8erw1V6ugHsni/de1ntgPL8jT4KCwFsQQtLRm+ADUBAA7YQI0qsisiAAAAAElFTkSuQmCC";



header("Content-Type: image/PNG");
echo base64_decode("iVBORw0KGgoAAAANSUhEUgAAAEQAAAAWAQAAAAEmKTd1AAAACXBIWXMAAAsSAAALEgHS3X78AAAA".$img);
exit;

}







function _checkKeys($array_name, $keys)
{
global $$array_name;
if(!is_array($$array_name)) return;
foreach($keys as $key) {
if(!isset(${$array_name}[$key])) {
global $_lang;
die($_lang['global.badinput']);
}
}
}












function _getAvatar($id, $path_only = false, $return_null = false, $full_size = false, $no_plugins = false, $no_link = false)
{


$path = _indexroot.'pictures/avatars/';


$exists = false;
if($id != -1) {
$udata = _userDataCache($id);
if(isset($udata['avatar'])) $exists = true;
}


if($id != -1 && !$no_plugins) {
$extend_return = false;
_extend('call', 'user.avatar', array('return' => &$extend_return, 'udata' => $udata, 'path_only' => $path_only, 'return_null' => $return_null, 'full_size' => $full_size));
if($extend_return !== false) return $extend_return;
}


if(!$exists && $return_null) return;


$path .= ($exists ? $udata['avatar'] : 'no-avatar'.(_template_dark ? '-dark' : '')).'.jpg';
if($path_only) return $path;


$output = '<img src="'.$path.'" alt="'.($exists ? (($udata['publicname'] === '') ? $udata['username'] : $udata['publicname']) : 'avatar').'" class="avatar2" />';
if($id != -1 && !$no_link) $output = '<a href="'._indexroot.'index.php?m=profile&amp;id='.$udata['username'].'">'.$output.'</a>';
return $output;

}






function _getDomain($url = _url)
{


static $cache = array();
if(isset($cache[$url])) return $cache[$url];


$purl = @parse_url($url);
return ($cache[$url] = (isset($purl['host']) ? $purl['host'] : null));

}






function _sysMailHeader()
{
if(_sysmail === '') return;
return (_mailerusefrom ? 'From' : 'Reply-To').": "._sysmail."\n";
}







function _extendLoad($dir = null)
{


if(_extend_enabled) {
$extend_dir = (isset($dir) ? $dir : _indexroot.'plugins/extend/');
$extend = @opendir($extend_dir);
if($extend !== false)
while($item = readdir($extend)) {


if($item === '.' || $item === '..' || $item[0] === '.' || !is_dir($extend_dir.$item)) continue;


$fname = $item;
if(substr($fname, 0, 6) === 'admin.') {
if(!_administration) continue;
$fname = substr($fname, 6);
} elseif(substr($item, 0, 4) === 'web.') {
if(_administration) continue;
$fname = substr($fname, 4);
}


require $extend_dir.$item.'/'.$fname.'.php';

}
return true;
}

return false;

}









function _extend($act, $idt, $arg = null, $arg2 = null)
{


static $data = array();


if(!_extend_enabled) return;


switch($act) {

case 'reg':
if(!isset($data[$idt])) $data[$idt] = array();
$pri = (isset($arg2) ? intval($arg2) : 0);
$data[$idt][] = array($arg, $pri);
if($pri !== 0) usort($data[$idt], '_extend_reg_sort');
break;

case 'call':
if(!isset($data[$idt])) return;
for($i = 0; isset($data[$idt][$i]); ++$i) {
$call = call_user_func($data[$idt][$i][0], $arg);
if($call === false) break;
}
break;

}

}




function _extend_reg_sort($a, $b)
{
if($a[1] === $b[1]) return 0;
if($a[1] > $b[1]) return 1;
return - 1;
}








function _extendArgs(&$output, $extra = array())
{
return array('output' => &$output, 'extra' => $extra);
}















function _pictureLoad($filepath, $limit = array(), $filename = null)
{


static $limit_default = array(
'filesize' => null,
'dimensions' => null,
);


$limit += $limit_default;


if(!isset($limit['filesize']) && ($memlimit = _phpIniLimit('memory_limit')) !== null) {
$limit['filesize'] = $memlimit - memory_get_usage();
if($limit['filesize'] <= 0) unset($limit['filesize']);
}


$code = 0;
do {




$ext = pathinfo((isset($filename) ? $filename : $filepath));
if(!isset($ext['extension'])) $ext['extension'] = '';
else $ext = mb_strtolower($ext['extension']);


if(!in_array($ext, $GLOBALS['__image_ext'])) {

$code = 1;
break;
}


$size = @filesize($filepath);
if($size === false) {

$code = 2;
break;
}
if(isset($limit['filesize']) && filesize($filepath) > $limit['filesize']) {

$code = 3;
break;
}


if(!_checkGD($ext)) {

$code = 4;
break;
}


switch($ext) {

case 'jpg':
case 'jpeg':
$res = @imagecreatefromjpeg($filepath);
break;

case 'png':
$res = @imagecreatefrompng($filepath);
break;

case 'gif':
$res = @imagecreatefromgif($filepath);
break;

}


if(!is_resource($res)) {
$code = 5;
break;
}


$x = imagesx($res);
$y = imagesy($res);


if(isset($limit['dimensions']) && ($x > $limit['dimensions']['x'] || $y > $limit['dimensions']['y'])) {
$code = 6;
break;
}


return array(true, $code, $res, $ext);


} while(false);


global $_lang;
$output = array(false, $code, $_lang['pic.load.'.$code], $ext);


switch($code) {

case 3:
$output[2] = str_replace('*maxkb*', round($limit['filesize'] / 1024), $output[2]);
break;

case 6:
$output[2] = str_replace(array('*maxw*', '*maxh*'), array($limit['dimensions']['x'], $limit['dimensions']['y']), $output[2]);
break;

}


return $output;

}



















function _pictureResize($res, $opt, $size = null)
{
global $_lang;


if(!isset($size)) {
$x = imagesx($res);
$y = imagesy($res);
} else list($x, $y) = $size;


if(isset($opt['keep_smaller']) && $opt['keep_smaller'] === true && $x < $opt['x'] && $y < $opt['y']) {
return array(true, 0, $res, true);
}


if($x == $opt['x'] && $y == $opt['y']) return array(true, 0, $res, true);


$newx = $opt['x'];
$newy = round($opt['x'] / ($x / $y));


$xoff = $yoff = 0;
if($opt['mode'] === 'zoom') {
if($newy < $opt['y']) {
$newx = $x / $y * $opt['y'];
$newy = $opt['y'];
$xoff = round(($opt['x'] - $newx) / 2);
} elseif($newy > $opt['y']) {
$yoff = round(($opt['y'] - $newy) / 2);
}
} elseif($opt['mode'] === 'fit') {
if($newy < $opt['y']) {
if(!isset($opt['pad']) || $opt['pad'] === true) $yoff = round(($opt['y'] - $newy) / 2);
else $opt['y'] = $newy;
} elseif($newy > $opt['y']) {
$newy = $opt['y'];
$newx = $x / $y * $opt['y'];
if(!isset($opt['pad']) || $opt['pad'] === true) $xoff = round(($opt['x'] - $newx) / 2);
else $opt['x'] = $newx;
}
} else return array(false, 1, $_lang['pic.resize.0']);


$output = imagecreatetruecolor($opt['x'], $opt['y']);


if($opt['mode'] === 'fit' && isset($opt['bgcolor'])) {
$bgc = imagecolorallocate($output, $opt['bgcolor'][0], $opt['bgcolor'][1], $opt['bgcolor'][2]);
imagefilledrectangle($output, 0, 0, $opt['x'], $opt['y'], $bgc);
}


if(imagecopyresampled($output, $res, $xoff, $yoff, 0, 0, $newx, $newy, $x, $y)) {
return array(true, 0, $output, false);
}
imagedestroy($output);
return array(false, 2, $_lang['pic.resize.2']);

}












function _pictureStoragePut($res, $path, $home_path, $format, $jpg_quality = 80, $uid = null)
{


if(!isset($uid)) $uid = uniqid('');


if(isset($home_path)) $path .= $home_path;


$code = 0;
do {


if(!is_dir($path) && !@mkdir($path, 0777, true)) {
$code = 1;
break;
}


if(!_checkGD($format)) {
$code = 2;
break;
}


$fname = $path.$uid.'.'.$format;


switch($format) {

case 'jpg':
case 'jpeg':
$write = @imagejpeg($res, $fname, $jpg_quality);
break;

case 'png':
$write = @imagepng($res, $fname);
break;

case 'gif':
$write = @imagegif($res, $fname);
break;

}


if($write) return array(true, $code, $fname, $uid);
$code = 3;

} while(false);



global $_lang;
return array(false, $code, $_lang['pic.put.'.$code]);


}










function _pictureStorageGet($path, $home_path, $uid, $format)
{
return $path.(isset($home_path) ? $home_path : '').$uid.'.'.$format;
}






function _xsrfProtect()
{
return '<input type="hidden" name="_security_token" value="'._xsrfToken().'" />';
}






function _xsrfAutoProtect($code)
{


$token = _xsrfToken();
$insert = '<input type="hidden" name="_security_token" value="'.$token.'" />';


static $backtrack_limit;
if(!isset($backtrack_limit)) {
$backtrack_limit = intval(ini_get('pcre.backtrack_limit'));
if($backtrack_limit === 0) $backtrack_limit = 40000;
else $backtrack_limit = round($backtrack_limit * 0.4);
}
if($backtrack_limit > strlen($code)) {
$preg = preg_replace('~(<form.*?method\s*=["\']?POST["\']?)(.*?)(</form>)~siu', '$1$2'.$insert.'$3', $code);
if($preg !== null) return $preg;
}


$off = 0;
$time = time();
$insert_len = strlen($insert);
while(($fpos = strpos($code, '<form', $off)) !== false) {


$off += 4;


$fend = strpos($code, '</form>', $off);
if($fend === false) break;


$mpos = stripos($code, 'method=\'POST\'', $off);
if($mpos === false || $mpos > $fend) {
$mpos = stripos($code, 'method="POST"', $off);
if($mpos === false || $mpos > $fend) {

$off = $fend + 7;
continue;
}
}


$code = substr($code, 0, $fend).$insert.substr($code, $fend)."\n";
$off = $fend + 7 + $insert_len;

}

return $code;

}








function _xsrfLink($url, $entity = true)
{
return _addGetToLink($url, '_security_token='.urlencode(_xsrfToken()), $entity);
}






function _xsrfToken()
{
static $token, $store_limit = 30;
if(!isset($token)) {


$token = uniqid('', true);


if(!isset($_SESSION[_sessionprefix.'security_token'])) $_SESSION[_sessionprefix.'security_token'] = array();
$_SESSION[_sessionprefix.'security_token'][] = $token;
if(sizeof($_SESSION[_sessionprefix.'security_token']) > $store_limit) array_shift($_SESSION[_sessionprefix.'security_token']);

}
return $token;
}







function _xsrfCheck($get = false)
{


if($get) $tvar = '_GET';
else $tvar = '_POST';


if(isset($GLOBALS[$tvar]['_security_token'])) {
$test = @strval($GLOBALS[$tvar]['_security_token']);
unset($GLOBALS[$tvar]['_security_token']);
} else $test = null;


if(!empty($_SESSION[_sessionprefix.'security_token']) && isset($test)) {

$check = array_search($test, $_SESSION[_sessionprefix.'security_token']);
if($check === false) return false;
array_splice($_SESSION[_sessionprefix.'security_token'], $check, 1);
return true;
}
return false;

}








function _showIP($ip, $repl = 'x')
{
if(_loginright_group == 1) return $ip;
return substr($ip, 0, strrpos($ip, '.') + 1).$repl;
}







function _getLang($langs)
{
if(!isset($langs[$current = $GLOBALS['_lang']['main.languagespecification']])) return key($langs);
return $current;
}







function _loadLang($dir, $langs)
{
if(!isset($langs[$lang = $GLOBALS['_lang']['main.languagespecification']])) $lang = current($langs);
return include $dir.DIRECTORY_SEPARATOR."lang.{$lang}.php";
}










function _mail($to, $subject, $message, $additional_headers = '')
{


$handled = false;
_extend('call', 'sys.mail', array('handled' => &$handled, 'to' => $to, 'subject' => $subject, 'message' => $message, 'headers' => $additional_headers));
if($handled) return true;


$subject = '=?UTF-8?B?'.base64_encode($subject).'?=';


return @mail($to, $subject, $message, $additional_headers);

}