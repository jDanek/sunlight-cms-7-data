<?php



if(!defined('_indexroot')) exit;


function _coreStartup()
{


static $called = false;
if($called) _systemFailure('Funkci _coreStartup() nelze volat vícekrát než jednou!');
$called = true;




require (defined('_core_config_override') ? _core_config_override : _indexroot.'config.php');
define('_mysql_prefix', $prefix);
define('_mysql_db', $database);


if(!isset($locale)) $locale = array('czech', 'utf8', 'cz_CZ');
if(!isset($timezone)) $timezone = 'Europe/Prague';
if(!isset($geo)) $geo = array(50.5, 14.26, 90.583333);


define('_dev', false);
define('_systemstate', 2);
define('_systemstate_revision', 2);
define('_systemversion', '7.5.1');


define('_core', '1');
define('_nl', "\n");
define('_sessionprefix', md5($server.$database.$user.$prefix)."-");
if(!defined('_administration')) define('_administration', 0);


define('_upload_dir', _indexroot.'upload/');
define('_plugin_dir', _indexroot.'plugins/common/');
define('_void_file', _indexroot.'data/void.nodelete');


define('_geo_latitude', $geo[0]);
define('_geo_longitude', $geo[1]);
define('_geo_zenith', $geo[2]);




define('_tmp_dir', _indexroot.'data/tmp/');
require _indexroot.'require/core.php';




if(!defined('_core_no_env_changes')) {


$err_rep = E_ALL;
if(_dev) $disable = array('E_DEPRECATED', 'E_STRICT');
else $disable = array('E_NOTICE ', 'E_USER_NOTICE', 'E_DEPRECATED', 'E_STRICT');
for($i = 0; isset($disable[$i]); ++$i)
if(defined($disable[$i])) $err_rep &= ~ constant($disable[$i]);
error_reporting($err_rep);


@setlocale(LC_TIME, $locale);
if(function_exists('date_default_timezone_set')) date_default_timezone_set($timezone);


mb_internal_encoding("UTF-8");
if(!defined('_header')) $header = "Content-Type: text/html; charset=UTF-8";
else $header = _header;
if($header != "") header($header);


if(_administration) {
ob_start();



function _admin_scv(){ if(!isset($GLOBALS['_admin_s'.'ce'])) ob_end_clean(); }
register_shutdown_function('_admin_scv');
}

}




$GLOBALS['__image_ext'] = array("png", "jpeg", "jpg", "gif");
$GLOBALS['__hcm_uid'] = 0;
$GLOBALS['__captcha_counter'] = 0;
$GLOBALS['__extset'] = array();
$GLOBALS['__sys_state'] = array('BETA', 'RC', 'STABLE');




require _indexroot."require/functions.php";
if(isset($_GET['___identify'])) {
echo "SunLight CMS "._systemversion.' '.$GLOBALS['__sys_state'][_systemstate]._systemstate_revision;
exit;
}



$con = @mysql_connect($server, $user, $password);
if(!$con or !@mysql_select_db($database, $con)) _systemFailure("Připojení k databázi se nezdařilo. Důvodem je pravděpodobně výpadek serveru nebo chybné přístupové údaje.</p><hr />\n<pre>"._htmlStr(mysql_error())."</pre><hr /><p>Zkontrolujte přístupové údaje v souboru <em>config.php</em>.");
if(function_exists('mysql_set_charset')) mysql_set_charset('utf8', $con);
else mysql_query("SET NAMES `utf8`", $con);
define('_mysql_link', $con);




if(!defined('_core_lightmode')) {


$query = DB::query("SELECT * FROM `"._mysql_prefix."-settings`", true);
if(DB::error() != false) _systemFailure("Připojení k databázi proběhlo úspěšně, ale dotaz na databázi selhal.</p><hr />\n<pre>"._htmlStr(DB::error())."</pre><hr /><p>Zkontrolujte, zda je databáze správně nainstalovaná.");
while($item = DB::row($query)) {


if($item['var'] === 'banned') {
if($item['val'] !== '') $set_banned = explode("\n", $item['val']);
else $set_banned = false;
continue;
}


if($item['var'][0] === '.') {
$GLOBALS['__extset'][substr($item['var'], 1)] = $item['val'];
continue;
}


define('_'.$item['var'], $item['val']);

}
DB::free($query);


if(_proxy_mode && isset($_SERVER['HTTP_X_FORWARDED_FOR'])) $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
else $ip = $_SERVER['REMOTE_ADDR'];
define('_userip', trim((($addr_comma = strpos($ip, ',')) === false) ? $ip : substr($ip, $addr_comma + 1)));


if(_install_check) require _indexroot.'require/installcheck.php';


if(!defined("_dbversion") or !_checkVersion("database", _dbversion)) {
_systemFailure("Verze nainstalované databáze není kompatibilní s verzí systému. Pokud byl právě aplikován patch pro přechod na novější verzi, pravděpodobně jste zapoměl(a) spustit skript pro aktualizaci databáze.");
}


require _indexroot."require/session.php";


if(_loginindicator and _language_allowcustom and _loginlanguage != "") $language = _loginlanguage;
else $language = _language;
$langfile = _indexroot."plugins/languages/".$language.".php";
$langfile_default = _indexroot."plugins/languages/default.php";

if(@file_exists($langfile)) {
$GLOBALS['_lang'] = require $langfile;
} else {
if(@file_exists($langfile_default)) $GLOBALS['_lang'] = require $langfile_default;
else _systemFailure("Zvolený ani přednastavený jazykový soubor nebyl nalezen.");
}


if(!_checkVersion("language_file", $GLOBALS['_lang']['main.version'])) {
DB::query("UPDATE `"._mysql_prefix."-settings` SET val='default' WHERE var='language'");
_systemFailure("Zvolený jazykový soubor není kompatibilní s verzí systému.");
}


if($set_banned !== '' && !_administration)
for($i = 0; isset($set_banned[$i]); ++$i) {
if(strpos(_userip, $set_banned[$i]) === 0) {
header('HTTP/1.0 403 Forbidden');
if(defined('_header')) die('Your IP address is banned');
require _indexroot.'require/ipban.php';
die;
}
}


$template = _indexroot."plugins/templates/"._template."/template.php";
$template_config = _indexroot."plugins/templates/"._template."/config.php";

if(!@file_exists($template) or !@file_exists($template_config)) {
DB::query('UPDATE `'._mysql_prefix.'-settings` SET val=\'default\' WHERE var=\'template\'');
_systemFailure("Zvolený motiv "._template." nebyl nalezen. Přepnuto na výchozí motiv.");
}

require $template_config;


if(!_checkVersion("template", _template_version) and !_administration) _systemFailure("Zvolený motiv není kompatibilní s verzí systému.");


_extendLoad();
_extend('call', 'sys.init');

}

}

_coreStartup();
