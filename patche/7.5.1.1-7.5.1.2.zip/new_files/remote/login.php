<?php

define('_indexroot', '../');
require _indexroot."require/load.php";


_checkKeys('_POST', array('secure', 'form_url'));
if(!isset($_POST['username'])) $_POST['username'] = '';
if(!isset($_POST['password'])) $_POST['password'] = '';
$result = 0;
$username = "";
if(!_loginindicator) {

if(_xsrfCheck()) {
if(_iplogCheck(1)) {


if($_POST['secure'] === '0') {

$username = DB::esc($_POST['username']);
$email = (strpos($_POST['username'], '@') !== false);
$password = $_POST['password'];
$secure = false;
} else {

$secure_data = explode('$', $_POST['secure']);
if(sizeof($secure_data) !== 2 || !is_numeric($secure_data[0])) die;
$secure_data[0] = intval($secure_data[0]);
$secure = true;
}

$persistent = _checkboxLoad('persistent');
if(isset($_SESSION[_sessionprefix.'login_key'])) {
$login_key = $_SESSION[_sessionprefix.'login_key'];
unset($_SESSION[_sessionprefix.'login_key']);
}


if(!$secure) $query = DB::query("SELECT * FROM `"._mysql_prefix."-users` WHERE `".($email ? 'email' : 'username')."`='".$username."'".((!$email && $username !== '') ? ' OR publicname=\''.$username.'\'' : ''));
else $query = DB::query('SELECT * FROM `'._mysql_prefix.'-users` WHERE id='.$secure_data[0]);
if(isset($login_key) && DB::size($query) != 0) {

$query = DB::row($query);
if(empty($username)) $username = $query['username'];
$groupblock = DB::row(DB::query("SELECT blocked FROM `"._mysql_prefix."-groups` WHERE id=".$query['group']));
if($query['blocked'] == 0 and $groupblock['blocked'] == 0) {
if($secure && $secure_data[1] === _md5HMAC($query['password'], $login_key) || !$secure && _md5Salt($password, $query['salt']) == $query['password']) {


DB::query("UPDATE `"._mysql_prefix."-users` SET logincounter=logincounter+1 WHERE id=".$query['id']);


if($persistent) setcookie(_sessionprefix."persistent_key", $query['id'].'$'._md5HMAC($query['password'], _userip), (time() + 2592000), "/");


$_SESSION[_sessionprefix."user"] = $query['id'];
$_SESSION[_sessionprefix."password"] = $query['password'];
$_SESSION[_sessionprefix."ip"] = _userip;
$_SESSION[_sessionprefix."ipbound"] = isset($_POST['ipbound']);
$result = 1;

} else {
_iplogUpdate(1);
}
} else {
$result = 2;
}

}

} else {
$result = 5;
}
} else {
$result = 6;
}

}


if($result != 1) $_GET['_return'] = _addFdGetToLink(_addGetToLink($_POST['form_url'], '_mlr='.$result, false), array('username' => $username));
_returnHeader();