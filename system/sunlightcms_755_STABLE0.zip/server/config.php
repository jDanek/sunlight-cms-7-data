<?php

// pristupove udaje
$server = "localhost";
$user = "";
$password = "";
$database = "";
$prefix = "sunlight";

// konfigurace
$locale = array('czech', 'utf8', 'cz_CZ');
$timezone = 'Europe/Prague';
$geo = array(50.5, 14.26, 90.583333); // latitude, longitude, zenith

// vyvojovy rezim
//$dev = true;
