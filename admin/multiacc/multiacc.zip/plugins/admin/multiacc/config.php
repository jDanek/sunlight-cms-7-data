<?php

return array(
    'title'     => 'MultiAcc',
    'access'    => true,
    'in-other'  => true,
    _loginright_level > 5000,
    'autotitle' => true,
);
