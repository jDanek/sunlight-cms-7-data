<?php
if (!defined('_core'))
{
    exit;
}

$output.="<p class='bborder'>Nástroj slouží jako orientační detektor multiúčtů, IP jsou získávány z příspěvků</p>";

// ziskani IP adres s vice uzivateli
$ips = DB::query("SELECT ip FROM `sunlight-posts` WHERE author<>-1 GROUP BY ip HAVING COUNT(distinct author) > 1 ORDER BY ip");

$ip_list = array();
while ($i = DB::row($ips))
{
    $ip_list[] = $i['ip'];
}

if (sizeof($ip_list) > 0)
{
    // ziskani uzivatelskych ID
    $users = DB::query("SELECT p.ip as ip, u.id as user_id 
    FROM `sunlight-users` u 
    LEFT JOIN `sunlight-posts` p ON p.author=u.id 
    WHERE p.ip IN(" . DB::arr($ip_list) . ") 
    GROUP BY u.id");

    $user_list = array();
    while ($u = DB::row($users))
    {
        $user_list[$u['ip']][] = $u['user_id'];
    }

    $output.= _formMessage(2, "Nalezeny shodné IP!");
    // vystup
    $output.="<table class='list'>"
            . "<thead><th>IP</th><th>Uživatelé</th></thead><tbody>";
    foreach ($user_list as $ip => $ids)
    {
        $output.="<tr><td>{$ip}</td><td></td></tr>";
        foreach ($ids as $u)
        {
            $output.="<tr><td></td><td>" . _linkUser($u) . "</td></tr>";
        }
    }
    $output.="</table>";
}
else
{
    $output.= _formMessage(1, "Nebyli nalezeny žádné uživatelské účty se shodnou IP adresou.");
}


