<?php 

return array( 
'title' => 'Langfile editor', 
'access' => _loginright_group == 1, 
'in-other' => true,
); 