<?php
/* --- kontrola jadra --- */
if(!defined('_core')) die;

/* --- skript pluginu --- */

// init
$base_url = 'index.php?p=lfe';
$lang_dir = _indexroot.'plugins/languages/';

// aktualni jazyk
$lang = (isset($_GET['edit']) ? basename($_GET['edit']) : null);

// cara
$output .= "<div class='hr'><hr /></div>\n";

// vyber?
if(!isset($lang) && !isset($_GET['copy'])) {


    ##### vyber #####

    $output .= "<table class='list'>
<thead><tr><td>Language file</td><td>Action</td></tr></thead>
<tbody>\n";
    $dir = opendir($lang_dir);
    while($item = readdir($dir)) {
        if($item === '.' || $item === '..' || substr($item, -4) !== '.php') continue;
        $xitem = substr($item, 0, -4);
        $output .= "<tr><td><a href='$base_url&amp;edit=$xitem'><img src='images/icons/edit.png' alt='edit' class='icon' />$xitem</a></td><td><a href='$base_url&amp;copy=$xitem'>duplicate</a></td></tr>\n";
    }
    $output .= "</tbody></table>
    
<br />
<p><a href='index.php?p=fman&dir=..%2Fplugins%2Flanguages%2F'><img src='images/icons/list.png' alt='fman' class='icon' />Browse language files using file manager</a></p>";

    return;


}

// kopie?
if(isset($_GET['copy'])) {
    
    ##### kopie ######
    
    // zpetny odkaz
    $output .= "<p><a href='$base_url'>&lt; back</a></p>";

    // najit soubor
    $copy = basename($_GET['copy']);
    $copy_file = $lang_dir.$copy.'.php';
    if(!file_exists($copy_file)) {
        $output .= _formMessage(3, 'Error');
        return;
    }
    
    // zpracovat
    if(isset($_POST['newname'])) {
        
        $newname = basename(trim($_POST['newname']));
        $new_file = $lang_dir.$newname.'.php';

        if($newname === '') $output .= _formMessage(2, 'Invalid new name');
        elseif(file_exists($new_file)) $output .= _formMessage(2, 'File already exists!');
        elseif(@file_put_contents($new_file, file_get_contents($copy_file)) !== false) {
            $output .= _formMessage(1, 'Done');
            return;
        } else $output .= _formMessage(2, 'Could not copy');
        
    }
    
    // formular
    $output .= "<form action='$base_url&amp;copy="._htmlStr($copy)."' method='post'>
<p>Duplicate <code>"._htmlStr($copy)."</code> and save it as <input name='newname' type='text' class='inputsmall' maxlength='16' /><em>.php</em></p>
<p><input type='submit' value='Copy' /></p>
<p><small>See <a href='http://www.rssboard.org/rss-language-codes' target='_blank'>List of language codes</a></small></p>
</form>
";

    return;

}

##### editace #####

// zpetny odkaz
$edit_url = $base_url.'&amp;edit='._htmlStr($lang);
$output .= "<p><a href='$base_url'><img src='images/icons/delete3.png' alt='cancel' class='icon' />cancel</a></p>";

// nacteni souboru
$lang_file = $lang_dir.$lang.'.php';
if(!file_exists($lang_file)) {
    $output .= _formMessage(3, 'Error');
    return;
}
$lang_data = require $lang_file;

// kontrola verze
if(!_checkVersion('language_file', $lang_data['main.version'])) {
    $output .= _formMessage(3, 'File not compatible ('._htmlStr($lang_data['main.version']));
    return;
}

// zamezeni editace default
if($lang === 'default') {
    $output .= _formMessage(3, 'Editing the default language directly is not allowed. Duplicate it first.');
    return;
}

// ulozeni
if(isset($_POST['lang']) && is_array($_POST['lang'])) {

    $lang_data = $_POST['lang'];
    if(@file_put_contents($lang_file, '<?php return '.var_export($_POST['lang'], true).';') !== false) {
        $output .= _formMessage(1, 'Saved!');
    } else {
        $output .= _formMessage(2, 'Could not save!'); 
    }

}

// funkce zaznamu
function _plugin_lfe_entries($entries, $parents = null)
{

    global $output;
    static $fields_readonly = array('main.version' => 0);

    foreach($entries as $e => $v) {

        // array
        if(is_array($v)) {
            _plugin_lfe_entries($v, (isset($parents) ? array_merge($parents, array($e)) : array($e)));
            continue;
        }

        // read only?
        $readonly = (!isset($parents) && isset($fields_readonly[$e]));

        // prepare field
        $vlen = strlen($v);
        $field_name = 'lang['.(isset($parents) ? implode('][', $parents) : $e).']'.(isset($parents) ? '['.$e.']' : '');
        if(strpos($v, _nl) === false && $vlen < 48) $field = "<input".($readonly ? ' readonly="readonly"' : '')." type='text' class='inputbig' name='$field_name' value='"._htmlStr($v)."' />";
        else  $field = "<textarea".($readonly ? ' readonly="readonly"' : '')." name='$field_name' rows='".(3 + substr_count($v, _nl) + intval($vlen / 90))."' cols='90'>"._htmlStr($v)."</textarea>";

        // entry
        $output .= "<tr>
<td><code>".(isset($parents) ? '['.implode(' &gt; ', $parents).']: ' : '')."$e</code></td>
<td>$field</td>
</tr>
";

    }
}

// formular
$output .= "<form action='$edit_url' method='post'>

<h2>Editing &quot;"._htmlStr($lang)."&quot;</h2><br />

<p><input type='submit' value='Save changes' /></p>

<table class='list'>
<tbody>
";

_plugin_lfe_entries($lang_data);


$output .= "</tbody>
</table>

</form>";
