<?php
/* ----- kontrola jadra ----- */

if(!defined('_core')) die;


/* ----- akce ----- */

// cara
$output .= '<div class="hr"><hr /></div>';

// formular
switch($action) {

    case 'uninstall':
        $output .= '<p>To uninstall this plugin, delete the following folders:</p>
<ul>
    <li><code>plugins/common/lfe/</code></li>
    <li><code>plugins/admin/lfe/</code></li>
</ul>
';
        break;

}
