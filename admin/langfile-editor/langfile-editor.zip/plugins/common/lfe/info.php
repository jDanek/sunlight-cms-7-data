<?php

return array(

    'name' => 'Langfile Editor',
    'descr' => 'Small tool used to edit language files',
    'version' => '1.0',
    'author' => 'ShiraNai7',
    'url' => 'http://sunlight.shira.cz/',
    'actions' => array('uninstall'),

);