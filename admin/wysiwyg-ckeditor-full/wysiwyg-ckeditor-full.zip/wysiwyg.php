<script type="text/javascript" src="modules/ckeditor/ckeditor.js"></script>
<script type="text/javascript">
/* <![CDATA[ */
$(document).ready(function(){
    CKEDITOR.config.baseHref = '<?php echo _url.'/'; ?>';
    CKEDITOR.config.defaultLanguage = 'en';
    CKEDITOR.config.height = 400;
    CKEDITOR.config.ignoreEmptyParagraph = true;
    CKEDITOR.config.entities = false;
    CKEDITOR.config.removePlugins = 'forms';
<?php if(_ajaxfm): ?>
    CKEDITOR.config.filebrowserBrowseUrl = 'modules/ajaxfm/ajaxfilemanager.php?editor=ckeditor';
<?php endif ?>
    $('.wysiwyg_editor').each(function(){
        CKEDITOR.replace(this);
    });
});
/* ]]> */
</script>