<?php
	/**
	 * language pack
	 * @author Logan Cai (cailongqun [at] yahoo [dot] com [dot] cn)
	 * @link www.phpletter.com
	 * @since 22/April/2007
	 *
	 */
	define('DATE_TIME_FORMAT', 'j.n.Y G:i');
	//Common
	//Menu
	
	
	
	
	define('MENU_SELECT', 'Vybrat');
	define('MENU_DOWNLOAD', 'Stáhnout');
	define('MENU_PREVIEW', 'Náhled');
	define('MENU_RENAME', 'Přejmenovat');
	define('MENU_EDIT', 'Upravit');
	define('MENU_CUT', 'Vyjmout');
	define('MENU_COPY', 'Kopírovat');
	define('MENU_DELETE', 'Smazat');
	define('MENU_PLAY', 'Přehrát');
	define('MENU_PASTE', 'Vložit');
	
	//Label
		//Top Action
		define('LBL_ACTION_REFRESH', 'Obnovit');
		define('LBL_ACTION_DELETE', 'Smazat');
		define('LBL_ACTION_CUT', 'Vyjmout');
		define('LBL_ACTION_COPY', 'Kopírovat');
		define('LBL_ACTION_PASTE', 'Vložit');
		define('LBL_ACTION_CLOSE', 'Zavřít');
		define('LBL_ACTION_SELECT_ALL', 'Vybrat vše');
		//File Listing
	define('LBL_NAME', 'Jméno');
	define('LBL_SIZE', 'Velikost');
	define('LBL_MODIFIED', 'Poslední změna');
		//File Information
	define('LBL_FILE_INFO', 'Informace o souboru:');
	define('LBL_FILE_NAME', 'Jméno:');
	define('LBL_FILE_CREATED', 'Vytvořen:');
	define('LBL_FILE_MODIFIED', 'Upraven:');
	define('LBL_FILE_SIZE', 'Velikost:');
	define('LBL_FILE_TYPE', 'Typ:');
	define('LBL_FILE_WRITABLE', 'Zápis');
	define('LBL_FILE_READABLE', 'Čtení');
		//Folder Information
	define('LBL_FOLDER_INFO', 'Informace o složce:');
	define('LBL_FOLDER_PATH', 'Složka:');
	define('LBL_CURRENT_FOLDER_PATH', 'Aktuální cesta:');
	define('LBL_FOLDER_CREATED', 'Vytvořena:');
	define('LBL_FOLDER_MODIFIED', 'Upravena:');
	define('LBL_FOLDER_SUDDIR', 'Podsložky:');
	define('LBL_FOLDER_FIELS', 'Soubory:');
	define('LBL_FOLDER_WRITABLE', 'Zápis');
	define('LBL_FOLDER_READABLE', 'Čtení');
	define('LBL_FOLDER_ROOT', 'hlavní složka');
		//Preview
	define('LBL_PREVIEW', 'Náhled');
	define('LBL_CLICK_PREVIEW', 'Klikntěte zde pro náhled.');
	//Buttons
	define('LBL_BTN_SELECT', 'Vybrat');
	define('LBL_BTN_CANCEL', 'Zrušit');
	define('LBL_BTN_UPLOAD', 'Nahrát');
	define('LBL_BTN_CREATE', 'Vytvořit');
	define('LBL_BTN_CLOSE', 'Zavřít');
	define('LBL_BTN_NEW_FOLDER', 'Nová složka');
	define('LBL_BTN_NEW_FILE', 'Nový soubor');
	define('LBL_BTN_EDIT_IMAGE', 'Upravit');
	define('LBL_BTN_VIEW', 'Zobrazení');
	define('LBL_BTN_VIEW_TEXT', 'Text');
	define('LBL_BTN_VIEW_DETAILS', 'Detaily');
	define('LBL_BTN_VIEW_THUMBNAIL', 'Miniatury');
	define('LBL_BTN_VIEW_OPTIONS', 'Zobrazit jako:');
	//pagination
	define('PAGINATION_NEXT', 'Další');
	define('PAGINATION_PREVIOUS', 'Předchozí');
	define('PAGINATION_LAST', 'Poslední');
	define('PAGINATION_FIRST', 'První');
	define('PAGINATION_ITEMS_PER_PAGE', 'Zobrazit %s položek na stránku');
	define('PAGINATION_GO_PARENT', 'Nadřazená složka');
	//System
	define('SYS_DISABLED', 'Přístup odepřen: systém je deaktivován.');
    define('SYS_NO_PATH', 'Nepodařilo se vytvořit uživatelský adresář.');
	
	//Cut
	define('ERR_NOT_DOC_SELECTED_FOR_CUT', 'Nebyly vybrány žádné dokumenty pro vyjmutí.');
	//Copy
	define('ERR_NOT_DOC_SELECTED_FOR_COPY', 'Nebyly vybrány žádné dokumenty pro kopírování.');
	//Paste
	define('ERR_NOT_DOC_SELECTED_FOR_PASTE', 'Nebyly vybrány žádné dokumenty pro vložení.');
	define('WARNING_CUT_PASTE', 'Opravdu chcete přesunout vybrané dokumenty do této složky?');
	define('WARNING_COPY_PASTE', 'Opravdu chcete zkopírovat vybrané dokumenty do této složky?');
	define('ERR_NOT_DEST_FOLDER_SPECIFIED', 'Neurčena cílová složka.');
	define('ERR_DEST_FOLDER_NOT_FOUND', 'Cílová složka nenalezena.');
	define('ERR_DEST_FOLDER_NOT_ALLOWED', 'Nemáte oprávnění přesunout soubory do této složky.');
	define('ERR_UNABLE_TO_MOVE_TO_SAME_DEST', 'Nepodařilo se přesunout soubor (%s): cesta je stejná.');
	define('ERR_UNABLE_TO_MOVE_NOT_FOUND', 'Nepodařilo se přesunout soubor (%s): soubor neexistuje.');
	define('ERR_UNABLE_TO_MOVE_NOT_ALLOWED', 'Nepodařilo se přesunout soubor (%s): přístup odepřen.');
 
	define('ERR_NOT_FILES_PASTED', 'Žádné soubory nebyly vloženy.');

	//Search
	define('LBL_SEARCH', 'Vyhledávání');
	define('LBL_SEARCH_NAME', 'Jméno souboru:');
	define('LBL_SEARCH_FOLDER', 'Prohledat:');
	define('LBL_SEARCH_QUICK', 'Ryhlé hledání');
	define('LBL_SEARCH_MTIME', 'Soubor změněn:');
	define('LBL_SEARCH_SIZE', 'Velikost:');
	define('LBL_SEARCH_ADV_OPTIONS', 'Další možnosti');
	define('LBL_SEARCH_FILE_TYPES', 'Typy souborů:');
	
	define('SEARCH_TYPE_EXE', 'Aplikace');
	define('SEARCH_TYPE_IMG', 'Obrázek');
	define('SEARCH_TYPE_ARCHIVE', 'Archív');
	define('SEARCH_TYPE_HTML', 'HTML');
	define('SEARCH_TYPE_VIDEO', 'Video');
	define('SEARCH_TYPE_MOVIE', 'Film');
	define('SEARCH_TYPE_MUSIC', 'Hudba');
	define('SEARCH_TYPE_FLASH', 'Flash');
	define('SEARCH_TYPE_PPT', 'PowerPoint');
	define('SEARCH_TYPE_DOC', 'Dokument');
	define('SEARCH_TYPE_WORD', 'Word');
	define('SEARCH_TYPE_PDF', 'PDF');
	define('SEARCH_TYPE_EXCEL', 'Excel');
	define('SEARCH_TYPE_TEXT', 'Text');
	define('SEARCH_TYPE_UNKNOWN', 'Neznámý');
	define('SEARCH_TYPE_XML', 'XML');
	define('SEARCH_ALL_FILE_TYPES', 'Všechny druhy');
	define('LBL_SEARCH_RECURSIVELY', 'Hledat rekurzivně:');
	define('LBL_RECURSIVELY_YES', 'Ano');
	define('LBL_RECURSIVELY_NO', 'Ne');
	define('BTN_SEARCH', 'Vyhledat');
	//thickbox
	define('THICKBOX_NEXT', 'Další&gt;');
	define('THICKBOX_PREVIOUS', '&lt;Předchozí');
	define('THICKBOX_CLOSE', 'Zavřít');
	//Calendar
	define('CALENDAR_CLOSE', 'Zavřít');
	define('CALENDAR_CLEAR', 'Reset');
	define('CALENDAR_PREVIOUS', '&lt;Zpět');
	define('CALENDAR_NEXT', 'Vpřed&gt;');
	define('CALENDAR_CURRENT', 'Dnes');
	define('CALENDAR_MON', 'Po');
	define('CALENDAR_TUE', 'Út');
	define('CALENDAR_WED', 'St');
	define('CALENDAR_THU', 'Čt');
	define('CALENDAR_FRI', 'Pá');
	define('CALENDAR_SAT', 'So');
	define('CALENDAR_SUN', 'Ne');
	define('CALENDAR_JAN', 'Led');
	define('CALENDAR_FEB', 'Úno');
	define('CALENDAR_MAR', 'Bře');
	define('CALENDAR_APR', 'Dub');
	define('CALENDAR_MAY', 'Kvě');
	define('CALENDAR_JUN', 'Čer');
	define('CALENDAR_JUL', 'Črv');
	define('CALENDAR_AUG', 'Srp');
	define('CALENDAR_SEP', 'Zář');
	define('CALENDAR_OCT', 'Říj');
	define('CALENDAR_NOV', 'Lis');
	define('CALENDAR_DEC', 'Pro');
	//ERROR MESSAGES
		//deletion
	define('ERR_NOT_FILE_SELECTED', 'Zvolte soubor.');
	define('ERR_NOT_DOC_SELECTED', 'Žádný dokument nebyl zvolen pro smazání.');
	define('ERR_DELTED_FAILED', 'Nepodařilo se smazat zvolené dokumenty.');
	define('ERR_FOLDER_PATH_NOT_ALLOWED', 'Nepovolená cesta.');
		//class manager
	define('ERR_FOLDER_NOT_FOUND', 'Nepodařilo se lokalizovat složku: ');
		//rename
	define('ERR_RENAME_FORMAT', 'Prosím zadejte jméno obsahující pouze písmena, čísla, mezeru, podtržítko nebo pomlčku.');
	define('ERR_RENAME_EXISTS', 'Dokument s tímto jménem již existuje.');
	define('ERR_RENAME_FILE_NOT_EXISTS', 'Soubor/složka neexistuje.');
	define('ERR_RENAME_FAILED', 'Přejmenování se nezdařilo, zkuste to znovu.');
	define('ERR_RENAME_EMPTY', 'Prosím zadejte jméno.');
	define('ERR_NO_CHANGES_MADE', 'Nebyly provedeny žádné změny.');
	define('ERR_RENAME_FILE_TYPE_NOT_PERMITED', 'Nemáte oprávnění přejmenovat soubor na tento typ.');
		//folder creation
	define('ERR_FOLDER_FORMAT', 'Prosím zadejte jméno obsahující pouze písmena, čísla, mezeru, podtržítko nebo pomlčku.');
	define('ERR_FOLDER_EXISTS', 'Složka s tímto jménem již existuje.');
	define('ERR_FOLDER_CREATION_FAILED', 'Nepodařilo se vytvořit složku, zkuste to znovu.');
	define('ERR_FOLDER_NAME_EMPTY', 'Prosím zadejte jméno.');
	define('FOLDER_FORM_TITLE', 'Nová složka');
	define('FOLDER_LBL_TITLE', 'Jméno složky:');
	define('FOLDER_LBL_CREATE', 'Vytvořit');
	//New File
	define('NEW_FILE_FORM_TITLE', 'Nový soubor');
	define('NEW_FILE_LBL_TITLE', 'Jméno souboru:');
	define('NEW_FILE_CREATE', 'Vytvořit');
		//file upload
	define('ERR_FILE_NAME_FORMAT', 'Prosím použijte soubor se jménem obsahující pouze písmena, čísla, mezeru, podtržítko nebo pomlčku.');
	define('ERR_FILE_NOT_UPLOADED', 'Žádný soubor nebyl zvolen pro nahrání.');
	define('ERR_FILE_TYPE_NOT_ALLOWED', 'Nemáte oprávnění nahrát tento typ souboru.');
	define('ERR_FILE_MOVE_FAILED', 'Nepodařilo se přesunout soubor.');
	define('ERR_FILE_NOT_AVAILABLE', 'Soubor není dostupný.');
	define('ERROR_FILE_TOO_BID', 'Soubor je příliš velký. (max: %s)');
	define('FILE_FORM_TITLE', 'Nahrát soubor');
	define('FILE_LABEL_SELECT', 'Zvolte soubor');
	define('FILE_LBL_MORE', 'Více');
	define('FILE_CANCEL_UPLOAD', 'Zrušit');
	define('FILE_LBL_UPLOAD', 'Nahrát');
	//file download
	define('ERR_DOWNLOAD_FILE_NOT_FOUND', 'Žádné soubory nebyly zvoleny pro nahrání.');
	//Rename
	define('RENAME_FORM_TITLE', 'Přejmenovat');
	define('RENAME_NEW_NAME', 'Nové jméno');
	define('RENAME_LBL_RENAME', 'Přejmenovat');

	//Tips
	define('TIP_FOLDER_GO_DOWN', 'Klikněte pro vstup do této složky');
	define('TIP_DOC_RENAME', 'Dvakrát klikněte pro změnu');
	define('TIP_FOLDER_GO_UP', 'Klikněte pro vstup do nadřazené složky');
	define('TIP_SELECT_ALL', 'Vybrat vše');
	define('TIP_UNSELECT_ALL', 'Žrušit výběr');
	//WARNING
	define('WARNING_DELETE', 'Opravdu chcete smazat zvolené soubory?');
	define('WARNING_IMAGE_EDIT', 'Zvolte obrázek pro úpravu.');
	define('WARNING_NOT_FILE_EDIT', 'Zvolte soubor pro úpravu.');
	define('WARING_WINDOW_CLOSE', 'Opravdu chcete zavřít okno?');
	//Preview
	define('PREVIEW_NOT_PREVIEW', 'Náhled nedostupný.');
	define('PREVIEW_OPEN_FAILED', 'Nepodařilo se otevřít soubor.');
	define('PREVIEW_IMAGE_LOAD_FAILED', 'Nepodařilo se načíst obrázek');

	//Login
	define('LOGIN_PAGE_TITLE', 'Ajax File Manager - přihlášení');
	define('LOGIN_FORM_TITLE', 'Přihlášení');
	define('LOGIN_USERNAME', 'Jméno:');
	define('LOGIN_PASSWORD', 'Heslo:');
	define('LOGIN_FAILED', 'Neplatné jméno či heslo.');
    define('LOGIN_DENIED', 'Nemáte potřebné oprávnění používat souborový manažer.');
	
	
	//88888888888   Below for Image Editor   888888888888888888888
		//Warning 
		define('IMG_WARNING_NO_CHANGE_BEFORE_SAVE', 'Neprovedli jste žádné změny.');
		
		//General
		define('IMG_GEN_IMG_NOT_EXISTS', 'Obrázek neexistuje');
		define('IMG_WARNING_LOST_CHANAGES', 'Všechny provedené změny budou ztraceny, pokračovat?');
		define('IMG_WARNING_REST', 'Všechny provedené změny budou ztraceny, opravdu chcete resetovat?');
		define('IMG_WARNING_EMPTY_RESET', 'Nebyly provedeny žádné změny');
		define('IMG_WARING_WIN_CLOSE', 'Opravdu chcete zavřít okno?');
		define('IMG_WARNING_UNDO', 'Opravdu chcete obnovit obrázek do předchozího stavu?');
		define('IMG_WARING_FLIP_H', 'Opravdu chcete obrázek obrátit horizontálně?');
		define('IMG_WARING_FLIP_V', 'Opravdu chcete obrázek obrátit vertikálně?');
		define('IMG_INFO', 'Informace o obrázku');
		
		//Mode
			define('IMG_MODE_RESIZE', 'Změnit velikost:');
			define('IMG_MODE_CROP', 'Oříznout:');
			define('IMG_MODE_ROTATE', 'Otočit:');
			define('IMG_MODE_FLIP', 'Převrátit:');
		//Button
		
			define('IMG_BTN_ROTATE_LEFT', '90&deg; &larr;');
			define('IMG_BTN_ROTATE_RIGHT', '90&deg; &rarr;');
			define('IMG_BTN_FLIP_H', 'Převrátit vodorovně');
			define('IMG_BTN_FLIP_V', 'Převrátit vertikálně');
			define('IMG_BTN_RESET', 'Reset');
			define('IMG_BTN_UNDO', 'Zpět');
			define('IMG_BTN_SAVE', 'Uložit');
			define('IMG_BTN_CLOSE', 'Zavřít');
			define('IMG_BTN_SAVE_AS', 'Uložit jako');
			define('IMG_BTN_CANCEL', 'Zrušit');
		//Checkbox
			define('IMG_CHECKBOX_CONSTRAINT', 'Zachovat poměr?');
		//Label
			define('IMG_LBL_WIDTH', 'Šířka:');
			define('IMG_LBL_HEIGHT', 'Výška:');
			define('IMG_LBL_X', 'X:');
			define('IMG_LBL_Y', 'Y:');
			define('IMG_LBL_RATIO', 'Poměr:');
			define('IMG_LBL_ANGLE', 'Úhel:');
			define('IMG_LBL_NEW_NAME', 'Nové jméno:');
			define('IMG_LBL_SAVE_AS', 'Uložit jako');
			define('IMG_LBL_SAVE_TO', 'Uložit do:');
			define('IMG_LBL_ROOT_FOLDER', 'Hlavní složka');
		//Editor
		//Save as 
		define('IMG_NEW_NAME_COMMENTS', 'Nezadávejte příponu.');
		define('IMG_SAVE_AS_ERR_NAME_INVALID', 'Prosím zadejte jméno obsahující pouze písmena, čísla, mezeru, podtržítko nebo pomlčku.');
		define('IMG_SAVE_AS_NOT_FOLDER_SELECTED', 'Cílová složka nezvolena.');
		define('IMG_SAVE_AS_FOLDER_NOT_FOUND', 'Čílová složka neexistuje.');
		define('IMG_SAVE_AS_NEW_IMAGE_EXISTS', 'Obrázek s tímto jménem již existuje.');

		//Save
		define('IMG_SAVE_EMPTY_PATH', 'Cesta k obrázku je prázdná.');
		define('IMG_SAVE_NOT_EXISTS', 'Obrázek neexistuje.');
		define('IMG_SAVE_PATH_DISALLOWED', 'Nemáte přístup k tomuto souboru.');
		define('IMG_SAVE_UNKNOWN_MODE', 'Neočekávaný mód operace s obrázkem.');
		define('IMG_SAVE_RESIZE_FAILED', 'Nepodařilo se změnit velikost obrázku.');
		define('IMG_SAVE_CROP_FAILED', 'Nepodařilo se ořezat obrázek.');
		define('IMG_SAVE_FAILED', 'Nepodařilos se uložit obrázek.');
		define('IMG_SAVE_BACKUP_FAILED', 'Nepodařilo se zálohovat originální obrázek.');
		define('IMG_SAVE_ROTATE_FAILED', 'Nepodařilo se otočit obrázek.');
		define('IMG_SAVE_FLIP_FAILED', 'Nepodařilo se převrátit obrázek.');
		define('IMG_SAVE_SESSION_IMG_OPEN_FAILED', 'Nepodařilo se otevřít obrázek z session.');
		define('IMG_SAVE_IMG_OPEN_FAILED', 'Nepodařilo se otevřít obrázek');
		
		
		//UNDO
		define('IMG_UNDO_NO_HISTORY_AVAIALBE', 'Nejsou kroky zpět.');
		define('IMG_UNDO_COPY_FAILED', 'Nepodařilo se obnovit obrázek.');
		define('IMG_UNDO_DEL_FAILED', 'Nepodařilo se odstranit obrázek ze session.');
	
	//88888888888   Above for Image Editor   888888888888888888888
	
	//88888888888   Session   888888888888888888888
		define('SESSION_PERSONAL_DIR_NOT_FOUND', 'Dedikovaná složka nenalezena.');
		define('SESSION_COUNTER_FILE_CREATE_FAILED', 'Nepodařilo se otevřít session čítač.');
		define('SESSION_COUNTER_FILE_WRITE_FAILED', 'Nepodařilo se zapsat do session čítače.');
	//88888888888   Session   888888888888888888888
	
	//88888888888   Below for Text Editor   888888888888888888888
		define('TXT_FILE_NOT_FOUND', 'Soubor nenalezen.');
		define('TXT_EXT_NOT_SELECTED', 'Prosím zvolte příponu');
		define('TXT_DEST_FOLDER_NOT_SELECTED', 'Prosím zvolte cílovou složku');
		define('TXT_UNKNOWN_REQUEST', 'Neznámy požadavek.');
		define('TXT_DISALLOWED_EXT', 'Nemáte oprávnění pracovat s tímto druhem souboru.');
		define('TXT_FILE_EXIST', 'Soubor s tímto jménem již existuje.');
		define('TXT_FILE_NOT_EXIST', 'Takový soubor neexistuje.');
		define('TXT_CREATE_FAILED', 'Nepodařilos se vytvořit nový soubor.');
		define('TXT_CONTENT_WRITE_FAILED', 'Nepodařilo se zapsat obsah do souboru.');
		define('TXT_FILE_OPEN_FAILED', 'Nepodařilo se otevřít soubor');
		define('TXT_CONTENT_UPDATE_FAILED', 'Nepodařilo se aktualizovat obsah souboru.');
		define('TXT_SAVE_AS_ERR_NAME_INVALID', 'Prosím zadejte jméno obsahující pouze písmena, čísla, mezeru, podtržítko nebo pomlčku.');
	//88888888888   Above for Text Editor   888888888888888888888
	
	
?>