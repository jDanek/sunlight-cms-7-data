<pre>Array
(
    [currentFolderPath] => ../../../../files/portal/uploaded/wales/
    [new_folder] => dokumenty
)
</pre>

28/Aug/2010 16:35:30