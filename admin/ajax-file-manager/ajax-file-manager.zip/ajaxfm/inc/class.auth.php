<?php
/**
 * the purpose I added this class is to make the file system much flexible
 * for customization.
 * Actually,  this is a kind of interface and you should modify it to fit your system
 * @author Logan Cai (cailongqun [at] yahoo [dot] com [dot] cn)
 * @link www.phpletter.com
 * @since 4/August/2007
 */
class Auth
{

    public $FormEnabled = false;
    private $Access = false;

    public function __construct()
    {

        // set access
        $this->Access = (_loginindicator && _loginright_administration && _loginright_adminfman);

        // define path
        $defdir_subpath = _loginname."/";
        _extend('call', 'admin.fman.userdir', array('subpath' => &$defdir_subpath));
        $xPath = _upload_dir.(_loginright_adminfmanlimit ? $defdir_subpath : '');
        if(!file_exists($xPath)) if(!@mkdir($xPath, 0775, true)) die(SYS_NO_PATH);
        define('CONFIG_SYS_DEFAULT_PATH', $xPath); //accept relative path only
        define('CONFIG_SYS_ROOT_PATH', ((!_loginright_adminfmanplus || _loginright_adminfmanlimit) ? CONFIG_SYS_DEFAULT_PATH : _indexroot)); //accept relative path only

    }

    function Auth()
    {
        $this->__construct();
    }

    /**
     * check if the user has logged
     * @return boolean
     */
    function isLoggedIn()
    {
        return $this->Access;
    }

    /**
     * validate the username & password
     * @return boolean
     *
     */
    function login()
    {
        return false;
    }
}

?>