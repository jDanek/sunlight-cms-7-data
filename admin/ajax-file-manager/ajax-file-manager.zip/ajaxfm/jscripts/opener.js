function k_ajaxfm(inputid, callback)
{
    var ajaxfm_url = "/framework/fc/_res/ajaxfm/ajaxfilemanager.php?editor=stand_alone";
    var ajaxfm_win;
    ajaxfm_win = window.open(ajaxfm_url, 'ajaxfm', 'toolbar=no,location=no,directories=no,menubar=no,width=980,height=480');
    ajaxfm_win.focus();
    window.ajaxfm_inputid = inputid;
    window.ajaxfm_callback = callback;
}

function k_ajaxfm_select(url)
{
    if(typeof window.ajaxfm_inputid != 'undefined') {
        // process url
        if(url.substring(0, k.url.length) == k.url) {
            url = url.substring(k.url.length);
        }
        
        // extra callback
        if(window.ajaxfm_callback != null) {
            url = window.ajaxfm_callback(url);
        }
        
        // set input value
        jQuery('#'+window.ajaxfm_inputid).attr('value', url);
    }
}