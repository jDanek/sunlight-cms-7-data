
function selectFile(url)
{

    // determine ckeditor function number
    var fnum = (function(paramName){
        var reParam = new RegExp('(?:[\?&]|&amp;)' + paramName + '=([^&]+)', 'i') ;
        var match = window.location.search.match(reParam) ;
        return (match && match.length > 1) ? match[1] : '' ;
    })('CKEditorFuncNum');
    
    // fix url
    url = _fix_file_url(url);
    
    // call and close
    window.opener.CKEDITOR.tools.callFunction(fnum, url);
    window.close() ;

}



function cancelSelectFile()
{
  // close popup window
  window.close() ;
}