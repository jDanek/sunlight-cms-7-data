function selectFile(url)
{
    // no action
    window.close() ;
}

function cancelSelectFile()
{
    // close popup window
    window.close();
}