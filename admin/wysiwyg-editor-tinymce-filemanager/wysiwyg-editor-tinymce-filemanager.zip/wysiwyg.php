<script language="javascript" type="text/javascript" src="modules/tinymce/tinymce.min.js"></script>
<script type="text/javascript">
	/* <![CDATA[ */
	$(document).ready(function () {

		tinyMCE.init({

			// General options
			document_base_url: '<?php echo _url; ?>',
            relative_urls : false,
            remove_script_host : true,
			selector: ".wysiwyg_editor",
			language: "cs",
			plugins: [
				"advlist autolink lists link image charmap preview hr anchor pagebreak",
				"searchreplace wordcount visualblocks visualchars code fullscreen",
				"insertdatetime media nonbreaking save table contextmenu directionality",
				"emoticons template paste textcolor responsivefilemanager"
			],
			/*content_css: "<?php echo _indexroot . 'plugins/templates/' . _template . '/style/' ?>classes.css",*/
			style_formats: [
				{
					title: 'Headers', items: [
					{title: 'Header 1', block: 'h1'},
					{title: 'Header 2', block: 'h2'},
					{title: 'Header 3', block: 'h3'},
					{title: 'Header 4', block: 'h4'},
					{title: 'Header 5', block: 'h5'},
					{title: 'Header 6', block: 'h6'}
				]
				},
				{
					title: 'Blocks', items: [
					{title: 'Paragraph', block: 'p'},
					{title: 'Blockquote', block: 'blockquote'},
					{title: 'Div', block: 'div'},
					{title: 'Pre', block: 'pre'}
				]
				},
				{
					title: 'Arena', items: [
					{title: 'Modrá', inline: 'span', classes: 'blue_text'},
				]
				}
			],
			toolbar1: "insertfile undo redo  preview | styleselect fontselect fontsizeselect | bold italic underline strikethrough superscript subscript code",
			toolbar2: "link image media<?php echo (_ajaxfm ? ' responsivefilemanager':''); ?> | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | forecolor backcolor emoticons",
			image_advtab: true,
			entity_encoding: "raw",
			rel_list: [
				{title: 'Zvětšovací okno', value: 'external'}
			],
			/*link_list: '../linklist.php',*/
			<?php if(_ajaxfm): ?>
			external_filemanager_path: "<?php echo _url; ?>/admin/modules/filemanager/",
			filemanager_title: "Responsive Filemanager",
			external_plugins: {"filemanager": "<?php echo _url; ?>/admin/modules/filemanager/plugin.min.js"},
			filemanager_access_key: "sunlight",
			<?php endif ?>
		});
	});
	/* ]]> */
</script>