=== Slovenstina ===
Verze: 	--
Autor: 	Aletic
Web: 	---

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Slovensky preklad systemu

== Instalace ==
	Nahrajte obsah slozky zip do rootu webu
	
== Pouziti ==
	Zmenu jazyka provedete v nastaveni systemu
	
== Odinstalace ==
	odstrante nasledujici soubor ze serveru:
		plugins/languages/slovak.php

== Changelog ==
