=== JV Article Nav ===
Verze 1.1
Autor: 	Jan Valent�k
Web: 	http://valentik.cz/

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Pridava k clankum odkazy pro prechod (predchozi/dalsi) mezi clanky stejne kategorie

== Instalace ==
	Nahrajte obsah adresare do korenoveho adresare

	v souboru layout.css u sv�ho motivu m��ete p�estylovat odkazy pomoc�
	#jv_article_nav{}
	#jv_article_nav .prev_article{}
	#jv_article_nav .next_article{}

== Odinstalace ==
	odstrante nasledujici adresare ze serveru:
		plugins/extend/jv_article_nav

== Changelog ==
Verze 1.1
[update] plugin upraven pro SL 7.5.4