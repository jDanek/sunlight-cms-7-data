<?php

/*
  Plugin: Article navigation
  Autor: Jan Valentík
  Web: http://valentik.cz
  Popis:
  Rozšíření automaticky vytvoří odkazy na předchozí a další článek.
 */

/* --- kontrola jadra --- */
if (!defined('_core'))
    die;

function _plugin_jv_article_nav($args) {
    if ($args['extra']['query']['home2'] < 0 and $args['extra']['query']['home3'] < 0) {
	$lang = array(//
	    'en' => array(
		'prev_article' => 'Previous article',
		'next_article' => 'Next article',
	    ), //
	    'cs' => array(
		'prev_article' => 'Předchozí článek',
		'next_article' => 'Další článek',
	    ), //
	);
	$lid = _getLang($lang);
	$category = DB::row(DB::query('SELECT var1 FROM `' . _mysql_prefix . '-root` WHERE id=' . $args['extra']['query']['home1']));
	switch ($category['var1']) {
	    case 1:
		$links= array('next','prev');
		$cond = 'time';
		break;
	    case 2:
		$links= array('next','prev');
		$cond = 'id';
		break;
	    case 3:
		$links= array('prev','next');
		$cond = 'title';
		break;
	    case 4:
		$links= array('next','prev');
		$cond = 'title';
		break;
	}
	$articles = array();
	$sql = "(SELECT 0 AS art_type, art.title, art.id, art.title_seo
				FROM `" . _mysql_prefix . "-articles` art
				WHERE art.id!=" . $args['extra']['query']['id'] . "
				    AND art.home1=".$args['extra']['query']['home1']."
				    AND art.`" . $cond . "`<'" . $args['extra']['query'][$cond] . "'
				    AND ".  _sqlArticleFilter()."
				ORDER BY art." . $cond . " DESC LIMIT 1)
			   UNION ALL
				(SELECT 1 AS art_type, art.title, art.id, art.title_seo
				FROM `" . _mysql_prefix . "-articles` art
				WHERE art.id!=" . $args['extra']['query']['id'] . "
				    AND art.home1=".$args['extra']['query']['home1']."
				    AND art.`" . $cond . "`>'" . $args['extra']['query'][$cond] . "'
				    AND ".  _sqlArticleFilter()."
				ORDER BY art." . $cond . " ASC LIMIT 1)";
	$arts = DB::query($sql);
	$args['output'] .='<div id="jv_article_nav">';
	while ($art = DB::row($arts)) {
	    $type = ($art['art_type'] == 0 ? $links[0] : $links[1]);
	    $args['output'] .= '<a title="' . $art['title'] . '" class="' . $type . '_article" href="' . _linkArticle($art['id'], $art['title_seo'], $args['extra']['query']['cat_title_seo']) . '">' . $lang[$lid][$type . '_article'] . '</a>';
	}
	$args['output'] .='</div>';
    }
}

function _plugin_jv_article_nav_css($args) {
    $args['output'] .= "<link rel=\"stylesheet\" href=\"" . _indexroot . "plugins/extend/jv_article_nav/jv_article_nav.css\" type=\"text/css\" media=\"screen\" />";
}

/* ---- registrace pluginu ---- */
_extend('reg', 'article.comments', '_plugin_jv_article_nav');
_extend('reg', 'tpl.head', '_plugin_jv_article_nav_css');
?>