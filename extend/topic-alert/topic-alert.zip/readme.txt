=== AlertAnswer ===
Verze 1.1
Autor: 	Petr Vostr�
Web: 	http://wall.cz/

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Pokud na Vasi zpravu nekdo odpovi, prijde Vam email. Nastaveni v administraci.

== Instalace ==
	Nahrajte obsah adresare do korenoveho adresare

== Odinstalace ==
	odstrante nasledujici adresare ze serveru:
		plugins/extend/alertanswer
		plugins/common/alertanswer

== Changelog ==
Verze 1.1
[update] plugin upraven pro SL 7.5.4