<?php

return array(

    'name' => 'Alert Answer',
    'descr' => 'Automatické zasílání upozornění na odpovědi ve fóru.',
    'version' => '1.1',
    'author' => 'petvo',
    'url' => 'http://wall.cz/',
    'actions' => array('config', 'uninstall'),

);