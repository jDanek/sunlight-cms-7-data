<?php
/* ----- kontrola jadra ----- */

if(!defined('_core')) die;


/* ----- lokalizace ----- */

$lang = array( //
    'title'=>'Hlavní možnosti',
    'show' => 'Rozesílání upozornění',
    'uninstall' => 'Pro odinstalování pluginu smažte následující adresáře',
    'desc'=>'povolit zasílání upozornění na odpovědi',
    );

/* ----- akce ----- */

// cara
$output .= '<div class="hr"><hr /></div>';

// formular
switch($action) {

    case 'config':

        // nacteni konfigurace
        $cfg = _pluginLoadConfig($plugin);

        // ulozeni
        if(isset($_POST['save'])) {

            // nacist
            $cfg['show'] = _checkboxLoad('show');

            // zpracovat
            if($cfg['show'] === '') $cfg['show'] = null;

            // ulozit
            if(_pluginSaveConfig($plugin, $cfg) !== false) $output .= _formMessage(1, $_lang['global.saved']);
            else  $output .= _formMessage(2, $_lang['global.error']);

        }

        // formular
        $output .= '
<fieldset id="settingsform">
<legend>'.$lang['title'].'</legend>
<form action="'.$url.'" method="post">
<table class="form">

<tr>
    <td><strong>'.$lang['show'].'</strong></td>
    <td><input type="checkbox" name="show" value="1"'._checkboxActivate($cfg['show']).' /></td>
    <td class="rpad">'.$lang['desc'].'</td>
</tr>

<tr>
    <td colspan="3"><input type="submit" name="save" value="'.$_lang['global.save'].'" /></td>
</tr>

</table>
'._xsrfProtect().'
</form>
</fieldset>
';
        break;


    case 'uninstall':
        $output .= '<p>'.$lang['uninstall'].':</p>
<ul>
    <li><code>plugins/common/alertanswer/</code></li>
    <li><code>plugins/extend/alertanswer/</code></li>
</ul>
';
        break;

}
