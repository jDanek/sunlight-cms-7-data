<?php

/* ----  kontrola jadra  ---- */

if (!defined('_core'))
    die;


/* ---- funkce pluginu ---- */

/*
  POST.PHP
  _extend('call', 'posts.submit',
  array('allow' => &$allow,
  'posttype' => $posttype,
  'posttarget' => $posttarget,
  'xhome' => $xhome,
  'subject' => &$subject,
  'text' => &$text,
  'author' => $author,
  'guest' => $guest));
 */

function _plugin_alertanswer_submit($args) {

    $config = require _plugin_dir . 'alertanswer/config.php';
    if ($config['show'] == 1) {

        $args['allow'] = true; //false = nelze uložit 
        //získání id autora domovského příspěvku
        
        $data=DB::query_row("SELECT p.id AS p_id, p.author AS p_author, p.subject AS p_subject,
            u.username, u.email, u.massemail,
            a.id AS a_id, a.title_seo AS a_title_seo, a.home1 AS a_home1,
            r.title_seo AS r_title_seo
                FROM `" . _mysql_prefix . "-posts` p
                LEFT JOIN `" . _mysql_prefix . "-users` u ON (u.id=p.author)
                LEFT JOIN `" . _mysql_prefix . "-articles` a ON (a.id=".$args['posttarget'].")
                LEFT JOIN `" . _mysql_prefix . "-root` r ON (r.id=a.home1)
                WHERE p.id=". intval($args['xhome']));
                
        if (
                ($args['posttype'] == 5 || $args['posttype'] == 2) 
                && $args['xhome'] != -1 
                && $data['author'] != -1 
                && $data['author'] != $args['author'] 
                && $data['massemail'] == 1
           ){

                        
            if ($args['posttype'] == 5) {
                $url = _url . "/index.php?m=topic&id=" . $args['xhome'];
            } // _indexOutput_url;
            if ($args['posttype'] == 2) {
                $url = _url . "/" . _linkArticle($data['a_id'], $data['a_title_seo'],$data['r_title_seo']);
            }
            $receiver = $data['email'];
            $sender = _sysmail;
            $subject = "Upozornění na odpověď v tématu na " . _title;
            $vzkaz = $_POST['text'];

            //odesilatel
            $headers = "From: " . _title . " <" . $sender . ">\n";
            $headers.='MIME-Version: 1.0' . "\r\n";
            $headers.='Content-type: text/html; charset=utf-8' . "\r\n";

            $body = "<html><head>
          <meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
          <title>Upozornění na odpověď v tématu</title>
          </head>  
          <style>
          a {color: #65A602;}
          a:hover {text-decoration: none;}
          </style>             
          <body style=\"font-family: Tahoma, Arial; font-size:12px; background: #FFF; color: #000; line-height: 1.35em;\">
          <p>Dobrý den uživateli <em>" . $data['username'] . "</em>,<br>ve Vašem tématu <span style=\"font-weight: bold; color: #333\">\"" . $data['p_subject'] . "\"</span> byla zaznamenána odpověď. Kliknutím na níže uvedený odkaz budete přesměrováni do Vašeho tématu.</p>
          <p>Adresa příspěvku: <a href=\"" . $url . "\">" . $url . "</a></p>         
          <p style=\"color: #666; border-top: 1px solid #888; padding:10px 0 0; margin:0 0 1em\">Pokud již nechcete dostávat upozornění, můžete jej vypnout v 'Nastavení' - 'Informační e-maily'.<br>
          (Upozornění bylo odesláno: " . _formatTime(time()) . ")</p>
          </body>    
          </html>";

            // odeslani
            if (_mail($receiver, $subject, $body, $headers)) {
                //$args['text'] .= '<br /><span class="post-postlink">E-mail úspěšne odeslán na '.$receiver.'.</span>';
            } else {
                //$args['text'] .= '<br /><span class="post-postlink">E-mail neodeslán.</span>';
            }
        }

        //tento text je přidán do příspěvku a uložen
        //$args['text'] = $args['text'].'<br />autor: '.$data['author'].'<br />guest: '.$args['guest'].'<br />xhome: '.$args['xhome'].'<br />subject: '.$args['p_subject'].'<br />posttarget: '.$args['posttarget'].'<br />'; 
    } else {
        //nic
    }
}

/*
  FUNCTIONS-POSTS.PHP
  _extend('call', 'posts.post',
  array('item' => &$item, 'avatar' => &$avatar, 'type' => $type));
 */

function _plugin_alertanswer_add($args) {

    //přidá text do všech příspěvků (odpovědí), text není uložen 
    $args['item']['text'] .= '<br /><span class="post-postlink">REKLAMA.</span>';
}

/* ---- registrace pluginu ---- */

_extend('reg', 'posts.submit', '_plugin_alertanswer_submit');
//_extend('reg', 'posts.post', '_plugin_alertanswer_add');