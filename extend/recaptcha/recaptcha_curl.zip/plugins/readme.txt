=== ReCaptcha ===
Verze 1.3
Autor: 	Jirka Dan�k
Web: 	http://jdanek.eu/

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Ochrana formul��� ReCaptchou od Google
	Vy�aduje vygenerov�n� specifick�ch API kl��� => https://www.google.com/recaptcha

== Instalace ==
	Nahrajte obsah adresare do korenoveho adresare


== Odinstalace ==
	odstrante nasledujici adresare ze serveru:
		plugins/extend/recaptcha
		plugins/common/recaptcha

== Changelog ==
1.3 Nahrazeni adresy hosta google.com za recaptcha.net (Cookies 2022)
1.2 Oprava funkcnosti pro vypnutou direktivu 'allow_url_fopen'
1.1 Oprava popisu global.check => captcha.input