<?php return array(
    'sitekey' => NULL,
    'secret'  => NULL,
);