<?php

/* ----- kontrola jadra ----- */

if (!defined('_core')) die;

/* ----- akce ----- */

switch ($action)
{

    case 'config':

        // nacteni konfigurace
        $cfg = _pluginLoadConfig($plugin);

        // ulozeni
        if (isset($_POST['save']))
        {

            // nacist
            $cfg['sitekey'] = _post('sitekey');
            $cfg['secret'] = _post('secret');

            // zpracovat
            if ($cfg['sitekey'] === '')
                $cfg['sitekey'] = null;

            if ($cfg['secret'] === '')
                $cfg['secret'] = null;

            // ulozit
            if (_pluginSaveConfig($plugin, $cfg) !== false)
                $output .= _formMessage(1, $_lang['global.saved']);
            else
                $output .= _formMessage(2, $_lang['global.error']);
        }


        // formular
        $output .= "<p class='bborder'>Potřebné API klíče získáte na webu <a href='https://www.google.com/recaptcha' target='_blank'>https://www.google.com/recaptcha</a></p>
<form action='" . $url . "' method='post'>
<table class='form'>
<tr>
  <td class='rpad'><strong>SiteKey</strong></td>
  <td><input type='text' name='sitekey' "._restorePostValue('sitekey',$cfg['sitekey'],false)." class='inputbig' /></td>
</tr>

<tr>
  <td class='rpad'><strong>Secret</strong></td>
  <td><input type='text' name='secret' "._restorePostValue('secret',$cfg['secret'],false)." class='inputbig' /></td>
</tr>

</table>
" . _xsrfProtect() . "
<input type='submit' name='save' value='" . $_lang['global.save'] . "' />
</form>";

        break;


    case 'uninstall':
        $output .= "<p>Pro odinstalování pluginu smažte následující adresáře:</p>
<ul>
    <li><code>root/plugins/common/recaptcha/</code></li>
    <li><code>root/plugins/extend/recaptcha/</code></li>
</ul>";

}