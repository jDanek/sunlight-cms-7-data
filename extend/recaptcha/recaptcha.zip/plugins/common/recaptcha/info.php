<?php

return array(
    'name' => 'ReCaptcha',
    'descr' => 'ReCaptcha pro ochranu Vašich formulářů',
    'version' => '1.0',
    'author' => 'Jirka Daněk',
    'url' => 'http://jdanek.eu/',
    'actions' => array('config', 'uninstall'),
);