<?php

// kontrola jadra
if (!defined('_core'))
{
    return;
}

$config = require _indexroot . "plugins/common/recaptcha/config.php";

// pokud nejsou klice vyplneny pouzije se systemova captcha
if (null !== $config['sitekey'] && null !== $config['secret'])
{
    // class autoloader
    SL::$classLoader->registerBaseNamespace('ReCaptcha', __DIR__ . DIRECTORY_SEPARATOR . 'vendor/src/ReCaptcha', true);


    _extend('regm', array(

        'tpl.head'         => function ($args)
        {
            $args['output'] .= "\n<script type='text/javascript' src='https://www.recaptcha.net/recaptcha/api.js'></script>";
        },
        'sys.captcha.init' => function ($args) use ($config)
        {
            if (!_loginindicator)
            {
                $args['output'] = array(
                    0 => $GLOBALS['_lang']['captcha.input'],
                    1 => "<div class='g-recaptcha' data-sitekey='{$config['sitekey']}'></div>",
                    2 => 1, // vertikalni zarovnani
                    3 => "", // obsah po tabulce
                    4 => "", // css trida pro <tr>
                );
            }

        },

        'sys.captcha.check' => function ($args) use ($config)
        {
            if (!_loginindicator)
            {
                if (isset($_POST['g-recaptcha-response']))
                {
                    $requestMethod = null;
                    if (!ini_get('allow_url_fopen'))
                    {
                        $requestMethod = new \ReCaptcha\RequestMethod\SocketPost();
                    }
                    $recaptcha = new \ReCaptcha\ReCaptcha($config['secret'], $requestMethod);
                    $resp = $recaptcha->verify($_POST['g-recaptcha-response'], $_SERVER['REMOTE_ADDR']);
                    $args['output'] = $resp->isSuccess();
                }
                else
                {
                    $args['output'] = false;
                }
            }
            else
            {
                $args['output'] = true;
            }
        },

    ));
}
