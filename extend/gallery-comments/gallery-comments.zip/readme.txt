=== Gallery comments ===
Verze 1.1
Autor: ShiraNai7
Web: http://sunlight.shira.cz

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Pridava ke galeriim komentare

== Instalace ==
	Nahrajte obsah adresare do korenoveho adresare

== Odinstalace ==
	1) odstrante nasledujici adresar ze serveru: 
		plugins/extend/gallery_comments/
	2) pres nastroj Administrace - Ostatni funkce - Vyhodnoceni SQL dotazu spustte nasledujici SQL dotaz:
		DELETE FROM `sunlight-posts` WHERE flag=1000

== Changelog ==
Verze 1.1
[update] plugin upraven pro SL 7.5.4