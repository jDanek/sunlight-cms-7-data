<?php
/* ----  kontrola jadra  ---- */

if(!defined('_core')) die;


/* ---- konfigurace ---- */

define('PLUGIN_GALLERY_COMMENTS_FLAG', '1000'); // flag pro komentare v db

// kontrola nastaveni
if(!_comments) {
    // komentare jsou globalne vypnuty
    return;
}


/* ---- WEB - funkce pluginu  ---- */

/**
 * [GALLERY COMMENTS PLUGIN] Callback pro zobrazeni komentaru
 * @param array $args
 */
function _plugin_gallery_comments_show($args)
{

    global $_lang;
    require_once (_indexroot.'require/functions-posts.php');
    $args['output'] .= "<br /><br />\n"._postsOutput(
        8,
        $args['extra']['query']['id'],
        array(_commentsperpage, true, false, PLUGIN_GALLERY_COMMENTS_FLAG, true, $_lang['posts.comments']),
        false,
        _indexOutput_url
    );

}

/**
 * [GALLERY COMMENTS PLUGIN] Callback pro validaci komentare
 * @param array $args
 */
function _plugin_gallery_comments_validate($args)
{
    // kontrola existence galerie
    if(0 !== DB::count(_mysql_prefix.'-root', 'id='.$args['home'].' AND type=5')) {
        $args['valid'] = true;
    }
}

/**
 * [GALLERY COMMENTS PLUGIN] Callback pro editaci komentare
 * @param array $args
 */
function _plugin_gallery_comments_edit($args)
{
    // zpetny odkaz
    $args['backlink'] = _linkRoot($args['query']['home']).'#posts';
}


/* ---- WEB - registrace pluginu ---- */

_extend('reg', 'page.gallery.post', '_plugin_gallery_comments_show'); // zobrazeni komentaru
_extend('reg', 'posts.'.PLUGIN_GALLERY_COMMENTS_FLAG.'.validate', '_plugin_gallery_comments_validate'); // validace komentare
_extend('reg', 'posts.'.PLUGIN_GALLERY_COMMENTS_FLAG.'.edit', '_plugin_gallery_comments_edit'); // editace komentare


/* ---- ADMIN  ---- */

if(_administration) {

    /**
     * [GALLERY COMMENTS PLUGIN] Callback pro smazani komentaru pri smazani galerie
     * @param array $args
     */
    function _plugin_gallery_comments_clean($args)
    {
        if('content-delete' === $GLOBALS['getp']) {
            global $id, $continue, $query;
            if($continue && 5 == $query['type'] && defined('_redirect_to')) {
                DB::query('DELETE FROM `'._mysql_prefix.'-posts` WHERE home='.$query['id'].' AND type=7 AND flag='.PLUGIN_GALLERY_COMMENTS_FLAG);
            }
        }
    }

    _extend('reg', 'admin.mod.post', '_plugin_gallery_comments_clean');

}