<?php

/*

    TOTO JE POUZE PŘÍKLAD!!
    -------------------------

    Pro reálné pluginy je třeba přejmenovat konstantu CUSTOM_PAGE_EXAMPLE_IDT,
    aby nevznikaly konflikty mezi různými pluginy.

    Také je třeba změnit hodnotu uvedené konstanty na dostatečně originální
    identifikátor (max 16 znaků).

*/

/* ----  kontrola jadra  ---- */

if(!defined('_core')) die;


/* ----  konfigurace  ---- */

// !! pro skutecne pluginy je treba zmenit nazev i hodnotu !!
// !! a pote take upravit kod nize, kde se konstanta pouziva !!
define('CUSTOM_PAGE_EXAMPLE_IDT', 'ppage_example');


/* ---- funkce pluginu - ADMINISTRACE ---- */

// registrace typu stranky
_extend('reg', 'ppage.reg', function($args){
    $args['infos'][CUSTOM_PAGE_EXAMPLE_IDT] = 'Ukázková plugin stránka';
});

// uprava stranky
_extend('reg', 'ppage.'.CUSTOM_PAGE_EXAMPLE_IDT.'.edit', function($args){
     // ponechame vychozi nastaveni
});

// smazani stranky
_extend('reg', 'ppage.'.CUSTOM_PAGE_EXAMPLE_IDT.'.delete.do', function($args){

     // nedelame nic.. stranka nema zadne "souvisejici polozky", ktere by bylo
     // potreba smazat, takze nechame system, aby pokracoval a stranku vymazal
     $args['handled'] = true;

});


/* ---- funkce pluginu - STRANKY ---- */

// registrace skriptu pro zobrazeni
_extend('reg', 'ppage.'.CUSTOM_PAGE_EXAMPLE_IDT.'.show', function($args){
    $args['file'] = __DIR__.DIRECTORY_SEPARATOR.'script_show.php';
});

// info v rozcestniku
_extend('reg', 'ppage.'.CUSTOM_PAGE_EXAMPLE_IDT.'.interinfo', function($args){
    $args['output'] = 'Info v rozcestníku pro ukázkovou plugin stránku';
});