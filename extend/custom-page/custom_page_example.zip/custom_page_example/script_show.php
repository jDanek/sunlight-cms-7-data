<?php

/* ----  kontrola jadra  ---- */

if(!defined('_core')) die;


/* ---- vystup stranky ---- */

// titulek
$title = $query['title'];

// obsah
$content .= "
<p>Toto je ukázková plugin stránka</p>

<h2>Data stránky:</h2>
<pre>
";

 $content .= _htmlStr(print_r($query, true));

$content .= "</pre>\n";