=== AComment Expire ===
Verze 1.1
Autor: ShiraNai7
Web: http://sunlight.shira.cz

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Po nastavitelnem poctu dni od vydani clanku budou komentare automaticky uzavreny.

== Instalace ==
	nahrajte obsah adresare plugins na server do adresare plugins

== Odinstalace ==
	odstrante nasledujici adresare ze serveru:
		plugins/extend/acommentexpire/
		plugins/common/acommentexpire/

== Changelog ==
[update] plugin upraven pro SL 7.5.4