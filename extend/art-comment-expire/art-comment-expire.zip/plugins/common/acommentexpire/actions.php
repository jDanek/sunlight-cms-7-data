<?php
/* ----- kontrola jadra ----- */

if(!defined('_core')) die;


/* ----- lokalizace ----- */

$lang = array( //
    'en' => array('expire' => 'Expiration time (days)', 'uninstall' => 'To uninstall this plugin, delete following directories'), //
    'cs' => array('expire' => 'Doba expirace (dny)', 'uninstall' => 'Pro odinstalování pluginu smažte následující adresáře'), //
    );
$lid = _getLang($lang);

/* ----- akce ----- */

// cara
$output .= '<div class="hr"><hr /></div>';

// formular
switch($action) {

    case 'config':

        // nacteni konfigurace
        $cfg = _pluginLoadConfig($plugin);

        // ulozeni
        if(isset($_POST['save'])) {

            // nacist
            $cfg['expire'] = intval($_POST['expire']);

            // zpracovat
            if($cfg['expire'] < 1) $cfg['expire'] = 1;
            $cfg['expire'] *= 86400;

            // ulozit
            if(_pluginSaveConfig($plugin, $cfg) !== false) $output .= _formMessage(1, $_lang['global.saved']);
            else  $output .= _formMessage(2, $_lang['global.error']);

        }

        // formular
        $output .= '
<form action="'.$url.'" method="post">
<table class="form">

<tr>
    <td class="rpad"><strong>'.$lang[$lid]['expire'].'</strong></td>
    <td><input type="text" name="expire" value="'.intval($cfg['expire'] / 86400).'" class="inputsmall" /></td>
</tr>

<tr>
    <td></td>
    <td><input type="submit" name="save" value="'.$_lang['global.save'].'" /></td>
</tr>

</table>
'._xsrfProtect().'
</form>
';
        break;

    case 'uninstall':
        $output .= '<p>'.$lang[$lid]['uninstall'].':</p>
<ul>
    <li><code>plugins/common/acommentexpire/</code></li>
    <li><code>plugins/extend/acommentexpire/</code></li>
</ul>
';
        break;

}
