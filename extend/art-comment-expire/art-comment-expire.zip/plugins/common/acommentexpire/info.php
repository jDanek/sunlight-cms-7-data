<?php

return array(

    'name' => 'AComment Expire',
    'descr' => 'Automatická deaktivace komentářů u článků po určité době od vydání',
    'version' => '1.0',
    'author' => 'ShiraNai7',
    'url' => 'http://sunlight.shira.cz/',
    'actions' => array('config', 'uninstall'),

);