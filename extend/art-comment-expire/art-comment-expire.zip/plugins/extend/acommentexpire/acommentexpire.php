<?php
/* ----  kontrola jadra  ---- */

if(!defined('_core')) die;


/* ---- funkce pluginu ---- */

/**
 * [ARTICLE COMMENT EXPIRE PLUGIN] Callback pro deaktivaci komentaru
 * @param array $args
 */
function _plugin_acommentexpire_disable($args)
{

    // nedelat nic, pokud jsou komentare jiz deaktivovany ci uzamceny
    if($args['extra']['query']['comments'] == 0 || $args['extra']['query']['commentslocked'] == 1) return;

    // zjistit, zda je treba uzamknout komentare
    $config = require _plugin_dir.'acommentexpire/config.php';
    if($args['extra']['query']['time'] + $config['expire'] < time()) {

        // uzamknout
        $args['extra']['query']['commentslocked'] = 1;
        $args['extra']['query']['_acommentexpire_used'] = true; // indikator pro hlasku

    }

}

/**
 * [ARTICLE COMMENT EXPIRE PLUGIN] Callback pro zobrazeni hlasky
 * @param array $args
 */
function _plugin_acommentexpire_message($args)
{
    
    // lokalizace
    static $lang = array( //
        'en' => array('msg' => 'Comments are closed automatically %s days after the article is posted.'), //
        'cs' => array('msg' => 'Komentáře jsou automaticky uzavřeny %s dnů po vydání článku.'), //
        );
    $lid = _getLang($lang);
        
    // podminena hlaska
    if(isset($args['extra']['query']['_acommentexpire_used'])) {
        $config = require _plugin_dir.'acommentexpire/config.php';
        $args['output'] .= '<br /><br />'._formMessage(1, sprintf($lang[$lid]['msg'], intval($config['expire'] / 86400)));
    }
}

/**
 * [ARTICLE COMMENT EXPIRE PLUGIN] Callback pro zamezeni ulozeni prispevku
 * @param array $args
 */
function _plugin_acommentexpire_submit($args)
{
    
    if($args['posttype'] == 2) {
        
        // ziskat cas clanku
        $data = DB::query('SELECT `time` FROM `'._mysql_prefix.'-articles` WHERE `id`='.intval($args['posttarget']));
        $data = DB::row($data);
        if($data === false) return;
        
        // zakazat?
        $config = require _plugin_dir.'acommentexpire/config.php';
        if($data['time'] + $config['expire'] < time()) {
            $args['allow'] = false;
        }
    }

}


/* ---- registrace pluginu ---- */

_extend('reg', 'article.pre', '_plugin_acommentexpire_disable'); // deaktivace komentaru
_extend('reg', 'article.comments', '_plugin_acommentexpire_message'); // hlaska
_extend('reg', 'posts.submit', '_plugin_acommentexpire_submit'); // zamezeni postu
