<?php

// check core
if (!defined('_core')) {
    die;
}

class Gamevatar
{
    /** @var array */
    protected $config = array(
        'path' => 'upload/%s/%s', // upload/<username>/<filename>
        'filename' => 'gamevatar.jpg',
        'class' => 'avatar2 gamevatar',
    );

    /**
     * @param array $config
     */
    function __construct(array $config = array())
    {
        $this->config = array_merge($this->config, $config);
    }

    /**
     * @param $args
     */
    function eventUserAvatar($args)
    {
        // only for registered users, the system solution is used for guests
        if ($args['udata']['id'] != -1) {

            // compose file path
            $path = _indexroot . sprintf($this->config['path'], $args['udata']['username'], $this->config['filename']);

            // check for file existence
            if (file_exists($path)) {

                // return only path
                if ($args['path_only']) {
                    $args['return'] = $path;
                    return;
                }

                // return complete
                $uname = (($args['udata']['publicname'] === '') ? $args['udata']['username'] : $args['udata']['publicname']);
                $image = '<img src="' . $path . '" alt="' . $uname . '" class="' . $this->config['class'] . '">';
                $output = '<a href="' . _indexroot . 'index.php?m=profile&amp;id=' . $args['udata']['username'] . '">' . $image . '</a>';
                $args['return'] = $output;
            }
        }
    }
}

// load config
$config = array();
if (file_exists($file = __DIR__ . DIRECTORY_SEPARATOR . 'config.php')) {
    $config = require $file;
}

// plugin registration
$gamevatar = new Gamevatar($config);
_extend('regm', array(
    'user.avatar' => array($gamevatar, 'eventUserAvatar'),
));