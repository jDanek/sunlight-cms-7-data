=== Gamevatar ===
Verze 1.0
Autor: 	Jirka Daněk
Web: 	http://jdanek.eu/

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Umožňuje načítání uživatelských avatarů ze specifické cesty např. /upload/<username>/<file.ext>
	V případě neexistence souboru vzdáleného avataru se použije standardní systémové řešení. 
	Plugin Gamevatar nahrazuje zobrazený avatar vždy (existuje-li) a to nezávisle na uživatelem definovaném avataru.

== Instalace ==
	Nahrajte obsah adresare do korenoveho adresare

== Odinstalace ==
	odstrante nasledujici adresare ze serveru:
		plugins/extend/gamevatar/

== Changelog ==