=== Backlink Event ===
Verze 1.1
Autor: Jirka Dan�k
Web: http://jdanek.eu

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Jedna se o event stranky
	
	Dovoluje nastavovat strankam vlastni backlink, provazat takto napriklad Galerie(sekce) > Rocniky(rozcestnik) > Jednotlive galerie
	pokud by se event pouzil na rozcestnik bude smerovat na sekci "Galerie"
	
	P��klad pou�it�:  
		backlink:index.php?p=fotogalerie

== Instalace ==
	Nahrajte obsah adresare do korenoveho adresare

== Odinstalace ==
	odstrante nasledujici adresare ze serveru:
		plugins/extend/backlink/

== Changelog ==
Verze 1.1
[update] plugin upraven pro SL 7.5.4