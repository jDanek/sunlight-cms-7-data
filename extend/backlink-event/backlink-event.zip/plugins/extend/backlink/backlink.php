<?php
/* ----  kontrola jadra  ---- */

if(!defined('_core')) die;

_extend('reg', array('page.event.backlink', 'page.backlink'), function($event_args, $backlink_args){
	if(!isset($event_args['arg'])) return;
	$backlink_args['backlink'] = _htmlStr($event_args['arg']);
});