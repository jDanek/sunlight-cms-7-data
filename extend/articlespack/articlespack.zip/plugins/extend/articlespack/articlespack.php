<?php

/*
  Název: ArticlePack v1.1
  Autor: Jiří Daněk
  Weby: http://sunlight.shira.cz; http://jdanek.eu; http://designflow.cz

  Informace: Rozsiruje informace o clancich, pridava moznost exportu clanku do PDF
 */

/* ---- kontrola jadra ---- */

if (!defined('_core'))
    die;

$GLOBALS['__plugin_articlespack_cfg'] = require _plugin_dir . $fname . '/config.php';

_extend('regm', array(
    /* Registrace CSS a JS do hlavicky webu */
    'tpl.head' => function($args) {
        $args['output'] .="\n<link href='./plugins/extend/articlespack/style/style.css?" . _cacheid . "' type='text/css' rel='stylesheet' />\n<script type='text/javascript' src='https://apis.google.com/js/plusone.js'>\n//{lang:'cs-CZ', parsetags:'explicit'}\n</script>";
    },
    /* Overload clanku */
    'article.pre' => function($args) {
        $args['extra']['file'] = __DIR__ . DIRECTORY_SEPARATOR . 'article_script.php';
    },
));

/* ---- registrace pluginu ---- */
_extend('reg', 'articlespack', function($args) {
            global $_lang, $__plugin_articlespack_cfg;

            $ap_separ = "&nbsp;|&nbsp;";

//fblike upraven podle uživatele MACO <maco.hys.cz>
            $facebooklike = ($__plugin_articlespack_cfg['showfblike'] !== 0 ? '<!--[if IE]>
<iframe src="//www.facebook.com/plugins/like.php?href=' . _url . '/' . _indexOutput_url . '&amp;send=false&amp;layout=button_count&amp;width=450&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font&amp;height=20" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:150px; height:21px;" allowTransparency="true"></iframe><![endif]-->
<!--[if !IE]>-->
<iframe src="//www.facebook.com/plugins/like.php?href=' . _url . '/' . _indexOutput_url . '&amp;send=false&amp;layout=button_count&amp;width=450&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font&amp;height=20" style="border:none; overflow:hidden; width:150px; height:21px;"></iframe><!--<![endif]-->' : '');
            $twittershare = ($__plugin_articlespack_cfg['showtwittershare'] !== 0 ? "<a href='https://twitter.com/share' class='twitter-share-button'>Tweet</a><script type='text/javascript'>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src='//platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document,'script','twitter-wjs');</script>" : "");
            $plusone = ($__plugin_articlespack_cfg['showgplusone'] !== 0 ? "<div id='plusone-div'></div><script type='text/javascript'>gapi.plusone.render('plusone-div',{'size': 'medium', 'count': 'true'});</script>" : "");


//odkaz pro tisk
            $printlink = (_printart ? "<img src='" . _templateImage("icons/print.png") . "' alt='print' class='icon' /> <a href='printart.php?id=" . $args['extra']['query']['id'] . "'>" . $_lang['article.print'] . "</a>" : "");
//odkaz pro pdf
            $pdflink = ($__plugin_articlespack_cfg['showanchor'] !== 0 ? "<img src='./plugins/extend/articlespack/images/pdf.png' alt='pdf' class='icon' /> <a href='pdf.php?id=" . $args['extra']['query']['id'] . "'>Stáhnout článek v PDF formátu</a>" : "");
//separator
            $separator = (_printart && $__plugin_articlespack_cfg['showanchor'] != 0 ? $ap_separ : "");

            $args['output'].= "
<div class='ap-wrap'>
<div class='ap-info'>
<div class='ap-posted'>{$_lang['article.posted']}: " . _formatTime($args['extra']['query']['time']) . "{$ap_separ}</div>
<div class='ap-readed'>{$_lang['article.readed']}: {$args['extra']['query']['readed']}x" . ($__plugin_articlespack_cfg['variant'] != 0 ? "</div><br />" : $ap_separ . "</div>") . "
<div class='ap-author'>{$_lang['article.author']}: " . _linkUser($args['extra']['query']['author'], 0, 1, 0) . "</div>";


            if ($args['extra']['query']['rateon'] == 1 and _ratemode != 0) {

                $stars = ((0 == $args['extra']['query']['ratenum']) ? 0 : round($args['extra']['query']['ratesum'] / $args['extra']['query']['ratenum'] * 0.05));

                $args['output'].= "
<div class='ap-star-rating'><!-- d1 -->

<div class='article-rated'><!-- d2 -->{$ap_separ}" . $_lang['article.rate'] . ":</div><!-- /d2 -->

<div class='article-rating" . ((_loginright_artrate && _iplogCheck(3, $args['extra']['query']['id'])) ? ' article-rating-active' : '') . "'>";
                for ($i = 1; $i <= 5; ++$i) {
                    $args['output'].= "<div class='article-rating-{$i}" . ((0 !== $i && $stars >= $i) ? ' act' : '') . "' title='Hodnoceno: {$args['extra']['query']['ratenum']}x'>";
                }
                $args['output'].= str_repeat('</div>', 5) . '';
                $args['output'].= "</div>
<script type='text/javascript'>//
<!--
var sl_art_id = " . $args['extra']['query']['id'] . ";
var sl_xsrf_token = '" . _xsrfToken() . "';
//-->
</script>
<script type='text/javascript' src='./plugins/extend/articlespack/js/hvezdy.js?" . _cacheid . "'></script></div>
";
            }

            $args['extra']['query']['rateon'] = "";

            $args['output'].= "
<br style=\"clear:both;\" />
</div>
<div class='ap-actions'>" . $printlink . "</div>
<div class='ap-social'>" . $facebooklike . $twittershare . $plusone . "</div>
</div>";
        }, 9);

		//<div class='ap-actions'>" . $printlink . $separator . $pdflink . "</div>

unset($__plugin_articlespack_cfg);