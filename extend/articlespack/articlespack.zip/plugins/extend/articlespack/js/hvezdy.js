(function(){
    
    // klikatelnost hvezd
    $('div.article-rating-active').click(function(){
       
        // pocet hvezd
        var stars = $(this).find('span:hover, div:hover').length;
               
        // odeslani hodnoceni
        $.ajax({
            url: sl_indexroot + 'remote/artrate.php',
            type: 'POST',
            data: {id: sl_art_id, r: stars * 20, _security_token: sl_xsrf_token},
            dataType: 'text',
            success: function(data){
                window.location.hash = '#ainfo';
                window.location.reload();
            }
        });
        
    });

    
    
    // neaktivni hodnoceni
    if(0 === $('div.article-rating-active').length) {
        $('div.article-rating').click(function(){
            alert('Již jste tento článek ohodnotili nebo nemáte hodnocení povoleno'); 
        });
    }
    
})();


