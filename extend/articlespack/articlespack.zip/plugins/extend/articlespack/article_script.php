<?php

/* ---  kontrola jadra  --- */
if (!defined('_core')) {
    exit;
}
/* --  navigace -- */
if ($query['visible'] == 1) {
    // pripravit obal
    $content .= "<div class='article-navigation'><span>" . $_lang['article.category'] . ": </span>";
    // nacist data vsech domovskych kategorii
    $homes = array();
    for ($i = 1; $i <= 3; ++$i)
        if ($query['home' . $i] != -1)
            $homes[] = $query['home' . $i];
    $q = DB::query('SELECT id,title,title_seo,var3 FROM `' . _mysql_prefix . '-root` WHERE id IN(' . implode(',', $homes) . ')');
    // zpracovat data kategorii
    $homes = array();
    $cat_showinfo = false;
    while ($r = DB::row($q)) {
        if ($r['id'] == $query['home1'])
            $homei = 1;
        elseif ($r['id'] == $query['home2'])
            $homei = 2;
        else
            $homei = 3;
        $homes[$homei] = $r;
        if ($r['var3'] == 1)
            $cat_showinfo = true;
    }
    // vypsat kategorie
    for ($i = 1; $i <= 3; ++$i) {
        if (!isset($homes[$i]))
            continue;
        $homes[$i] = "<a href='" . _linkRoot($homes[$i]['id'], $homes[$i]['title_seo']) . "'>" . $homes[$i]['title'] . "</a>";
    }
    $content .= implode(', ', $homes) . "</div>\n";
    unset($homes);
} else
    $cat_showinfo = null;
/* --  titulek  -- */
$title = $query['title'];
// if(_template_autoheadings) {
$content .= "<h1>" . $title . "</h1>\n";
// }
/* --  perex  -- */
_extend('call', 'article.perex.before', $extend_args); // rozsireni pred perexem
$content .= "<p class='article-perex'>" . (isset($query['picture_uid']) ? "<img class='article-perex-image' src='" . _pictureStorageGet(_indexroot . 'pictures/articles/', null, $query['picture_uid'], 'jpg') . "' alt='" . $query['title'] . "' />" : '') . $query['perex'] . "</p>\n";
// if(isset($query['picture_uid'])) $content .= "<div class='cleaner'></div>\n";
_extend('call', 'article.perex.after', $extend_args); // rozsireni za perexem
/* --  obsah  -- */
$content .= "<div class='article-content'>\n" . _parseHCM($query['content']) . "\n</div>\n";
/* --  informacni tabulka  -- */
// zalomeni
$content .= "<div class='cleaner'></div>\n";
// priprava
$info = array("basicinfo" => null, "idlink" => null, "rateresults" => null, "rateform" => null, "infobox" => null);
// ID clanku
if (_loginright_adminart) {
    $info['idlink'] = (($info['basicinfo'] != null) ? "<br />" : '') . "<strong>" . $_lang['global.id'] . ":</strong> <a href='admin/index.php?p=content-articles-edit&amp;id=" . $id . "&amp;returnid=load&amp;returnpage=1'>" . $id . " <img src='" . _templateImage("icons/edit.png") . "' alt='edit' class='icon' /></a>";
}

// infobox
if ($query['infobox'] != "") {
    $info['infobox'] = _parseHCM($query['infobox']);
}

// sestaveni kodu
if (count(_arrayRemoveValue($info, null)) != 0) {
    // zacatek tabulky
    $content .= "
<div class='anchor'><a name='ainfo'></a></div>
<table class='article-info'>
<tr valign='top'>
";
    // prvni bunka
    if ($info['idlink'] != null) {
        $content .= "<td>" . $info['idlink'] . "</td>";
    }

    // druha bunka
    if ($info['infobox'] != null) {
        $content .= "<td>" . $info['infobox'] . "</td>";
    }

    // konec tabulky
    $content .= "\n</tr>\n</table>\n";
} else {
    $content.="<br />";
}

// rozsireni pred komentari
_extend('call', 'articlespack.author', $extend_args);
_extend('call', 'articlespack', $extend_args);
_extend('call', 'article.comments', $extend_args);

// komentare
if ($query['comments'] == 1 and _comments) {
    require_once (_indexroot . 'require/functions-posts.php');
    $content .= _postsOutput(2, $id, $query['commentslocked']);
}
// zapocteni precteni
if ($query['confirmed'] == 1 and $query['time'] <= time() and _iplogCheck(2, $id)) {
    DB::query("UPDATE `" . _mysql_prefix . "-articles` SET readed=" . ($query['readed'] + 1) . " WHERE id=" . $id);
    _iplogUpdate(2, $id);
}