<?php

/* ----  kontrola jadra  ---- */
if (!defined('_core'))
    die;

/* ---- registrace pluginu ---- */

_extend('reg', 'tpl.head', function ($args)
{
    global $id, $type;
    //dotazy
    if ($type == 1)
    {
        $q_art = DB::row(DB::query("SELECT a.picture_uid,a.perex,u.publicname AS publicname, u.username AS username
                                    FROM `" . _mysql_prefix . "-articles` a
                                    LEFT JOIN `" . _mysql_prefix . "-users` u ON a.author=u.id
                                    WHERE a.public='1' AND a.visible='1' AND a.id='{$id}'"));

        $picture = (isset($q_art['picture_uid']) ? "<meta property='og:image' content='" . _pictureStorageGet(_url . '/pictures/articles/', null, $q_art['picture_uid'], 'jpg') . "' />" : "");
        $description = strip_tags($q_art['perex']);
        $showname = (!strLen($q_art['publicname']) ? $q_art['username'] : $q_art['publicname']);
    }
    else
    {
        $q_art = DB::row(DB::query("SELECT * FROM `" . _mysql_prefix . "-root` WHERE public='1' AND visible='1' AND id='{$id}'"));
        $picture = "<meta property='og:image' content='" . _url . "/pictures/fb-default.png' />";
        $description = ((!$q_art['description'] == "" && !_templatePageIsIndex()) ? $q_art['description'] : _description);
        $showname = _author;
    }

    $args['output'] .= "
    <meta property='fb:admins' content='' />
    <meta property='og:title' content='" . _indexOutput_title . "' />
    <meta property='og:url' content='" . (_templatePageIsIndex() ? _url : _url . "/" . _indexOutput_url) . "' />
    " . $picture . "
    <meta property='og:site_name' content='" . _title . "' />
    <meta property='og:type' content='" . ($type == 1 ? "article" : "website") . "' />
    <meta property='og:description' content='{$description}' />
    ";
});
