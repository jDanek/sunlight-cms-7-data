<?php return array (
  'variant' => 0,
  'showanchor' => 1,
  'showfblike' => 1,
  'showtwittershare' => 1,
  'showgplusone' => 1,
);