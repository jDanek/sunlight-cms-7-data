<?php

return array(

    'name' => 'Articles Pack',
    'descr' => 'Rozšiřující možnosti článku',
    'version' => '1.3.3',
    'author' => 'Jirka Daněk & Tomáš Smetka',
    'url' => 'http://www.designflow.cz',
    'actions' => array('config', 'uninstall'),

);