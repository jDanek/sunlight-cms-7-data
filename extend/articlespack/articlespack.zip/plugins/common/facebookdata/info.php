<?php 

return array( 

'name' => 'Facebook data (upraveno pro SL 7.5.2)', 
'descr' => 'Zobrazuje na fb požadovaná data článku (titulek, obrázek, perex)', 
'version' => '1.1', 
'author' => 'Michal Landsman & Jiří Daněk', 
'url' => 'http://insuit.cz/', 
'actions' => array('config', 'uninstall'), 

); 