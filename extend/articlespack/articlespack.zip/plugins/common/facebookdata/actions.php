<?php 

/* ----- kontrola jadra ----- */ 

if(!defined('_core')) die; 

/* ----- akce ----- */ 

switch($action) { 

case 'config': 
$output .= '<br />
<p>Veškeré nastavení musíte provést editací souboru: <b><a href="./index.php?p=fman&dir=..%2Fplugins%2Fextend%2Ffacebookdata%2F&a=edit&name=ZmFjZWJvb2tkYXRhLnBocA%3D%3D" title="Editovat v Souborovém manažeru">/plugins/extend/facebookdata/facebookdata.php</a></b></p>
<p>Nastavujete: 
<ul>
<li>defaultního obrázku pro jiné typy stránek, než článek.</li>
<li>kód do fb:admins, která zajistí autorizaci pro <a href="https://www.facebook.com/insights/" target="_blank" title="Přejít na přehled">přehled úspěšnosti na facebooku</a></li>
</ul>
</p>
'; 
break; 

case 'uninstall': 
$output .= '
<p></p>
<p>Máte dvě možnosti deinstalace. Přejmenovat složku pluginu tak, že před její název připíšte tečku (.facebookdata), či složku pluginu smazat.<br />
Budete-li chtít plugin úplně odstranit smažte následující:</p>
<ul>
<li>./plugins/common/facebookdata/</li>
<li>./plugins/common/facebookdata/actions.php</li>
<li>./plugins/common/facebookdata/info.php</li>
<li>./plugins/extend/facebookdata/facebookdata.php</li>
</ul>'; 
break; 
 
} 