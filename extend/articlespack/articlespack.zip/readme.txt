=== ArticlesPack ===
Verze 1.3.4
Autor: Jirka Dan�k
Web: http://jdanek.eu

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Plugin menici vypis informaci detailu clanku

== Instalace ==
	nahrajte obsah adresare plugins na server do adresare plugins

== Odinstalace ==
	odstrante nasledujici adresare ze serveru:
		plugins/extend/articlespack/
		plugins/common/articlespack/

== Changelog ==
Verze 1.3.4
[update] plugin upraven pro SL 7.5.4
[odebrano] docasne odebrana PDF knihovna, s prichodem novejsiho PHP prestala fungovat
Verze 1.3.3
[zmena] rozsireni meni paticku clankum, a pridava nekolik socialnich tlacitek a moznost exportu do PDF 