<?php

/* ----  kontrola jadra  ---- */

if (!defined('_core'))
{
    die;
}

/**
 * Extrabox extend
 * @author jDanek <jdanek.eu>
 */
class Extrabox
{

    /**
     * Registrace eventu
     * 
     * @param array $args
     */
    public function registerEvent(array $args)
    {
        $pargs = (isset($args['arg']) ? explode(':', $args['arg'], 2) : array(10, null));
        $column = $pargs[0];
        $box = (isset($pargs[1]) ? $pargs[1] : null);

        /* definice konstanty pro pouziti v templatu */
        define('_jdextrabox', $this->renderBox($column, $box));
    }

    /**
     * Vykresleni boxu
     * 
     * @param int $column cislo sloupce
     * @param string|null $box cislo boxu / cisla vice boxu oddelenych pomlckou 1-2-3
     * @return string
     */
    public function renderBox($column = 1, $box = null)
    {
        $output = "\n";

        if (!_notpublicsite or _loginindicator)
        {

            $boxArray = ($box !== null ? "AND (" . _sqlWhereColumn("ord", $box, false) . ")" : " ORDER BY ord");

            $boxes = array();
            $query = DB::query('SELECT title,content,class FROM `' . _mysql_prefix . '-boxes` WHERE visible=1 AND `column`=' . DB::val($column) . (_loginindicator ? '' : ' AND `public`=1') . $boxArray);
            
			if($query == false) {
				return '';
			}
			
			while ($item = DB::row($query))
            {
                $boxes[] = $item;
            }
            DB::free($query);

            // extend
            $extendOutput = _extend('buffer', 'tpl.boxes', array('boxes' => $boxes, 'column' => $column));
            if ('' !== $extendOutput)
            {
                return $extendOutput;
            }

            // obsah
            if (_template_boxes_parent != "")
            {
                $output .= "<" . _template_boxes_parent . ">\n";
            }

            foreach ($boxes as $item)
            {

                $title = ("" !== $item['title'] ? "<" . _template_boxes_title . " class='box-title'>" . $item['title'] . "</" . _template_boxes_title . ">\n" : "");

                // titulek venku
                if (0 == _template_boxes_title_inside && "" !== $title)
                {
                    $output .= $title;
                }

                // starttag polozky
                if ("" !== _template_boxes_item)
                {
                    $output .= "<" . _template_boxes_item . " class='box-item" . (isset($item['class']) ? ' ' . $item['class'] : '') . "'>\n";
                }

                // titulek vevnitr
                if (1 == _template_boxes_title_inside && "" !== $title)
                {
                    $output .= $title;
                }

                // obsah
                $output .= _parseHCM($item['content']);

                // endtag polozky
                if ("" !== _template_boxes_item)
                {
                    $output .= "\n</" . _template_boxes_item . ">";
                }

                $output .= (1 == _template_boxes_bottom ? "<" . _template_boxes_item . " class='box-bottom'></" . _template_boxes_item . ">\r\n" : "\r\n");
            }
            if ("" !== _template_boxes_parent)
            {
                $output .= "</" . _template_boxes_parent . ">\n";
            }
        }

        return $output;
    }

}

$extrabox = new Extrabox();
_extend('regm', array(
    'page.event.extrabox' => array($extrabox, 'registerEvent'),
));
