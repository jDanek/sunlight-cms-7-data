=== Extrabox ===
Verze 1.2
Autor: Jirka Dan�k
Web: http://jdanek.eu

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Dovoluje vlozit do stranky box z vybraneho sloupce, za pouziti poradi jako identifikatoru.
	Jedna se o event stranky

	P��klad pou�it�:  
		extrabox:10:1-2-3
		extrabox:(cislo sloupce),(poradi boxu)

== Instalace ==
	Nahrajte obsah adresare do korenoveho adresare
	Do template.php vlo�it <?php if(defined('_jdextrabox')) echo _jdextrabox; ?>

== Odinstalace ==
	odstrante nasledujici adresare ze serveru:
		plugins/extend/extrabox/

== Changelog ==
Verze 1.2
[fix] vraceni prazdneho retezce pokud neni nalezen zadny box
Verze 1.1
[update] plugin upraven pro SL 7.5.4