<?php

/**
 * priklad: slimpage:foobar (nacte foobar.php)
 */
/* ---- kontrola jadra ---- */
if (!defined('_core'))
{
    die;
}

/**
 * Slimpage extend
 * @author jDanek <jdanek.eu>
 */
class Slimpage
{

    /** @var string */
    private $template;

    /**
     * Registrace eventu
     * 
     * @param array $args
     */
    public function registerEvent(array $args)
    {
        $template = _indexroot . "plugins/templates/" . _template . "/" . (isset($args['arg']) ? $args['arg'] : 'slim') . ".php";
        if (file_exists($template))
        {
            $this->template = $template;
        }
    }

    /**
     * Nahrazeni sablony
     * 
     * @param array $args
     */
    public function replaceTemplate(array $args)
    {
        $args['output'] = $this->template;
    }

}

$slimpage = new Slimpage();
_extend('regm', array(
    'page.event.slimpage' => array($slimpage, 'registerEvent'),
    'index.template'      => array($slimpage, 'replaceTemplate'),
));
