=== SlimPage ===
Verze 1.1
Autor: 	Jirka Dan�k
Web: 	http://jdanek.eu/

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Systemovy event pro overload template stranky

== Instalace ==
	Nahrajte obsah adresare do korenoveho adresare
	Jedna se o event stranky
	
	defaultne nastaven nazev souboru 'slim' (/plugins/templates/<nazev motivu>/slim.php)
	Pouziti:
		slimpage:jmenosouboru

== Odinstalace ==
	odstrante nasledujici adresare ze serveru:
		plugins/extend/slimpage

== Changelog ==
Verze 1.1
[update] plugin upraven pro SL 7.5.4