=== Generator Sitemap ===
Verze 1.1
Autor: 	Jan Valent�k
	Jirka Dan�k

Web: 	http://valentik.cz/
	http://jdanek.eu/

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Generuje soubor sitemap.xml pro lepsi indexaci stranek

== Instalace ==
	Nahrajte obsah adresare do korenoveho adresare
	soubory gss.xls a sitemap.xml umistete do korene webu
	
	v administraci Generovani sitemap najdete v sekci Ostatni funkce.
	pristup nastaven pro uroven 600 a vice

== Odinstalace ==
	odstrante nasledujici adresare ze serveru:
		plugins/admin/gensitemap/

== Changelog ==
Verze 1.1
[update] plugin upraven pro SL 7.5.4