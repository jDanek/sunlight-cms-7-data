<?php

/* --- kontrola jadra --- */
if(!defined('_core')) exit;

function _formatLastMod($timestamp){

if (PHP_VERSION >= '5.1.3'){
  return date("Y-m-d\TH:i:sP", $timestamp);
  }else{
  return date("Y-m-d\TH:i:s+01:00", $timestamp);
  }
  
}

// lokalizace
    static $lang = array( //
        'en' => array('sitemap'=>'Generate sitemap','generator_ok'=>'File <strong>sitemap.xml </ strong> has been generated and stored.','generator_ok_1'=>'The size of the generated sitemap.xml file: ','generator_ok_2'=>'Tool to generate sitemap.xml file. ','generator_result'=>'Result'), //
        'cs' => array('sitemap'=>'Generování sitemap','generator_ok'=>'Soubor <strong>sitemap.xml</strong> byl vygenerován a uložen.','generator_ok_1'=>'Velikost vygenerovaného souboru sitemap.xml: ','generator_ok_2'=>'Nástroj na vygenerování souboru sitemap.xml. ','generator_result'=>'Výsledek'), //
        );
    $lid = _getLang($lang);

//
if(isset($_POST['Submit']))
{
  //nastavení priorit
  $prioKatSek="0.8";
  $prioArt="0.5";

  //nastavení chnagefreq
  $freqKatSek="weekly";
  $freqArt="monthly";

  //příprava souboru
$file = @FOpen(_indexroot."sitemap.xml", "w");

  //hlavička a doména
$data='<?xml version="1.0" encoding="UTF-8"?'.'>
<?xml-stylesheet type="text/xsl" href="'._url.'/gss.xsl" ?'.'>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.google.com/schemas/sitemap/0.84 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
	<url>
		<loc>'._url.'</loc>
		<lastmod>'._formatLastMod(time()).'</lastmod>
		<priority>1.0</priority>
		<changefreq>always</changefreq>
	</url>';

  @FPutS($file, $data);

    //vypis kategorií a sekcí
$cats=DB::query("SELECT id,type,title,title_seo,var1,var2 FROM `"._mysql_prefix."-root` WHERE visible=1 AND public=1 AND type!=4");
while($item=DB::row($cats)){
$data='
	<url>
		<loc>'._url.'/'._linkRoot($item['id'],$item['title_seo']).'</loc>
		<lastmod>'._formatLastMod(time()).'</lastmod>
		<priority>'.$prioKatSek.'</priority>
		<changefreq>'.$freqKatSek.'</changefreq>
	</url>';

  @FPutS($file, $data);

  }

  //vypis članků
  $arts=DB::query("SELECT id,title,title_seo,time FROM `"._mysql_prefix."-articles` WHERE visible=1 AND public=1 AND confirmed=1 AND time<=".time()." ORDER BY time DESC");
  while($art=DB::row($arts)){
$data='
	<url>
		<loc>'._url.'/'._linkArticle($art['id'],$item['title_seo']).'</loc>
		<lastmod>'._formatLastMod($art['time']).'</lastmod>
		<priority>'.$prioArt.'</priority>
		<changefreq>'.$freqArt.'</changefreq>
	</url>';

  @FPutS($file, $data);

  }
  //konec souboru
  $data=_nl.'</urlset>';

  @FPutS($file, $data);

  @FClose($file);
  //Sestavení zprávy
  $sizefile=round(@filesize(_indexroot."sitemap.xml")/1024);
  $output.="<fieldset>
		<legend>".$lang[$lid]['generator_result']."</legend>
		<table><tr><td valign='top'><img src='../plugins/admin/gensitemap/accept.png' alt='icon'/></td><td valign='top'>
		<ul>
			<li>".$lang[$lid]['generator_ok']."</li>
			<li>".$lang[$lid]['generator_ok_1']."".$sizefile." (kB).</li>
		</ul>
		</td></tr></table>
	</fieldset>";
  
}
 
$output .= '<fieldset>
   <legend>Generování souboru sitemap.xml</legend>
	Můžete si vygenerovat nový obsah souboru <em>sitemap.xml</em><br /><br />
	<form name="gensm" method="post" enctype="multipart/form-data" action="">
        ' . _xsrfProtect() . '
	<input name="Submit" type="submit" value="Generovat">
    </form>
</fieldset>';
  
   return $output;