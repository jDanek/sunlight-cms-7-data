<?php 
return array( 
'title' => 'Generátor Sitemap', 
'access' => _loginright_level > 600,
'in-other' => true,
); 