=== Gravatar ===
Verze 1.1
Autor: 	ShiraNai7
Web: 	http://sunlight.shira.cz/

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Umozni uzivatelum pouzit gravatar.com jako zdroj pro svuj avatar.

== Instalace ==
	Nahrajte obsah adresare do korenoveho adresare

== Odinstalace ==
	odstrante nasledujici adresare ze serveru:
		plugins/extend/gravatar/
		plugins/common/gravatar/

== Changelog ==
Verze 1.1
[update] plugin upraven pro SL 7.5.4