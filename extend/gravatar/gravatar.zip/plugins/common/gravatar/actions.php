<?php
/* ----- kontrola jadra ----- */

if(!defined('_core')) die;


/* ----- lokalizace ----- */

$lang = array( //
    'en' => array('width' => 'Avatar width for posts', 'width.hint' => 'this option specifies width of avatar that is loaded for displaying in user posts / comments and is template-dependednt, common value is <code>50</code>', 'default' => 'Default avatar', 'uninstall' => 'To uninstall this plugin, delete following directories'), //
    'cs' => array('width' => 'Šířka avataru u příspěvků', 'width.hint' => 'tato volba určuje šířku avataru, který je načten pro zobrazení u příspěvků / komentářů a záleží na použitém motivu, běžná hodnota je <code>50</code>', 'default' => 'Výchozí avatar', 'uninstall' => 'Pro odinstalování pluginu smažte následující adresáře'), //
    );
$lid = _getLang($lang);

/* ----- akce ----- */

// cara
$output .= '<div class="hr"><hr /></div>';

// formular
switch($action) {

    case 'config':

        // nacteni konfigurace
        $cfg = _pluginLoadConfig($plugin);

        // ulozeni
        if(isset($_POST['save'])) {

            // nacist
            $cfg['width'] = intval($_POST['width']);
            $cfg['default'] = trim(strval($_POST['default']));

            // zpracovat
            if($cfg['width'] < 10) $cfg['width'] = 10;
            if($cfg['default'] === '') $cfg['default'] = null;

            // ulozit
            if(_pluginSaveConfig($plugin, $cfg) !== false) $output .= _formMessage(1, $_lang['global.saved']);
            else  $output .= _formMessage(2, $_lang['global.error']);

        }

        // formular
        $output .= '
<form action="'.$url.'" method="post">
<table class="form">

<tr>
    <td class="rpad"><strong>'.$lang[$lid]['width'].'<span class="text-green">*</span></strong></td>
    <td><input type="text" name="width" value="'.$cfg['width'].'" class="inputsmall" /></td>
</tr>

<tr>
    <td class="rpad"><strong>'.$lang[$lid]['default'].'</strong></td>
    <td><input type="text" name="default" value="'._htmlStr($cfg['default']).'" class="inputsmall" /> <a href="http://en.gravatar.com/site/implement/images/#default-image" target="_blank" title="'.$_lang['global.help'].'"><img src="images/icons/help.png" alt="help" class="icon" /></a></td>
</tr>

<tr>
    <td></td>
    <td><input type="submit" name="save" value="'.$_lang['global.save'].'" /></td>
</tr>

</table>
'._xsrfProtect().'
</form>

<p><small><span class="text-green">*</span> '.$lang[$lid]['width.hint'].'</small></p>
';
        break;

    case 'uninstall':
        $output .= '<p>'.$lang[$lid]['uninstall'].':</p>
<ul>
    <li><code>plugins/common/gravatar/</code></li>
    <li><code>plugins/extend/gravatar/</code></li>
</ul>
';
        break;

}
