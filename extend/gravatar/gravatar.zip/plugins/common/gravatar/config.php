<?php return array (
  'width' => 50,
  'default' => 'identicon',
);