<?php

return array(

    'name' => 'Gravatar',
    'descr' => 'Rozšíří systém avatarů o napojení na <a href="http://gravatar.com/" target="_blank">gravatar.com</a>',
    'version' => '1.0',
    'author' => 'ShiraNai7',
    'url' => 'http://sunlight.shira.cz/',
    'actions' => array('config', 'uninstall'),

);