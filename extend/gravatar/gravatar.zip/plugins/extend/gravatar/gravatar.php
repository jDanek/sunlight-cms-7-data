<?php
/* ----  kontrola jadra  ---- */

if(!defined('_core')) die;


/* ----  nacteni konfigurace  ---- */

$GLOBALS['__plugin_gravatar_cfg'] = require _plugin_dir.$fname.'/config.php';


/* ---- funkce pluginu ---- */

/**
 * [GRAVATAR PLUGIN] Callback pro zobrazeni avataru
 * @param array $args
 * @return bool false
 */
function _plugin_gravatar_display($args)
{

    // nahrazeni systemoveho avataru
    if(isset($args['udata']['avatar_mode'], $args['udata']['email']) && $args['udata']['avatar_mode'] == 1) {

        global $__plugin_gravatar_cfg;

        // sestaveni url
        $url = 'http://www.gravatar.com/avatar/'.md5(strtolower($args['udata']['email'])).'.jpg?s='.($args['full_size'] ? 96 : $__plugin_gravatar_cfg['width']).(isset($__plugin_gravatar_cfg['default']) ? '&amp;d='.urlencode($__plugin_gravatar_cfg['default']) : '');

        // cesta ci kod
        if($args['path_only']) $args['return'] = $url;
        else  $args['return'] = '<a href="'._indexroot.'index.php?m=profile&amp;id='.$args['udata']['username'].'"><img src="'.$url.'" alt="'.$args['udata']['username'].'" class="avatar2" /></a>';

    }

    // dalsi pluginy se nevolaji
    return false;

}

/**
 * [GRAVATAR PLUGIN] Callback pro rozsireni user cache
 * @param array $args
 */
function _plugin_gravatar_user_cache($args)
{
    $args['extend'][] = array(array('u.avatar_mode', 'u.email'));
}

/**
 * [GRAVATAR PLUGIN] Callback pro zmenu modu avataru v nastaveni uziv.
 * @param array $args
 * @return bool false
 */
function _plugin_gravatar_settings_edit($args)
{

    // lokalizace
    static $lang = array( //
        'en' => array('type' => 'Avatar type', 'sys' => 'system', 'gravatar' => 'gravatar.com'), //
        'cs' => array('type' => 'Typ avataru', 'sys' => 'systémový', 'gravatar' => 'gravatar.com'), //
        );
    $lid = _getLang($lang);
    
    // vystup
    global $__plugin_gravatar_cfg;
    $args['output'] .= '<table>
<tr valign="top">
    <td rowspan="2"><strong>'.$lang[$lid]['type'].':</strong></td>
    <td><label><input type="radio" name="avatar_mode" id="user_settings_avatar_mode_sys"'._checkboxActivate($args['extra']['query']['avatar_mode'] == 0).' value="0" /> '.$lang[$lid]['sys'].'</label></td>
    <td><label><input type="radio" name="avatar_mode" id="user_settings_avatar_mode_gravatar"'._checkboxActivate($args['extra']['query']['avatar_mode'] == 1).' value="1" /> '.$lang[$lid]['gravatar'].'</label> <a href="http://gravatar.com/" target="_blank">&#94;</a></td>
</tr>

<tr valign="top">
    <td><label for="user_settings_avatar_mode_sys">'._getAvatar($args['extra']['query']['id'], false, false, true, true, true).'</label></td>
    <td><label for="user_settings_avatar_mode_gravatar"><img src="http://www.gravatar.com/avatar/'.md5(strtolower($args['extra']['query']['email'])).'.jpg?s=96'.(isset($__plugin_gravatar_cfg['default']) ? '&amp;d='.urlencode($__plugin_gravatar_cfg['default']) : '').'" alt="gravatar" /></label></td>
</tr>
</table>

<div class="hr"><hr /></div>';

    // dalsi pluginy se nevolaji
    return false;

}

/**
 * [GRAVATAR PLUGIN] Callback pro ulozeni modu avataru v nastaveni uziv.
 * @param array $args
 */
function _plugin_gravatar_settings_submit($args)
{
    
    // nacist zmenu
    if(isset($_POST['avatar_mode']) && $_POST['avatar_mode'] == 1) $new_mode = 1;
    else $new_mode = 0;
    
    // vlozit do query
    if($new_mode != $args['current_query']['avatar_mode']) {
        $args['query']['avatar_mode'] = $new_mode;
    }
    
}


/* ---- registrace pluginu ---- */

_extend('reg', 'user.avatar', '_plugin_gravatar_display'); // zobrazeni avataru
_extend('reg', 'user.cache.init', '_plugin_gravatar_user_cache'); // nacitani avatar_mode v user cache
_extend('reg', 'mod.settings.avatar', '_plugin_gravatar_settings_edit'); // uprava avataru v nastaveni
_extend('reg', 'mod.settings.submit', '_plugin_gravatar_settings_submit'); // ulozeni avataru v nastaveni
