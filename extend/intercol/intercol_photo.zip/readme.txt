=== Intercol ===
Verze 1.1
Autor: 	ShiraNai7
Web: 	http://sunlight.shira.cz/

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Vypis polozek v rozcestniku do sloupcoveho layoutu. Plugin se vaze na konkretni rozcestniky pomoci udalosti stranky.

== Instalace ==
	Nahrajte obsah adresare do korenoveho adresare

	Zakladni pouziti

	  - v administraci vytvorte/upravte rozcestnik
	  - do pole "Udalosti" vyplnte "intercol" (bez uvozovek)
	  - nyni se bude rozcestnik vypisovat do tabulky o dvou sloupcich
	
	Vice sloupcu

	  - pocet sloupcu lze uvest jako argument udalosti,
    		napriklad: "intercol:3" (bez uvozovek)
	  - pocet sloupcu je omezen na rozmezi 2-10


	Trida tabulky

	- tabulce lze pridat vlastni CSS tridu pouzitim dalsiho
    	argumentu, napriklad: "intercol:3:mojetrida" (bez uvozovek)

== Odinstalace ==
	odstrante nasledujici adresare ze serveru:
		plugins/extend/intercol/

== Changelog ==
Verze 1.1
[update] plugin upraven pro SL 7.5.4