<?php
/* ----  kontrola jadra  ---- */

if(!defined('_core')) die;


/* ---- funkce pluginu ---- */

/**
 * [INTERCOL PLUGIN] Callback pro vypis rozcestniku
 * @param array $args
 * @return bool false
 */
function _plugin_intercol($args)
{

    // kontrola typu stranky
    if(7 == $args['query']['type']) {

        $pargs = (isset($args['arg']) ? explode(':', $args['arg'], 2) : array(2, null));

        // pocet sloupcu
        $colnum = intval($pargs[0]);
        if($colnum < 2) return;
        if($colnum > 10) return;

        // ulozeni argumentu
        $args['query']['_intercol_num'] = $colnum;
        $args['query']['_intercol_class'] = (isset($pargs[1]) ? strval($pargs[1]) : null);

        // nahrazeni skriptu
        _extend('reg', 'page.intersection.pre', '_plugin_intercol_overload');

    }

}

/**
 * @ignore
 */
function _plugin_intercol_overload($args)
{
    $args['extra']['file'] = dirname(__FILE__).DIRECTORY_SEPARATOR.'script_intersection.php';
}


/* ---- registrace pluginu ---- */

_extend('reg', 'page.event.intercol', '_plugin_intercol');
