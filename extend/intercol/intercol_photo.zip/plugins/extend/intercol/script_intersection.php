<?php
// kontrola jadra
if(!defined('_core')) {
	exit;
}

// titulek
$title = $query['title'];
if(_template_autoheadings && $query['autotitle']) {
	$content .= "<h1>".$query['title']."</h1>\n";
}
_extend('call', 'page.intersection.aftertitle', $extend_args);

// obsah
_extend('call', 'page.intersection.content.before', $extend_args);
if($query['content'] != "") $content .= _parseHCM($query['content'])."\n\n";
_extend('call', 'page.intersection.content.after', $extend_args);

// vypis polozek
$items = DB::query("SELECT id,title,title_seo,type,type_idt,intersectionperex,var1 FROM `"._mysql_prefix."-root` WHERE intersection=".$id." AND visible=1 ORDER BY ord");
if(DB::size($items) != 0) {

    // vypis
    $item_str = '';
    $item_arr = array();
	while($item = DB::row($items)) {

		// titulek
		$item_str .= "<h2 class='list-title'><a href='"._linkRoot($item['id'], $item['title_seo'])."'".(($item['type'] == 6 and $item['var1'] == 1) ? " target='_blank'" : '').">".$item['title']."</a></h2>\n";

		// perex
		if($item['intersectionperex'] != "") {
			$item_str .= "<p class='list-perex'>".$item['intersectionperex']."</p>\n";
		}

		// informace
		if($query['var1'] == 1) {
			$iteminfo = "";

			switch($item['type']) {

					// sekce
				case 1:
					if($item['var1'] == 1) {
						$iteminfo .= "<span>".$_lang['article.comments'].":</span> ".DB::result(DB::query("SELECT COUNT(id) FROM `"._mysql_prefix."-posts` WHERE type=1 AND home=".$item['id']), 0);
					}
					break;

					// kategorie
				case 2:
					$iteminfo .= "<span>".$_lang['global.articlesnum'].":</span> ".DB::result(DB::query("SELECT COUNT(id) FROM `"._mysql_prefix."-articles` AS art WHERE (home1=".$item['id']." OR home2=".$item['id']." OR home3=".$item['id'].") AND "._sqlArticleFilter()), 0);
					break;

					// kniha
				case 3:

					// nacteni jmena autora posledniho prispevku
					$lastpost = DB::query("SELECT author,guest FROM `"._mysql_prefix."-posts` WHERE home=".$item['id']." ORDER BY id DESC LIMIT 1");
					if(DB::size($lastpost) != 0) {
						$lastpost = DB::row($lastpost);
						if($lastpost['author'] != -1) {
							$lastpost = _linkUser($lastpost['author'], null, true, true);
						} else {
							$lastpost = $lastpost['guest'];
						}
					} else {
						$lastpost = "-";
					}

					$iteminfo .= "<span>".$_lang['global.postsnum'].":</span> ".DB::result(DB::query("SELECT COUNT(id) FROM `"._mysql_prefix."-posts` WHERE type=3 AND home=".$item['id']), 0)._template_listinfoseparator."<span>".$_lang['global.lastpost'].":</span> ".$lastpost;
					break;

					// galerie
				case 5:
				
				/* moje uprava - obrazky */
					$rimgs = DB::query_row("SELECT id,title,prev,full FROM `"._mysql_prefix."-images` WHERE home=".$item['id']." ORDER BY RAND() LIMIT 1"); //ORDER BY id DESC
					$thumb = _pictureThumb($rimgs['full'], array('x' => null, 'y' => 96,));
                                        
					$result = "<a href='"._linkRoot($item['id'], $item['title_seo'])."'".(($item['type'] == 6 and $item['var1'] == 1) ? " target='_blank'" : '')."><img src='{$thumb}' class='nahled' /></a>";
					
					$iteminfo = "<div align='center' style='padding:0 0 5px 0; float:bottom;'>".$result."</div>";
				/* konec moje uprava */
				
					$iteminfo .= "<span>".$_lang['global.imgsnum'].":</span> ".DB::result(DB::query("SELECT COUNT(id) FROM `"._mysql_prefix."-images` WHERE home=".$item['id']), 0);
					break;

					// forum
				case 8:
					$iteminfo .= "<span>".$_lang['global.topicsnum'].":</span> ".DB::result(DB::query("SELECT COUNT(id) FROM `"._mysql_prefix."-posts` WHERE type=5 AND home=".$item['id']." AND xhome=-1"), 0)._template_listinfoseparator."<span>".$_lang['global.answersnum'].":</span> ".DB::result(DB::query("SELECT COUNT(id) FROM `"._mysql_prefix."-posts` WHERE type=5 AND home=".$item['id']." AND xhome!=-1"), 0);
					break;

                    // plugin stranka
                case 9:
                    _extend('call', 'ppage.'.$item['type_idt'].'.interinfo', _extendArgs($iteminfo));
                    break;

			}

			if($iteminfo != "") {
				$item_str .= "<div class='list-info'>".$iteminfo."</div>\n";
			}
		}

        $item_arr[] = array($item_str, str_replace('/', '_', $item['title_seo']));
        $item_str = '';

	}

    // vypis do sloupcu
    $colnum = $query['_intercol_num'];
    $item_chunks = array_chunk($item_arr, $colnum);
    $last_i = $colnum - 1;

    $row_even = false;
    $row_counter = 0;

    $content .= "<table".(isset($query['_intercol_class']) ? " class='{$query['_intercol_class']}'" : '')."><tbody>\n";
    foreach($item_chunks as $item_chunk) {

        $row_even = !$row_even;
        ++$row_counter;

        $content .= "<tr class='row-".($row_even ? 'even' : 'odd')." row-{$row_counter}'>\n";

        $cell_even = true;
        for($i = 0; isset($item_chunk[$i]); ++$i) {
            $content .= "<td class='inter-page-{$item_chunk[$i][1]} cell-".($cell_even ? 'even' : 'odd')." cell-".($i + 1)."'>\n{$item_chunk[$i][0]}\n</td>\n";
            if($last_i !== $i && !isset($item_chunk[$i + 1])) {
                $fill_count = $colnum - $i - 1;
                for($ii = 0; $ii < $fill_count; ++$ii) {
                    $cell_even = !$cell_even;
                    $content .= "<td class='cell-filler cell-".($cell_even ? 'even' : 'odd')." cell-".($i + $ii + 2)."'></td>";
                }
            }
            $cell_even = !$cell_even;
        }
        $content .= "</tr>\n";

    }
    $content .= "</tbody></table>\n";


} else {
	$content .= $_lang['global.nokit'];
}