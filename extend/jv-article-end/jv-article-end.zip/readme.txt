=== JV Article End ===
Verze 1.1
Autor: 	Jan Valent�k
Web: 	http://valentik.cz/

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Moznost kazdemu clanku nastavit datum do kdy ma byt clanek vydan.

== Instalace ==
	Nahrajte obsah adresare do korenoveho adresare
	V administraci rozsireni provedte instalaci pluginu (provede se instalace do databaze)

	Zakladni pouziti

 	- v administraci pri vytvareni/editaci clanku zadejte datum do kdy ma byt clanek zvrejnen
  	- pokud ma mit clanek neomezenou platnost, zaskrtnete volbu "nastavit stejne jako vydano"


== Odinstalace ==
	v administraci roz���en� prove�te odinstalaci pluginu (odinstaluje se z datab�ze)
	odstrante nasledujici adresare ze serveru:
		plugins/extend/jv_article_end
  		plugins/common/jv_article_end

== Changelog ==
Verze 1.1
[update] plugin upraven pro SL 7.5.4