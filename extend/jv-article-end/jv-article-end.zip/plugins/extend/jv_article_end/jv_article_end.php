<?php

/* ----  kontrola jadra  ---- */
if (!defined('_core'))
    die;

/* ---- funkce pluginu ---- */

/**
 * Upraveny soubor pro editaci clanku
 * @param array $args 
 */
function _plugin_jv_article_end_form($args) {
    if ($args['extra']['name'] == 'content-articles-edit') {
        $args['extra']['file'] = _indexroot . 'plugins/extend/jv_article_end/content-articles-edit.php';
	return false;
    }
}

/**
 * Vypis clanku
 * @param array $args 
 */
function _plugin_jv_article_end_category($args) {
    $args['extra']['file'] = _indexroot . 'plugins/extend/jv_article_end/category.php';
    return false;
}

/* ---- registrace pluginu ---- */

_extend('reg', 'admin.mod.init', '_plugin_jv_article_end_form');
_extend('reg', 'page.category.pre', '_plugin_jv_article_end_category');