<?php

/* ----- kontrola jadra ----- */

if (!defined('_core'))
    die;

/* ----- lokalizace ----- */

$lang = array(//
    'en' => array(
        'install' => '<p>Installation complete.</p>',
        'uninstall' => '<p>Uninstallation from database complete.</p>',
        'uninstall_error' => '<p>Instalace pluginu se nezdařila.</p>',
        'dirs' => '<p>To uninstall this plugin, delete following directories:</p>',
        'submit' => 'YES',
        'question' => '<p>You really want to uninstall the plugin?</p>',
        'exist' => '<p>Column <cite>"jv_timeend"</cite> in table <cite>"' . _mysql_prefix . '-articles"</cite> exist.</p><p>If this column not using other plugin remove it before installation.</p>',
        'docs' => '<p></p>'
    ), //
    'cs' => array(
        'install' => '<p>Instalace pluginu proběhla úspěšně.</p>',
        'uninstall' => '<p>Odinstalace pluginu z databáze proběhla úspěšně.</p>',
        'uninstall_error' => '<p>Instalace pluginu se nezdařila.</p>',
        'dirs' => '<p>Pro odinstalování pluginu smažte následující adresáře:</p>',
        'submit' => 'ANO',
        'question' => '<p>Opravdu chcete plugin odinstalovat?</p>',
        'exist' => '<p>Sloupec <cite>"jv_timeend"</cite> v tabulce <cite>"' . _mysql_prefix . '-articles"</cite> potřebný pro správnou funkčnost tohoto pluginu již existuje.</p><p>Instalace již byla pravděpodobně již provedena.</p>',
        'docs' => '<p>Při editaci článku umožní nastavit konec platnosti vydání článku.<br />
            Pokud bude třeba články vypisovat s použitím HCM modulu, je třeba příslušný modul upravit.<br />
            </p>'
    ), //
);
$lid = _getLang($lang);

/* ----- akce ----- */

// cara
$output .= '<div class="hr"><hr /></div>';

// formular
switch ($action) {

    case 'docs':
        $output .= $lang[$lid]['docs'];
        break;
    case 'install':
        $sql = DB::query('SHOW COLUMNS FROM `' . _mysql_prefix . '-articles` LIKE "jv_timeend"');
        if (DB::rown($sql)) {
            $output .= $lang[$lid]['exist'];
        } else {
            DB::query('ALTER TABLE `' . _mysql_prefix . '-articles` ADD `jv_timeend` int(11) NOT NULL');
            DB::query('UPDATE `' . _mysql_prefix . '-articles` SET `jv_timeend`=`time`');
            $output .= $lang[$lid]['install'];
        }
        break;
    case 'uninstall':
        if (isset($_POST['confirmed']) and $_POST['confirmed'] == 'ANO') {
            if (DB::query('ALTER TABLE `' . _mysql_prefix . '-articles` DROP `jv_timeend`')) {
                $output .= $lang[$lid]['uninstall'];
            } else {
                $output .= $lang[$lid]['uninstall_error'];
            }
            $output .= $lang[$lid]['dirs'] . '
                <ul>
                    <li><code>plugins/common/jv_article_end/</code></li>
                    <li><code>plugins/extend/jv_article_end/</code></li>
                </ul>
                ';
        } else {
            $output .= '<form action="" method="post">';
            $output .= $lang[$lid]['question'];
            $output .= _xsrfProtect().'<input type="submit" name="confirmed" value="' . $lang[$lid]['submit'] . '" />';
            $output .= '</form>';
        }
        break;
}
