<?php

return array(

    'name' => 'JV Article End',
    'descr' => 'Možnost zadat konec publikování článku.',
    'version' => '1.0',
    'author' => 'Jval',
    'url' => 'http://www.valentik.eu/',
    'actions' => array('install','uninstall','docs'),

);