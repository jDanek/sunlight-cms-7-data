<?php

return array(
    'name'    => 'Profile Plus',
    'descr'   => 'Rozšiřuje možnosti uživatelských profilů (bydliště, pohlaví, facebook, twitter)',
    'version' => '1.5',
    'author'  => 'Jirka Daněk',
    'url'     => 'http://jdanek.eu',
    'actions' => array('install', 'config', 'manage', 'uninstall'),
);