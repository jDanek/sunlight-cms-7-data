<?php

/* ----- kontrola jadra ----- */

if (!defined('_core'))
{
    die;
}

/**
 * @param $user_id
 * @return array|bool
 */
function getUserData($user_id)
{
    $username = DB::esc($user_id);
    $query = DB::query_row("SELECT * FROM `" . _mysql_prefix . "-users` WHERE username='{$username}'");
    return $query;
}

global $_lang;

/* ----- akce ----- */
$profilePlus = new ProfilePlus();
$exists = $profilePlus->isInstalled(); //výsledek testu sloupcu
// cara
$output .= '<p class="bborder"></p>';

// formular
switch ($action)
{

    /* --- INSTALACE --- */
    case 'install':

        if (isset($_POST['installyes']) && (!$exists))
        {
            DB::query("ALTER TABLE `" . _mysql_prefix . "-users` ADD `facebook` tinytext NOT NULL, ADD `twitter` tinytext NOT NULL, ADD `residence` varchar(50) NOT NULL, ADD `gender` tinyint(1) NOT NULL DEFAULT '0'");
            $output .= _formMessage(1, $_lang['profileplus']['install.successfullyadd']);
        }

        $installform = "
		<fieldset id='installcolumn'><legend>{$_lang['profileplus']['install.legend']}</legend>
		<label>{$_lang['profileplus']['install.description']}</label><br /><br />
		<form action='{$url}' method='post'><input type='submit' name='installyes' value='{$_lang['profileplus']['install.button']}' />" . _xsrfProtect() . "</form>
		</fieldset>";

        $output .= (!$exists ? $installform : _formMessage(2, $_lang['profileplus']['install.columnexists']));

        break;

    /* --- KONFIGURACE --- */
    case 'config':

        // nacteni konfigurace
        $cfg = _pluginLoadConfig($plugin);

        // ulozeni
        if (isset($_POST['save']))
        {

            // nacist
            $cfg['showgender'] = _checkboxLoad('showgender');
            $cfg['showresidence'] = _checkboxLoad('showresidence');
            $cfg['showfacebook'] = _checkboxLoad('showfacebook');
            $cfg['showtwitter'] = _checkboxLoad('showtwitter');

            // zpracovat
            if ($cfg['showgender'] === '')
            {
                $cfg['showgender'] = null;
            }
            if ($cfg['showresidence'] === '')
            {
                $cfg['showresidence'] = null;
            }
            if ($cfg['showfacebook'] === '')
            {
                $cfg['showfacebook'] = null;
            }
            if ($cfg['showtwitter'] === '')
            {
                $cfg['showtwitter'] = null;
            }

            // ulozit
            if (_pluginSaveConfig($plugin, $cfg) !== false)
            {
                $output .= _formMessage(1, $_lang['global.saved']);
            }
            else
                $output .= _formMessage(2, $_lang['global.error']);
        }

        // formular
        $output .= "
			<fieldset id='setform'>
			 <legend>{$_lang['profileplus']['config.main']}</legend>
			<form action='{$url}' method='post'>
			<table class='form'>

			<tr>
			  <td class='rpad'><strong>{$_lang['profileplus']['profile.gender']}</strong></td>
			  <td><input type='checkbox' name='showgender' value='1'" . _checkboxActivate($cfg['showgender']) . " /></td>
			  <td class='lpad'>{$_lang['profileplus']['config.showgender']}</td>
			</tr>

			<tr>
			  <td class='rpad'><strong>{$_lang['profileplus']['profile.residence']}</strong></td>
			  <td><input type='checkbox' name='showresidence' value='1'" . _checkboxActivate($cfg['showresidence']) . " /></td>
			  <td class='lpad'>{$_lang['profileplus']['config.showresidence']}</td>
			</tr>

			<tr>
			  <td class='rpad'><strong>{$_lang['profileplus']['profile.facebook']}</strong></td>
			  <td><input type='checkbox' name='showfacebook' value='1'" . _checkboxActivate($cfg['showfacebook']) . " /></td>
			  <td class='lpad'>{$_lang['profileplus']['config.showfacebook']}</td>
			</tr>

			<tr>
			  <td class='rpad'><strong>{$_lang['profileplus']['profile.twitter']}</strong></td>
			  <td><input type='checkbox' name='showtwitter' value='1'" . _checkboxActivate($cfg['showtwitter']) . " /></td>
			  <td class='lpad'>{$_lang['profileplus']['config.showtwitter']}</td>
			</tr>			 

			</table>

                        " . _xsrfProtect() . "
			<input type='submit' name='save' value='{$_lang['global.save']}' />
			</form>";

        break;

    /* --- SPRAVA --- */
    case 'manage':

        if (!$exists)
        {
            $output .= _formMessage(2, $_lang['profileplus']['manage.installneeded']);
        }
        else
        {
            /* presmerovani */
            if (isset($_GET['r']))
            {
                switch ($_GET['r'])
                {
                    case 1:
                        $output .= _formMessage(1, $_lang['profileplus']['manage.updatesuccessfully'] . " <small>(" . _formatTime(time()) . ")</small>");
                        break;
                }
            }

            /* ulozeni dat do databaze */
            if (isset($_POST['managesubmit']))
            {
                $user = getUserData(DB::esc(_post('uid')));
                $errors = array();

                $residence = DB::esc(_post('residence')); //bydliste
                $gender = _post('gender'); //pohlavi

                $facebook = _htmlStr(trim(_post('facebook')));
                if (mb_strlen($facebook) > 255)
                {
                    $facebook = mb_substr($facebook, 0, 255);
                }
                if ($facebook != "" and !_validateURL("http://{$facebook}"))
                {
                    $facebook = "";
                }
                else
                {
                    $facebook = DB::esc($facebook);
                }

                $twitter = _htmlStr(trim(_post('twitter')));
                if (mb_strlen($twitter) > 255)
                {
                    $twitter = mb_substr($twitter, 0, 255);
                }
                if ($twitter != "" and !_validateURL("http://{$twitter}"))
                {
                    $twitter = "";
                }
                else
                {
                    $twitter = DB::esc($twitter);
                }

                // avatar
                $avatar = $user['avatar'];

                // smazani avataru
                if (_checkboxLoad("removeavatar") && isset($avatar))
                {
                    @unlink(_indexroot . 'pictures/avatars/' . $avatar . '.jpg');
                    $avatar = null;
                }
echo "<pre>";
var_dump($avatar);
var_dump($_FILES);
echo "</pre>";

                // upload avataru
                if (isset($_FILES['avatar']) && is_uploaded_file($_FILES['avatar']['tmp_name']))
                {
                    // zpracovani
                    $avatarUid = _pictureProcess(array(
                        'file_path'     => $_FILES['avatar']['tmp_name'],
                        'file_name'     => $_FILES['avatar']['name'],
                        'limit'         => array('filesize' => 1048576, 'dimensions' => array('x' => 1400, 'y' => 1400)),
                        'resize'        => array('mode' => 'zoom', 'x' => 96, 'y' => 128),
                        'target_path'   => _indexroot . 'pictures/avatars/',
                        'target_format' => 'jpg',
                        'jpg_quality'   => 95,
                    ), $avatarError);

                    if (false !== $avatarUid)
                    {
                        // smazani stareho avataru
                        if (null !== $avatar)
                        {
                            @unlink(_indexroot . 'pictures/avatars/' . $avatar . '.jpg');
                        }

                        // ok
                        $avatar = $avatarUid;
                    }
                    else
                    {
                        $errors[] = $_lang['global.avatar'] . ' - ' . $avatarError;
                    }
                }

                if (count($errors) > 0)
                {
                    $output .= _formMessage(_eventList($errors));
                }
                else
                {
                    $data = array(
                        'avatar'    => (isset($avatar) ? $avatar : null),
                        'facebook'  => $facebook,
                        'twitter'   => $twitter,
                        'residence' => $residence,
                        'gender'    => $gender,
                    );

                    DB::update(_mysql_prefix . "-users", "id=" . $user['id'], $data);
                    define("_redirect_to", "index.php?p=settings-plugins&action=profileplus.manage&r=1&id={$user['username']}");
                    return;
                }
            }

            $output .= "<p class='bborder'>{$_lang['profileplus']['manage.description']}</p>
		            <form action='{$url}' method='POST'>"
                . _xsrfProtect() . "
		            <input type='text' name='id' class='inputmedium' " . (isset($_GET['id']) ? "value='" . _get('id') . "'" : "") . " />
		            <input type='submit' name='openuser' value='{$_lang['global.open']}' />
		            </form>
		            <div class='hr'><hr></div>";

            if (isset($_GET['id']) || isset($_POST['openuser']))
            {
                //otevreni adresou / formularem
                $user_id = (isset($_GET['id']) ? _get('id') : _post('id'));

                // nacteni uzivatelskych dat
                $query = getUserData($user_id);

                $levelconflict = true;

                if (_loginright_adminusers)
                {
                    if (false !== $query)
                    {
                        if ($query['id'] != _loginid)
                        {
                            if (_levelCheck($query['id']))
                            {
                                $levelconflict = false;
                            }
                            else
                            {
                                $levelconflict = true;
                                $output .= _formMessage(3, $_lang['global.disallowed']);
                                break;
                            }
                        }
                        else
                        {
                            define('_redirect_to', _indexroot . 'index.php?m=settings');
                            return;
                        }

                        if (!$levelconflict)
                        {
                            $avatar_path = _getAvatar($query['id'], true, false, true, true);

                            $output .= "
							<form action='{$url}' method='post' name='userform'  enctype='multipart/form-data'>
							<h1>Editujete uživatele: {$query['username']} <a href='../index.php?m=profile&id={$query['username']}' target='_blank'>profil &gt;</a></h1>
							<table class='formtable'>
							
							
							
							<tr>
							<td><strong>{$_lang['profileplus']['profile.gender']}</strong></td>
							<td>
							<select name='gender' >
							<option value='0' " . ($query['gender'] == '0' ? "selected='selected'" : "") . ">{$_lang['profileplus']['profile.gender.man']}</option>
							<option value='1' " . ($query['gender'] == '1' ? "selected='selected'" : "") . ">{$_lang['profileplus']['profile.gender.woman']}</option>
							</select>
							</td>
							
							<td rowspan='6' class='rpad'><strong>" . $_lang['mod.settings.avatar.upload'] . ":</strong> <input type='file' name='avatar' />
							   <div class='avatar'><img src='" . $avatar_path . "' alt='avatar' /></div>
                               <p class='minip'>" . $_lang['mod.settings.avatar.hint'] . "</p><p><label><input type='checkbox' name='removeavatar' value='1' /> " . $_lang['mod.settings.avatar.remove'] . "</label></p>
                            </td>
							</tr>
							
							<tr>
							<td class='rpad'><strong>{$_lang['profileplus']['profile.residence']}</strong></td>
							<td><input type='text' name='residence' class='inputsmall'" . _restorePostValue('residence', $query['residence']) . " /></td>
							</tr>

							<tr>
							<td class='rpad'><strong>{$_lang['profileplus']['profile.facebook']}</strong></td>
							<td><input type='text' name='facebook' class='inputsmall'" . _restorePostValue('facebook', $query['facebook'], false, true, false) . " /> <small>{$_lang['mod.settings.web.hint']}</small></td>
							</tr>
							
							<tr>
							<td class='rpad'><strong>{$_lang['profileplus']['profile.twitter']}</strong></td>
							<td><input type='text' name='twitter' class='inputsmall'" . _restorePostValue('twitter', $query['twitter'], false, true, false) . " /> <small>{$_lang['mod.settings.web.hint']}</small></td>
							</tr>
							
							<tr><td></td><td></td></tr>
							
							<tr>
							<td><input type='hidden' name='uid' value='{$query['username']}'></td>
							<td>" . _xsrfProtect() . "<input type='submit' name='managesubmit' value='{$_lang['global.save']}' /></td>
							<td></td>
							</tr>

							</table>
							</form>	";
                        }
                    }
                    else
                    {
                        $output .= _formMessage(3, $_lang['admin.users.edit.badusername']);
                    }
                }
                else
                {
                    $output .= _formMessage(3, $_lang['global.disallowed']);
                }

            }


        }//konec if $exists

        break;

    /* --- DEINSTALACE --- */
    case 'uninstall':

        $output .= "<p>{$_lang['profileplus']['uninstall']}:</p>
		<ul>
			<li><code>root/plugins/common/profileplus/</code></li>
			<li><code>root/plugins/extend/profileplus/</code></li>
		</ul>";

        if (isset($_POST['uninstallyes']) && ($exists))
        {
            DB::query("ALTER TABLE  `" . _mysql_prefix . "-users` DROP `facebook`,  DROP `twitter`,  DROP `residence`,  DROP `gender`");
            $output .= _formMessage(1, $_lang['profileplus']['uninstall.successfullyremoved']);
        }

        $uninstallform = "
		<fieldset id='uninstallcolumn'><legend>{$_lang['profileplus']['uninstall.legend']}</legend>
		<label>{$_lang['profileplus']['uninstall.description']}</label><br /><br />
		<form action='{$url}' method='post'><input type='submit' name='uninstallyes' value='{$_lang['profileplus']['uninstall.button']}' />" . _xsrfProtect() . "</form>
		</fieldset>";

        $output .= ($exists ? $uninstallform : _formMessage(2, $_lang['profileplus']['uninstall.columnnotexists']));

        break;
}