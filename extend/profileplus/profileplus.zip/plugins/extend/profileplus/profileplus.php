<?php

/* ----  kontrola jadra  ---- */

if (!defined('_core'))
{
    die;
}

SL::$classLoader->registerClass("ProfilePlus", __DIR__ . DIRECTORY_SEPARATOR . "class/ProfilePlus.php");

$profilePlus = new ProfilePlus();

if (true === $profilePlus->isInstalled())
{
    _extend('reg', 'sys.init', function ($args) use ($profilePlus)
    {
        _extend('regm', array(
            'mod.profile.pre'  => array($profilePlus, 'regCustomProfile'),
            'mod.settings.pre' => array($profilePlus, 'regCustomSettings'),
            'mod.reg.pre'      => array($profilePlus, 'regCustomReg'),
            'mod.ulist.pre'    => array($profilePlus, 'regCustomUlist'),
            'tpl.head'         => array($profilePlus, 'onHead'),
        ));
    });
}