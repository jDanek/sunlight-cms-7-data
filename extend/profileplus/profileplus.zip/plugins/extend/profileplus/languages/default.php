<?php

return array(
        'profile.personal'     => 'Osobní',
        'profile.galery'       => 'Galerie',//odstranit (?)
        'profile.editprofile'  => 'upravit svůj profil',
        'profile.gender'       => 'Pohlaví',
        'profile.gender.man'   => 'Muž',
        'profile.gender.woman' => 'Žena',
        'profile.residence'    => 'Bydliště',
        'profile.facebook'     => 'Facebook',
        'profile.twitter'      => 'Twitter',
        'profile.credits'      => 'Kredity',

        'message.new' => 'Napsat zprávu',

        'install.button'          => 'Provést instalaci sloupců do databáze',
        'install.legend'          => 'Instalace sloupců do databáze',
        'install.description'     => 'Přidání sloupců důležitých pro správný chod rozšíření <em>Profile Plus</em>',
        'install.successfullyadd' => 'Provedeno! Sloupce byli úspěšně přidány do databáze.',
        'install.columnexists'    => 'Sloupce v databázi již existují.',

        'uninstall'                     => 'Pro odinstalování pluginu smažte následující adresáře',
        'uninstall.button'              => 'Odebrat sloupce z databáze',
        'uninstall.legend'              => 'Instalace sloupců do databáze',
        'uninstall.description'         => 'Odebrání sloupců z databáze pro rozšíření <em>Profile Plus</em>',
        'uninstall.successfullyremoved' => 'Sloupce byli úspěšně odebrány.',
        'uninstall.columnnotexists'     => 'Sloupce v databázi neexistují.',

        'manage.installneeded'      => 'Nejprve je nezbytné provést instalaci sloupců do databáze',
        'manage.description'        => 'Editaci uživatelského profilu můžete provést, až po zapsání uživatelského jména (<em>username</em>), které chcete editovat',
        'manage.updatesuccessfully' => 'Provedeno! Data byla aktualizována.',

        'config.main'          => 'Hlavní nastavení',
        'config.showgender'    => 'povolit zobrazení pohlaví uživatele v profilu',
        'config.showresidence' => 'povolit zobrazení bydliště v profilu',
        'config.showfacebook'  => 'povolit zobrazení odkazu na Facebook profil',
        'config.showtwitter'   => 'povolit zobrazení odkazu na Twitter profil',
        'config.showcredits'   => '( nedostupné! ) - plánovaná funkce',
);