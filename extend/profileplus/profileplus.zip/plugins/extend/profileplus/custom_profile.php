<?php

/* ----  kontrola jadra  ---- */

if (!defined('_core'))
{
    die;
}

global $_lang;
$profilePlus = new ProfilePlus();

$form = false;
$message = "";
$id = null;

if (isset($_GET['id']))
{
    $id = DB::esc($_GET['id']);
    $query = DB::query_row("SELECT * FROM `" . _mysql_prefix . "-users` WHERE username='{$id}'");

    if (false !== $query)
    {
        //$query = DB::row($query);
        $groupdata = DB::query_row("SELECT title,descr,icon,color,blocked FROM `" . _mysql_prefix . "-groups` WHERE id={$query['group']}");
        $form = true;

        if (empty($query['note']))
            $note = "";
        else
            $note = "<tr valign='top'><td>" . $profilePlus->getIcon('note') . " <strong>{$_lang['global.note']}</strong></td><td><div class='note'>" . _parsePost($query['note']) . "</div></td></tr>";

        $query['avatar'] = _getAvatar($query['id'], true, false, true);
        $arts = DB::result(DB::query("SELECT COUNT(*) FROM `" . _mysql_prefix . "-articles` AS art WHERE author={$query['id']} AND " . _sqlArticleFilter()), 0);

        $avgrate = $_lang['article.rate.nodata'];
        if ($arts != 0)
        {
            $avgrate = DB::result(DB::query("SELECT ROUND(SUM(ratesum)/SUM(ratenum)) FROM `" . _mysql_prefix . "-articles` WHERE rateon=1 AND ratenum!=0 AND confirmed=1 AND author={$query['id']}"), 0);
            if ($avgrate === null)
            {
                $avgrate = $_lang['article.rate.nodata'];
            }
            else
            {
                $avgrate = "&Oslash; {$avgrate}%";
            }
        }
        $posts_count = DB::result(DB::query("SELECT COUNT(id) FROM `" . _mysql_prefix . "-posts` WHERE `author`='{$query['id']}' AND `type`!=6 AND `type`!=4"), 0);
    }
    else
    {
        $message = _formMessage(2, $_lang['global.baduser']);
        $found = false;
    }
}


/* standard profil */
if (_template_autoheadings == 1)
{
    $module .= "<h1>" . (empty($query['publicname']) ? $query['username'] : $query['publicname']) . "</h1>";
}

if ($form == true)
{
    if ($query['blocked'] == 1 or $groupdata['blocked'] == 1)
    {
        $module .= "\n<strong class='important'>{$_lang['mod.profile.blockednote']}</strong><br /><br />\n";
    }

    // argumenty pro nove sloty
    unset($query['password'], $query['salt']); //odebrani informaci o hesle a saltu
    $profilePlusArgs = array('user' => $query, 'group' => $groupdata);

    // moznost vlastniho nastaveni nekterych vlastnosti
    $settings = array(
        'avatar' => _getAvatar($query['id'], true, false, true),
    );

    // pole s daty pro generovani tabulek
    $userDataArray = array(
        'username'   => array(
            'show'  => true,
            'icon'  => null,
            'title' => $_lang['login.username'],
            'value' => $query['username'],
        ),
        'publicname' => array(
            'show'  => (!empty($query['publicname'])),
            'icon'  => null,
            'title' => $_lang['mod.settings.publicname'],
            'value' => $query['publicname'],
        ),
        'group'      => array(
            'show'  => true,
            'icon'  => null,
            'title' => $_lang['global.group'],
            'value' => (!empty($groupdata['icon']) ? "<img src='" . _indexroot . "pictures/groupicons/{$groupdata['icon']}' alt='icon' class='icon' /> " : '') . (($groupdata['color'] !== '') ? "<span style='color:{$groupdata['color']};'>{$groupdata['title']}</span>" : $groupdata['title']),
        ),
        'groupdescr' => array(
            'show'  => (!empty($groupdata['descr'])),
            'icon'  => null,
            'title' => $_lang['mod.profile.groupdescr'],
            'value' => $groupdata['descr'],
        ),
        'lastact'    => array(
            'show'  => true,
            'icon'  => null,
            'title' => $_lang['mod.profile.lastact'],
            'value' => _formatTime($query['activitytime']) . " <span>(" . ($profilePlus->userIsOnline($query['id']) ? "Online" : "Offline") . ")</span>",
        ),
        'gender'     => array(
            'show'  => _boolean($profilePlus->getConfigAdminValue('showgender')),
            'icon'  => null,
            'title' => $_lang['profileplus']['profile.gender'],
            'value' => $profilePlus->getIcon("gender{$query['gender']}") . " " . ($query['gender'] == '0' ? $_lang['profileplus']['profile.gender.man'] : $_lang['profileplus']['profile.gender.woman'])),
    );

    $contactUserArray = array(
        'residence' => array(
            'show'  => (!empty($query['residence']) && _boolean($profilePlus->getConfigAdminValue('showresidence'))),
            'icon'  => $profilePlus->getIcon('residence'),
            'title' => $_lang['profileplus']['profile.residence'],
            'value' => $query['residence'],
        ),
        'email'     => array(
            'show'  => _profileemail,
            'icon'  => $profilePlus->getIcon('email'),
            'title' => $_lang['global.email'],
            'value' => _mailto($query['email']),
        ),
        'icq'       => array(
            'show'  => ($query['icq'] != 0),
            'icon'  => $profilePlus->getIcon('icq'),
            'title' => $_lang['global.icq'],
            'value' => $query['icq'] . "<img src='http://status.icq.com/online.gif?icq={$query['icq']}&amp;img=5' alt='icq status' class='icon' />",
        ),
        'skype'     => array(
            'show'  => !empty($query['skype']),
            'icon'  => $profilePlus->getIcon('skype'),
            'title' => $_lang['global.icq'],
            'value' => $query['skype'],
        ),
        'msn'       => array(
            'show'  => !empty($query['msn']),
            'icon'  => $profilePlus->getIcon('msn'),
            'title' => $_lang['global.msn'],
            'value' => _mailto(_htmlStr($query['msn'])),
        ),
        'jabber'    => array(
            'show'  => !empty($query['jabber']),
            'icon'  => $profilePlus->getIcon('jabber'),
            'title' => $_lang['global.jabber'],
            'value' => _mailto(_htmlStr($query['jabber'])),
        ),
        'facebook'  => array(
            'show'  => !empty($query['facebook']) && _boolean($profilePlus->getConfigAdminValue('showfacebook')),
            'icon'  => $profilePlus->getIcon('facebook'),
            'title' => $_lang['profileplus']['profile.facebook'],
            'value' => "<a href='http://{$query['facebook']}' target='_blank' rel='nofollow'>" . _cutStr($query['facebook'], 32) . "</a>",
        ),
        'twitter'   => array(
            'show'  => !empty($query['twitter']) && _boolean($profilePlus->getConfigAdminValue('showtwitter')),
            'icon'  => $profilePlus->getIcon('twitter'),
            'title' => $_lang['profileplus']['profile.twitter'],
            'value' => "<a href='http://{$query['twitter']}' target='_blank' rel='nofollow'>" . _cutStr($query['twitter'], 32) . "</a>",
        ),
        'web'       => array(
            'show'  => !empty($query['web']),
            'icon'  => $profilePlus->getIcon('web'),
            'title' => $_lang['global.web'],
            'value' => "<a href='http://{$query['web']}' target='_blank' rel='nofollow'>" . _cutStr($query['web'], 32) . "</a>",
        ),
    );

    $statsUserArray = array(
        'register'   => array(
            'show'  => true,
            'icon'  => $profilePlus->getIcon('register'),
            'title' => $_lang['mod.profile.regtime'],
            'value' => _formatTime($query['registertime']),
        ),
        'comments'   => array(
            'show'  => true,
            'icon'  => $profilePlus->getIcon('comments'),
            'title' => $_lang['global.postsnum'],
            'value' => $posts_count . ($posts_count > 0 ? ", <a href='index.php?m=profile-posts&amp;id={$id}'>{$_lang['global.show']} &gt;</a>" : ""),
        ),
        'arts'       => array(
            'show'  => $arts > 0,
            'icon'  => $profilePlus->getIcon('articles'),
            'title' => $_lang['global.articlesnum'],
            'value' => $arts . ", <a href='index.php?m=profile-arts&amp;id={$id}'>{$_lang['global.show']} &gt;</a>",
        ),
        'ratting'    => array(
            'show'  => ($arts > 0 && _ratemode != 0),
            'icon'  => $profilePlus->getIcon('ratting'),
            'title' => $_lang['article.rate'],
            'value' => $avgrate,
        ),
        'logincount' => array(
            'show'  => true,
            'icon'  => $profilePlus->getIcon('logincount'),
            'title' => $_lang['mod.profile.logincounter'],
            'value' => $query['logincounter'] . "x",
        ),
        'note'       => array(
            'show'  => !empty($query['note']),
            'icon'  => $profilePlus->getIcon('note'),
            'title' => $_lang['global.note'],
            'value' => "<div class='note'>" . _parsePost($query['note']) . "</div>",
        ),
    );

    // extend pro upravu hodnot
    _extend('call', 'profileplus.profile.edit', array(
        'userdata' => $profilePlusArgs,
        'settings' => &$settings,
        'tables'   => array(
            'basic' => &$userDataArray,
            'links' => &$contactUserArray,
            'stats' => &$statsUserArray,
        ),
    ));

    /* zakladni informace */
    $output = "<table>"
        . ((_loginindicator) && (_loginid == $query['id']) ? "<div align='right'><a href='./index.php?m=settings' class='pp-usermenu-settings'>{$_lang['profileplus']['profile.editprofile']}</a></div>" : "")
        . (_loginindicator && (_loginid != $query['id']) && _levelCheck(_loginid) && _loginright_administration && _loginright_adminusers ? "
	  <div align='right'>
	  <a href='./admin/index.php?p=users-edit&id={$query['username']}' class='user-action-useredit' title='Vstup do administrace - úprava uživatelského profilu'>Upravit</a> &bull; 
	  <a href='./admin/index.php?p=settings-plugins&action=profileplus.manage&id={$query['username']}' class='user-action-useredit' title='Vstup do administrace - úprava uživatelské rozšířené nabídky Profile+ pluginu'>Upravit rozšířené</a>
	  </div>" : "")
        . "<tr valign='top'>
	  <td class='avatartd'>
	    <div class='avatar'>
	        <img src='{$settings['avatar']}' alt='avatar' />
	    </div>
	  </td>
	  <td>"
        . $profilePlus->generateTable($userDataArray, 'profiletable')
        . "</td></tr></table>";
    $output .= "<div class='hr'><hr /></div>";

    /* kontaktní informace */
    $output .= "
	 <div class='wlimiter'><table class='profiletable'>"

        . _extend('buffer', 'profileplus.links.before', $profilePlusArgs)
        . $profilePlus->generateTable($contactUserArray, '', true)
        . _extend('buffer', 'profileplus.links', $profilePlusArgs) // kompatibilita s v1.4
        . _extend('buffer', 'profileplus.links.after', $profilePlusArgs)

        . _extend('buffer', 'profileplus.stats.before', $profilePlusArgs)
        . $profilePlus->generateTable($statsUserArray, '', true)
        . _extend('buffer', 'profileplus.stats.after', $profilePlusArgs)

        // kompatibilita s v1.4
        . _extend('buffer', 'profileplus.notes.before', $profilePlusArgs)
        . _extend('buffer', 'profileplus.notes.after', $profilePlusArgs)

        . "</table></div> ";

    //napsat vzkaz
    if (_loginindicator && _messages && $query['id'] != _loginid && $query['blocked'] == 0 && $groupdata['blocked'] == 0)
    {
        $output .= "<p><img src ='" . _templateImage("icons/bubble.png") . "' alt= 'msg' class= 'icon' /><a href = 'index.php?m=messages&amp;a=new&amp;receiver={$query['username']}' >{$_lang['mod.messages.new']} &gt;</a ></p > ";
    }
}
$module .= $output;
