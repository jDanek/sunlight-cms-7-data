=== ProfilePlus ===
Verze 1.4
Autor: 	Jirka Dan�k
Web: 	http://jdanek.eu/

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Jde o rozsireni obsahove casti profilu o pohlavi, Facebook, Twitter, bydliste a aktivitu uzivatele

== Instalace ==
	Nahrajte obsah adresare do korenoveho adresare
	V administraci je nutne provest instalaci pluginu, instalace prida do databaze sloupecky pro nova data

== Odinstalace ==
	odstrante nasledujici adresare ze serveru:
		plugins/extend/profileplus
		plugins/common/profileplus

== Changelog ==
Verze 1.4
[update] "sloty" doplneny o informace o uzivateli a skupine, neni jiz potreba extra dotaz pro ziskani ID
Verze 1.3
[update] aktualizace overloadovanych skriptu dle systemu
[news] pridan sloty pro vypis vlastniho obsahu na profilu
	"profileplus.links" - za odkazy na sluzby
	"profileplus.notes.before" - pred poznamkami
	"profileplus.notes.after" - za poznamkami
Verze 1.2
[update] plugin upraven pro SL 7.5.4