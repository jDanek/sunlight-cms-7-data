<?php return array(
    'showgender'    => 1,
    'showresidence' => 1,
    'showfacebook'  => 1,
    'showtwitter'   => 1,
    'showcredits'   => 0,
);