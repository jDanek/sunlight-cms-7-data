<?php

/* ----- kontrola jadra ----- */

if (!defined('_core'))
{
    die;
}

global $_lang;

/* ----- akce ----- */
$profilePlus = new ProfilePlus();
$exists = $profilePlus->isInstalled(); //výsledek testu sloupcu
// cara
$output .= '<p class="bborder"></p>';

// formular
switch ($action) {

    /* --- INSTALACE --- */
    case 'install':

        if (isset($_POST['installyes']) && (!$exists))
        {
            DB::query("ALTER TABLE `" . _mysql_prefix . "-users` ADD `facebook` tinytext NOT NULL, ADD `twitter` tinytext NOT NULL, ADD `residence` varchar(50) NOT NULL, ADD `gender` tinyint(1) NOT NULL DEFAULT '0', ADD  `credits` INT( 11 ) NOT NULL DEFAULT  '0'");
            $output .= _formMessage(1, $_lang['profileplus']['install.successfullyadd']);
        }

        $installform = "
		<fieldset id='installcolumn'><legend>{$_lang['profileplus']['install.legend']}</legend>
		<label>{$_lang['profileplus']['install.description']}</label><br /><br />
		<form action='{$url}' method='post'><input type='submit' name='installyes' value='{$_lang['profileplus']['install.button']}' />" . _xsrfProtect() . "</form>
		</fieldset>";

        $output .= (!$exists ? $installform : _formMessage(2, $_lang['profileplus']['install.columnexists']));

        break;

    /* --- KONFIGURACE --- */
    case 'config':

        // nacteni konfigurace
        $cfg = _pluginLoadConfig($plugin);

        // ulozeni
        if (isset($_POST['save']))
        {

            // nacist
            $cfg['showgender'] = _checkboxLoad('showgender');
            $cfg['showresidence'] = _checkboxLoad('showresidence');
            $cfg['showfacebook'] = _checkboxLoad('showfacebook');
            $cfg['showtwitter'] = _checkboxLoad('showtwitter');
            $cfg['showcredits'] = _checkboxLoad('showcredits');

            // zpracovat
            if ($cfg['showgender'] === '')
            {
                $cfg['showgender'] = null;
            }
            if ($cfg['showresidence'] === '')
            {
                $cfg['showresidence'] = null;
            }
            if ($cfg['showfacebook'] === '')
            {
                $cfg['showfacebook'] = null;
            }
            if ($cfg['showtwitter'] === '')
            {
                $cfg['showtwitter'] = null;
            }
            if ($cfg['showcredits'] === '')
            {
                $cfg['showcredits'] = null;
            }

            // ulozit
            if (_pluginSaveConfig($plugin, $cfg) !== false)
            {
                $output .= _formMessage(1, $_lang['global.saved']);
            }
            else
                $output .= _formMessage(2, $_lang['global.error']);
        }

        // formular
        $output .= "
			<fieldset id='setform'>
			 <legend>{$_lang['profileplus']['config.main']}</legend>
			<form action='{$url}' method='post'>
			<table class='form'>

			<tr>
			  <td class='rpad'><strong>{$_lang['profileplus']['profile.gender']}</strong></td>
			  <td><input type='checkbox' name='showgender' value='1'" . _checkboxActivate($cfg['showgender']) . " /></td>
			  <td class='lpad'>{$_lang['profileplus']['config.showgender']}</td>
			</tr>

			<tr>
			  <td class='rpad'><strong>{$_lang['profileplus']['profile.residence']}</strong></td>
			  <td><input type='checkbox' name='showresidence' value='1'" . _checkboxActivate($cfg['showresidence']) . " /></td>
			  <td class='lpad'>{$_lang['profileplus']['config.showresidence']}</td>
			</tr>

			<tr>
			  <td class='rpad'><strong>{$_lang['profileplus']['profile.facebook']}</strong></td>
			  <td><input type='checkbox' name='showfacebook' value='1'" . _checkboxActivate($cfg['showfacebook']) . " /></td>
			  <td class='lpad'>{$_lang['profileplus']['config.showfacebook']}</td>
			</tr>

			<tr>
			  <td class='rpad'><strong>{$_lang['profileplus']['profile.twitter']}</strong></td>
			  <td><input type='checkbox' name='showtwitter' value='1'" . _checkboxActivate($cfg['showtwitter']) . " /></td>
			  <td class='lpad'>{$_lang['profileplus']['config.showtwitter']}</td>
			</tr>

			<tr>
			  <td class='rpad'><strong>{$_lang['profileplus']['profile.credits']}</strong></td>
			  <td><input type='checkbox' name='showcredits' value='1'" . _checkboxActivate($cfg['showcredits']) . " disabled='disabled' /></td>
			  <td class='lpad'>{$_lang['profileplus']['config.showcredits']}</td>
			</tr>
			 

			</table>

                        " . _xsrfProtect() . "
			<input type='submit' name='save' value='{$_lang['global.save']}' />
			</form>";

        break;

    /* --- SPRAVA --- */
    case 'manage':

        if (!$exists)
        {
            $output .= _formMessage(2, $_lang['profileplus']['manage.installneeded']);
        }
        else
        {

            /* ukladani dat do DB */
            if (isset($_POST['managesubmit']))
            {

                $username = DB::esc($_POST['val']); //bydliste

                $credits = DB::esc($_POST['credits']); //bydliste
                $residence = DB::esc($_POST['residence']); //bydliste
                $gender = $_POST['gender']; //pohlavi

                $facebook = _htmlStr(trim($_POST['facebook']));
                if (mb_strlen($facebook) > 255)
                {
                    $facebook = mb_substr($facebook, 0, 255);
                }
                if ($facebook != "" and ! _validateURL("http://{$facebook}"))
                {
                    $facebook = "";
                }
                else
                {
                    $facebook = DB::esc($facebook);
                }

                $twitter = _htmlStr(trim($_POST['twitter']));
                if (mb_strlen($twitter) > 255)
                {
                    $twitter = mb_substr($twitter, 0, 255);
                }
                if ($twitter != "" and ! _validateURL("http://{$twitter}"))
                {
                    $twitter = "";
                }
                else
                {
                    $twitter = DB::esc($twitter);
                }

                DB::query("UPDATE `" . _mysql_prefix . "-users` SET facebook='{$facebook}',twitter='{$twitter}',residence='{$residence}',gender='{$gender}',credits='{$credits}' WHERE username='{$username}'");
                define("_redirect_to", "index.php?p=settings-plugins&action=profileplus.manage&r=1&id={$username}");
                return;
            }

            if (isset($_GET['r']))
            {
                switch ($_GET['r']) {
                    case 1:
                        $output .= _formMessage(1, $_lang['profileplus']['manage.updatesuccessfully'] . " <small>(" . _formatTime(time()) . ")</small>");
                        $_POST['id'] = $_GET['id'];
                        break;
                }
            }

            $output .= "
		<p class='bborder'>{$_lang['profileplus']['manage.description']}</p>
		<form action='{$url}' method='post'>
		" . _xsrfProtect() . "
		<input type='text' name='id' class='inputmedium' " . (isset($_GET['id']) ? "value='{$_GET['id']}'" : "") . " /> <input type='submit' value='{$_lang['global.open']}' />
		</form>";

            $levelconflict = true;

            if (isset($_GET['id']))
            {
                $_POST['id'] = $_GET['id'];
            }

            if (isset($_POST['id']))
            {
                $id = DB::esc(_anchorStr($_POST['id'], false));
                $userid = DB::esc(_anchorStr($_POST['id'], false));
                $query = DB::query("SELECT * FROM `" . _mysql_prefix . "-users` WHERE username='{$id}'");

                if (_loginright_adminusers)
                {
                    if (DB::size($query) != 0)
                    {
                        $query = DB::row($query);

                        if ($query['id'] != _loginid)
                        {

                            if (_levelCheck($query['id']))
                            {
                                $levelconflict = false;
                            }
                            else
                            {
                                $levelconflict = true;
                                $output .= _formMessage(3, $_lang['global.disallowed']);
                                break;
                            }
                        }
                        else
                        {
                            define('_redirect_to', _indexroot . 'index.php?m=settings');
                            return;
                        }

                        if (!$levelconflict)
                        {
                            $output .= "
							<form action='{$url}' method='post' name='userform'" . _jsCheckForm("userform", ($id != null ? array("username", "email") : array("username", "email", "password"))) . ">
							<h1>Editujete uživatele: {$query['username']}</h1>
							<table class='formtable'>
							
							<input type='hidden' name='val' value='{$query['username']}'>
							
							<tr>
							<td><strong>{$_lang['profileplus']['profile.gender']}</strong></td>
							<td>
							<select name='gender' >
							<option value='0' " . ($query['gender'] == '0' ? "selected='selected'" : "") . ">{$_lang['profileplus']['profile.gender.man']}</option>
							<option value='1' " . ($query['gender'] == '1' ? "selected='selected'" : "") . ">{$_lang['profileplus']['profile.gender.woman']}</option>
							</select>
							</td>
							</tr>
							
							<tr>
							<td class='rpad'><strong>{$_lang['profileplus']['profile.credits']}</strong></td>
							<td><input type='text' name='credits' class='inputsmall'" . _restorePostValue('credits', $query['credits']) . " /></td>
							</tr>

							<tr>
							<td class='rpad'><strong>{$_lang['profileplus']['profile.residence']}</strong></td>
							<td><input type='text' name='residence' class='inputsmall'" . _restorePostValue('residence', $query['residence']) . " /></td>
							</tr>

							<tr>
							<td class='rpad'><strong>{$_lang['profileplus']['profile.facebook']}</strong></td>
							<td><input type='text' name='facebook' class='inputsmall'" . _restorePostValue('facebook', $query['facebook'], false, true, false) . " /> <small>{$_lang['mod.settings.web.hint']}</small></td>
							</tr>
							
							<tr>
							<td class='rpad'><strong>{$_lang['profileplus']['profile.twitter']}</strong></td>
							<td><input type='text' name='twitter' class='inputsmall'" . _restorePostValue('twitter', $query['twitter'], false, true, false) . " /> <small>{$_lang['mod.settings.web.hint']}</small></td>
							</tr>
							
							<tr><td></td>
							<td>" . _xsrfProtect() . "<input type='submit' name='managesubmit' value='{$_lang['global.save']}' /></td>
							</tr>

							</table>
							</form>	";
                        }
                    }
                    else
                    {
                        $output .= _formMessage(3, $_lang['admin.users.edit.badusername']);
                    }
                }
                else
                {
                    $output .= _formMessage(3, $_lang['global.disallowed']);
                }
            }//konec post id
        }//konec if $exists

        break;

    /* --- DEINSTALACE --- */
    case 'uninstall':

        $output .= "<p>{$_lang['profileplus']['uninstall']}:</p>
		<ul>
			<li><code>root/plugins/common/profileplus/</code></li>
			<li><code>root/plugins/extend/profileplus/</code></li>
		</ul>";

        if (isset($_POST['uninstallyes']) && ($exists))
        {
            DB::query("ALTER TABLE  `" . _mysql_prefix . "-users` DROP `facebook`,  DROP `twitter`,  DROP `residence`,  DROP `gender`,  DROP `credits`");
            $output .= _formMessage(1, $_lang['profileplus']['uninstall.successfullyremoved']);
        }

        $uninstallform = "
		<fieldset id='uninstallcolumn'><legend>{$_lang['profileplus']['uninstall.legend']}</legend>
		<label>{$_lang['profileplus']['uninstall.description']}</label><br /><br />
		<form action='{$url}' method='post'><input type='submit' name='uninstallyes' value='{$_lang['profileplus']['uninstall.button']}' />" . _xsrfProtect() . "</form>
		</fieldset>";

        $output .= ($exists ? $uninstallform : _formMessage(2, $_lang['profileplus']['uninstall.columnnotexists']));

        break;
}