<?php

return array(
    'name'    => 'Profile Plus',
    'descr'   => 'Rozšiřuje možnosti uživatelských profilů (bydliště, pohlaví, facebook, twitter, kredity)',
    'version' => '1.4',
    'author'  => 'Jirka Daněk',
    'url'     => 'http://jdanek.eu',
    'actions' => array('install', 'config', 'manage', 'uninstall'),
);