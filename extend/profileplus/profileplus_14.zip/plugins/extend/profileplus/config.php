<?php

return array(

    // mapa dostupnych lokalizaci
    'lang_map' => array(
        'default' => 'cs',
    ),

    'pluginname'    => 'Profile Plus', // jmeno pluginu
    'plugin_dir'    => _indexroot . 'plugins/extend/profileplus/', // adresar pluginu
    'plugin_images' => _indexroot . 'plugins/extend/profileplus/images/', // adresar obrazku
    'plugin_icons'  => _indexroot . 'plugins/extend/profileplus/images/icons/', // adresar ikonek

);