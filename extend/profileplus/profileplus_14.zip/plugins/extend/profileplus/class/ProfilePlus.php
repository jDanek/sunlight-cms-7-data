<?php

/**
 * ProfilePlus extend
 * 
 * @author Jirka Daněk <jdanek.eu>
 */
class ProfilePlus
{

    const IDENITIFIER = 'profileplus';

    private $root;

    /** @var array */
    private $config = array();

    /** @var array */
    private $configAdmin = array();

    /** @var array */
    private $requiredColumns = array("gender", "facebook", "twitter", "residence", "credits");

    function __construct()
    {
        $this->root = _indexroot . "plugins/extend/profileplus/";
        $this->config = require $this->root . "config.php";
        $this->configAdmin = require _plugin_dir . 'profileplus/config.php';

        _registerLangPack("profileplus", $this->root . "languages/");
    }

    /**
     * Ziskat nastaveni podle klice
     * 
     * @param string $key
     * @return mixed|null
     */
    public function getConfigValue($key)
    {
        if (isset($this->config[$key]))
        {
            return $this->config[$key];
        }
        return null;
    }

    /**
     * Ziskat admin nastaveni podle klice
     * @param type $key
     * @return mixed|null
     */
    public function getConfigAdminValue($key)
    {
        if (isset($this->configAdmin[$key]))
        {
            return $this->configAdmin[$key];
        }
        return null;
    }

    /**
     * Overeni zda ma extend nainstalovane potrebne databazove sloupce
     * 
     * @return boolean
     */
    public function isInstalled()
    {
        $exist = false;

        $query = DB::query("SHOW COLUMNS FROM `" . _mysql_prefix . "-users`");
        while ($row = DB::row($query))
        {
            if (in_array($row['Field'], $this->requiredColumns))
            {
                $exist = true;
            }
        }
        return $exist;
    }

    /**
     * Ziskani nastaveni
     * @return array
     */
    public function getConfig()
    {
        return $this->config;
    }

    /**
     * Ziskani nastaveni administrace
     * @return array
     */
    public function getConfigAdmin()
    {
        return $this->configAdmin;
    }

    /**
     * Ziskani ikonky
     * 
     * @param string $imgname
     * @return string
     */
    public function getIcon($imgname = null)
    {
        $imgname = (($imgname === null) ? 'blank' : $imgname);
        return "<img src='{$this->config['plugin_icons']}{$imgname}.png' alt='ikonka' class='pp-icons' />";
    }

    /**
     * Ziskani stavu online/offline podle posledni aktivity (orientacni informace)
     * 
     * @param int $id
     * @param int $time
     * @return string
     */
    public function userIsOnline($id, $time = 300)
    {
        $query = DB::query_row("SELECT activitytime FROM `" . _mysql_prefix . "-users` WHERE id=" . DB::esc($id));
        return (time() - $query['activitytime'] < $time ? true : false);
    }

    /**
     * Vlastni stylovani uzivatelskeho seznamu
     * 
     * @global array $_lang
     * @param int $id
     * @param string|null $username
     * @return string
     */
    public function userListView($id = null, $username = null)
    {
        global $_lang;

        return "<li class='user'>
                    <div class='view'>
                        <div class='row'>
                            <div class='user-name'>" . _linkUser($id) . "
                                <span " . ($this->userIsOnline($id) ? "class='user-online' title='Online'" : "class='user-offline' title='Offline'") . "></span>
                            </div>
                        </div>
                        <a class='user-link' href='./index.php?m=profile&id={$username}'>
                            <div class='row user-info'>
                                <div class='user-image'>
                                    <img src='" . _getAvatar($id, true) . "' />
                                </div>
                            </div>
                        </a>
                    <div class='row user-actions'>
                        " . (_loginindicator && _messages ? "<a href='./index.php?m=messages&a=new&receiver={$username}' class='user-action-message'>{$_lang['profileplus']['message.new']} ></a>" : "") . "
                    </div> 
                    </div>
                </li>";
    }

    //=========================================================================

    /**
     * Overload modulu profile
     * 
     * @param array $args
     */
    public function regCustomProfile($args)
    {
        $args['extra']['mid'] = 'pplus';
        $args['extra']['custom'] = true;
        $args['extra']['file'] = $this->root . 'custom_profile.php';
    }

    /**
     * Overload modulu settings
     * 
     * @param array $args
     */
    public function regCustomSettings($args)
    {
        $args['extra']['mid'] = 'pplusedit';
        $args['extra']['custom'] = true;
        $args['extra']['file'] = $this->root . 'custom_settings.php';
    }

    /**
     * Overload modulu registrace
     * 
     * @param array $args
     */
    public function regCustomReg($args)
    {
        $args['extra']['mid'] = 'pplusreg';
        $args['extra']['custom'] = true;
        $args['extra']['file'] = $this->root . 'custom_reg.php';
    }

    /**
     * Overload modulu ulist
     * 
     * @param array $args
     */
    public function regCustomUlist($args)
    {
        $args['extra']['mid'] = 'pplusulist';
        $args['extra']['custom'] = true;
        $args['extra']['file'] = $this->root . 'custom_ulist.php';
    }

    /**
     * Registrace CSS a JS
     * 
     * @param array $args
     */
    public function onHead($args)
    {
        $args['output'] .= "<link href='{$this->root}style/style.css?" . _cacheid . "' type='text/css' rel='stylesheet' />";
    }

}
