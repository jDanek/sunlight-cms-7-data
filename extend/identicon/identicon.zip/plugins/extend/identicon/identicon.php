<?php

if (!defined('_core'))
{
    die;
}

// registrace Identicon
SL::$classLoader->registerBaseNamespace('Identicon', __DIR__ . '/lib/src/Identicon');

/**
 * Class IdenticonPlugin
 * @author Jirka Danek <jdanek.eu>
 */
class IdenticonPlugin
{

    /**
     * @param $string
     * @return string
     */
    public function generateIdenticon($string, $size = 96, $color = null)
    {
        $identicon = new Identicon\Identicon();
        $imageDataUri = $identicon->getImageDataUri(md5(strtolower($string)), $size, $color);
        return $imageDataUri;

    }

    /**
     * @param $args
     * @return bool
     */
    public function identiconDisplay($args)
    {
        // nahrazeni systemoveho avataru
        if (isset($args['udata']['avatar_mode'], $args['udata']['email']) && $args['udata']['avatar_mode'] == 2)
        {
            $color = ($args['udata']['color'] != "" ? str_replace('#', '', ColorHelper::getHexFromName($args['udata']['color'])) : null);
            $identicon = $this->generateIdenticon($args['udata']['email'], 96, $color);
            if ($args['path_only'])
            {
                $args['return'] = $identicon;
            }
            else
            {
                $args['return'] = "<a href='" . _indexroot . "index.php?m=profile&amp;id=" . $args['udata']['username'] . "'><img src='" . $identicon . "' alt='" . $args['udata']['username'] . "' class='avatar2' /></a>";
            }
        }

        // dalsi pluginy se nevolaji
        return false;
    }

    /**
     * @param $args
     */
    public function userCache($args)
    {
        $args['extend'][] = array(array('u.avatar_mode', 'u.email', 'g.color'));
    }

    /**
     * @param $args
     * @return bool
     */
    public function settingsEdit($args)
    {
        // lokalizace
        static $lang = array( //
            'en' => array('type' => 'Avatar type', 'sys' => 'system', 'identicon' => 'Identicon'), //
            'cs' => array('type' => 'Typ avataru', 'sys' => 'systémový', 'identicon' => 'Identicon'), //
        );
        $lid = _getLang($lang);

        // vystup
        $args['output'] .= "<table>
<tr valign='top'>
    <td rowspan='2'><strong>" . $lang[$lid]['type'] . ":</strong></td>
    <td><label><input type='radio' name='avatar_mode' id='user_settings_avatar_mode_sys'" . _checkboxActivate($args['extra']['query']['avatar_mode'] == 0) . " value='0' /> " . $lang[$lid]['sys'] . "</label></td>
    <td><label><input type='radio' name='avatar_mode' id='user_settings_avatar_mode_identicon'" . _checkboxActivate($args['extra']['query']['avatar_mode'] == 2) . " value='2' /> " . $lang[$lid]['identicon'] . "</label></td>
</tr>

<tr valign='top'>
    <td><label for='user_settings_avatar_mode_sys'>" . _getAvatar($args['extra']['query']['id'], false, false, true, true, true) . "</label></td>
    <td><label for='user_settings_avatar_mode_identicon'><img src='" . $this->generateIdenticon($args['extra']['query']['email']) . "' alt='identicon' /></label></td>
</tr>
</table>

<div class='hr'><hr /></div>";

        // dalsi pluginy se nevolaji
        return false;
    }

    /**
     * @param $args
     */
    public function settingsSubmit($args)
    {
        // nacist zmenu
        if (isset($_POST['avatar_mode']) && $_POST['avatar_mode'] == 2)
        {
            $new_mode = 2;
        }
        else
        {
            $new_mode = 0;
        }

        // vlozit do query
        if ($new_mode != $args['current_query']['avatar_mode'])
        {
            $args['query']['avatar_mode'] = $new_mode;
        }
    }

}

class ColorHelper
{
    /** @var array standard 147 HTML color names */
    private static $colors = array(
        'aliceblue'            => 'F0F8FF',
        'antiquewhite'         => 'FAEBD7',
        'aqua'                 => '00FFFF',
        'aquamarine'           => '7FFFD4',
        'azure'                => 'F0FFFF',
        'beige'                => 'F5F5DC',
        'bisque'               => 'FFE4C4',
        'black'                => '000000',
        'blanchedalmond '      => 'FFEBCD',
        'blue'                 => '0000FF',
        'blueviolet'           => '8A2BE2',
        'brown'                => 'A52A2A',
        'burlywood'            => 'DEB887',
        'cadetblue'            => '5F9EA0',
        'chartreuse'           => '7FFF00',
        'chocolate'            => 'D2691E',
        'coral'                => 'FF7F50',
        'cornflowerblue'       => '6495ED',
        'cornsilk'             => 'FFF8DC',
        'crimson'              => 'DC143C',
        'cyan'                 => '00FFFF',
        'darkblue'             => '00008B',
        'darkcyan'             => '008B8B',
        'darkgoldenrod'        => 'B8860B',
        'darkgray'             => 'A9A9A9',
        'darkgreen'            => '006400',
        'darkgrey'             => 'A9A9A9',
        'darkkhaki'            => 'BDB76B',
        'darkmagenta'          => '8B008B',
        'darkolivegreen'       => '556B2F',
        'darkorange'           => 'FF8C00',
        'darkorchid'           => '9932CC',
        'darkred'              => '8B0000',
        'darksalmon'           => 'E9967A',
        'darkseagreen'         => '8FBC8F',
        'darkslateblue'        => '483D8B',
        'darkslategray'        => '2F4F4F',
        'darkslategrey'        => '2F4F4F',
        'darkturquoise'        => '00CED1',
        'darkviolet'           => '9400D3',
        'deeppink'             => 'FF1493',
        'deepskyblue'          => '00BFFF',
        'dimgray'              => '696969',
        'dimgrey'              => '696969',
        'dodgerblue'           => '1E90FF',
        'firebrick'            => 'B22222',
        'floralwhite'          => 'FFFAF0',
        'forestgreen'          => '228B22',
        'fuchsia'              => 'FF00FF',
        'gainsboro'            => 'DCDCDC',
        'ghostwhite'           => 'F8F8FF',
        'gold'                 => 'FFD700',
        'goldenrod'            => 'DAA520',
        'gray'                 => '808080',
        'green'                => '008000',
        'greenyellow'          => 'ADFF2F',
        'grey'                 => '808080',
        'honeydew'             => 'F0FFF0',
        'hotpink'              => 'FF69B4',
        'indianred'            => 'CD5C5C',
        'indigo'               => '4B0082',
        'ivory'                => 'FFFFF0',
        'khaki'                => 'F0E68C',
        'lavender'             => 'E6E6FA',
        'lavenderblush'        => 'FFF0F5',
        'lawngreen'            => '7CFC00',
        'lemonchiffon'         => 'FFFACD',
        'lightblue'            => 'ADD8E6',
        'lightcoral'           => 'F08080',
        'lightcyan'            => 'E0FFFF',
        'lightgoldenrodyellow' => 'FAFAD2',
        'lightgray'            => 'D3D3D3',
        'lightgreen'           => '90EE90',
        'lightgrey'            => 'D3D3D3',
        'lightpink'            => 'FFB6C1',
        'lightsalmon'          => 'FFA07A',
        'lightseagreen'        => '20B2AA',
        'lightskyblue'         => '87CEFA',
        'lightslategray'       => '778899',
        'lightslategrey'       => '778899',
        'lightsteelblue'       => 'B0C4DE',
        'lightyellow'          => 'FFFFE0',
        'lime'                 => '00FF00',
        'limegreen'            => '32CD32',
        'linen'                => 'FAF0E6',
        'magenta'              => 'FF00FF',
        'maroon'               => '800000',
        'mediumaquamarine'     => '66CDAA',
        'mediumblue'           => '0000CD',
        'mediumorchid'         => 'BA55D3',
        'mediumpurple'         => '9370D0',
        'mediumseagreen'       => '3CB371',
        'mediumslateblue'      => '7B68EE',
        'mediumspringgreen'    => '00FA9A',
        'mediumturquoise'      => '48D1CC',
        'mediumvioletred'      => 'C71585',
        'midnightblue'         => '191970',
        'mintcream'            => 'F5FFFA',
        'mistyrose'            => 'FFE4E1',
        'moccasin'             => 'FFE4B5',
        'navajowhite'          => 'FFDEAD',
        'navy'                 => '000080',
        'oldlace'              => 'FDF5E6',
        'olive'                => '808000',
        'olivedrab'            => '6B8E23',
        'orange'               => 'FFA500',
        'orangered'            => 'FF4500',
        'orchid'               => 'DA70D6',
        'palegoldenrod'        => 'EEE8AA',
        'palegreen'            => '98FB98',
        'paleturquoise'        => 'AFEEEE',
        'palevioletred'        => 'DB7093',
        'papayawhip'           => 'FFEFD5',
        'peachpuff'            => 'FFDAB9',
        'peru'                 => 'CD853F',
        'pink'                 => 'FFC0CB',
        'plum'                 => 'DDA0DD',
        'powderblue'           => 'B0E0E6',
        'purple'               => '800080',
        'red'                  => 'FF0000',
        'rosybrown'            => 'BC8F8F',
        'royalblue'            => '4169E1',
        'saddlebrown'          => '8B4513',
        'salmon'               => 'FA8072',
        'sandybrown'           => 'F4A460',
        'seagreen'             => '2E8B57',
        'seashell'             => 'FFF5EE',
        'sienna'               => 'A0522D',
        'silver'               => 'C0C0C0',
        'skyblue'              => '87CEEB',
        'slateblue'            => '6A5ACD',
        'slategray'            => '708090',
        'slategrey'            => '708090',
        'snow'                 => 'FFFAFA',
        'springgreen'          => '00FF7F',
        'steelblue'            => '4682B4',
        'tan'                  => 'D2B48C',
        'teal'                 => '008080',
        'thistle'              => 'D8BFD8',
        'tomato'               => 'FF6347',
        'turquoise'            => '40E0D0',
        'violet'               => 'EE82EE',
        'wheat'                => 'F5DEB3',
        'white'                => 'FFFFFF',
        'whitesmoke'           => 'F5F5F5',
        'yellow'               => 'FFFF00',
        'yellowgreen'          => '9ACD32',
    );

    /**
     * @param $color
     * @return string
     */
    public static function getHexFromName($color)
    {
        $color_name = strtolower($color);
        if (isset(static::$colors[$color_name]))
        {
            return ('#' . static::$colors[$color_name]);
        }
        else
        {
            return ($color_name);
        }
    }
}

$identiconPlugin = new IdenticonPlugin();

/* ---- registrace pluginu ---- */
_extend('regm', array(
    'user.avatar'         => array($identiconPlugin, 'identiconDisplay'), // zobrazeni avataru
    'user.cache.init'     => array($identiconPlugin, 'userCache'), // nacitani avatar_mode v user cache
    'mod.settings.avatar' => array($identiconPlugin, 'settingsEdit'), // uprava avataru v nastaveni
    'mod.settings.submit' => array($identiconPlugin, 'settingsSubmit'), // ulozeni avataru v nastaveni
));