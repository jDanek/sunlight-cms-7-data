=== Identicon ===
Verze 1.0
Autor: 	Jirka Dan�k
Web: 	http://jdanek.eu/

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Umozni uzivatelum pouzit Identicon (obrazek generovan� za pomoci textu) jako zdroj pro svuj avatar.
	http://identicon.net/

== Instalace ==
	Nahrajte obsah adresare do korenoveho adresare

== Odinstalace ==
	odstrante nasledujici adresare ze serveru:
		plugins/extend/identicon/

== Changelog ==