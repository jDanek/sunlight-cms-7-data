<?php

/* ----  kontrola jadra  ---- */

if (!defined('_core'))
    die;
//plugin config
$GLOBALS['usersign_cfg'] = require _plugin_dir . 'usersign/config.php';

_extend('regm', array(
    /* rozsireni user cache o jméno skupiny */
    'user.cache.init' => function($args) {
        $args['extend'][] = array(array('u.note', 'g.title'));
    },
    /* pridani uziv.podpisu do prispevku */
    'posts.post' => function($args) {
        if (6 === $args['type'] && 1 === $GLOBALS['usersign_cfg']['showsign']) {
            $data = _userDataCache($args['item']['author']);
            $sign = _parsePost(isset($data['note']) ? $data['note'] : "");
            $args['item']['text'] = $args['item']['text'] . (!empty($sign) ? "<br /><br /><span class='hr'></span>{$sign}" : "");
        }
    }
));