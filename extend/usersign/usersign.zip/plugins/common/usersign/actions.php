<?php
/* ----- kontrola jadra ----- */

if(!defined('_core')) die;

global $_lang;

/* ----- akce ----- */

// cara
$output .= '<p class="bborder"></p>';

// formular
switch($action) {

    case 'config':

        // nacteni konfigurace
        $cfg = _pluginLoadConfig($plugin);

        // ulozeni
        if(isset($_POST['save'])) {

            // nacist
            $cfg['showsign'] = _checkboxLoad ('showsign');
              

            // zpracovat
            if($cfg['showsign'] === '') $cfg['showsign'] = null;
            

            // ulozit
            if(_pluginSaveConfig($plugin, $cfg) !== false) $output .= _formMessage(1, $_lang['global.saved']);
            else  $output .= _formMessage(2, $_lang['global.error']);

        }

        // formular
        $output .= "
<form action='{$url}' method='post'>
<fieldset id='usersign_settings'>
<legend>Hlavní nastavení</legend>
<table class='form'>
<tr>
  <td class='rpad'><strong>Uživatelské podpisy</strong></td>
  <td><input type='checkbox' name='showsign' value='1'"._checkboxActivate($cfg['showsign'])." /></td>
  <td class='lpad'>zapnutí zobrazení uživatelských podpisů pod příspěvky v diskusi (<em>načítáno z uživatelských poznámek!!!</em>)</td>
 </tr>
 
</table>
</fieldset>

<input type='submit' name='save' value='{$_lang['global.save']}' />
</form>
";
		break;

    case 'uninstall':
        $output .= "<p>{$_lang['usersign']['admin.uninstall.desc']}</p>
<ul>
    <li><code>root/plugins/common/usersign/</code></li>
    <li><code>root/plugins/extend/usersign/</code></li>
</ul>
";
        break;

}