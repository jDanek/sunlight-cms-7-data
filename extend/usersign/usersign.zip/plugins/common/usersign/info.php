<?php

return array(
    'name' => 'Usersign',
    'descr' => 'Uživatelské podpisy do diskuse',
    'version' => '1.0',
    'author' => 'Jirka Daněk',
    'url' => 'http://www.jdanek.eu',
    'actions' => array('config', 'uninstall'),
);