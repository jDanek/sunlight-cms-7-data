<?php return array (
  'showsign' => 1,
);