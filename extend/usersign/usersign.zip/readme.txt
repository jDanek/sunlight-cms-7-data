=== UserSign ===
Verze 1.1
Autor: 	Jirka Dan�k
Web: 	http://jdanek.eu/

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Rozsireni dovoluje pridat do prispevku v diskusi uzivatelky podpis. Nacita se z uzivatelskych poznamek.

== Instalace ==
	Nahrajte obsah adresare do korenoveho adresare

== Odinstalace ==
	odstrante nasledujici adresare ze serveru:
		plugins/extend/usersign
		plugins/common/usersign

== Changelog ==
Verze 1.1
[update] plugin upraven pro SL 7.5.4