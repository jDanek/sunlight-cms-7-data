<?php

/* ----  kontrola jadra  ---- */
if(!defined('_core')) die;


/* ---- funkce pluginu ---- */

/**
 * ADVERTISING RC2 - umístění náhodných reklam pod článek
 * soubory s reklamním kódem umístit do složky reklamy/468-endclanek/
 * @param array $args
 */

function _atw_advertis_start($args)
{

  $args['output'] .='<!-- Sklik-kontext-start --><!-- google_ad_section_start -->';

}

function _atw_advertis_end($args)
{

  $args['output'] .='<!-- Sklik-kontext-stop --><!-- google_ad_section_end -->';

}

function _atw_advertis($args)
{

  $args['output'] .=_parseHCM('[hcm]randomfile,reklamy/endclanek/,1,1[/hcm]');

}


/* ---- registrace pluginu ---- */

_extend('reg', 'article.pre', '_atw_advertis_start');
_extend('reg', 'article.post', '_atw_advertis_end');
_extend('reg', 'article.comments', '_atw_advertis');