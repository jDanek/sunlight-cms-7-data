<?php

/*--- kontrola jadra ---*/
if(!defined('_core')){exit;}

/*--- definice funkce modulu ---*/
function _HCM_jd_photogallery($parametr1='vychozi1', $parametr2='vychozi2'){

global $_lang;
$query=DB::query("SELECT * FROM `"._mysql_prefix."-root` WHERE type=5 and intersection=-1");

$output="<table class='gall' cellspacing='5'><tr>";
$x=1;

while ($result=DB::row($query)) {
     $output.="<td width='33%'>";
     $imgid=DB::row(DB::query("select id from `"._mysql_prefix."-images` where home=".$result["id"]." order by rand() limit 1"));
     $output.="<a style='text-align:center;' href='"._linkRoot($result["id"],$result["title_seo"])."'><div style='height:35px;'>".$result["title"]."</div>";
     
	 if ($imgid){
       $output.="<img src='remote/imgprev.php?h=100&amp;id=".$imgid["id"]."' />";
     }
     else{
       $output.="<div style='height:82px;'></div>";
     }
     
	 $output.="</a><br />";
     $output.="<br />";
     $counter=DB::count(_mysql_prefix."-images", "home=".$result["id"]);
     $output.="Počet fotografií: ".$counter."</td>";
     if (is_int($x/3)) $output.="</tr><tr>";
     $x++;
}
$output.="</tr></table>";


  return $output;
}