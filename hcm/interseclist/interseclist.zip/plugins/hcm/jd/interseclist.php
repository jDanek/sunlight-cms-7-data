<?php

/* --- kontrola jadra --- */
if(!defined('_core')) exit;


/* --- definice funkce modulu --- */
function _HCM_jd_interseclist($ids="all",$visible=0,$columns=1,$showsubs=1)
{
$return="";

static $lang = array(
	'en' => array('numsubs' => 'Number of subpages'),
	'cs' => array('numsubs' => 'Počet podstránek'),
	'sk' => array('numsubs' => 'Počet podstránok'),
);
$lid = _getLang($lang);



$idsArray = ($ids != "all" ? "("._sqlWhereColumn("id",$ids,false).") AND":"");

$result = DB::query("SELECT * FROM `"._mysql_prefix."-root` WHERE ".$idsArray." type=7 AND public=1 ".($visible=1?"AND visible=1":"")." ORDER BY id");

//sloupcovani
$position = 1;
$return.="<table class='interseclist-tab'>";

while ($item = DB::row($result)) {
$return.=(($position == 1)?"<tr class='interseclist-row'>":"");

$return.="<td class='interseclist-cell' style='width: ".(100/$columns)."%'><h2 class='list-title'><a href='"._linkRoot($item['id'])."'>".$item['title']."</a></h2>\n";
$return.=(($item['intersectionperex'] != "")?'<p class="list-perex">'.$item['intersectionperex'].'</p>':'');
$return.= (($showsubs == 1)?"<span>".$lang[$lid]['numsubs'].":</span> ".DB::count(_mysql_prefix."-root", "intersection=".$item['id'])."</td>":"");

if($position == $columns){$return.= "</tr> ";$position = 1;}else{$position++;}
}//while

if($position != 1){for($z=($columns-$position); $z>0 ; $z--){$return.= "<td></td>";}$return.= "</tr>";}
$return.="</table>";

return $return;
}