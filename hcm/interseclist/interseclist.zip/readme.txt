=== InterSecList ===
Verze: 	1.1
Autor: 	Jirka Dan�k
Web: 	http://jdanek.eu

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Jednoduch� HCM modul pro v�pis rozcestn�k� va�eho webu. Prim�rn� je ur�en pro pou�it� v sekc�ch, zobrazuje rozcestn�ky v z�vislosti na nastaven�.

== Instalace ==

== Pouziti ==
	Pou�it�: [hcm]jd/interseclist,(id rozcestn�ku),(pouze viditeln�),(pocet sloupcu),(zobrazit doplnkovy text)[/hcm]
	!!! vice rozcestn�ku lze odd�lit poml�kou...
	[hcm]jd/interseclist,1-2-3-4-5,0,2,1[/hcm]
	
== Odinstalace ==
	odstrante nasledujici soubor ze serveru:
		plugins/hcm/jd/interseclist.php

== Changelog ==
Verze 1.1
[update] plugin upraven pro SL 7.5.4