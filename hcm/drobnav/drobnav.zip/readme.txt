=== DrobNav ===
Verze: 	2.3
Autor: 	Jirka Dan�k
Web: 	http://jdanek.eu

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Drobe�kov� navigace

== Instalace ==

== Pouziti ==
	[hcm]jd/drobnav,'>'[/hcm]
	nebo
	<?php echo _parseHCM("[hcm]jd/drobnav[/hcm]");?> 
	
== Odinstalace ==
	odstrante nasledujici soubor ze serveru:
		plugins/hcm/jd/drobnav.php

== Changelog ==
Verze 2.3
[novinka] pridana udalost 'hcm.breadcrumbs' pro lepsi manipulaci s drobecky
Verze 2.2
[update] plugin upraven pro SL 7.5.4