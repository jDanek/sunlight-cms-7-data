=== ImageUploader ===
Verze: 	1.1
Autor: 	Tom� Smetka
Web: 	---

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	HCM modul ur�en� pro nahr�v�n� obr�zk� na str�nky.

== Instalace ==

== Pouziti ==
	[hcm]df/imageupload[/hcm]
	
== Odinstalace ==
	odstrante nasledujici soubor ze serveru:
		plugins/hcm/df/imageupload.php
== Changelog ==
Verze 1.1
[update] plugin upraven pro SL 7.5.4