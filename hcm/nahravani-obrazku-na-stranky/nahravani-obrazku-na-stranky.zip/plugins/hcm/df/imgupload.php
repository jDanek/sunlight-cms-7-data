﻿<?php

/* --- kontrola jadra --- */
if (!defined('_core'))
    exit;

/* ---
  HCM: IMG upload
  Autor: Tomáš Smetka - www.DesignFLOW.cz
  Verze: 1.0
  Příklad použití: [hcm]df/imgupload,720,565,,8000,upload/imgupload/[/hcm]
  --- */

function _HCM_df_imgupload($x = "720", $y = "565", $size = "8000", $path = "upload/imgupload/") {
    $result = "";
    $koncovky = array('jpg', 'jpeg', 'png', 'gif');
    if (isset($_POST['formular'])) {
        if (!$_FILES || $_FILES["image"]["error"] == $size) {
            $result.=_formMessage(2, "Soubor je příliš velký, maximální velikost je " . $size . " kB");
        } elseif ($_FILES["image"]["error"] == UPLOAD_ERR_NO_FILE) {
            $result.=_formMessage(2, "Nevybrali jste soubor, který chcete nahrát.");
        } elseif ($_FILES["image"]["error"]) {
            $result.=_formMessage(2, "Soubor se nepodařilo nahrát, kontaktujte prosím správce serveru.");
        } elseif (!in_array(strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION)), $koncovky)) {
            $result.=_formMessage(2, "Koncovka souboru musí být jedna z: " . implode(", ", $koncovky) . "");
        } elseif (!($imagesize = getimagesize($_FILES["image"]["tmp_name"])) || $imagesize[2] > 3) {
            $result.=_formMessage(2, "Typ obrázku musí být JPG, PNG nebo GIF.");
        } else {
            $resize_x = $x;
            $resize_y = $y;
            @$image = _pictureLoad($_FILES['image']['tmp_name'], array(), $_FILES['image']['name']);
            if ($image[0]) {
                $image_resized = _pictureResize($image[2], array('mode' => 'fit', 'keep_smaller' => true, 'bgcolor' => array(255, 255, 255), 'x' => $resize_x, 'y' => $resize_y));

                if (!$image_resized[3]) {
                    imagedestroy($image[2]);
                }

                if ($image_resized[0]) {
                    if (isset($image)) {
                        @mkdir(_indexroot . $path, 0777);
                        $image = _pictureStoragePut($image_resized[2], _indexroot . $path, null, 'jpg', 100);
                    }
                }
            }
            $result.=_formMessage(1, "Fotografie byla úspěšně nahrána.");
        }
    }



    $result.="
    <form action='' method='post' name='imgupload'  enctype='multipart/form-data'> 
    <table>
    <tr>
    <td  class='rpad'>Přiložit obrázek</td>
    <td class='lpad'><input type='file' name='image' /></td>
    </tr>
    <tr>
    <td class='rpad'></td>
    <td class='lpad'><input type='submit' value='Odeslat' name='formular' /></td>
    </tr>
    </table>"._xsrfProtect()."</form>";
    return $result;
}

