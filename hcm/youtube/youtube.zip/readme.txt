=== Youtube ===
Verze: 	1.2
Autor: 	Jan Valent�k
	Tom� Smetka
Web: 	http://valentik.cz/

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Vlozeni Youtube videa do str�nky

== Instalace ==

== Pouziti ==
  Parametry:        ID videa, HD (0/1), ���ka vide, v��ka videa, form�t zobrazen� (old/new)
  P��klad pou�it�:  [hcm]df/youtube,y9ouVCrplic,0,640,385,old[/hcm]
	
== Odinstalace ==
	odstrante nasledujici soubor ze serveru:
		plugins/hcm/df/youtube.php

== Changelog ==
Verze 1.2
[update] plugin upraven pro SL 7.5.4