﻿<?php

/*--- kontrola jadra ---*/
if(!defined('_core')){exit;}


/*--- definice funkce modulu ---*/
function _HCM_df_youtube($id,$hd="0",$width="640",$height="385",$type='new'){
  $output='';
  if ($id!=''){
    switch ($type) {
    case 'old':
      $output.='<object width="'.$width.'" height="'.$height.'">
                  <param name="movie" value="http://www.youtube.com/v/'.$id.'?fs=1&amp;hl=cs_CZ&amp;rel=0&amp;hd='.$hd.'"></param>
                  <param name="allowFullScreen" value="true"></param>
                  <param name="allowscriptaccess" value="always"></param>
                  <embed src="http://www.youtube.com/v/'.$id.'?fs=1&amp;hl=cs_CZ&amp;rel=0&amp;hd='.$hd.'" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="'.$width.'" height="'.$height.'"></embed>
                </object>';
    	break;
    case 'new':
      $output.='<iframe width="'.$width.'" height="'.$height.'" src="http://www.youtube.com/embed/'.$id.'?fs=1&amp;rel=0&amp;hd='.$hd.'" frameborder="0" allowfullscreen></iframe>';
    	break;
    }
  }
  return $output; 
}
