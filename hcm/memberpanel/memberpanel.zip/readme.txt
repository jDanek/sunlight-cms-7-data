=== MemberPanel ===
Verze 1.2
Autor: 	Jirka Dan�k
Web: 	http://jdanek.eu/

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Uzivatelsky panel pro pouziti v boxech

== Instalace ==
	Nahrajte obsah adresare do korenoveho adresare
	Pouziti v pres HCM napriklad v boxu zapisem
		[hcm]memberpanel[/hcm]

== Odinstalace ==
	odstrante nasledujici adresare ze serveru:
		plugins/extend/memberpanel

== Changelog ==
Verze 1.1
[update] plugin upraven pro SL 7.5.4