<?php
/* ----  kontrola jadra  ---- */

if(!defined('_core')) die;


/* ---- konfigurace  ---- */

$mp_config			= $GLOBALS['_plugin_memberpanel_cfg']		= require __DIR__.DIRECTORY_SEPARATOR.'config.php';
$mp_config_admin	= $GLOBALS['_plugin_memberpanel_cfg_admin']	= require _plugin_dir.'memberpanel/config.php';

/* ---- lokalizace  ---- */

// volba
$lang = _language;
if(!isset($mp_config['lang_map'][$lang])) $lang = 'default';

// slouceni
$GLOBALS['_lang'] += require __DIR__.DIRECTORY_SEPARATOR.'lang_'.$mp_config['lang_map'][$lang].'.php';
$GLOBALS['mp_cfg'] = _plugin_memberpanel_cfg();
$GLOBALS['mp_cfg_admin'] = _plugin_memberpanel_cfg_admin();

/* ---- pomocne funkce ---- */

function _plugin_memberpanel_cfg($name = null, $index = null)
{
    if(null === $name) return $GLOBALS['_plugin_memberpanel_cfg'];
    if(null === $index) return $GLOBALS['_plugin_memberpanel_cfg'][$name];
    return $GLOBALS['_plugin_memberpanel_cfg'][$name][$index];
}

function _plugin_memberpanel_cfg_admin($name = null, $index = null)
{
    if(null === $name) return $GLOBALS['_plugin_memberpanel_cfg_admin'];
    if(null === $index) return $GLOBALS['_plugin_memberpanel_cfg_admin'][$name];
    return $GLOBALS['_plugin_memberpanel_cfg_admin'][$name][$index];
}

/**
 * Samotny kod HCM Memberpanel
 */
function _HCM_memberpanel() {

global $_lang, $mp_cfg, $mp_cfg_admin;
		
// lokalizace
    if (!_loginindicator){
		$output=_templateUserMenu(true);
	}else{
		$output="<div class='mp-wrapper'>";//obal
		$output.="<div class='mp-left mp-float-left'><img src='"._getAvatar(_loginid, true)."' class='mp-avatar' /></div>";//leva strana s avatarem
		$output.="<div class='mp-right'><strong>{$_lang['memberpanel']['web.welcome']}</strong><br />"._linkUser (_loginid, null, true, true, null, '', $ignore_publicname = false);// prava strana
			$output.=(($mp_cfg_admin['showgroup'] == 1)?"<br /><br /><small>"._loginright_groupname."</small>":"");//zobrazit skupinu, je-li povoleno
		$output.="</div>";
		$output.="<div class='mp-cleaner'></div>";
		$output.="<div class='mp-list-item'>";//nabidka

			//pocet neprectených vzkazů
			if($mp_cfg_admin['showmessage'] == 1){
				$mquery = DB::result(DB::query("SELECT COUNT(id) FROM `"._mysql_prefix."-pm` WHERE (receiver="._loginid." AND receiver_deleted=0 AND receiver_readtime<update_time) OR (sender="._loginid." AND sender_deleted=0 AND sender_readtime<update_time)"), 0);
				$messages_count=(($mquery!=0)?"<strong>{$mquery}</strong>":"0");
					$output.="<div class='mp-align-center'><small>{$_lang['memberpanel']['web.message.unread1']} ".$messages_count." {$_lang['memberpanel']['web.message.unread2']}</small></div>";
					$output.="<div class='mp-separator'></div>";
			}
			
		$output.=_templateUserMenu(true);//usermenu

		$output.="</div></div>";
		}
	return $output;
}

/**
 * Registrace CSS a JS do hlavičky webu
 */
_extend('reg', 'tpl.head', function($args){ 
$args['output'] .= "
<link href='./plugins/extend/memberpanel/style/style.css?"._cacheid."' type='text/css' rel='stylesheet' />";});

/**
 * Extend pro MemberPanel 
 */
_extend('reg', 'tpl.usermenu.beforelogout', function($args){
global $_lang;
	$args['output'] .= "<li><a href='"._indexroot."index.php?m=search' class='usermenu-item-search'>{$_lang['mod.search']}</a></li>";
	$args['output'] .= ((_loginright_administration) ? "<li><a href='"._indexroot."admin' class='usermenu-item-admin'>{$_lang['admin.link']}</a></li>" : '');
});

unset($mp_config, $mp_config_admin, $lang);