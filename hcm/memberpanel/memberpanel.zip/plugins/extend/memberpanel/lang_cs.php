<?php

return array(

    'memberpanel' => array(
		'web.welcome'=>'Vítejte',
		'web.message.unread1'=>'Máte',
		'web.message.unread2'=>'nepřečtených vzkazů.',
		
		'admin.usehcm'=>'Použití modulu',
		'admin.use.desc'=>'Zápis HCM modulu:',
		'admin.mainsettings'=>'Hlavní nastavení',
		'admin.group'=>'Skupina',
		'admin.group.desc'=>'Zobrazovat uživatelskou skupinu',
		'admin.message'=>'Zprávy',
		'admin.message.desc'=>'Zobrazovat textový popisek o počtu zpráv',
		'admin.uninstall'=>'Odinstalace',
		'admin.uninstall.desc'=>'Pro odinstalování pluginu smažte následující adresáře:',
	)
);