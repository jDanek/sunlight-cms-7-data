<?php

return array(

    // mapa dostupnych lokalizaci
    'lang_map' => array(
        'default' =>    'cs',
    ),
	
    'pluginname' => 		'Profile Plus', // jmeno pluginu
	'token' =>				'aHR0cDovL2pkYW5lay5ldQ==', //secure token
    'plugin_dir' =>         _indexroot.'plugins/extend/memberpanel/', // adresar pluginu
    'plugin_images' =>      _indexroot.'plugins/extend/memberpanel/images/', // adresar obrazku
	'plugin_style' =>		_indexroot.'plugins/extend/memberpanel/style/', // adresar stylu

);