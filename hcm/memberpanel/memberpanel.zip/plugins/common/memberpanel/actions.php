<?php
/* ----- kontrola jadra ----- */

if(!defined('_core')) die;

global $_lang;

/* ----- akce ----- */

// cara
$output .= '<p class="bborder"></p>';

// formular
switch($action) {

    case 'config':

        // nacteni konfigurace
        $cfg = _pluginLoadConfig($plugin);

        // ulozeni
        if(isset($_POST['save'])) {

            // nacist
            $cfg['showgroup'] = _checkboxLoad ('showgroup');
            $cfg['showmessage'] = _checkboxLoad ('showmessage');
                      

            // zpracovat
            if($cfg['showgroup'] === '') $cfg['showgroup'] = null;
            if($cfg['showmessage'] === '') $cfg['showmessage'] = null;
            

            // ulozit
            if(_pluginSaveConfig($plugin, $cfg) !== false) $output .= _formMessage(1, $_lang['global.saved']);
            else  $output .= _formMessage(2, $_lang['global.error']);

        }

        // formular
        $output .= "
<fieldset id='settingsform'>
<legend>{$_lang['memberpanel']['admin.usehcm']}</legend>
<p>{$_lang['memberpanel']['admin.use.desc']} <pre>[hcm]memberpanel[/hcm]</pre></p>
</fieldset>        
        
<form action='{$url}' method='post'>
<fieldset id='settingsform'>
<legend>{$_lang['memberpanel']['admin.mainsettings']}</legend>
<table class='form'>
<tr>
  <td class='rpad'><strong>{$_lang['memberpanel']['admin.group']}</strong></td>
  <td><input type='checkbox' name='showgroup' value='1'"._checkboxActivate($cfg['showgroup'])." /></td>
  <td class='lpad'>{$_lang['memberpanel']['admin.group.desc']}</td>
 </tr>
 
<tr>
  <td class='rpad'><strong>{$_lang['memberpanel']['admin.message']}</strong></td>
  <td><input type='checkbox' name='showmessage' value='1'"._checkboxActivate($cfg['showmessage'])." /></td>
  <td class='lpad'>{$_lang['memberpanel']['admin.message.desc']}</td>
 </tr> 

</table>
</fieldset>
"._xsrfProtect()."
<input type='submit' name='save' value='{$_lang['global.save']}' />
</form>
";
		break;

    case 'uninstall':
        $output .= "<p>{$_lang['memberpanel']['admin.uninstall.desc']}</p>
<ul>
    <li><code>root/plugins/common/memberpanel/</code></li>
    <li><code>root/plugins/extend/memberpanel/</code></li>
</ul>
";
        break;

}