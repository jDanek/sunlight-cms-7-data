<?php

return array(
    'name' => 'Member Panel',
    'descr' => 'Vylepšená uživatelská nabídka',
    'version' => '1.1',
    'author' => 'Jirka Daněk',
    'url' => 'http://www.designflow.cz',
    'actions' => array('config', 'uninstall'),
);