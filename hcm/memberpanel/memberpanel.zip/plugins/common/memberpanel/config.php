<?php return array (
  'showgroup' => 1,
  'showmessage' => 1,
);