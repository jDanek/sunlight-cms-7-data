=== MassEmail ===
Verze: 	1.2
Autor: 	Tom� Smetka
Web: 	---

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Prihlasovaci formular s avatarem

== Instalace ==
	1. Nahr�t slozku plugins do rootu webu (vedle index.php, config.php,...)
	2. Spustit SQL k�d (napr. p�es phpMyAdmin, SQL n�stroj v administraci):

CREATE TABLE `sunlight-massemail` (
  `id` int(11) NOT NULL auto_increment,
  `email` tinytext NOT NULL,
  `time` int(11) NOT NULL,
  `active` tinyint(4) NOT NULL,
  `ip` varchar(15) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

== Pouziti ==
	[hcm]df/massemail[/hcm]
	
== Odinstalace ==
	odstrante adresar
		plugins/admin/massemail
	odstrante nasledujici soubor ze serveru:
		plugins/hcm/df/massemail.php

== Changelog ==
Verze 1.2
[fix] oprava sql pro admin vypis pocetu prihlasenych a odhlasenych 
Verze 1.1
[update] plugin upraven pro SL 7.5.4