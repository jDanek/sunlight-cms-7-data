﻿<?php

/* --- kontrola jadra --- */
if (!defined('_core')) {
    exit;
}
/* --- definice funkce modulu --- */

function _HCM_df_massemail() {
    $result = "";
    $result.="";
            if (isset($_POST['prihlaseni'])) {
                $error_log = array();
                if (!_validateEmail($_POST['email']))
                    $error_log[] = "Vyplňte e-mail."; 
                    if (sizeof($error_log) > 0) {
                    $result.=_formMessage(2, _eventList($error_log, 'errors'));
                } else {
 
                // odhlasit
                if (isset($_POST['stav']) && intval($_POST['stav']) == 1) {
                    
                    if (DB::count(_mysql_prefix . "-massemail", "email='" . DB::esc($_POST['email']) . "' AND active='0'") > 0) {
                        $result.=_formMessage(3, "Bohužel, email je již odhlášen.");
                    } else {
                        if (DB::update(_mysql_prefix . "-massemail", "email='" . DB::esc($_POST['email']) . "'", array('active' => 0))) {
                            $result.=_formMessage(1, "E-mail byl odhlášen.");
                        } else {
                            $result.=_formMessage(3, "Email se nepodařilo odhlásit.");
                        }
                    } 
    
                // prihlasit    	
                } else {
                    if (DB::count(_mysql_prefix . "-massemail", "email='" . DB::esc($_POST['email']) . "'") > 0) {
                        $result.=_formMessage(3, "Bohužel, email je již v systému.");
                    } else {
                        if (DB::insert(_mysql_prefix . "-massemail", array('id' => '', 'time' => time(), 'email' => DB::esc($_POST['email']), 'active' => '1', 'ip' => $_SERVER["REMOTE_ADDR"]))) {
                            $result.=_formMessage(1, "E-mail byl přihlášen.");
                        } else {
                            $result.=_formMessage(3, "Email se nepodařilo přihlásit.");
                        }
                    }  
                }                      
              }
            }
            
            $result.="              
            <form action='" . _indexOutput_url . "' method='post' name='prihlaseni'>               
             <table cellspacing='0' class='form'>              
             <tr>                           
             <td><input name='email' type='text' maxlength='64' value='Váš e-mail' onfocus=\"if(this.value=='Váš e-mail'){this.value=''}\" onblur=\"if(this.value==''){this.value='Váš e-mail'}\" /></td>                
             <td><input value='Odeslat' name='prihlaseni' type='submit' /></td>
             </tr> 
             <tr>                
             <td colspan='2'>
             <label><input type='checkbox' value='1' name='stav' ".((isset($_POST['stav']) && $_POST['stav']==1)?"  checked='yes'":"")."/>Odhlásit z odběru</label>
             </td>             
             </tr>              
             </table>
			"._xsrfProtect()."
             </form>";
    return $result;
    
}

