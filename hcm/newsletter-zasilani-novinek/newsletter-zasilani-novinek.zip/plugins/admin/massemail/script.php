﻿<?php
if (!defined('_core')) {
    exit;
}

if (isset($_GET['delete'])) {
    if (DB::query("DELETE FROM `" . _mysql_prefix . "-massemail`  WHERE  id =" . intval($_GET['delete']))) {
        header("Location: index.php?p=massemail");
    } else {
        echo DB::error();
    }
}


if (!isset($_GET['send'])) {
$output.="
<p>Přehled přihlášených a odhlášených e-mailů do newsletter. 
<span style='color: green'>Přihlášení: ".DB::count(_mysql_prefix."-massemail", "active='1'")."</span> &nbsp;
<span style='color: red'>Odhlášení: ".DB::count(_mysql_prefix."-massemail", "active='0'")."</span>
</p>
<p><a href='index.php?p=massemail&amp;send'><img src='images/icons/new.png' alt='' /> Zaslat novinky</a></p>
<table class='list'>
<thead>
<tr>
    <td>Datum</td>
    <td colspan='2'>E-mail</td>
    <td colspan='2'>IP adresa</td>
</tr>
</thead>
<tbody>";

$paging = _resultPaging("index.php?p=massemail", 40, "massemail", "id");
$query = DB::query("SELECT * FROM `" . _mysql_prefix . "-massemail` ORDER BY id DESC " . $paging[1]);
while ($item = DB::row($query)) {

    if ($item["active"] == 1) {
            $active = "<span style='color: green'>Přihlášen</span>";
        } else {
            $active = "<span style='color: red'>Odhlášen</span>";
    }
    
    $output.= "
    <tr>
    <td>" . _formatTime($item["time"]) . "</td>
    <td>" . $item["email"] . "</td>
    <td>" . $active . "</td>
    <td>" . $item["ip"] . "</td>
    <td><a href='index.php?p=massemail&amp;delete=" . $item['id'] . "' onclick='return _sysDelete();'><img src='images/icons/delete.png' class='icon' /> Smazat</a></td>
    </tr>";
}

$output.=" <tr><td colspan='5'>" . $paging[0] . "</td></tr></tbody></table>";

}

if (isset($_GET['send'])) {
if (isset($_POST['massemail'])) {
    $error_log = array();
    if (!_validateEmail($_POST['sender']))
        $error_log[] = "Vyplňte prosím správně e-mail odesílatele!";
    if (empty($_POST['subject']))
        $error_log[] = "Vyplňte prosím předmět!";
    if (empty($_POST['text']))
        $error_log[] = "Vyplňte prosím text!";
    if (sizeof($error_log) > 0) {
        $output .=_formMessage(2, _eventList($error_log, 'errors'));
    } else {
    
        $sql = DB::query("SELECT * FROM `" . _mysql_prefix . "-massemail`  WHERE active='1'");
        while ($row = DB::row($sql)) {
            $emails[] = $row["email"];
        };
        $email_send = implode(",", $emails);


        $to      = _sysmail;
        $subject = $_POST['subject'];
        $message = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">        
                  <html>        
                    <head>        
                      <meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\">        
                      <title>" . $_POST['subject'] . "
                      </title>        
                    </head>        
                    <body>        " . $_POST['text'] . "         
                    </body>        
                  </html>";

                   
          // To send HTML mail, the Content-type header must be set
          $headers  = 'MIME-Version: 1.0' . "\r\n";
          $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
          
          // Additional headers
          $headers .= 'To: "Novinky z webu" <'._sysmail.'>' . "\r\n";
          $headers .= 'From: "Novinky z webu" <'._sysmail.'>' . "\r\n";
          $headers .= 'Bcc: '.$email_send.'' . "\r\n";


        if (_mail($to, $subject, $message, $headers)) {
            $output .=_formMessage(1, "Hromadný email byl zaslán.");}
        else { 
       $output .=_formMessage(3, "Newsletter se nepodařilo odeslat");
    }
  }
}




$output .= "
<p>Zasílání novinek na e-maily.</p>
<p><a href='index.php?p=massemail'><img src='images/icons/delete.png' alt='new' /> Zpět na výpis</a></p>
<form class='cform' action='index.php?p=massemail&amp;send' method='post' name='massemail'>  
  <table class='formtable'>    
    <tr>      
      <td class='rpad'><strong>Odesílatel</strong></td><td>        
        <input type='text' name='sender' " . _restorePostValue("sender", _sysmail) . " class='inputbig' /></td>    
    </tr>    
    <tr>      
      <td class='rpad'><strong>Předmět</strong></td><td>        
        <input type='text' name='subject' class='inputbig' " . _restorePostValue("subject") . " /></td>    
    </tr>    
    <tr valign='top'>      
      <td class='rpad'><strong>Obsah e-mailu</strong></td><td>      
      <textarea name='text' class='areabig' rows='9' cols='94'>" . _restorePostValue("text", null, true) . "</textarea></td>    
    </tr>    
    <tr>
    <td>&nbsp;</td><td><input type='submit' value='Odeslat' name='massemail'  name='massemail' /></td>    
    </tr>  
  </table>
</form>";
}