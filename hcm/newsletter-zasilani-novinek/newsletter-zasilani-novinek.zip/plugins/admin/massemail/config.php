<?php
return array(
'title' => 'Newsletter',
'access' => true,
'in-other' => true,
_loginright_level > 10000,
'autotitle' => true, 
); 