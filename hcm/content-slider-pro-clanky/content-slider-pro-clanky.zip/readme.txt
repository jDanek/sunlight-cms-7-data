=== ContentSlider ===
Verze 1.1
Autor: 	Jan Valent�k
	Tom� Smetka
	Jirka Dan�k
Web: 	http://valentik.cz/
	http://jdanek.eu/

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Content slider

== Instalace ==

== Pouziti ==
	[hcm]jd/slider,5,null,5-7[/hcm] (zobrazit 5 �l�nk� ze v�ech kategori�, ale vynechat kategorie 5,7) 

== Odinstalace ==
	odstrante nasledujici slozky a soubory ze serveru:
		plugins/hcm/jd/slider.php
		plugins/hcm/jd/slider/
		plugins/extend/web.slideractivator/

== Changelog ==
Verze 1.1
[update] plugin upraven pro SL 7.5.4