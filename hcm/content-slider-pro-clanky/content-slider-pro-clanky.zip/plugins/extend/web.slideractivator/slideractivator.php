<?php 

/*
PLUGIN AKTIVATOR PRO SLIDER (REDAK�N� SUNLIGHT 7.5.0)

Verze: 1.0 (Unor 2012)
Autor: Ji�� Dan�k
Osobn� web: http://www.jdanek.eu
Web: http://www.designflow.cz/
*/

/* ----  kontrola jadra  ---- */ 
if(!defined('_core')) die; 


/* ---- funkce pluginu ---- */ 

/** 
 * [ACTIVATOR PLUGIN] Nahrazuje rucni vkladani css a js pro HCM Slider
 * @param array $args 
 */ 
 function _plugin_slider_addcss($args)
 {
 $args['output'] .= "
<script type='text/javascript' src='./plugins/hcm/jd/slider/js/setting.js?"._cacheid."'></script>
<script type='text/javascript' src='./plugins/hcm/jd/slider/js/jquery.js?"._cacheid."'></script>
<link href='./plugins/hcm/jd/slider/style.css?"._cacheid."' type='text/css' rel='stylesheet' />";
 }
 
/* ---- registrace pluginu ---- */  
_extend('reg', 'tpl.head', '_plugin_slider_addcss');//pridani do template.php
