﻿<?php

/* --- kontrola jadra --- */
if(!defined('_core')) exit;

/* --- parser kategorii  --- */
function _catFilter($column, $values, $variant='0', $isnumeric = true)
{
$values = _arrayRemoveValue(explode("-", $values), "");
$values_count = count($values);
$sql = "";
$counter = 1;

foreach($values as $value) {

if($isnumeric) $value = intval($value);
else $value = "'".DB::esc($value)."'";

$sql .=($variant!='0' ? $column."!=".$value : $column."=".$value);

if($counter != $values_count) $sql .= " OR ";
++$counter;

}
return $sql;
}

/* --- Tělo--- */
function _HCM_jd_slider($limit='5',$catY='null',$catN='null'){
    $fragment='';
    $result='';
	/* --- upresneni slideru START--- */
	$cy=($catY!='null' ? " AND "._catFilter('home1',$catY,'0') : ""); //kategorie chtěné
	$cn=($catN!='null' ? " AND "._catFilter('home1',$catN,'1') : ""); //kategorie nechtěné
	$sestava="confirmed=1".$cy.$cn." AND time<=".time();
	/* --- upresneni slideru KONEC--- */

	
    $query = DB::query("SELECT id,title,perex,time,picture_uid FROM `"._mysql_prefix."-articles`"."  WHERE ".$sestava." ORDER BY time DESC LIMIT ".$limit."");
						
    $data=array();
    while($item=DB::row($query)){
      $data[]=$item;
    }
    
   	$result.='<div id="featured"><ul class="ui-tabs-nav">';
    foreach ($data as $key=>$value) {
      $key=$key+1;
      $path=_indexroot.'pictures/articles/'.$value['picture_uid'].'.jpg';
      if(file_exists($path)){}
      else {$path = null;}
     $result.='<li class="ui-tabs-nav-item'.($key==1 ? ' ui-tabs-selected':'').'" id="nav-fragment-'.$key.'"><a href="#fragment-'.$key.'"><img src="'.$path.'" width="78px"  alt="" /><span>'.$value['title'].'</span></a></li>';
     $fragment.='<div id="fragment-'.$key.'" class="ui-tabs-panel'.($key!=1 ? ' ui-tabs-hide':'').'"><a href="'._linkArticle($value['id']).'"><img src="'.$path.'" alt="'.($value['title']).'" /></a><div class="info"><h2><a href="'._linkArticle($value['id']).'">'.$value['title'].'</a></h2><div class="infoperex"><p>'.$value['perex'].'</p></div></div></div>';
    }
	  $result.='</ul>';
    $result.=$fragment;
    $result.='</div>';
    return $result;
}