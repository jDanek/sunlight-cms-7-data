=== TopicList ===
Verze 1.1
Autor: 	Jirka Dan�k
Web: 	http://jdanek.eu/

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	HCM modul pro v�pis t�mat ze V�ECH diskus� do kter�ch bylo naposledy p�isp�no. Odkaz vede v�dy na nejnov�j�� p��sp�vek v t�matu

== Instalace ==

== Pouziti ==
	[hcm]jd/topiclist,(limit)[/hcm]
	
== Odinstalace ==
	odstrante nasledujici soubor ze serveru:
		plugins/hcm/jd/topiclist.php

== Changelog ==
Verze 1.1
[update] plugin upraven pro SL 7.5.4