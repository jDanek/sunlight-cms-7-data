<?php

if (!defined('_core')) {
    exit;
}

function _HCM_jd_topiclist($limit = null) {

    $result = "";
    $result .= "<ul class='topiclist-ul'>";
    if (isset($limit) and intval($limit) >= 1)
    {
        $limit = abs(intval($limit));
    }
    else
    {
        $limit = 10;
    }

    $query = DB::query("SELECT t.id as t_id, t.subject as t_subject, t.home as t_home, t.xhome as t_xhome, t.time as t_time, t.author as t_author, t.guest as t_guest,
        p.id as p_id, p.xhome as p_xhome, p.author as p_author, p.guest as p_guest, p.time as p_time, r.title as r_title, up.username as up_username, up.publicname as up_publicname, ut.username as ut_username, ut.publicname as ut_publicname,
          (SELECT COUNT(id) FROM `" . _mysql_prefix . "-posts` WHERE id<p_id AND type=5 AND xhome=p_xhome AND home=t_home) as page_result
                        FROM  `" . _mysql_prefix . "-posts` t 
                        LEFT JOIN `" . _mysql_prefix . "-posts` p ON (p.xhome=t.id)
                        LEFT JOIN `" . _mysql_prefix . "-users` up ON (up.id=p.author)
                        LEFT JOIN `" . _mysql_prefix . "-users` ut ON (ut.id=t.author)
                        INNER JOIN `" . _mysql_prefix . "-root` r ON (t.home=r.id AND r.level<=" . _loginright_level . ")
                        WHERE t.bumptime=p.time OR t.bumptime=t.time AND t.type=5 AND t.xhome=-1 ORDER BY t.bumptime DESC LIMIT " . $limit);



    while ($item = DB::row($query))
    {
        if ($item['t_xhome'] == -1 && null !== $item['p_id'])
        {
            // vypocet stranky
            $post_page = intval($item['page_result'] / _commentsperpage) + 1;
            // 
            $hometitle = array("title" => $item['t_subject']);
            $homelink = _addGetToLink("index.php?m=topic&amp;id=" . $item['p_xhome'], "page={$post_page}#post-{$item['p_id']}");
            $authorname = (($item['p_author'] != -1) ? (!empty($item['up_publicname']) ? $item['up_publicname'] : $item['up_username']) : $item['p_guest']);
            $time = $item['p_time'];
        }
        elseif ($item['t_xhome'] == -1 && null === $item['p_id'])
        {
			$hometitle = array("title" => $item['t_subject']);
            $homelink = "index.php?m=topic&amp;id=" . $item['t_id'];
            $authorname = (($item['t_author'] != -1) ? (!empty($item['ut_publicname']) ? $item['ut_publicname'] : $item['ut_username']) : $item['t_guest']);
            //$item['ut_guest'] - nahrazeno uvozovkami nahoře
            //$authorname = (($item['ut_author'] != -1) ? $item['ut_author']: $item['ut_guest']);
            $time = $item['t_time'];
        }

        if (date('dmY', time()) === date('dmY', $time))
        {
            $datum = "<span class='today'><strong>DNES</strong></span> " . date('H:i', $time);
        }
        elseif (date("dmY", strtotime("yesterday")) === date('dmY', $time))
        {
            $datum = "<span class='yesterday'><strong>VČERA</strong></span> " . date('H:i', $time);
        }
        else
        {
            $datum = _formatTime($time);
        }

        $hometitle = $hometitle['title'];
        $result .= "<li><a href='{$homelink}'" . (strlen($hometitle) > 32 ? " title='{$hometitle}'" : "") . "'>"
                . _cutStr($hometitle, 30) . "</a><br /><small>└ {$item['r_title']}<br />└ {$authorname} - {$datum}</small></li>\n";
    }
    $result .= "</ul>";
    return $result;
}