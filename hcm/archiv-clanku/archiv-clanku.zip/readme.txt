=== Archiv ===
Verze: 	1.1
Autor: 	Petr Vostr�
Web: 	http://wall.cz/

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Archiv �l�nk�

== Instalace ==

== Pouziti ==
	[hcm]archiv/archiv[/hcm]
	
== Odinstalace ==
	odstrante nasledujici soubor ze serveru:
		plugins/hcm/archiv

== Changelog ==
Verze 1.1
[update] plugin upraven pro SL 7.5.4