<?php
/* ----- kontrola jadra ----- */

if(!defined('_core')) die;


/* ----- lokalizace ----- */

$lang = array( //
    'pathJS' => 'Cesta k souborům (*.js)', 'uninstall' => 'Pro odinstalování pluginu smažte následující adresáře', //
    'pathCSS' => 'Cesta k souborům (*.css)', 'uninstall' => 'Pro odinstalování pluginu smažte následující adresáře', //    
    );

/* ----- akce ----- */

// cara
$output .= '<div class="hr"><hr /></div>';

// formular
switch($action) {

    case 'config':

        // nacteni konfigurace
        $cfg = _pluginLoadConfig($plugin);

        // ulozeni
        if(isset($_POST['save'])) {

            // nacist
            $cfg['pathJS'] = $_POST['pathJS'];
            $cfg['pathCSS'] = $_POST['pathCSS'];

            // ulozit
            if(_pluginSaveConfig($plugin, $cfg) !== false) $output .= _formMessage(1, $_lang['global.saved']);
            else  $output .= _formMessage(2, $_lang['global.error']);

        }

        // formular
        $output .= '
<form action="'.$url.'" method="post">
<table class="form">

<tr>
    <td class="rpad"><strong>'.$lang['pathJS'].'</strong></td>
    <td><input type="text" name="pathJS" value="'.$cfg['pathJS'].'" class="inputsmall" /></td>
</tr>

<tr>
    <td class="rpad"><strong>'.$lang['pathCSS'].'</strong></td>
    <td><input type="text" name="pathCSS" value="'.$cfg['pathCSS'].'" class="inputsmall" /></td>
</tr>

<tr>
    <td></td>
    <td><input type="submit" name="save" value="'.$_lang['global.save'].'" /></td>
</tr>
     
</table>
'._xsrfProtect().'
</form>
';
        break;


    case 'uninstall':
        $output .= '<p>'.$lang['uninstall'].':</p>
<ul>
    <li><code>plugins/common/head_hcm/</code></li>
    <li><code>plugins/extend/head_hcm/</code></li>
</ul>
';
        break;

}
