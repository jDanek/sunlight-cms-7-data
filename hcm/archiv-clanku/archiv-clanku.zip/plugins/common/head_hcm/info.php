<?php

return array(

    'name' => 'Head HCM - Archiv',
    'descr' => 'Generování a vložení odkazů na soubory (*.js, *.css) do hlavičky stránky.',
    'version' => '1.0',
    'author' => 'petvo',
    'url' => 'http://wall.cz/',
    'actions' => array('config', 'uninstall'),

);