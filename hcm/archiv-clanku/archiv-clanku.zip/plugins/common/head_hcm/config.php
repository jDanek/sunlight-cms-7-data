<?php return array (
  'pathJS' => 'plugins/hcm/archiv/jscript/',
  'pathCSS' => 'plugins/hcm/archiv/css/',
);