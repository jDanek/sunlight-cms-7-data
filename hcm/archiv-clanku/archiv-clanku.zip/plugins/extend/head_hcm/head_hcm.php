<?php

/*
Plugin: Head HCM
Autor: Petr Vostrý
Web: http://wall.cz
Popis:
Rozšíření automaticky vytvoří odkazy na *.JS a *.CSS soubory z nastavených složek do hlavičky stránky.
*/

/* --- kontrola jadra --- */
if(!defined('_core')) die;

function _plugin_head_hcm($args)
{
  
  $config = require _plugin_dir.'head_hcm/config.php';
  
//načtení souborů jen s koncovkou JS
  if($config['pathJS'] != ""){ 
    $output = "";
    $cesta = _indexroot.$config['pathJS'];
    $counter = 0;
  
    if(@file_exists($cesta) and @is_dir($cesta)) {
      $handle = @opendir($cesta);
      while($item = @readdir($handle)) {
        if(@is_dir($cesta.$item) or $item == "." or $item == "..") {
          continue;
        }
        if(in_array(pathinfo($item, PATHINFO_EXTENSION), array('js'))) {
          $items[] = $item;
        }
      }
      natsort($items);
      $output .= "\r\n";
      foreach($items as $item) {
        $counter ++;
        $output .= "<script type=\"text/javascript\" src=\"".$cesta.$item."\"></script>".($counter == count($items)?"":"\r\n");
      }    
      @closedir($handle);
    }
    $args['output'] .= $output; 
    $items = "";
  }
  
//načtení souborů jen s koncovkou JS
  if($config['pathCSS'] != ""){
    $output = "";
    $cesta = _indexroot.$config['pathCSS'];
    $counter = 0;
  
    if(@file_exists($cesta) and @is_dir($cesta)) {
      $handle = @opendir($cesta);
      while($item = @readdir($handle)) {
        if(@is_dir($cesta.$item) or $item == "." or $item == "..") {
          continue;
        }

        if(in_array(pathinfo($item, PATHINFO_EXTENSION), array('css'))) {
          $items[] = $item;
        }
      }
      natsort($items);
      $output .= "\r\n";
      foreach($items as $item) {
        $counter ++;
        $output .= "<link rel=\"stylesheet\" href=\"".$cesta.$item."\" type=\"text/css\" media=\"screen\" />".($counter == count($items)?"":"\r\n");
      }    
      @closedir($handle);
    }
    $args['output'] .= $output;      
  }else{
    $args['output'] = "";
  }


}

/* ---- registrace pluginu ---- */ 
_extend('reg', 'tpl.head', '_plugin_head_hcm');

?>