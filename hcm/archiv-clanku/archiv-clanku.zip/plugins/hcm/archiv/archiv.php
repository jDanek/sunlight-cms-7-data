<?php

if (!defined('_core')) {
    exit;
}


/*
  HCM modul Archiv 2.0
  Autor: Petr Vostrý
  Web: http://wall.cz
  Parametry (nepovinné):
  --------------------
  1. ID kategorie. Více kategorií je odděleno čárkami
  2. Robalení archivu:
  0 = rok
  1 = rok a měsíce
  příklad: [hcm]archiv/archiv,1-2-4,0[/hcm]
 */

/* --- definice funkce modulu --- */

function _HCM_archiv_archiv($kategorie = null, $zobraz = 0) {

    $output = "";
    $months = array("", "Leden", "Únor", "Březen", "Duben", "Květen", "Červen", "Červenec", "Srpen", "Září", "Říjen", "Listopad", "Prosinec");
    $artview = intval($zobraz);

    // limitovani na kategorie
    $rcats = _sqlArticleWhereCategories($kategorie);

    // pripojeni casti
    $rcond = " WHERE " . _sqlArticleFilter(true);
    if ($rcats != "") {
        $rcond .= " AND " . $rcats;
    }

    $tree = array();
    $query = DB::query("SELECT art.id,art.time,art.title,art.title_seo,cat.title_seo AS category FROM `" . _mysql_prefix . "-articles` AS art LEFT JOIN `" . _mysql_prefix . "-root` AS cat ON art.home1=cat.id" . $rcond . " ORDER BY art.time DESC");
    while ($item = DB::row($query)) {
        $tree[date("Y", $item['time'])][date("n", $item['time'])][$item['id']] = array('title' => $item['title'], 'title_seo' => $item['title_seo'], 'category' => $item['category']);
    }

    $output .= "<ul id='nav'>\n";
    foreach ($tree as $year_key => $year_value) {
        $count = 0;
        for ($x = 0; $x < 13; $x++) {
            if (isset($tree[$year_key][$x])) {
                $count+=count($tree[$year_key][$x]);
            }
        }
        $output .= "  <li class='expandable'>" . $year_key . "<span class='cnt'>&nbsp;(" . $count . ")</span>\n";
        $output .= "  <ul class='block'>\n";
        foreach ($year_value as $month_key => $month_value) {
            $output .= "    <li" . ($artview == 1 ? " class='expandable'" : "") . ">" . $months[$month_key] . "<span class='cnt'>&nbsp;(" . count($tree[$year_key][$month_key]) . ")</span>";
            $output .= "    <ul class='block'>\n";
            foreach ($month_value as $art_key => $art_value) {
                $output .= "<li" . ($artview == 1 ? " class='artlink'" : "") . "><a href='" . _linkArticle($art_key, $art_value['title_seo'], $art_value['category']) . "' title='" . $art_value['title'] . "'>" . $art_value['title'] . "</a></li>\n";
            }
            $output .= "    </ul>\n";
            $output .= "    </li>\n";
        }
        $output .= "  </ul>\n";
        $output .= "  </li>\n";
    }
    $output .= "</ul>\n";

    return $output;
}

?>