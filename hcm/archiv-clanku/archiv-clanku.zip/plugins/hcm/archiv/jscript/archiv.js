var imgContract = './plugins/hcm/archiv/images/contract.gif';
var imgExpand = './plugins/hcm/archiv/images/expand.gif';

function init(){

    if(!document.getElementById) return;
    if(!document.getElementsByTagName) return;
    if(!document.createElement) return;

    var navigation = document.getElementById('nav');
    var navSub = navigation.getElementsByTagName('ul');
    var navSubArt = navigation.getElementsByTagName('li');
    var par = 0;

    for (i=0; i<navSubArt.length; i++){
	x = document.getElementsByTagName('li')[i];	
	if(x.className == "artlink") {
	    par = 2;
	    break;
	} else {
	    par = 1;
	}	
    }
    for (i=0; i<par; i++){
	var toggleImage = document.createElement('img');
	toggleImage.setAttribute('src', imgContract);
	toggleImage.style.cursor = "pointer";
	toggleImage.onclick = function() {
	    toggleNav(this);
	}
	navSub[i].parentNode.insertBefore(toggleImage, navSub[i].parentNode.firstChild);
	navSub[i].style.display="block";
	navSub[i].parentNode.className = "expandable";
    }

    for (i=par; i<navSub.length; i++){
	var toggleImage = document.createElement('img');
	toggleImage.setAttribute('src', imgExpand);
	toggleImage.style.cursor = "pointer";
	toggleImage.onclick = function() {
	    toggleNav(this);
	}
	navSub[i].parentNode.insertBefore(toggleImage, navSub[i].parentNode.firstChild);
	navSub[i].style.display = "none";
	navSub[i].parentNode.className = "expandable";
    }


}

function toggleNav(whichOne){

    var theParent = whichOne.parentNode;
    var theParentULs = theParent.getElementsByTagName('ul');
    var theParentImage = theParent.getElementsByTagName('img');
	
    if (theParentULs[0].style.display == "none") {
	theParentULs[0].style.display = "block";
	theParentImage[0].setAttribute('src', imgContract);
    }
    else {
	theParentULs[0].style.display = "none";
	theParentImage[0].setAttribute('src', imgExpand);
    }
	
}

window.onload = init;