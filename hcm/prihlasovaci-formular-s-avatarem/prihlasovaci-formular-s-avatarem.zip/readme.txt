=== LoginForm ===
Verze: 	1.1
Autor: 	Tom� Smetka
Web: 	---

Verze systemu: 7.5.x

== Licence ==
	License: MIT
	License URL: https://opensource.org/licenses/MIT

== Popis ==
	Prihlasovaci formular s avatarem

== Instalace ==

== Pouziti ==
	[hcm]df/loginform[/hcm]
	
== Odinstalace ==
	odstrante nasledujici soubor ze serveru:
		plugins/hcm/df/loginform.php

== Changelog ==
Verze 1.1
[update] plugin upraven pro SL 7.5.4