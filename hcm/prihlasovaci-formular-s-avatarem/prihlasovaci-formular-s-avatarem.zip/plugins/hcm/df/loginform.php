﻿<?php

if(!defined('_core')) {
exit;
}

function _HCM_df_loginform(){

$result="";
if (_loginindicator==0){
$result.="<form action='./remote/login.php' name='login_form' method='post'>
<table id='logintable'>
<tr><td align='right'>Jméno&nbsp;</td><td><input type='text' maxlength='24' name='username' /></td></tr>
<tr><td align='right'>Heslo&nbsp;</td><td><input name='password' type='password' /></td></tr>
<tr><td>&nbsp;</td><td><input value='Přihlásit se' type='submit' /> <a href='index.php?m=reg'>nový účet</a> • <a href='index.php?m=lostpass'>reset hesla</a></td></tr>
</table>
<input type='hidden' name='form_url' value='index.php?m=login' />"._xsrfProtect()."</form>";
}
else{


$sql = DB::query_row("SELECT avatar FROM `" . _mysql_prefix . "-users`  WHERE id='"._loginid."'");
$avatar_path=_indexroot."pictures/avatars/".$sql['avatar'].".jpg"; 
if(!@file_exists($avatar_path)){
$img="<img src='"._indexroot."pictures/avatars/no-avatar.jpg' alt='Avatar' />";
} else {
$img="<img src='".$avatar_path. "' alt='Avatar' />";}

$result.="<div id='avatar-div'>".$img."</div><div id='ul-menu'>"._templateUserMenu (true)."</div>";
} 

return $result;
}
