﻿<?php if(!defined('_core')){exit;}?>
<!DOCTYPE html>
<html>
<head>
<?php _templateHead(); ?>
</head>

<body>
  
<!-- wrap starts here -->
<div id="wrap">

	<div id="header"><div id="header-content">	
		
		<h1 id="logo"><a href="./"><?php echo _title; ?></a></h1>	
		<h2 id="slogan"><?php echo _description; ?></h2>		
		
		<!-- Menu Tabs -->
    <div id="menu"><?php echo _templateMenu(0,4); ?></div>		
			
	</div></div>
	
	<div class="headerphoto">
    <div id="frmsear"><?php echo _parseHCM("[hcm]search[/hcm]"); ?></div>
  </div>
				
	<div id="content-wrap"><div id="content">		
		
		<div id="sidebar" >
			<div class="sidebox"><?php _templateBoxes(); ?></div>
    </div>

		<div id="main">		
		  <div class="post"><?php _templateContent(); ?></div>	
    </div>

    <div class="cleaner"></div>
		
	</div></div>

<!-- footer starts here -->	
<div id="footer"><div id="footer-content">

  <div id="links"><?php _templateLinks(); ?> | Design © <a href="http://wall.cz" title="wall.cz">wall.cz</a> &amp; konverze <a href="http://www.designflow.cz" title="DesignFLOW">DesignFlow.cz</a> &amp; <a href="http://www.smetka.net" title="Smetka.net">smetka.net</a> &amp; <a href="http://www.bluewebtemplates.com/" title="Website Templates">website templates</a> by <a href="http://www.styleshout.com/">styleshout</a> </div>	
	
</div></div
<!-- footer ends here -->
	
<!-- wrap ends here -->
</div>

</body>
</html>
